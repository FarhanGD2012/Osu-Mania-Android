# Server Versus untuk Osu! Mania

Server kecil (Node.js + WebSocket, tanpa database) untuk mode **Versus online**: room dengan kode, siap, mulai bersama,
skor langsung, hasil akhir. Aplikasi hanya perlu alamatnya (Pengaturan > Akun & Versus > Alamat server Versus).

Server TIDAK ikut berjalan sendiri: kamu (atau temanmu) harus menjalankannya sekali. Pilih salah satu.

## A. Gratis di internet (bisa dimainkan dari mana saja)
Contoh dengan Render.com (layanan lain yang mendukung Node + WebSocket juga bisa: Railway, Koyeb, Fly.io, Glitch):
1. Buat repo GitHub baru berisi isi folder ini (`server.js`, `package.json`).
2. Di render.com: **New > Web Service** > pilih repo itu. Runtime **Node**, Build Command `npm install`, Start Command `npm start`. Pilih paket Free.
3. Setelah jalan, salin alamatnya (mis. `https://nama-server.onrender.com`) dan isi di aplikasi sebagai `wss://nama-server.onrender.com`
   (menulis `https://...` juga boleh, otomatis diganti jadi `wss://`).
4. Paket gratis "tidur" kalau lama tidak dipakai: koneksi pertama bisa butuh ~30 detik. Tekan **Coba lagi** di layar Versus.

## B. Satu Wi-Fi (tanpa internet), pakai Termux di HP salah satu pemain
```
pkg install nodejs
cd versus-server && npm install && npm start
```
Lihat IP HP itu (`ifconfig`), lalu semua pemain mengisi `192.168.x.x:8080` di aplikasi (otomatis `ws://`).

## C. Di PC / VPS
`npm install && npm start` (port dari variabel `PORT`, bawaan 8080). Pasang di belakang HTTPS (Nginx / Caddy) agar bisa `wss://`.

## Uji
`npm test` (server harus sudah jalan) menjalankan dua pemain tiruan: buat room, gabung, siap, mulai, skor langsung, hasil.

## Catatan
- Opsi env: `PORT`, `MAX_PLAYERS` (bawaan 8), `ALLOW_SOLO=1` (boleh mulai sendirian, untuk uji coba).
- Server tidak menyimpan apa pun dan tidak memeriksa skor (percaya klien); cocok untuk main bareng teman, bukan kompetisi resmi.
- Semua pemain harus punya chart yang sama: host memilih chart hasil unduhan (punya ID set osu!), pemain lain tinggal menekan **Unduh chart** di lobi.
