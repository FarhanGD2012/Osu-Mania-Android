// Uji alur Versus: dua pemain tiruan. Jalankan server dulu (ALLOW_SOLO tidak perlu), lalu: node test.js [ws://localhost:8080]
'use strict';
const WebSocket = require('ws');
const URL = process.argv[2] || 'ws://localhost:8080';
const assert = require('assert');

function client(name) {
  const ws = new WebSocket(URL);
  const c = { ws, name, msgs: [], room: null, id: null, wait: [] };
  ws.on('message', (d) => {
    const m = JSON.parse(d.toString());
    c.msgs.push(m);
    if (m.t === 'hello') c.id = m.id;
    if (m.t === 'room') c.room = m;
    c.wait = c.wait.filter(w => { if (w.f(m)) { w.r(m); return false; } return true; });
  });
  c.send = (o) => ws.send(JSON.stringify(o));
  c.next = (f, ms = 3000) => new Promise((res, rej) => {
    const hit = c.msgs.find(f); if (hit) return res(hit);
    const t = setTimeout(() => rej(new Error(name + ' timeout menunggu pesan')), ms);
    c.wait.push({ f, r: (m) => { clearTimeout(t); res(m); } });
  });
  return new Promise(res => ws.on('open', () => { c.send({ t: 'hello', name }); c.next(m => m.t === 'hello').then(() => res(c)); }));
}

(async () => {
  const a = await client('Andi'), b = await client('Budi');
  a.send({ t: 'ping', c: 123 });
  const pong = await a.next(m => m.t === 'pong'); assert.strictEqual(pong.c, 123);

  a.send({ t: 'create' });
  const r1 = await a.next(m => m.t === 'room');
  assert.strictEqual(r1.code.length, 4); assert.strictEqual(r1.host, a.id);

  b.send({ t: 'join', code: r1.code.toLowerCase() });
  await b.next(m => m.t === 'room' && m.players.length === 2);
  console.log('gabung ok, kode', r1.code);

  a.send({ t: 'start' });
  const e1 = await a.next(m => m.t === 'error'); assert(/chart/i.test(e1.msg));

  a.send({ t: 'chart', setId: 1234, title: 'T', artist: 'A', creator: 'C', version: '[Hard]', keys: 4, notes: 500 });
  await b.next(m => m.t === 'room' && m.chart && m.chart.setId === 1234);

  a.msgs.length = 0;
  a.send({ t: 'start' });
  const e2 = await a.next(m => m.t === 'error'); assert(/belum siap/.test(e2.msg));

  b.send({ t: 'ready', ready: true });
  await a.next(m => m.t === 'room' && m.players.find(p => p.id === b.id).ready);
  a.send({ t: 'start' });
  const st = await b.next(m => m.t === 'start'); assert(st.at > Date.now());
  console.log('mulai ok, jeda', st.at - Date.now(), 'ms');

  a.send({ t: 'score', score: 1000, acc: 99.5, combo: 10, hp: 1, prog: 0.1 });
  b.send({ t: 'score', score: 5000, acc: 97, combo: 30, hp: 0.9, prog: 0.1 });
  const sc = await a.next(m => m.t === 'scores' && m.p.length === 2);
  assert(sc.p.find(x => x[0] === b.id)[1] === 5000);
  console.log('skor langsung ok');

  a.send({ t: 'finish', score: 900000, acc: 98.1, maxCombo: 400, failed: false, counts: [1, 2, 3, 4, 5, 6] });
  b.send({ t: 'finish', score: 950000, acc: 99.1, maxCombo: 500, failed: false, counts: [1, 2, 3, 4, 5, 6] });
  const res = await a.next(m => m.t === 'results');
  assert.strictEqual(res.ranking[0].name, 'Budi'); assert.strictEqual(res.ranking.length, 2);
  console.log('hasil ok:', res.ranking.map(r => r.name + ' ' + r.score).join(' > '));

  // keluar di tengah main -> dianggap gagal
  a.msgs.length = 0; b.msgs.length = 0;
  b.send({ t: 'ready', ready: true });
  await a.next(m => m.t === 'room' && m.state === 'lobby' && m.players.find(p => p.id === b.id).ready);
  a.send({ t: 'start' });
  await b.next(m => m.t === 'start');
  b.send({ t: 'leave' });
  a.send({ t: 'finish', score: 1, acc: 1, maxCombo: 1, failed: false });
  const res2 = await a.next(m => m.t === 'results');
  assert(res2.ranking.find(r => r.name === 'Budi').failed);
  console.log('keluar di tengah main ok');
  console.log('SEMUA UJI LULUS');
  process.exit(0);
})().catch(e => { console.error('GAGAL:', e.message); process.exit(1); });
