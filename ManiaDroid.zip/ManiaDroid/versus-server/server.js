// Server Versus untuk Osu! Mania (ManiaDroid). WebSocket + JSON, tanpa database (semua di memori).
// Jalankan: npm install && npm start     (port dari env PORT, bawaan 8080)
'use strict';
const http = require('http');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8080;
const MAX_PLAYERS = parseInt(process.env.MAX_PLAYERS || '8', 10);
const ALLOW_SOLO = process.env.ALLOW_SOLO === '1'; // 1 = boleh mulai sendirian (untuk uji coba)
const START_DELAY_MS = 6000;                        // jeda dari "Mulai" sampai detik 0 lagu (semua pemain disamakan)

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' });
  res.end('ManiaDroid Versus server OK\nRoom aktif: ' + rooms.size + '\n');
});
const wss = new WebSocketServer({ server, maxPayload: 64 * 1024 });

const rooms = new Map(); // kode -> room
let nextId = 1;

const clean = (s, n) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, n);
const num = (v, lo, hi, d) => { v = Number(v); return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d; };

function send(ws, obj) {
  if (ws.readyState === 1) ws.send(JSON.stringify(obj));
}
function genCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; // tanpa I / O supaya tidak membingungkan
  for (let k = 0; k < 200; k++) {
    let c = '';
    for (let i = 0; i < 4; i++) c += A[Math.floor(Math.random() * A.length)];
    if (!rooms.has(c)) return c;
  }
  return null;
}
function pub(p) {
  return { id: p.id, name: p.name, avatar: p.avatar, ready: p.ready, state: p.state, score: p.score, acc: p.acc, combo: p.combo, hp: p.hp, prog: p.prog };
}
function roomInfo(r) {
  return { t: 'room', code: r.code, host: r.hostId, state: r.state, chart: r.chart, players: [...r.players.values()].map(pub) };
}
function broadcast(r, obj) {
  const s = JSON.stringify(obj);
  for (const p of r.players.values()) if (p.ws.readyState === 1) p.ws.send(s);
}

function leaveRoom(p) {
  const r = p.room;
  if (!r) return;
  p.room = null;
  if (r.state === 'playing' && p.state === 'playing') {
    p.state = 'finished';
    p.result = { id: p.id, name: p.name, score: p.score, acc: p.acc, maxCombo: p.combo, failed: true, left: true };
    r.results.set(p.id, p.result);
  }
  r.players.delete(p.id);
  p.ready = false;
  p.state = 'lobby';
  if (r.players.size === 0) { rooms.delete(r.code); return; }
  if (r.hostId === p.id) r.hostId = r.players.keys().next().value;
  broadcast(r, roomInfo(r));
  checkFinished(r);
}

function checkFinished(r) {
  if (r.state !== 'playing') return;
  for (const q of r.players.values()) if (q.state !== 'finished') return;
  const list = [...r.results.values()];
  list.sort((a, b) => (a.failed - b.failed) || (b.score - a.score));
  r.state = 'lobby';
  for (const q of r.players.values()) { q.ready = false; q.state = 'lobby'; }
  broadcast(r, { t: 'results', ranking: list });
  broadcast(r, roomInfo(r));
}

const handlers = {
  hello(p, m) {
    p.name = clean(m.name, 24) || ('Pemain' + p.id);
    p.avatar = clean(m.avatar, 200);
    p.hello = true;
    send(p.ws, { t: 'hello', id: p.id, serverNow: Date.now() });
  },
  ping(p, m) { send(p.ws, { t: 'pong', c: m.c, s: Date.now() }); },
  create(p) {
    leaveRoom(p);
    const code = genCode();
    if (!code) return send(p.ws, { t: 'error', msg: 'Server penuh, coba lagi nanti' });
    const r = { code, hostId: p.id, players: new Map(), chart: null, state: 'lobby', results: new Map(), dirty: false };
    rooms.set(code, r);
    r.players.set(p.id, p);
    p.room = r; p.ready = false; p.state = 'lobby';
    send(p.ws, roomInfo(r));
  },
  join(p, m) {
    const code = clean(m.code, 8).toUpperCase();
    const r = rooms.get(code);
    if (!r) return send(p.ws, { t: 'error', msg: 'Room ' + code + ' tidak ditemukan' });
    if (r.state === 'playing') return send(p.ws, { t: 'error', msg: 'Pertandingan sedang berjalan, tunggu selesai' });
    if (r.players.size >= MAX_PLAYERS) return send(p.ws, { t: 'error', msg: 'Room penuh' });
    if (p.room === r) return send(p.ws, roomInfo(r));
    leaveRoom(p);
    r.players.set(p.id, p);
    p.room = r; p.ready = false; p.state = 'lobby'; p.score = 0; p.acc = 100; p.combo = 0; p.hp = 1; p.prog = 0;
    broadcast(r, roomInfo(r));
  },
  leave(p) { leaveRoom(p); send(p.ws, { t: 'left' }); },
  chart(p, m) {
    const r = p.room;
    if (!r || r.hostId !== p.id || r.state !== 'lobby') return;
    r.chart = {
      setId: num(m.setId, 0, 1e9, 0),
      title: clean(m.title, 120), artist: clean(m.artist, 120), creator: clean(m.creator, 60),
      version: clean(m.version, 120), keys: num(m.keys, 1, 10, 4), notes: num(m.notes, 0, 1e6, 0),
    };
    for (const q of r.players.values()) q.ready = false;
    broadcast(r, roomInfo(r));
  },
  ready(p, m) {
    const r = p.room;
    if (!r || r.state !== 'lobby') return;
    p.ready = !!m.ready;
    broadcast(r, roomInfo(r));
  },
  start(p) {
    const r = p.room;
    if (!r || r.hostId !== p.id || r.state !== 'lobby') return;
    if (!r.chart || !r.chart.setId) return send(p.ws, { t: 'error', msg: 'Pilih chart dulu' });
    if (r.players.size < 2 && !ALLOW_SOLO) return send(p.ws, { t: 'error', msg: 'Butuh minimal 2 pemain' });
    for (const q of r.players.values()) {
      if (q.id !== r.hostId && !q.ready) return send(p.ws, { t: 'error', msg: q.name + ' belum siap' });
    }
    r.state = 'playing';
    r.results = new Map();
    for (const q of r.players.values()) { q.state = 'playing'; q.score = 0; q.acc = 100; q.combo = 0; q.hp = 1; q.prog = 0; q.result = null; }
    const at = Date.now() + START_DELAY_MS;
    broadcast(r, { t: 'start', at, serverNow: Date.now() });
    broadcast(r, roomInfo(r));
  },
  score(p, m) {
    const r = p.room;
    if (!r || r.state !== 'playing' || p.state !== 'playing') return;
    p.score = num(m.score, 0, 2e6, p.score);
    p.acc = num(m.acc, 0, 100, p.acc);
    p.combo = num(m.combo, 0, 1e6, p.combo);
    p.hp = num(m.hp, 0, 1, p.hp);
    p.prog = num(m.prog, 0, 1, p.prog);
    r.dirty = true;
  },
  finish(p, m) {
    const r = p.room;
    if (!r || r.state !== 'playing' || p.state !== 'playing') return;
    p.state = 'finished';
    p.score = num(m.score, 0, 2e6, p.score);
    p.acc = num(m.acc, 0, 100, p.acc);
    const res = {
      id: p.id, name: p.name, score: p.score, acc: p.acc,
      maxCombo: num(m.maxCombo, 0, 1e6, 0), failed: !!m.failed,
      counts: Array.isArray(m.counts) ? m.counts.slice(0, 6).map(v => num(v, 0, 1e6, 0)) : [],
    };
    p.result = res;
    r.results.set(p.id, res);
    r.dirty = true;
    checkFinished(r);
  },
};

wss.on('connection', (ws) => {
  const p = { id: String(nextId++), ws, name: '', avatar: '', hello: false, room: null, ready: false, state: 'lobby',
    score: 0, acc: 100, combo: 0, hp: 1, prog: 0, result: null, alive: true, bucket: 60, last: Date.now() };
  ws.on('pong', () => { p.alive = true; });
  ws.on('message', (data) => {
    // batasi laju pesan (anti banjir): ~60 pesan/detik rata-rata
    const now = Date.now();
    p.bucket = Math.min(60, p.bucket + (now - p.last) * 0.06);
    p.last = now;
    if (--p.bucket < 0) return;
    let m;
    try { m = JSON.parse(data.toString()); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    const h = handlers[m.t];
    if (!h || (!p.hello && m.t !== 'hello' && m.t !== 'ping')) return;
    try { h(p, m); } catch (e) { console.error('handler error', m.t, e); }
  });
  ws.on('close', () => { leaveRoom(p); });
  ws.on('error', () => {});
});

// siaran skor langsung ~4x per detik, hanya untuk room yang sedang main dan ada perubahan
setInterval(() => {
  for (const r of rooms.values()) {
    if (r.state !== 'playing' || !r.dirty) continue;
    r.dirty = false;
    broadcast(r, { t: 'scores', p: [...r.players.values()].map(q => [q.id, q.score, q.acc, q.combo, q.hp, q.prog, q.state === 'finished' ? 1 : 0]) });
  }
}, 250);

// buang koneksi mati
setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive = false;
    ws.ping();
  }
}, 30000);
wss.on('connection', (ws) => { ws.isAlive = true; ws.on('pong', () => { ws.isAlive = true; }); });

server.listen(PORT, () => console.log('Versus server berjalan di port ' + PORT));
