# ManiaDroid 1.1

Game ritme ala osu!mania (4K–10K) untuk Android. Offline; internet hanya dipakai di layar **Unduh chart**.

## Build APK (tanpa Android Studio)
1. Upload `ManiaDroid.zip` ke repo GitHub (nama sama = menimpa versi lama) dan buat `.github/workflows/build.yml`.
2. Tab **Actions** -> tunggu hijau -> unduh artifact **ManiaDroid-debug-apk** -> install `app-debug.apk`.
3. Proyek ini memakai keystore tetap (`app/debug.keystore`), jadi update berikutnya bisa menimpa tanpa uninstall.
   (Khusus pindah dari versi 1.0 ke 1.1: uninstall sekali karena tanda tangannya beda.)

## Fitur
- Default landscape (bisa diganti: portrait / otomatis). Note bulat atau persegi panjang (Pengaturan).
- Impor .osz, unduh chart dengan 5 mirror + fallback otomatis, unduh via ID.
- Video background diputar tanpa suara; fallback ke gambar BG (atau frame video) jika format tidak didukung.
