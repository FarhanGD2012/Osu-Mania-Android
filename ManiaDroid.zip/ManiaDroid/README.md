# ManiaDroid

Game ritme ala osu!mania (4K–10K) untuk Android. Offline; internet hanya dipakai di layar **Unduh**.

## Build APK (tanpa Android Studio)
1. Buat repo GitHub, upload seluruh isi folder ini.
2. Buka tab **Actions** → workflow **Build APK** (jalan otomatis tiap push).
3. Setelah hijau, unduh artifact **ManiaDroid-debug-apk**, ekstrak, lalu install `app-debug.apk`.

## Cara pakai
- **Impor .osz**: pilih satu/beberapa file chart dari penyimpanan.
- **Unduh**: cari judul/artis/mapper, atau ketik ID beatmapset lalu Cari. Mirror bisa diganti di Pengaturan.
- Tekan lama chart di daftar untuk menghapusnya.
- Video background: diputar tanpa suara di belakang gameplay. Jika chart tidak punya gambar BG, diambil satu frame dari videonya.
  Jika format videonya tidak didukung Android (mis. AVI/FLV lama), gambar BG tetap tampil.
