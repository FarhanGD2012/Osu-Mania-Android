# OSU DROID 2.1 (proyek penggemar, bukan produk resmi osu!)

Game ritme ala osu!mania (1K–10K) untuk Android. Bermain solo 100% offline; internet hanya untuk **Unduh chart** dan **Multiplayer lewat internet** (Multiplayer lewat Wi-Fi / hotspot tidak butuh internet).

## Build APK (tanpa Android Studio)
1. Upload `ManiaDroid.zip` ke repo GitHub (nama sama = menimpa) dan buat `.github/workflows/build.yml`.
2. Tab **Actions** -> tunggu hijau -> unduh artifact **ManiaDroid-debug-apk** -> install `app-debug.apk`.
3. Keystore tetap (`app/debug.keystore`): update berikutnya bisa menimpa tanpa uninstall.

## Baru di 2.1
- **Nama & gambar game: OSU DROID** (ikon, logo menu, nama aplikasi).
- **Musik menu ikut ke semua layar** (Pengaturan, Unduh, Pilih lagu, Profil, Multiplayer) kecuali Sinkron / Editor / saat main. Mini-player (sebelumnya / jeda / berikutnya + garis kemajuan) tampil di **atas** layar-layar itu; di menu utama tetap di bawah.
- **BOT**: tulisan tetap "BOT", **hijau = nyala, merah = mati**.
- **Slide**: geser jari ke kolom lain saat main = note di kolom itu ikut tertekan (kolom yang dilewati juga).
- **Profil lokal**: nama, kata sandi, foto, bio, statistik; tanpa Google. Pindah HP lewat Ekspor / Impor akun.
- **Favorit**: ikon hati di kartu chart, tombol filter Favorit (tanpa internet).
- **Info chart lengkap**: ketuk kartu chart (belum diunduh pun). **Preview penuh** dengan bar merah ala YouTube (lagu penuh diambil sebagian lewat HTTP Range; jika gagal: mode tanpa suara yang tetap bisa digeser).

## Baru di 2.0
**Multiplayer tanpa akun (ditulis ulang)**
- **Akun / login osu! dihapus.** Tidak ada lagi Client ID / Secret. Hanya ada nama pemain (Pengaturan > Multiplayer, atau ketuk chip kiri atas menu utama).
- **Penyebab crash lama** ("Osu! Mania telah berhenti" saat Versus): callback ronde di layar Versus bernama `onStart()` dan bentrok dengan `onStart()` bawaan Android. Sudah diganti `onRoundStart()` dan seluruh Versus ditulis ulang.
- **Tanpa server buatan sendiri.** HP host menjadi server room (`MpHub`). Dua jalur:
  - **Wi-Fi / hotspot (tanpa internet):** host buat room lalu menyalakan hotspot; pemain lain sambung ke hotspot itu. Room muncul otomatis di daftar (siaran UDP port 47771), atau pakai **Gabung host hotspot (otomatis)** / **Gabung lewat IP**. Data lewat TCP port 47770. Chart yang belum dimiliki diambil langsung dari HP pemilihnya lewat Wi-Fi (port 47772), tanpa internet.
  - **Internet:** relay MQTT lewat broker publik gratis (hivemq / emqx / mosquitto; tanpa pendaftaran). Room punya kode 6 karakter (contoh `A7K2QM`) dan bisa tampil di daftar room internet. Chart diambil dari mirror bila punya ID osu!.
- **Pemain tanpa batas** (batas opsional di pengaturan room). Diuji 150 pemain sekaligus.
- **Pengaturan room seperti osu!lazer:** nama, password, **tipe match** (Head-to-head / Team versus merah-biru), **antrean chart** (host saja / semua pemain / semua pemain bergiliran), **kondisi menang** (skor / akurasi / combo tertinggi), **mulai otomatis** (hitung mundur), batas pemain, tampil di daftar publik. Keluarkan pemain (host). Hasil akhir menampilkan peringkat + total tim.
- Hanya pemain yang memakai ManiaDroid yang bisa masuk.

**BOT dan Replay**
- **BOT** (ala Autoplay): tombol **BOT** di pilih lagu, atau **BOT** di menu jeda. Map jalan sendiri, semua MAX. Skornya tidak dicatat sebagai rekor.
- **Replay**: setelah selesai main (tanpa jeda), layar hasil punya tombol **Replay** yang memutar ulang sentuhanmu lewat mesin penilaian yang sama. Replay hanya disimpan untuk permainan terakhir (di memori).

**Skin osu!lazer**
- Skin note bawaan sekarang **osu!lazer (Argon)**: kotak membulat bergradasi, garis putih di tepi hit, tanda panah, target hit, kolom menyala saat ditekan, badan hold gelap yang menyala saat ditahan, warna per mode key persis skin Argon.
- **Trail note (badan hold) kustom:** Pengaturan > Note > Atur warna & gambar note: tiap kolom punya warna trail sendiri dan bisa dipasangi gambar (diulang memanjang mengikuti panjang hold, ikut bergerak bersama note). Terpisah untuk tiap mode key.
- Warna kustom, gambar kustom per kolom, dan bentuk lama (bulat / persegi panjang) tetap ada di Pengaturan > Note. Pemain lama dipindah sekali ke Argon.

**Pengaturan baru** (yang sudah ada tidak diubah): volume utama, hitungan tombol (key counter), jeda otomatis saat game ditinggalkan, cuplikan lagu saat memilih chart, kolom menyala saat ditekan, blur background (Android 12+), siap otomatis, bersihkan cache.

**Anti-lag**: prioritas thread utama dinaikkan saat bermain, "sustained performance" dinyalakan bila didukung, sinkron video diperlonggar (tidak ada seek berantai), siaran status room digabung.

## Baru di 1.9
**Layar main**
- Chart tanpa video: latar **hitam polos** (`Backdrop.NO_VIDEO_BG`). Ikon aplikasi juga berlatar hitam.
- Garis pemisah antar bulatan dihapus; tinggal dua garis luar (kiri & kanan).
- **Hitbox bulatan paling kiri / kanan**: penyebab utamanya gestur "Back" tepi layar Android 10+ yang menelan sentuhan di tepi (kena di mode 9K–10K / kolom lebar). Sekarang area di sekitar garis hit dikecualikan dari gestur sistem (Pengaturan > Kontrol > "Kunci gestur tepi layar"), dan sentuhan di luar lajur tetap dihitung ke kolom terluar.
- **Optimasi saat banyak note**: tidak ada `String.format` di jalur panas, posisi lagu dibaca ~25x/detik dengan penghalusan (scroll tidak "loncat"), efek tombol menu dimatikan saat bermain, refresh rate layar tertinggi diminta otomatis (90/120 Hz).
- Pengaturan baru: ukuran HUD, tampil/sembunyi persen-HP / skor-akurasi / combo / tulisan hit, **bar kesalahan timing**, **efek cincin saat note kena**, tombol jeda bisa dimatikan, tampilkan FPS, refresh rate tinggi.
- Info judul di awal lagu pindah ke tengah atas (tidak menimpa bulatan).

**Unduh chart**
- Tombol **Preview** di tiap kartu: membuka layar pratinjau berisi cuplikan lagu, daftar diff (SR, jumlah note, BPM, durasi, OD, HP) dan **pratinjau note jatuh** dari diff yang dipilih (file .osu satu diff diambil sekilas, tanpa mengunduh seluruh set).
- Filter baru: **Urutkan** (relevansi / paling banyak dimainkan / paling banyak di-like / terbaru / rating) dan **Periode** (hari ini / minggu ini / bulan ini / tahun ini / semua waktu). Periode = set yang di-ranked atau diperbarui dalam rentang itu, lalu diurutkan menurut pilihan.
- **Unduhan lebih cepat tanpa mengurangi kualitas**: file dipecah jadi beberapa koneksi paralel (Pengaturan > Unduhan, bawaan 4) lalu disambung; isi file sama persis (video tetap ada). Terputus di tengah = lanjut dari titik putus, bukan mulai ulang. Mirror yang terakhir berhasil dicoba paling awal.

**Akun osu! & Versus online (versi 1.9, digantikan Multiplayer di 2.0, lihat atas)**

**Menu**
- Pilih lagu: latar sampul chart terpilih, urutkan (judul / artis / mapper / terbaru / jumlah note) dan filter key.
- Menu utama: tombol Versus + chip profil osu!. Pengaturan: bagian "Akun & Versus", pengaturan baru di tiap bagian.

## Sebelumnya di 1.8
- **Gambar osu! kamu dipakai sebagai ikon aplikasi dan logo di game** (logo menu yang berdenyut + intro). Gambar ada di `res/drawable-nodpi/osu_logo.png`; ikon di `res/mipmap-*`.
- **Menu jeda baru ala osu!lazer**: pita lebar di tengah, judul lagu, persen lagu + HP, empat tombol jajar genjang berwarna (Lanjut / Ulangi / Setelan / Keluar).
- **Setelan di menu jeda langsung membuka pengaturan lengkap** (layar besar), bukan panel kecil. Kembali dari sana, menu jeda masih ada.
- **Menu lebih lazer**: tombol bergradasi tipis, dialog panel bergradasi, layar hasil memakai tombol jajar genjang, tampilan kosong di Pilih lagu punya tombol pintas Unduh chart.
- **3 level bawaan dihapus** (Neon Circles, Pink Horizon, Soft Landing). Salinan yang sudah terpasang di HP dihapus otomatis sekali saja; chart impor/unduhan kamu aman.
- **Chart tanpa video**: (di 1.8 abu-abu; sejak 1.9 kembali hitam).
- **Layar main**: garis/bar di paling atas dihapus; persen lagu, HP, dan akurasi dibesarkan.

## Sebelumnya di 1.7
- **Nama aplikasi "Osu! Mania"** dan **ikon logo osu! biasa** (pink, cincin putih, tulisan "osu!").
- **Ikon sama di mana-mana**: ikon adaptif (XML) dihapus dan diganti PNG polos di semua ukuran, jadi layar pemasangan / pemindaian keamanan, layar utama, dan layar terbaru memakai gambar yang sama (sebelumnya pemasang HP tidak bisa membaca ikon adaptif lalu menampilkan ikon "play" bawaan).
- (Lagu bawaan 1.7 sudah dihapus di 1.8.)
- **Suara tombol**: semua tombol (menu, pilih lagu, unduh, pengaturan, dialog, menu jeda) berbunyi saat diketuk. Ada suara berbeda untuk tombol kembali dan untuk logo. Atur di Pengaturan > Audio (nyala/mati + volume).
- **Efek tekan**: tombol sedikit mengecil saat ditekan lalu memantul kembali.
- **Logo tengah lebih besar** dan denyutnya sedikit lebih kuat; tulisan logo jadi "osu!". Petunjuk "Ketuk logo untuk mulai" pindah ke atas supaya tidak menimpa logo.
- **Menu utama**: tombol keluar dari balik logo satu per satu, garis tipis di tepi pita tombol.
- **Transisi antar layar** memudar halus (tetap landscape).

## Sebelumnya di 1.6
- **Fullscreen** di semua layar (tombol navigasi HP disembunyikan; geser dari tepi untuk memunculkan sementara).
- **Tombol kembali** ala osu!lazer di pojok kiri atas (Pilih lagu, Unduh chart, Gaya note).
- **Note minimalis** (warna rata + garis tepi tipis). **Pengaturan > Note > Atur warna & gambar note**: warna dan gambar kustom per kolom, terpisah untuk tiap mode key, dengan pratinjau langsung.
- Efek putih saat menekan kini hanya di dalam bulatan note kosong (tidak lagi satu kolom penuh).
- **Unduh chart** didesain ulang ala osu!lazer: kartu dua kolom dengan sampul, status (Ranked/Loved), tombol unduh dengan persen berdesimal (mis. 07.35%) dan garis kemajuan, tombol dengar cuplikan lagu, muat otomatis saat menggulir, pesan galat yang ramah.
- **Bahasa Indonesia / English** (Pengaturan > Bahasa). Tulisan saat main ikut berganti (Meleset / Terlalu cepat / Terlambat atau Miss / Early / Late).
- Lanjut dari jeda: musik mundur beberapa detik, note yang sudah kena tetap hilang, plus hitung mundur 3-2-1 (atur di Pengaturan > Gameplay).
- Persen progres berdesimal (00.00%) di game (lagu + HP), di bar lagu menu, dan di unduhan.
- Ketuk saat intro **mempercepat** intro (x3, lalu makin cepat), bukan melewatinya.
- Perbaikan: warna tombol menu yang jadi hitam setelah diklik; tombol Enter/cari di keyboard pada pencarian (keyboard tidak lagi memenuhi layar); ikon aplikasi disamakan di semua tempat (termasuk layar terbaru/saran).

## Sebelumnya di 1.5
- Pengaturan ala osu!lazer: sidebar bagian di kiri, daftar bisa digulir, saklar dan slider bergaya lazer, pilihan lewat daftar; tanpa emoji. Latar menu terlihat langsung di belakangnya.
- Latar menu bawaan ala osu!lazer (gradasi + segitiga melayang yang ikut berdenyut mengikuti lagu). Bisa diganti di Pengaturan > Latar menu: bawaan / hitam polos / gambar sendiri, plus warna tema dan matikan gerakan segitiga.
- Menu utama ala osu!lazer: ketuk logo -> logo mengecil dan jalur tombol berwarna muncul (Setelan, Sinkron, Impor | logo | Main, Editor, Unduh, Keluar).
- Efek putih saat disentuh hanya muncul di dalam bentuk tombol / bulatan logo, tidak lagi meluber jadi kotak.
- Bar lagu menu dibuat kecil dan minimalis, dengan garis kemajuan lagu.
- Layar hasil baru: peringkat besar, skor menghitung naik, akurasi, combo, rincian MAX/300/200/100/50/Miss, tanda skor terbaik baru.
- Info chart di pilih lagu dikecilkan dan dirapikan.
- Semua emoji / simbol gambar di seluruh layar diganti teks.

## Sebelumnya di 1.4
- Intro ala osu!lazer saat game dibuka (bisa dimatikan di Pengaturan > Tampilan); ketuk layar untuk melewati.
- Logo osu berdenyut mengikuti lagu menu (lagu dianalisis di HP, tanpa izin tambahan; hasilnya disimpan di cache).
- Note bulat bertekstur hitcircle ala osu! (cincin putih, gradasi warna, kilap).
- Tombol jeda pindah ke kanan; menu jeda baru (Lanjut / Ulangi / Setelan / Keluar) dengan panel pengaturan cepat.
- Perbaikan lag saat menekan banyak jari sekaligus (input tanpa batching, hitsound di thread terpisah, HUD tanpa alokasi per frame).

## Fitur
- Menu ala osu!lazer, latar segitiga (bisa hitam polos / gambar sendiri); musik menu (lagu tambahan sendiri + lagu chart) dengan popup ganti lagu.
- Pengaturan: latar menu & gambar background sendiri, suara klik sendiri, musik menu, offset, tampilan, tombol controller.
- Chart tanpa video tampil hitam (opsi di Pengaturan untuk menampilkan gambar BG chart).
- Pencarian chart: filter artis, kesulitan (Easy..Expert), jumlah key, status.
- Editor: tap, hold (tahan lama + geser, atau mode Hold), hapus, snap, uji main, atur BPM/offset, background & video.
- Sinkron otomatis; controller/keyboard dengan tombol per kolom yang bisa dipilih.
