# Osu Mania 1.2 (proyek penggemar, bukan produk resmi osu!)

Game ritme ala osu!mania (1K–10K) untuk Android. Offline; internet hanya dipakai di layar **Unduh chart**.

## Build APK (tanpa Android Studio)
1. Upload `ManiaDroid.zip` ke repo GitHub (nama sama = menimpa) dan buat `.github/workflows/build.yml`.
2. Tab **Actions** -> tunggu hijau -> unduh artifact **ManiaDroid-debug-apk** -> install `app-debug.apk`.
3. Keystore tetap (`app/debug.keystore`): update berikutnya bisa menimpa tanpa uninstall.

## Fitur
- Menu ala osu!lazer (logo -> menu), pilih lagu dengan panel info (BPM, durasi, note, OD, HP, kepadatan).
- Controller/keyboard: semua tombol (A/B/X/Y, L1/L2/R1/R2, D-Pad, L3/R3, trigger analog). Atur di Pengaturan -> Atur tombol.
- Sinkron: ketuk note, tampil selisih ms, offset diperbarui otomatis (sentuhan & controller terpisah).
- Editor chart: edit chart yang ada atau buat dari file audio; snap grid, tap/hold/hapus, uji main, simpan.
- Impor .osz, unduh via 5 mirror dengan fallback, video background (fallback gambar BG).
