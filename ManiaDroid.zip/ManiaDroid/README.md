# Osu Mania 1.4 (proyek penggemar, bukan produk resmi osu!)

Game ritme ala osu!mania (1K–10K) untuk Android. Offline; internet hanya dipakai di layar **Unduh chart**.

## Build APK (tanpa Android Studio)
1. Upload `ManiaDroid.zip` ke repo GitHub (nama sama = menimpa) dan buat `.github/workflows/build.yml`.
2. Tab **Actions** -> tunggu hijau -> unduh artifact **ManiaDroid-debug-apk** -> install `app-debug.apk`.
3. Keystore tetap (`app/debug.keystore`): update berikutnya bisa menimpa tanpa uninstall.

## Baru di 1.4
- Intro ala osu!lazer saat game dibuka (bisa dimatikan di Pengaturan > Tampilan); ketuk layar untuk melewati.
- Logo osu berdenyut mengikuti lagu menu (lagu dianalisis di HP, tanpa izin tambahan; hasilnya disimpan di cache).
- Note bulat bertekstur hitcircle ala osu! (cincin putih, gradasi warna, kilap).
- Tombol jeda pindah ke kanan; menu jeda baru (Lanjut / Ulangi / Setelan / Keluar) dengan panel pengaturan cepat.
- Perbaikan lag saat menekan banyak jari sekaligus (input tanpa batching, hitsound di thread terpisah, HUD tanpa alokasi per frame).

## Fitur
- Menu ala osu!lazer, latar hitam polos; musik menu (lagu tambahan sendiri + lagu chart) dengan popup ganti lagu.
- Pengaturan: gambar background sendiri, suara klik sendiri, musik menu, offset, tampilan, tombol controller.
- Chart tanpa video tampil hitam (opsi di Pengaturan untuk menampilkan gambar BG chart).
- Pencarian chart: filter artis, kesulitan (Easy..Expert), jumlah key, status.
- Editor: tap, hold (tahan lama + geser, atau mode Hold), hapus, snap, uji main, atur BPM/offset, background & video.
- Sinkron otomatis; controller/keyboard dengan tombol per kolom yang bisa dipilih.
