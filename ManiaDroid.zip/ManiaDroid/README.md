# Osu! Mania 1.8 (proyek penggemar, bukan produk resmi osu!)

Game ritme ala osu!mania (1K–10K) untuk Android. Offline; internet hanya dipakai di layar **Unduh chart**.

## Build APK (tanpa Android Studio)
1. Upload `ManiaDroid.zip` ke repo GitHub (nama sama = menimpa) dan buat `.github/workflows/build.yml`.
2. Tab **Actions** -> tunggu hijau -> unduh artifact **ManiaDroid-debug-apk** -> install `app-debug.apk`.
3. Keystore tetap (`app/debug.keystore`): update berikutnya bisa menimpa tanpa uninstall.

## Baru di 1.8
- **Gambar osu! kamu dipakai sebagai ikon aplikasi dan logo di game** (logo menu yang berdenyut + intro). Gambar ada di `res/drawable-nodpi/osu_logo.png`; ikon di `res/mipmap-*`.
- **Menu jeda baru ala osu!lazer**: pita lebar di tengah, judul lagu, persen lagu + HP, empat tombol jajar genjang berwarna (Lanjut / Ulangi / Setelan / Keluar).
- **Setelan di menu jeda langsung membuka pengaturan lengkap** (layar besar), bukan panel kecil. Kembali dari sana, menu jeda masih ada.
- **Menu lebih lazer**: tombol bergradasi tipis, dialog panel bergradasi, layar hasil memakai tombol jajar genjang, tampilan kosong di Pilih lagu punya tombol pintas Unduh chart.
- **3 level bawaan dihapus** (Neon Circles, Pink Horizon, Soft Landing). Salinan yang sudah terpasang di HP dihapus otomatis sekali saja; chart impor/unduhan kamu aman.
- **Chart tanpa video**: latar abu-abu (chart dengan video tetap video; di editor tetap hitam). Warna: `Backdrop.NO_VIDEO_GRAY`. Masih ikut diredupkan oleh "Redup background".
- **Layar main**: garis/bar di paling atas dihapus; persen lagu, HP, dan akurasi dibesarkan.

## Sebelumnya di 1.7
- **Nama aplikasi "Osu! Mania"** dan **ikon logo osu! biasa** (pink, cincin putih, tulisan "osu!").
- **Ikon sama di mana-mana**: ikon adaptif (XML) dihapus dan diganti PNG polos di semua ukuran, jadi layar pemasangan / pemindaian keamanan, layar utama, dan layar terbaru memakai gambar yang sama (sebelumnya pemasang HP tidak bisa membaca ikon adaptif lalu menampilkan ikon "play" bawaan).
- (Lagu bawaan 1.7 sudah dihapus di 1.8.)
- **Suara tombol**: semua tombol (menu, pilih lagu, unduh, pengaturan, dialog, menu jeda) berbunyi saat diketuk. Ada suara berbeda untuk tombol kembali dan untuk logo. Atur di Pengaturan > Audio (nyala/mati + volume).
- **Efek tekan**: tombol sedikit mengecil saat ditekan lalu memantul kembali.
- **Logo tengah lebih besar** dan denyutnya sedikit lebih kuat; tulisan logo jadi "osu!". Petunjuk "Ketuk logo untuk mulai" pindah ke atas supaya tidak menimpa logo.
- **Menu utama**: tombol keluar dari balik logo satu per satu, garis tipis di tepi pita tombol.
- **Transisi antar layar** memudar halus (tetap landscape).

## Sebelumnya di 1.6
- **Fullscreen** di semua layar (tombol navigasi HP disembunyikan; geser dari tepi untuk memunculkan sementara).
- **Tombol kembali** ala osu!lazer di pojok kiri atas (Pilih lagu, Unduh chart, Gaya note).
- **Note minimalis** (warna rata + garis tepi tipis). **Pengaturan > Note > Atur warna & gambar note**: warna dan gambar kustom per kolom, terpisah untuk tiap mode key, dengan pratinjau langsung.
- Efek putih saat menekan kini hanya di dalam bulatan note kosong (tidak lagi satu kolom penuh).
- **Unduh chart** didesain ulang ala osu!lazer: kartu dua kolom dengan sampul, status (Ranked/Loved), tombol unduh dengan persen berdesimal (mis. 07.35%) dan garis kemajuan, tombol dengar cuplikan lagu, muat otomatis saat menggulir, pesan galat yang ramah.
- **Bahasa Indonesia / English** (Pengaturan > Bahasa). Tulisan saat main ikut berganti (Meleset / Terlalu cepat / Terlambat atau Miss / Early / Late).
- Lanjut dari jeda: musik mundur beberapa detik, note yang sudah kena tetap hilang, plus hitung mundur 3-2-1 (atur di Pengaturan > Gameplay).
- Persen progres berdesimal (00.00%) di game (lagu + HP), di bar lagu menu, dan di unduhan.
- Ketuk saat intro **mempercepat** intro (x3, lalu makin cepat), bukan melewatinya.
- Perbaikan: warna tombol menu yang jadi hitam setelah diklik; tombol Enter/cari di keyboard pada pencarian (keyboard tidak lagi memenuhi layar); ikon aplikasi disamakan di semua tempat (termasuk layar terbaru/saran).

## Sebelumnya di 1.5
- Pengaturan ala osu!lazer: sidebar bagian di kiri, daftar bisa digulir, saklar dan slider bergaya lazer, pilihan lewat daftar; tanpa emoji. Latar menu terlihat langsung di belakangnya.
- Latar menu bawaan ala osu!lazer (gradasi + segitiga melayang yang ikut berdenyut mengikuti lagu). Bisa diganti di Pengaturan > Latar menu: bawaan / hitam polos / gambar sendiri, plus warna tema dan matikan gerakan segitiga.
- Menu utama ala osu!lazer: ketuk logo -> logo mengecil dan jalur tombol berwarna muncul (Setelan, Sinkron, Impor | logo | Main, Editor, Unduh, Keluar).
- Efek putih saat disentuh hanya muncul di dalam bentuk tombol / bulatan logo, tidak lagi meluber jadi kotak.
- Bar lagu menu dibuat kecil dan minimalis, dengan garis kemajuan lagu.
- Layar hasil baru: peringkat besar, skor menghitung naik, akurasi, combo, rincian MAX/300/200/100/50/Miss, tanda skor terbaik baru.
- Info chart di pilih lagu dikecilkan dan dirapikan.
- Semua emoji / simbol gambar di seluruh layar diganti teks.

## Sebelumnya di 1.4
- Intro ala osu!lazer saat game dibuka (bisa dimatikan di Pengaturan > Tampilan); ketuk layar untuk melewati.
- Logo osu berdenyut mengikuti lagu menu (lagu dianalisis di HP, tanpa izin tambahan; hasilnya disimpan di cache).
- Note bulat bertekstur hitcircle ala osu! (cincin putih, gradasi warna, kilap).
- Tombol jeda pindah ke kanan; menu jeda baru (Lanjut / Ulangi / Setelan / Keluar) dengan panel pengaturan cepat.
- Perbaikan lag saat menekan banyak jari sekaligus (input tanpa batching, hitsound di thread terpisah, HUD tanpa alokasi per frame).

## Fitur
- Menu ala osu!lazer, latar segitiga (bisa hitam polos / gambar sendiri); musik menu (lagu tambahan sendiri + lagu chart) dengan popup ganti lagu.
- Pengaturan: latar menu & gambar background sendiri, suara klik sendiri, musik menu, offset, tampilan, tombol controller.
- Chart tanpa video tampil hitam (opsi di Pengaturan untuk menampilkan gambar BG chart).
- Pencarian chart: filter artis, kesulitan (Easy..Expert), jumlah key, status.
- Editor: tap, hold (tahan lama + geser, atau mode Hold), hapus, snap, uji main, atur BPM/offset, background & video.
- Sinkron otomatis; controller/keyboard dengan tombol per kolom yang bisa dipilih.
