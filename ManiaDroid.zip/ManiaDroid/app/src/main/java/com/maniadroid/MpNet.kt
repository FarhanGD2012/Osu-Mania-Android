package com.maniadroid

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Lapisan jaringan Multiplayer (tanpa akun, tanpa server buatan sendiri):
 *  - LAN / hotspot: TCP langsung ke HP host (+ siaran UDP supaya lobi otomatis muncul),
 *  - Internet: relay MQTT lewat broker publik gratis (tidak perlu memasang server apa pun),
 *  - Transfer chart langsung dari HP host lewat LAN.
 * Semua kelas di file ini murni Kotlin/Java (tanpa API Android) supaya mudah diuji.
 */
object MpConst {
    const val LAN_PORT = 47770
    const val DISC_PORT = 47771
    const val FILE_PORT = 47772
    const val ROOT = "maniadroid/v1"

    /** Broker publik gratis. Huruf pertama kode room menunjuk broker mana yang dipakai (A = 0, B = 1, C = 2). */
    val BROKERS = listOf("broker.hivemq.com" to 1883, "broker.emqx.io" to 1883, "test.mosquitto.org" to 1883)
    const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    fun brokerLetter(i: Int): Char = "ABC"[i]
    fun brokerIndexOf(code: String): Int = when (code.firstOrNull()) {
        'A' -> 0
        'B' -> 1
        'C' -> 2
        else -> -1
    }

    fun newCode(brokerIdx: Int): String {
        val r = java.security.SecureRandom()
        val sb = StringBuilder()
        sb.append(brokerLetter(brokerIdx))
        for (i in 0 until 5) sb.append(ALPHABET[r.nextInt(ALPHABET.length)])
        return sb.toString()
    }

    fun upTopic(code: String) = "$ROOT/r/$code/up"
    fun downTopic(code: String) = "$ROOT/r/$code/down"
    fun lobbyTopic(code: String) = "$ROOT/lobby/$code"
    const val LOBBY_FILTER = "$ROOT/lobby/+"
}

object MpUtil {
    /** Alamat IPv4 perangkat ini (bukan loopback), diurutkan: jaringan lokal dulu. */
    fun localIps(): List<String> {
        val out = ArrayList<String>()
        try {
            val e = NetworkInterface.getNetworkInterfaces() ?: return out
            for (ni in e) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is java.net.Inet4Address && !a.isLoopbackAddress) out.add(a.hostAddress ?: continue)
                }
            }
        } catch (e: Exception) {
        }
        fun rank(ip: String) = when {
            ip.startsWith("192.168.") -> 0
            ip.startsWith("172.") -> 1
            ip.startsWith("10.") -> 2
            else -> 3
        }
        return out.sortedBy { rank(it) }
    }

    fun broadcastAddresses(): List<InetAddress> {
        val out = LinkedHashSet<InetAddress>()
        try {
            val e = NetworkInterface.getNetworkInterfaces()
            if (e != null) for (ni in e) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) ia.broadcast?.let { out.add(it) }
            }
        } catch (e: Exception) {
        }
        try {
            out.add(InetAddress.getByName("255.255.255.255"))
        } catch (e: Exception) {
        }
        return out.toList()
    }
}

// ============================================================ MQTT 3.1.1 mini (QoS 0)

class MqttLite(private val clientId: String) {
    interface Listener {
        fun onMessage(topic: String, payload: ByteArray)
        fun onClosed(reason: String)
    }

    @Volatile var listener: Listener? = null
    @Volatile var isOpen = false
        private set
    private var sock: Socket? = null
    private var out: OutputStream? = null
    private val wlock = Any()
    private var closedNotified = false

    private fun writeStr(o: ByteArrayOutputStream, s: String) {
        val b = s.toByteArray(Charsets.UTF_8)
        o.write(b.size shr 8)
        o.write(b.size and 0xFF)
        o.write(b)
    }

    private fun remLen(n: Int): ByteArray {
        val o = ByteArrayOutputStream()
        var x = n
        do {
            var d = x % 128
            x /= 128
            if (x > 0) d = d or 0x80
            o.write(d)
        } while (x > 0)
        return o.toByteArray()
    }

    private fun packet(first: Int, body: ByteArray) {
        synchronized(wlock) {
            val o = out ?: throw IOException("MQTT tertutup")
            o.write(first)
            o.write(remLen(body.size))
            o.write(body)
            o.flush()
        }
    }

    /** Memblokir sampai tersambung (panggil dari thread latar). willTopic != null: broker menghapus pesan tertahan itu jika putus mendadak. */
    fun connect(host: String, port: Int, willTopic: String?, timeoutMs: Int = 7000) {
        val s = Socket()
        try {
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(host, port), timeoutMs)
            s.soTimeout = timeoutMs
            val ins = DataInputStream(BufferedInputStream(s.getInputStream()))
            out = BufferedOutputStream(s.getOutputStream())
            sock = s
            val vh = ByteArrayOutputStream()
            writeStr(vh, "MQTT")
            vh.write(4)
            var flags = 0x02
            if (willTopic != null) flags = flags or 0x04 or 0x20
            vh.write(flags)
            vh.write(0)
            vh.write(45)
            writeStr(vh, clientId)
            if (willTopic != null) {
                writeStr(vh, willTopic)
                vh.write(0)
                vh.write(0)
            }
            packet(0x10, vh.toByteArray())
            val b0 = ins.read()
            if (b0 < 0) throw IOException("Broker menutup koneksi")
            val rl = readRemLen(ins)
            val body = ByteArray(rl)
            ins.readFully(body)
            if ((b0 shr 4) != 2 || body.size < 2 || body[1].toInt() != 0) throw IOException("Broker menolak koneksi")
            s.soTimeout = 0
            isOpen = true
            Thread { readLoop(ins) }.also { it.isDaemon = true; it.name = "mqtt-read" }.start()
            Thread {
                try {
                    while (isOpen) {
                        Thread.sleep(20000)
                        if (isOpen) packet(0xC0, ByteArray(0))
                    }
                } catch (e: Exception) {
                    notifyClosed(e.message ?: "putus")
                }
            }.also { it.isDaemon = true; it.name = "mqtt-ping" }.start()
        } catch (e: Exception) {
            try {
                s.close()
            } catch (x: Exception) {
            }
            isOpen = false
            throw e
        }
    }

    private fun readRemLen(ins: DataInputStream): Int {
        var mul = 1
        var v = 0
        for (i in 0 until 4) {
            val b = ins.read()
            if (b < 0) throw IOException("Koneksi putus")
            v += (b and 0x7F) * mul
            if (b and 0x80 == 0) return v
            mul *= 128
        }
        throw IOException("Paket MQTT rusak")
    }

    private fun readLoop(ins: DataInputStream) {
        try {
            while (true) {
                val b0 = ins.read()
                if (b0 < 0) throw IOException("Broker memutus koneksi")
                val rl = readRemLen(ins)
                val body = ByteArray(rl)
                ins.readFully(body)
                if ((b0 shr 4) == 3 && body.size >= 2) {
                    val qos = (b0 shr 1) and 3
                    val tl = ((body[0].toInt() and 0xFF) shl 8) or (body[1].toInt() and 0xFF)
                    if (2 + tl > body.size) continue
                    val topic = String(body, 2, tl, Charsets.UTF_8)
                    var idx = 2 + tl
                    if (qos > 0) idx += 2
                    if (idx > body.size) continue
                    try {
                        listener?.onMessage(topic, body.copyOfRange(idx, body.size))
                    } catch (e: Exception) {
                    }
                }
            }
        } catch (e: Exception) {
            notifyClosed(e.message ?: "putus")
        }
    }

    private fun notifyClosed(reason: String) {
        val first: Boolean
        synchronized(this) {
            first = !closedNotified
            closedNotified = true
            isOpen = false
        }
        try {
            sock?.close()
        } catch (e: Exception) {
        }
        if (first) listener?.onClosed(reason)
    }

    fun subscribe(filter: String) {
        val b = ByteArrayOutputStream()
        b.write(0)
        b.write(1)
        writeStr(b, filter)
        b.write(0)
        packet(0x82, b.toByteArray())
    }

    fun publish(topic: String, payload: ByteArray, retain: Boolean = false) {
        val b = ByteArrayOutputStream()
        writeStr(b, topic)
        b.write(payload)
        packet(0x30 or (if (retain) 1 else 0), b.toByteArray())
    }

    fun publish(topic: String, text: String, retain: Boolean = false) = publish(topic, text.toByteArray(Charsets.UTF_8), retain)

    fun close() {
        try {
            if (isOpen) packet(0xE0, ByteArray(0))
        } catch (e: Exception) {
        }
        synchronized(this) {
            closedNotified = true
            isOpen = false
        }
        try {
            sock?.close()
        } catch (e: Exception) {
        }
    }
}

// ============================================================ LAN (TCP, satu baris = satu pesan JSON)

class LanConn(val sock: Socket) {
    private val q = LinkedBlockingQueue<String>(3000)
    @Volatile var alive = true
        private set
    val remote: String get() = sock.inetAddress?.hostAddress ?: "?"

    init {
        sock.tcpNoDelay = true
        Thread {
            try {
                val o = BufferedOutputStream(sock.getOutputStream(), 8192)
                while (alive) {
                    val s = q.poll(2, TimeUnit.SECONDS) ?: continue
                    if (s.isEmpty()) break
                    o.write(s.toByteArray(Charsets.UTF_8))
                    o.write(10)
                    if (q.isEmpty()) o.flush()
                }
                o.flush()
            } catch (e: Exception) {
            }
            close()
        }.also { it.isDaemon = true; it.name = "lan-write" }.start()
    }

    fun send(line: String) {
        if (!alive) return
        if (!q.offer(line)) close() // klien terlalu lambat: putuskan
    }

    /** Tutup setelah semua pesan yang sudah antre terkirim (supaya "kicked" / "error" sempat sampai). */
    fun closeSoft() {
        if (alive) q.offer("")
    }

    fun close() {
        if (!alive) return
        alive = false
        q.offer("")
        try {
            sock.close()
        } catch (e: Exception) {
        }
    }

    /** Baca baris sampai putus (memblokir). */
    fun readLines(onLine: (String) -> Unit) {
        try {
            val r = sock.getInputStream().bufferedReader(Charsets.UTF_8)
            while (alive) {
                val l = r.readLine() ?: break
                if (l.isNotEmpty() && l.length < 200_000) onLine(l)
            }
        } catch (e: Exception) {
        }
        close()
    }
}

class LanServer(
    private val onLine: (LanConn, String) -> Unit,
    private val onDrop: (LanConn) -> Unit
) {
    private var ss: ServerSocket? = null
    @Volatile var port = 0
        private set
    @Volatile private var running = false

    /** Coba port bawaan, lalu beberapa port berikutnya bila terpakai. Return port yang dipakai, atau 0 jika gagal. */
    fun start(): Int {
        for (p in MpConst.LAN_PORT until MpConst.LAN_PORT + 1) {
            try {
                val s = ServerSocket()
                s.reuseAddress = true
                s.bind(InetSocketAddress(p))
                ss = s
                port = p
                break
            } catch (e: Exception) {
            }
        }
        if (ss == null) {
            try {
                val s = ServerSocket(0)
                ss = s
                port = s.localPort
            } catch (e: Exception) {
                return 0
            }
        }
        running = true
        Thread {
            val s = ss ?: return@Thread
            while (running) {
                val c = try {
                    s.accept()
                } catch (e: Exception) {
                    break
                }
                try {
                    val conn = LanConn(c)
                    Thread {
                        conn.readLines { l -> onLine(conn, l) }
                        onDrop(conn)
                    }.also { it.isDaemon = true; it.name = "lan-read" }.start()
                } catch (e: Exception) {
                }
            }
        }.also { it.isDaemon = true; it.name = "lan-accept" }.start()
        return port
    }

    fun stop() {
        running = false
        try {
            ss?.close()
        } catch (e: Exception) {
        }
    }
}

object LanClient {
    /** Memblokir. Throws bila gagal. */
    fun connect(ip: String, port: Int, timeoutMs: Int, onLine: (String) -> Unit, onDrop: () -> Unit): LanConn {
        val s = Socket()
        s.connect(InetSocketAddress(ip, port), timeoutMs)
        val c = LanConn(s)
        Thread {
            c.readLines(onLine)
            onDrop()
        }.also { it.isDaemon = true; it.name = "lan-client" }.start()
        return c
    }
}

// ============================================================ siaran UDP: lobi muncul otomatis di HP lain

class LanBeacon(private val info: () -> String?) {
    @Volatile private var running = false

    fun start() {
        if (running) return
        running = true
        Thread {
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket()
                sock.broadcast = true
                while (running) {
                    val s = info()
                    if (s != null) {
                        val b = s.toByteArray(Charsets.UTF_8)
                        for (a in MpUtil.broadcastAddresses()) {
                            try {
                                sock.send(DatagramPacket(b, b.size, a, MpConst.DISC_PORT))
                            } catch (e: Exception) {
                            }
                        }
                    }
                    Thread.sleep(1500)
                }
            } catch (e: Exception) {
            } finally {
                sock?.close()
            }
        }.also { it.isDaemon = true; it.name = "lan-beacon" }.start()
    }

    fun stop() {
        running = false
    }
}

class LanScanner(private val onFound: (ip: String, json: String) -> Unit) {
    @Volatile private var running = false
    private var sock: DatagramSocket? = null

    fun start() {
        if (running) return
        running = true
        Thread {
            try {
                val s = DatagramSocket(null)
                s.reuseAddress = true
                s.broadcast = true
                s.bind(InetSocketAddress(MpConst.DISC_PORT))
                s.soTimeout = 1000
                sock = s
                val buf = ByteArray(2048)
                while (running) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        onFound(p.address.hostAddress ?: continue, String(p.data, 0, p.length, Charsets.UTF_8))
                    } catch (e: java.net.SocketTimeoutException) {
                    }
                }
            } catch (e: Exception) {
            } finally {
                try {
                    sock?.close()
                } catch (e: Exception) {
                }
            }
        }.also { it.isDaemon = true; it.name = "lan-scan" }.start()
    }

    fun stop() {
        running = false
        try {
            sock?.close()
        } catch (e: Exception) {
        }
    }
}

// ============================================================ transfer chart lewat LAN (host -> pemain)

class ChartServer(private val provide: (String) -> File?) {
    private var ss: ServerSocket? = null
    @Volatile var port = 0
        private set
    @Volatile private var running = false

    fun start(): Int {
        try {
            val s = ServerSocket()
            s.reuseAddress = true
            try {
                s.bind(InetSocketAddress(MpConst.FILE_PORT))
            } catch (e: Exception) {
                s.bind(InetSocketAddress(0))
            }
            ss = s
            port = s.localPort
        } catch (e: Exception) {
            return 0
        }
        running = true
        Thread {
            val s = ss ?: return@Thread
            while (running) {
                val c = try {
                    s.accept()
                } catch (e: Exception) {
                    break
                }
                Thread { serve(c) }.also { it.isDaemon = true; it.name = "chart-serve" }.start()
            }
        }.also { it.isDaemon = true; it.name = "chart-accept" }.start()
        return port
    }

    private fun serve(c: Socket) {
        try {
            c.soTimeout = 15000
            val r = c.getInputStream().bufferedReader(Charsets.UTF_8)
            val line = r.readLine() ?: return
            val o = DataOutputStream(BufferedOutputStream(c.getOutputStream(), 65536))
            val f = if (line.startsWith("GET ")) provide(line.substring(4).trim()) else null
            if (f == null || !f.isFile) {
                o.writeLong(-1L)
                o.flush()
                return
            }
            o.writeLong(f.length())
            FileInputStream(f).use { it.copyTo(o, 65536) }
            o.flush()
        } catch (e: Exception) {
        } finally {
            try {
                c.close()
            } catch (e: Exception) {
            }
        }
    }

    fun stop() {
        running = false
        try {
            ss?.close()
        } catch (e: Exception) {
        }
    }
}

object ChartFetch {
    /** Unduh .osz dari HP host ke [dest]. progress(diterima, total). Return true bila lengkap. */
    fun fetch(ip: String, port: Int, key: String, dest: File, progress: (Long, Long) -> Unit): Boolean {
        val s = Socket()
        try {
            s.connect(InetSocketAddress(ip, port), 6000)
            s.soTimeout = 20000
            val o = s.getOutputStream()
            o.write(("GET $key\n").toByteArray(Charsets.UTF_8))
            o.flush()
            val ins = DataInputStream(BufferedInputStream(s.getInputStream(), 65536))
            val len = ins.readLong()
            if (len <= 0) return false
            var got = 0L
            val buf = ByteArray(65536)
            FileOutputStream(dest).use { f ->
                while (got < len) {
                    val n = ins.read(buf, 0, minOf(buf.size.toLong(), len - got).toInt())
                    if (n < 0) break
                    f.write(buf, 0, n)
                    got += n
                    progress(got, len)
                }
            }
            return got == len
        } catch (e: Exception) {
            return false
        } finally {
            try {
                s.close()
            } catch (e: Exception) {
            }
        }
    }
}
