package com.maniadroid

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class DownloadActivity : Activity() {
    private val items = ArrayList<Downloader.Remote>()
    private val state = HashMap<Int, String>()
    private val filter = Downloader.Filter()
    private lateinit var adapter: BaseAdapter
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var artistIn: EditText
    private lateinit var moreBtn: Button
    private var page = 0
    private var query = ""
    private var loading = false
    private var more = true

    private fun dp(v: Int) = Ui.dp(this, v)

    private inner class Holder {
        val img = ImageView(this@DownloadActivity)
        val title = Ui.text(this@DownloadActivity, "", 15f, Ui.TEXT, true)
        val sub = Ui.text(this@DownloadActivity, "", 12f, Ui.SUB)
        val btn = Button(this@DownloadActivity)
        val root = LinearLayout(this@DownloadActivity)

        init {
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.background = Ui.rounded(Ui.BG, dp(12).toFloat())
            img.clipToOutline = true
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.END
            sub.maxLines = 2
            sub.ellipsize = TextUtils.TruncateAt.END
            btn.isAllCaps = false
            btn.textSize = 12f
            btn.setTextColor(Color.WHITE)
            btn.stateListAnimator = null
            btn.background = Ui.ripple(Ui.rounded(Ui.ACCENT, dp(22).toFloat()))
            btn.isFocusable = false
            val texts = LinearLayout(this@DownloadActivity)
            texts.orientation = LinearLayout.VERTICAL
            texts.addView(title)
            texts.addView(sub)
            root.orientation = LinearLayout.HORIZONTAL
            root.gravity = Gravity.CENTER_VERTICAL
            root.setPadding(dp(10), dp(8), dp(10), dp(8))
            root.background = Ui.rounded(Ui.CARD, dp(16).toFloat())
            root.addView(img, LinearLayout.LayoutParams(dp(60), dp(60)))
            val tp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            tp.leftMargin = dp(12)
            tp.rightMargin = dp(8)
            root.addView(texts, tp)
            root.addView(btn, LinearLayout.LayoutParams(dp(104), dp(42)))
            root.layoutParams = AbsListView.LayoutParams(-1, -2)
            root.tag = this
        }
    }

    private fun field(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(Ui.SUB)
        e.setTextColor(Ui.TEXT)
        e.textSize = 13f
        e.background = Ui.rounded(0x33FFFFFF, dp(22).toFloat())
        e.setPadding(dp(16), dp(8), dp(16), dp(8))
        e.inputType = InputType.TYPE_CLASS_TEXT
        e.imeOptions = EditorInfo.IME_ACTION_SEARCH
        e.setSingleLine(true)
        e.setOnEditorActionListener { _, _, _ ->
            load(true)
            true
        }
        return e
    }

    private fun chip(label: () -> String, active: () -> Boolean, onClick: () -> Unit): TextView {
        val t = Ui.text(this, label(), 12f, Ui.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(7), dp(14), dp(7))
        fun paint() {
            t.text = label()
            t.background = Ui.ripple(Ui.rounded(if (active()) Ui.ACCENT else Ui.CARD2, dp(16).toFloat()))
        }
        paint()
        t.setOnClickListener {
            onClick()
            paint()
            load(true)
        }
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.rightMargin = dp(6)
        t.layoutParams = lp
        return t
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = Ui.bgGradient()
        root.setPadding(dp(16), dp(10), dp(16), dp(6))

        // baris judul
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(Ui.text(this, "Unduh chart", 22f, Ui.TEXT, true))
        val mirrorTv = Ui.text(this, "   Mirror: ${Downloader.names[Settings.mirror]}  ·  hanya osu!mania", 11f, Ui.SUB)
        head.addView(mirrorTv)
        root.addView(head)

        // baris pencarian
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        input = field("Judul lagu / mapper, atau ID beatmapset")
        artistIn = field("Artis")
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.3f))
        val ap = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.8f)
        ap.leftMargin = dp(8)
        row.addView(artistIn, ap)
        val sb = Ui.button(this, "Cari") { load(true) }
        val sbp = LinearLayout.LayoutParams(-2, -2)
        sbp.leftMargin = dp(8)
        row.addView(sb, sbp)
        val rp = LinearLayout.LayoutParams(-1, -2)
        rp.topMargin = dp(8)
        root.addView(row, rp)

        // baris filter
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.gravity = Gravity.CENTER_VERTICAL
        chips.addView(chip({ "Kesulitan: ${Downloader.DIFF_NAMES[filter.diff]}" }, { filter.diff != 0 }) {
            filter.diff = (filter.diff + 1) % Downloader.DIFF_NAMES.size
        })
        chips.addView(chip({ "Key: ${Downloader.KEY_NAMES[filter.keyIdx]}" }, { filter.keyIdx != 0 }) {
            filter.keyIdx = (filter.keyIdx + 1) % Downloader.KEY_NAMES.size
        })
        chips.addView(chip({ "Status: ${Downloader.STATUS_NAMES[filter.status]}" }, { filter.status != 0 }) {
            filter.status = (filter.status + 1) % Downloader.STATUS_NAMES.size
        })
        val web = Ui.text(this, "Cari ID di situs osu!", 12f, Ui.ACCENT, true)
        web.setPadding(dp(10), dp(7), dp(10), dp(7))
        web.setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://osu.ppy.sh/beatmapsets?m=3")))
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak ada browser", Toast.LENGTH_SHORT).show()
            }
        }
        chips.addView(web)
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips)
        val hp = LinearLayout.LayoutParams(-1, -2)
        hp.topMargin = dp(8)
        root.addView(hs, hp)

        status = Ui.text(this, "", 12f, Ui.SUB)
        status.setPadding(0, dp(4), 0, dp(4))
        root.addView(status)

        val list = ListView(this)
        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = dp(8)
        list.selector = ColorDrawable(Color.TRANSPARENT)
        moreBtn = Ui.button(this, "Muat lebih banyak", false) { load(false) }
        moreBtn.visibility = View.GONE
        list.addFooterView(moreBtn)
        adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(position: Int): Any = items[position]
            override fun getItemId(position: Int) = items[position].id.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val h = (convertView?.tag as? Holder) ?: Holder()
                val r = items[position]
                h.title.text = if (r.artist.isEmpty()) r.title else "${r.artist} - ${r.title}"
                h.sub.text = r.info
                Img.load("https://assets.ppy.sh/beatmaps/${r.id}/covers/list.jpg", h.img)
                val installed = File(Library.songsDir(this@DownloadActivity), "dl_${r.id}").exists()
                val s = state[r.id]
                h.btn.text = s ?: if (installed) "Terpasang" else "Unduh"
                h.btn.isEnabled = s == null
                h.btn.setOnClickListener { startDownload(r) }
                return h.root
            }
        }
        list.adapter = adapter
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        load(true)
    }

    private fun load(reset: Boolean) {
        if (loading) return
        if (reset) {
            page = 0
            items.clear()
            more = true
            filter.artist = artistIn.text.toString().trim()
            val text = input.text.toString().trim()
            query = (filter.artist + " " + text).trim()
            adapter.notifyDataSetChanged()
            val id = text.toIntOrNull()
            if (id != null && id > 0 && filter.artist.isEmpty()) { // unduh langsung lewat ID beatmapset
                items.add(Downloader.Remote(id, "Beatmapset #$id", "", "", "", "Unduh langsung via ID"))
                adapter.notifyDataSetChanged()
                status.text = ""
                moreBtn.visibility = View.GONE
                return
            }
        }
        loading = true
        status.text = "Memuat…"
        val q = query
        val startPage = page
        val f = Downloader.Filter(filter.artist, filter.diff, filter.keyIdx, filter.status)
        Thread {
            try {
                val acc = ArrayList<Downloader.Remote>()
                var pg = startPage
                var tries = 0
                var lastSize: Int
                do { // saat filter aktif, ambil beberapa halaman sampai cukup hasil
                    val r = Downloader.search(q, pg)
                    lastSize = r.size
                    pg++
                    tries++
                    for (x in r) if (Downloader.matches(x, f)) acc.add(x)
                } while (f.active && acc.size < 8 && lastSize >= 20 && tries < 5)
                runOnUiThread {
                    items.addAll(acc)
                    page = pg
                    more = lastSize >= 20
                    loading = false
                    status.text = if (items.isEmpty()) "Tidak ada hasil (coba ubah filter)"
                    else "${items.size} hasil · sumber: ${Downloader.lastSearchMirror}"
                    moreBtn.visibility = if (more && items.isNotEmpty()) View.VISIBLE else View.GONE
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    loading = false
                    status.text = "Pencarian gagal di semua mirror (${e.message}). " +
                            "Cek internet, atau ketik ID beatmapset (angka) lalu tekan Cari."
                }
            }
        }.start()
    }

    private fun startDownload(r: Downloader.Remote) {
        if (state.containsKey(r.id)) return
        state[r.id] = "0%"
        adapter.notifyDataSetChanged()
        Thread {
            try {
                val n = Downloader.download(this, r.id) { txt ->
                    runOnUiThread {
                        state[r.id] = txt
                        adapter.notifyDataSetChanged()
                    }
                }
                runOnUiThread {
                    state.remove(r.id)
                    Toast.makeText(this, "Terpasang: $n chart mania", Toast.LENGTH_SHORT).show()
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    state.remove(r.id)
                    Toast.makeText(this, "Gagal unduh: ${e.message}", Toast.LENGTH_LONG).show()
                    adapter.notifyDataSetChanged()
                }
            }
        }.start()
    }
}
