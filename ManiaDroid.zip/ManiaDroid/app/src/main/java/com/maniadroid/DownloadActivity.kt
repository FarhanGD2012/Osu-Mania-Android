package com.maniadroid

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.io.File
import kotlin.math.abs

/**
 * Unduh chart ala osu!lazer (daftar beatmap online): latar menu di belakang, tombol kembali di pojok kiri atas,
 * kotak cari + filter, lalu kartu beatmap dua kolom (sampul, judul, artis, mapper, key, status) dengan tombol unduh.
 * Hasil dimuat otomatis saat daftar digulir ke bawah.
 */
class DownloadActivity : BaseActivity() {
    private val items = ArrayList<Downloader.Remote>()
    private val state = HashMap<Int, String>()
    private val filter = Downloader.Filter()
    private lateinit var adapter: BaseAdapter
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var artistIn: EditText
    private lateinit var emptyBox: LinearLayout
    private lateinit var emptyTitle: TextView
    private lateinit var emptySub: TextView
    private lateinit var retryBtn: TextView
    private var page = 0
    private var query = ""
    private var loading = false
    private var more = true
    private var failed = false

    private fun dp(v: Int) = Ui.dp(this, v)

    // ---------- kartu beatmap ----------
    private inner class CardView : FrameLayout(this@DownloadActivity) {
        val img = ImageView(context)
        val title = Ui.text(context, "", 15f, Ui.TEXT, true)
        val artist = Ui.text(context, "", 12f, 0xFFE0E0EE.toInt())
        val mapper = Ui.text(context, "", 11f, Ui.SUB)
        val chips = Ui.text(context, "", 11f, Ui.ACCENT, true)
        val stats = Ui.text(context, "", 10.5f, 0xFFA8A8C0.toInt())
        val badge = Ui.text(context, "", 9.5f, Color.WHITE, true)
        val btn = Ui.text(context, "", 12f, Color.WHITE, true)
        val prev = Ui.text(context, "Preview", 11.5f, Color.WHITE, true)
        val prog = ProgressLine(context)
        var remote: Downloader.Remote? = null

        init {
            background = Ui.rounded(Ui.CARD, dp(16).toFloat())
            clipToOutline = true
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            addView(img, LayoutParams(-1, -1))
            val shade = View(context)
            shade.background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xF2101018.toInt(), 0xC0101018.toInt(), 0x66101018.toInt())
            )
            addView(shade, LayoutParams(-1, -1))

            val col = LinearLayout(context)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_VERTICAL
            col.setPadding(dp(14), dp(6), dp(100), dp(6))
            for (t in arrayOf(title, artist, mapper, chips, stats)) {
                t.maxLines = 1
                t.ellipsize = TextUtils.TruncateAt.END
                col.addView(t)
            }
            addView(col, LayoutParams(-1, -1))

            badge.setPadding(dp(7), dp(2), dp(7), dp(2))
            badge.letterSpacing = 0.08f
            val bl = LayoutParams(-2, -2, Gravity.TOP or Gravity.END)
            bl.topMargin = dp(7)
            bl.rightMargin = dp(9)
            addView(badge, bl)

            // tombol Unduh dan Preview bertumpuk di kanan
            btn.gravity = Gravity.CENTER
            btn.maxLines = 1
            prev.gravity = Gravity.CENTER
            prev.maxLines = 1
            prev.background = Ui.ripple(Ui.lazerFill(0xFF2B2A3A.toInt(), dp(15).toFloat(), true, context))
            val stack = LinearLayout(context)
            stack.orientation = LinearLayout.VERTICAL
            stack.addView(btn, LinearLayout.LayoutParams(dp(78), dp(34)))
            stack.addView(prev, LinearLayout.LayoutParams(dp(78), dp(30)).also { it.topMargin = dp(6) })
            val sp0 = LayoutParams(-2, -2, Gravity.END or Gravity.BOTTOM)
            sp0.rightMargin = dp(9)
            sp0.bottomMargin = dp(9)
            addView(stack, sp0)
            btn.setOnClickListener { remote?.let { r -> if (!state.containsKey(r.id) && !installed(r.id)) startDownload(r) } }
            prev.setOnClickListener { remote?.let { r -> openPreview(r) } }

            // garis kemajuan unduhan di dasar kartu
            addView(prog, LayoutParams(-1, dp(3), Gravity.BOTTOM))
            prog.visibility = View.GONE
        }
    }

    private fun openPreview(r: Downloader.Remote) {
        MapPreview(this, r, installed(r.id) || state.containsKey(r.id)) { startDownload(r) }.show()
    }

    private fun compact(n: Int): String = when {
        n >= 1_000_000 -> String.format(java.util.Locale.US, "%.1fM", n / 1_000_000f)
        n >= 1_000 -> String.format(java.util.Locale.US, "%.1fK", n / 1_000f)
        else -> n.toString()
    }

    private fun installed(id: Int) = File(Library.songsDir(this), "dl_$id").exists()

    private fun bind(c: CardView, r: Downloader.Remote) {
        c.remote = r
        c.visibility = View.VISIBLE
        c.title.text = if (r.title.isEmpty()) "Beatmapset #${r.id}" else r.title
        c.artist.text = r.artist
        c.artist.visibility = if (r.artist.isEmpty()) View.GONE else View.VISIBLE
        c.mapper.text = if (r.creator.isEmpty()) L.t("Unduh langsung via ID", "Direct download by ID") else "mapper ${r.creator}"
        val ks = r.keyCounts.filter { it > 0 }.distinct().sorted().joinToString(", ") { "${it}K" }
        val known = r.stars.filter { it > 0f }
        val sr = if (known.isEmpty()) "" else String.format(java.util.Locale.US, "  ·  SR %.1f–%.1f", known.min(), known.max())
        val diffs = if (r.stars.isEmpty()) "" else "${r.stars.size} diff"
        c.chips.text = listOf(ks, diffs).filter { it.isNotEmpty() }.joinToString("  ·  ") + sr

        val hue = (abs(r.title.hashCode()) % 360).toFloat()
        c.img.setBackgroundColor(Color.HSVToColor(floatArrayOf(hue, 0.45f, 0.32f)))
        Img.load("https://assets.ppy.sh/beatmaps/${r.id}/covers/card.jpg", c.img)

        val st = r.status.lowercase()
        val (txt, col) = when (st) {
            "ranked", "approved" -> Pair("RANKED", 0xFF3FA66A.toInt())
            "loved" -> Pair("LOVED", 0xFFE0508F.toInt())
            "qualified" -> Pair("QUALIFIED", 0xFF3F8EC8.toInt())
            "graveyard", "wip", "pending" -> Pair(st.uppercase(), 0xFF6B6A7C.toInt())
            else -> Pair("", 0)
        }
        c.badge.visibility = if (txt.isEmpty()) View.GONE else View.VISIBLE
        c.badge.text = txt
        c.badge.background = Ui.rounded(col, dp(8).toFloat())

        val s = state[r.id]
        val isInstalled = installed(r.id)
        c.btn.text = when {
            s != null -> L.t(s)
            isInstalled -> L.t("Terpasang")
            else -> L.t("Unduh")
        }
        val active = s == null && !isInstalled
        c.btn.background = Ui.ripple(Ui.rounded(if (active) Ui.ACCENT else 0xFF2B2A3A.toInt(), dp(18).toFloat()))
        c.btn.isEnabled = active
        // garis kemajuan unduhan
        val frac = s?.removeSuffix("%")?.toFloatOrNull()
        if (frac != null && s.endsWith("%")) {
            c.prog.visibility = View.VISIBLE
            c.prog.frac = frac / 100f
        } else c.prog.visibility = View.GONE
        // statistik populer (dimainkan / suka) ditampilkan di baris chip jika tersedia
        if (r.plays > 0 || r.favs > 0) {
            c.stats.visibility = View.VISIBLE
            c.stats.text = L.t("${compact(r.plays)} dimainkan  ·  ${compact(r.favs)} suka", "${compact(r.plays)} plays  ·  ${compact(r.favs)} favourites")
        } else c.stats.visibility = View.GONE
    }

    private inner class Row : LinearLayout(this@DownloadActivity) {
        val a = CardView()
        val b = CardView()

        init {
            orientation = HORIZONTAL
            val l1 = LayoutParams(0, dp(108), 1f)
            l1.rightMargin = dp(5)
            val l2 = LayoutParams(0, dp(108), 1f)
            l2.leftMargin = dp(5)
            addView(a, l1)
            addView(b, l2)
            layoutParams = AbsListView.LayoutParams(-1, -2)
        }
    }

    // ---------- kolom input & filter ----------
    private fun field(hint: String): EditText {
        val e = EditText(this)
        e.hint = L.t(hint)
        e.setHintTextColor(Ui.SUB)
        e.setTextColor(Ui.TEXT)
        e.textSize = 13.5f
        e.background = Ui.rounded(0x40FFFFFF, dp(22).toFloat())
        e.setPadding(dp(18), 0, dp(18), 0)
        e.inputType = InputType.TYPE_CLASS_TEXT
        Ui.searchField(e) { load(true) } // Enter / tombol cari di keyboard menjalankan pencarian
        return e
    }

    private fun filterChip(label: () -> String, options: () -> List<String>, cur: () -> Int, set: (Int) -> Unit): LazerDropdown {
        val dd = LazerDropdown(this, label())
        dd.setOnClickListener {
            LDialog.pick(this, label().substringBefore(":"), options(), cur()) { i ->
                set(i)
                dd.text = label()
                load(true)
            }
        }
        return dd
    }

    private fun doSearch() {
        Ui.hideKeyboard(input)
        input.clearFocus()
        artistIn.clearFocus()
        load(true)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)

        filter.sort = Settings.dlSort.coerceIn(0, Downloader.SORT_NAMES.size - 1)
        filter.period = Settings.dlPeriod.coerceIn(0, Downloader.PERIOD_NAMES.size - 1)

        val root = FrameLayout(this)
        root.addView(MenuBackdrop(this), Ui.matchParams())
        val dim = View(this)
        dim.setBackgroundColor(0x80000000.toInt())
        root.addView(dim, Ui.matchParams())

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), 0, dp(16), dp(6))
        root.addView(body, Ui.matchParams())

        // judul di sebelah tombol kembali
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(LazerTitle(this, L.t("Unduh chart"), L.t("cari chart", "browse")))
        val sub = Ui.text(this, "", 11f, Ui.SUB)
        sub.text = "   " + L.t("Mirror") + ": " + L.t(Downloader.names[Settings.mirror.coerceIn(0, Downloader.names.size - 1)]) +
                "  ·  " + L.t("hanya osu!mania")
        head.addView(sub, LinearLayout.LayoutParams(0, -2, 1f))
        val web = Ui.text(this, "Cari ID di situs osu!", 12f, Ui.ACCENT, true)
        web.setPadding(dp(12), dp(8), dp(8), dp(8))
        web.setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://osu.ppy.sh/beatmapsets?m=3")))
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak ada browser", Toast.LENGTH_SHORT).show()
            }
        }
        head.addView(web)
        val hp = LinearLayout.LayoutParams(-1, dp(LazerBack.H_DP))
        hp.leftMargin = dp(LazerBack.W_DP + 14 - 16)
        body.addView(head, hp)

        // pencarian
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        input = field("Judul lagu / mapper, atau ID beatmapset")
        artistIn = field("Artis")
        row.addView(input, LinearLayout.LayoutParams(0, dp(44), 1.3f))
        val ap = LinearLayout.LayoutParams(0, dp(44), 0.8f)
        ap.leftMargin = dp(8)
        row.addView(artistIn, ap)
        val sb = Ui.button(this, "Cari") { doSearch() }
        sb.minHeight = dp(44)
        sb.minimumHeight = dp(44)
        val sbp = LinearLayout.LayoutParams(-2, dp(44))
        sbp.leftMargin = dp(8)
        row.addView(sb, sbp)
        val rp = LinearLayout.LayoutParams(-1, -2)
        rp.topMargin = dp(4)
        body.addView(row, rp)

        // filter
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.gravity = Gravity.CENTER_VERTICAL
        fun addChip(v: View) {
            val lp = LinearLayout.LayoutParams(-2, dp(36))
            lp.rightMargin = dp(8)
            chips.addView(v, lp)
        }
        addChip(filterChip(
            { L.t("Kesulitan") + ": " + L.t(Downloader.DIFF_NAMES[filter.diff]) },
            { Downloader.DIFF_NAMES.map { L.t(it) } }, { filter.diff }) { filter.diff = it })
        addChip(filterChip(
            { "Key: " + L.t(Downloader.KEY_NAMES[filter.keyIdx]) },
            { Downloader.KEY_NAMES.map { L.t(it) } }, { filter.keyIdx }) { filter.keyIdx = it })
        addChip(filterChip(
            { "Status: " + L.t(Downloader.STATUS_NAMES[filter.status]) },
            { Downloader.STATUS_NAMES.map { L.t(it) } }, { filter.status }) { filter.status = it })
        addChip(filterChip(
            { L.t("Urutkan") + ": " + L.t(Downloader.SORT_NAMES[filter.sort]) },
            { Downloader.SORT_NAMES.map { L.t(it) } }, { filter.sort }) { filter.sort = it; Settings.dlSort = it })
        addChip(filterChip(
            { L.t("Periode") + ": " + L.t(Downloader.PERIOD_NAMES[filter.period]) },
            { Downloader.PERIOD_NAMES.map { L.t(it) } }, { filter.period }) { filter.period = it; Settings.dlPeriod = it })
        val chipScroll = android.widget.HorizontalScrollView(this)
        chipScroll.isHorizontalScrollBarEnabled = false
        chipScroll.addView(chips)
        val cp = LinearLayout.LayoutParams(-1, -2)
        cp.topMargin = dp(8)
        body.addView(chipScroll, cp)

        status = Ui.text(this, "", 11.5f, Ui.SUB)
        status.setPadding(dp(2), dp(6), 0, dp(4))
        body.addView(status)

        // daftar kartu dua kolom + pesan kosong / galat di tengah
        val listFrame = FrameLayout(this)
        val list = ListView(this)
        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = dp(10)
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.clipToPadding = false
        list.setPadding(0, 0, 0, dp(12))
        list.isVerticalScrollBarEnabled = false
        adapter = object : BaseAdapter() {
            override fun getCount() = (items.size + 1) / 2
            override fun getItem(position: Int): Any = position
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val r = (convertView as? Row) ?: Row()
                bind(r.a, items[position * 2])
                if (position * 2 + 1 < items.size) bind(r.b, items[position * 2 + 1]) else {
                    r.b.visibility = View.INVISIBLE
                    r.b.remote = null
                }
                return r
            }
        }
        list.adapter = adapter
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView?, s: Int) {}
            override fun onScroll(v: AbsListView?, first: Int, visible: Int, total: Int) {
                if (more && !loading && !failed && total > 0 && first + visible >= total - 1) load(false)
            }
        })
        listFrame.addView(list, FrameLayout.LayoutParams(-1, -1))

        emptyBox = LinearLayout(this)
        emptyBox.orientation = LinearLayout.VERTICAL
        emptyBox.gravity = Gravity.CENTER
        emptyBox.visibility = View.GONE
        emptyTitle = Ui.text(this, "", 16f, Color.WHITE, true)
        emptyTitle.gravity = Gravity.CENTER
        emptySub = Ui.text(this, "", 12.5f, Ui.SUB)
        emptySub.gravity = Gravity.CENTER
        retryBtn = Ui.text(this, "Coba lagi", 14f, Color.WHITE, true)
        retryBtn.gravity = Gravity.CENTER
        retryBtn.setPadding(dp(22), dp(10), dp(22), dp(10))
        retryBtn.background = Ui.ripple(Ui.rounded(Ui.ACCENT, dp(20).toFloat()))
        retryBtn.setOnClickListener { load(true) }
        emptyBox.addView(emptyTitle)
        emptyBox.addView(emptySub, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = dp(6) })
        emptyBox.addView(retryBtn, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = dp(14) })
        listFrame.addView(emptyBox, FrameLayout.LayoutParams(-1, -1).also { it.leftMargin = dp(30); it.rightMargin = dp(30) })
        body.addView(listFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        // pojok kiri atas: tombol kembali ala osu!lazer
        root.addView(
            LazerBack(this) { finish() },
            FrameLayout.LayoutParams(dp(LazerBack.W_DP), dp(LazerBack.H_DP), Gravity.TOP or Gravity.START)
        )
        setContentView(root)
        load(true)
    }

    private fun showEmpty(title: String?, sub: String = "", retry: Boolean = false) {
        if (title == null) {
            emptyBox.visibility = View.GONE
            return
        }
        emptyBox.visibility = View.VISIBLE
        emptyTitle.text = L.t(title)
        emptySub.text = L.t(sub)
        emptySub.visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
        retryBtn.visibility = if (retry) View.VISIBLE else View.GONE
    }

    private fun isOffline(msg: String?): Boolean {
        val m = (msg ?: "").lowercase()
        return m.contains("unable to resolve host") || m.contains("unknownhost") || m.contains("failed to connect") ||
                m.contains("network is unreachable") || m.contains("timeout") || m.contains("timed out")
    }

    private fun load(reset: Boolean) {
        if (loading) return
        if (reset) {
            page = 0
            items.clear()
            more = true
            failed = false
            filter.artist = artistIn.text.toString().trim()
            val text = input.text.toString().trim()
            query = (filter.artist + " " + text).trim()
            adapter.notifyDataSetChanged()
            showEmpty(null)
            val id = text.toIntOrNull()
            if (id != null && id > 0 && filter.artist.isEmpty()) { // unduh langsung lewat ID beatmapset
                items.add(Downloader.Remote(id, "", "", "", "", ""))
                adapter.notifyDataSetChanged()
                status.text = ""
                more = false
                return
            }
        }
        loading = true
        status.text = L.t("Memuat…")
        val q = query
        val startPage = page
        val f = Downloader.Filter(filter.artist, filter.diff, filter.keyIdx, filter.status, filter.sort, filter.period)
        // Dengan periode (hari ini / minggu ini / ...): ambil menurut tanggal terbaru lalu saring + urutkan di HP
        val periodMode = f.period != 0
        val serverSort = if (periodMode) 3 else f.sort
        val maxTries = if (periodMode) 12 else 5
        val wantMin = if (periodMode) 12 else 8
        val cutoff = if (periodMode) System.currentTimeMillis() - Downloader.periodSeconds(f.period) * 1000L else 0L
        Thread {
            try {
                val acc = ArrayList<Downloader.Remote>()
                var pg = startPage
                var tries = 0
                var lastSize: Int
                var olderThanPeriod = false
                do { // saat filter aktif, ambil beberapa halaman sampai cukup hasil
                    val r = Downloader.search(q, pg, serverSort)
                    lastSize = r.size
                    pg++
                    tries++
                    for (x in r) if (Downloader.matches(x, f)) acc.add(x)
                    // urutan terbaru: bila seluruh halaman sudah lebih tua dari periode, tidak perlu lanjut
                    if (periodMode && r.isNotEmpty() && r.all { it.rankedAt in 1 until cutoff }) olderThanPeriod = true
                } while (f.active && acc.size < wantMin && lastSize >= 20 && tries < maxTries && !olderThanPeriod)
                if (olderThanPeriod) lastSize = 0
                runOnUiThread {
                    items.addAll(acc)
                    Downloader.sortLocal(items, f.sort)
                    page = pg
                    more = lastSize >= 20
                    loading = false
                    if (items.isEmpty()) {
                        status.text = ""
                        showEmpty("Tidak ada hasil", "Coba kata kunci lain atau ubah filter.")
                    } else {
                        status.text = L.t(
                            "${items.size} hasil  ·  sumber: ${Downloader.lastSearchMirror}",
                            "${items.size} results  ·  source: ${Downloader.lastSearchMirror}"
                        )
                        showEmpty(null)
                    }
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    loading = false
                    failed = true
                    status.text = ""
                    if (isOffline(e.message)) {
                        showEmpty(
                            "Tidak bisa terhubung ke internet",
                            "Periksa koneksi data / Wi-Fi, lalu tekan Coba lagi.\nAtau ketik ID beatmapset (angka) lalu tekan Cari.",
                            true
                        )
                    } else {
                        showEmpty(
                            "Pencarian gagal di semua mirror",
                            "Server sedang bermasalah. Coba lagi sebentar lagi, atau ketik ID beatmapset (angka) lalu tekan Cari.",
                            true
                        )
                    }
                }
            }
        }.start()
    }

    private fun startDownload(r: Downloader.Remote) {
        if (state.containsKey(r.id)) return
        state[r.id] = "0%"
        adapter.notifyDataSetChanged()
        Thread {
            try {
                val n = Downloader.download(this, r.id) { txt ->
                    runOnUiThread {
                        state[r.id] = txt
                        adapter.notifyDataSetChanged()
                    }
                }
                runOnUiThread {
                    state.remove(r.id)
                    Toast.makeText(this, L.t("Terpasang: $n chart mania", "Installed: $n mania charts"), Toast.LENGTH_SHORT).show()
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    state.remove(r.id)
                    val msg = if (isOffline(e.message)) L.t("Tidak ada koneksi internet", "No internet connection")
                    else L.t("Gagal unduh: ${e.message}", "Download failed: ${e.message}")
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    adapter.notifyDataSetChanged()
                }
            }
        }.start()
    }
}
