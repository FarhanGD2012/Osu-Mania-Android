package com.maniadroid

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.min

/**
 * Menu jeda ala osu!lazer: latar gelap redup, kartu di tengah dengan ubin
 * Lanjut / Ulangi / Setelan / Keluar. "Setelan" membuka panel pengaturan cepat
 * (kecepatan scroll, volume, redup background, offset, getar) tanpa keluar dari game.
 */
class PauseOverlay(
    ctx: Context,
    private val title: String,
    private val sub: String,
    private val onContinue: () -> Unit,
    private val onRetry: () -> Unit,
    private val onQuit: () -> Unit,
    private val onAllSettings: () -> Unit,
    private val onChanged: () -> Unit
) : FrameLayout(ctx) {

    private val card = LinearLayout(ctx)
    private val dm = ctx.resources.displayMetrics
    private var inSettings = false

    private fun dp(v: Int) = Ui.dp(context, v)

    /** ScrollView yang tingginya dibatasi, supaya panel pengaturan tidak melebihi layar landscape. */
    private class CappedScroll(c: Context, private val maxH: Int) : ScrollView(c) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
        }
    }

    init {
        setBackgroundColor(0xD0050509.toInt())
        isClickable = true
        isFocusable = true
        card.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xF2171724.toInt())
        bg.cornerRadius = dp(26).toFloat()
        bg.setStroke(dp(1), 0x28FFFFFF)
        card.background = bg
        card.setPadding(dp(20), dp(16), dp(20), dp(18))
        val w = min(dp(480), dm.widthPixels - dp(32))
        addView(card, LayoutParams(w, LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        showMain()

        alpha = 0f
        card.scaleX = 0.94f
        card.scaleY = 0.94f
        animate().alpha(1f).setDuration(170).start()
        card.animate().scaleX(1f).scaleY(1f).setDuration(210).start()
    }

    /** true jika masih di panel pengaturan dan baru saja kembali ke menu utama. */
    fun back(): Boolean {
        if (!inSettings) return false
        showMain()
        return true
    }

    private fun tile(kind: Int, label: String, tint: Int, primary: Boolean, click: () -> Unit): View {
        val t = LinearLayout(context)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.setPadding(dp(6), dp(8), dp(6), dp(8))
        t.background = Ui.ripple(Ui.rounded(if (primary) Ui.ACCENT else 0x2EFFFFFF, dp(20).toFloat()))
        val ic = IconView(context, kind, if (primary) Color.WHITE else tint)
        t.addView(ic, LinearLayout.LayoutParams(dp(34), dp(34)))
        val tx = Ui.text(context, label, 13f, Color.WHITE, true)
        tx.gravity = Gravity.CENTER
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.topMargin = dp(6)
        t.addView(tx, lp)
        t.setOnClickListener { click() }
        return t
    }

    private fun showMain() {
        inSettings = false
        card.removeAllViews()

        val head = Ui.text(context, "JEDA", 12f, Ui.ACCENT, true)
        head.letterSpacing = 0.25f
        head.gravity = Gravity.CENTER
        card.addView(head, LinearLayout.LayoutParams(-1, -2))

        val t = Ui.text(context, title, 17f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val tp = LinearLayout.LayoutParams(-1, -2)
        tp.topMargin = dp(6)
        card.addView(t, tp)

        val s = Ui.text(context, sub, 12f, Ui.SUB)
        s.gravity = Gravity.CENTER
        s.maxLines = 1
        s.ellipsize = TextUtils.TruncateAt.END
        card.addView(s, LinearLayout.LayoutParams(-1, -2))

        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        fun add(v: View, first: Boolean = false) {
            val lp = LinearLayout.LayoutParams(0, dp(92), 1f)
            if (!first) lp.leftMargin = dp(8)
            row.addView(v, lp)
        }
        add(tile(IconView.PLAY, "Lanjut", Color.WHITE, true) { onContinue() }, true)
        add(tile(IconView.RETRY, "Ulangi", 0xFFFFD84D.toInt(), false) { onRetry() })
        add(tile(IconView.SETTINGS, "Setelan", 0xFFB9B9FF.toInt(), false) { showSettings() })
        add(tile(IconView.EXIT, "Keluar", 0xFFFF7A7A.toInt(), false) { onQuit() })
        val rp = LinearLayout.LayoutParams(-1, -2)
        rp.topMargin = dp(16)
        card.addView(row, rp)
    }

    // ---------- panel pengaturan cepat ----------
    private fun showSettings() {
        inSettings = true
        card.removeAllViews()

        val head = LinearLayout(context)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val back = Ui.text(context, "Kembali", 14f, Color.WHITE, true)
        back.setPadding(dp(14), dp(8), dp(14), dp(8))
        back.background = Ui.ripple(Ui.rounded(0x2EFFFFFF, dp(18).toFloat()))
        back.setOnClickListener { showMain() }
        head.addView(back, LinearLayout.LayoutParams(-2, -2))
        val ttl = Ui.text(context, "Pengaturan", 17f, Color.WHITE, true)
        val tp = LinearLayout.LayoutParams(-2, -2)
        tp.leftMargin = dp(14)
        head.addView(ttl, tp)
        card.addView(head, LinearLayout.LayoutParams(-1, -2))

        val list = LinearLayout(context)
        list.orientation = LinearLayout.VERTICAL
        slider(list, "Kecepatan scroll", 1, 40, Settings.scrollSpeed, { it.toString() }) { Settings.scrollSpeed = it }
        slider(list, "Volume musik", 0, 100, Settings.musicVol, { "$it%" }) { Settings.musicVol = it }
        slider(list, "Volume hitsound", 0, 100, Settings.sfxVol, { "$it%" }) { Settings.sfxVol = it }
        slider(list, "Redup background", 0, 100, Settings.bgDim, { "$it%" }) { Settings.bgDim = it }
        slider(list, "Offset sentuhan", -300, 300, Settings.offset, { "$it ms" }) { Settings.offset = it }
        toggle(list, "Getar saat tap", Settings.haptic) { Settings.haptic = it }

        val all = Ui.button(context, "Semua pengaturan…", false) { onAllSettings() }
        val ap = LinearLayout.LayoutParams(-1, -2)
        ap.topMargin = dp(14)
        list.addView(all, ap)

        val maxH = (dm.heightPixels - dp(130)).coerceAtLeast(dp(140))
        val sv = CappedScroll(context, maxH)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        val sp = LinearLayout.LayoutParams(-1, -2)
        sp.topMargin = dp(8)
        card.addView(sv, sp)
    }

    private fun slider(
        parent: LinearLayout, label: String, min: Int, max: Int, value: Int,
        fmt: (Int) -> String, set: (Int) -> Unit
    ) {
        val top = LinearLayout(context)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(Ui.text(context, label, 13f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        val vt: TextView = Ui.text(context, fmt(value), 12.5f, Ui.ACCENT, true)
        top.addView(vt, LinearLayout.LayoutParams(-2, -2))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(10)
        parent.addView(top, lp)
        val sl = LazerSlider(context, min, max, value) {
            vt.text = fmt(it)
            set(it)
            onChanged()
        }
        parent.addView(sl, LinearLayout.LayoutParams(-1, -2))
    }

    private fun toggle(parent: LinearLayout, label: String, value: Boolean, set: (Boolean) -> Unit) {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(Ui.text(context, label, 13f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = LazerSwitch(context, value) {
            set(it)
            onChanged()
        }
        row.addView(sw, LinearLayout.LayoutParams(-2, -2))
        row.setOnClickListener { sw.toggle() }
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(12)
        parent.addView(row, lp)
    }
}
