package com.maniadroid

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.min

/** Huruf peringkat besar di dalam cincin berwarna. */
private class RankBadge(ctx: Context, private val rank: String, private val col: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 4f
        p.style = Paint.Style.FILL
        p.color = Color.argb(0x26, Color.red(col), Color.green(col), Color.blue(col))
        cv.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.07f
        p.color = col
        cv.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        p.textSize = r * (if (rank.length > 1) 1.05f else 1.35f)
        p.color = col
        cv.drawText(rank, cx, cy + p.textSize * 0.35f, p)
    }
}

/**
 * Layar hasil ala osu!lazer: peringkat besar di kiri; skor, akurasi, combo, dan rincian
 * hit (MAX / 300 / 200 / 100 / 50 / Miss) di kanan, dengan tombol Ulangi dan Kembali.
 */
class ResultOverlay(
    ctx: Context,
    title: String,
    sub: String,
    r: Result,
    best: Int,
    newBest: Boolean,
    onRetry: () -> Unit,
    onBack: () -> Unit
) : FrameLayout(ctx) {

    private fun dp(v: Int) = Ui.dp(context, v)

    private fun rankColor(rank: String): Int = when (rank) {
        "SS" -> 0xFFFFE27A.toInt()
        "S" -> 0xFFFFC94D.toInt()
        "A" -> 0xFF6FE08A.toInt()
        "B" -> 0xFF4DA3FF.toInt()
        "C" -> 0xFFB48CFF.toInt()
        else -> 0xFFFF5A6A.toInt()
    }

    init {
        setBackgroundColor(0xE6050509.toInt())
        isClickable = true
        isFocusable = true
        val dm = resources.displayMetrics

        val card = LinearLayout(context)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0xF2151422.toInt())
        bg.cornerRadius = dp(22).toFloat()
        bg.setStroke(dp(1), 0x26FFFFFF)
        card.background = bg
        card.setPadding(dp(22), dp(16), dp(22), dp(16))
        val w = min(dp(600), dm.widthPixels - dp(32))
        addView(card, LayoutParams(w, LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        // ---- kiri: peringkat ----
        val rankCol = rankColor(r.rank)
        val left = LinearLayout(context)
        left.orientation = LinearLayout.VERTICAL
        left.gravity = Gravity.CENTER_HORIZONTAL
        val badge = RankBadge(context, r.rank, rankCol)
        left.addView(badge, LinearLayout.LayoutParams(dp(104), dp(104)))
        val status = Ui.text(context, if (r.failed) "GAGAL" else "SELESAI", 11f, if (r.failed) 0xFFFF7A8A.toInt() else Ui.ACCENT, true)
        status.letterSpacing = 0.22f
        val sp0 = LinearLayout.LayoutParams(-2, -2)
        sp0.topMargin = dp(8)
        left.addView(status, sp0)
        card.addView(left, LinearLayout.LayoutParams(dp(112), -2))

        // ---- kanan: rincian ----
        val right = LinearLayout(context)
        right.orientation = LinearLayout.VERTICAL
        val lp = LinearLayout.LayoutParams(0, -2, 1f)
        lp.leftMargin = dp(20)
        card.addView(right, lp)

        val t = Ui.text(context, title, 16f, Color.WHITE, true)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        right.addView(t)
        val s = Ui.text(context, sub, 12f, Ui.SUB)
        s.maxLines = 1
        s.ellipsize = TextUtils.TruncateAt.END
        right.addView(s)

        // skor besar (menghitung naik)
        val scoreTv = Ui.text(context, String.format(Locale.US, "%07d", 0), 34f, Color.WHITE, true)
        scoreTv.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD))
        val sp1 = LinearLayout.LayoutParams(-2, -2)
        sp1.topMargin = dp(6)
        right.addView(scoreTv, sp1)
        if (newBest && !r.failed) {
            val nb = Ui.text(context, "SKOR TERBAIK BARU", 10f, 0xFFFFD84D.toInt(), true)
            nb.letterSpacing = 0.15f
            right.addView(nb)
        } else {
            right.addView(Ui.text(context, L.t("Terbaik: ", "Best: ") + String.format(Locale.US, "%07d", best), 11.5f, Ui.SUB))
        }

        // akurasi & combo
        val mid = LinearLayout(context)
        mid.orientation = LinearLayout.HORIZONTAL
        fun stat(label: String, value: String) {
            val c = LinearLayout(context)
            c.orientation = LinearLayout.VERTICAL
            c.addView(Ui.text(context, label, 10.5f, Ui.SUB))
            c.addView(Ui.text(context, value, 18f, Color.WHITE, true))
            val cp = LinearLayout.LayoutParams(-2, -2)
            cp.rightMargin = dp(28)
            mid.addView(c, cp)
        }
        stat("Akurasi", String.format(Locale.US, "%.2f%%", r.acc))
        stat("Combo maks", "${r.maxCombo}x")
        val mp = LinearLayout.LayoutParams(-1, -2)
        mp.topMargin = dp(10)
        right.addView(mid, mp)

        // rincian hit
        val grid = LinearLayout(context)
        grid.orientation = LinearLayout.HORIZONTAL
        val names = arrayOf("MAX", "300", "200", "100", "50", L.t("Meleset", "Miss"))
        val cols = intArrayOf(0xFF7FDCFF.toInt(), 0xFFFFD84D.toInt(), 0xFF6FE08A.toInt(), 0xFF4DA3FF.toInt(), 0xFFB0B0C4.toInt(), 0xFFFF5A6A.toInt())
        for (i in names.indices) {
            val cell = LinearLayout(context)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER
            cell.setPadding(0, dp(6), 0, dp(6))
            cell.background = Ui.rounded(0x22FFFFFF, dp(10).toFloat())
            val n = Ui.text(context, "${r.counts[i]}", 15f, Color.WHITE, true)
            n.gravity = Gravity.CENTER
            cell.addView(n)
            val l = Ui.text(context, names[i], 10.5f, cols[i], true)
            l.gravity = Gravity.CENTER
            cell.addView(l)
            val cp = LinearLayout.LayoutParams(0, -2, 1f)
            if (i > 0) cp.leftMargin = dp(6)
            grid.addView(cell, cp)
        }
        val gp = LinearLayout.LayoutParams(-1, -2)
        gp.topMargin = dp(12)
        right.addView(grid, gp)

        // tombol
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        val retry = Ui.button(context, "Ulangi", true, 12) { onRetry() }
        retry.minHeight = dp(42)
        retry.minimumHeight = dp(42)
        retry.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        row.addView(retry, LinearLayout.LayoutParams(0, -2, 1.4f))
        val back = Ui.button(context, "Kembali", false, 12) { onBack() }
        back.minHeight = dp(42)
        back.minimumHeight = dp(42)
        back.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        val bp = LinearLayout.LayoutParams(0, -2, 1f)
        bp.leftMargin = dp(8)
        row.addView(back, bp)
        val rp = LinearLayout.LayoutParams(-1, -2)
        rp.topMargin = dp(14)
        right.addView(row, rp)

        // ---- animasi masuk ----
        alpha = 0f
        card.scaleX = 0.94f
        card.scaleY = 0.94f
        animate().alpha(1f).setDuration(220).start()
        card.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        badge.scaleX = 1.7f
        badge.scaleY = 1.7f
        badge.alpha = 0f
        badge.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(260).setDuration(420)
            .setInterpolator(OvershootInterpolator(1.2f)).start()
        val a = ValueAnimator.ofInt(0, r.score)
        a.duration = 1000
        a.startDelay = 200
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener { scoreTv.text = String.format(Locale.US, "%07d", it.animatedValue as Int) }
        a.start()
    }
}
