package com.maniadroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Pengelola Versus online (satu per aplikasi): koneksi WebSocket ke server Versus, status room, siaran skor lawan,
 * dan hasil akhir. Semua callback ke [listener] dijalankan di thread utama.
 */
object Versus : WsClient.Listener {
    class Player(val id: String) {
        var name = ""
        var avatar = ""
        var ready = false
        var state = "lobby"
        var score = 0
        var acc = 100f
        var combo = 0
        var hp = 1f
        var prog = 0f
        var finished = false
    }

    class ChartInfo(val setId: Int, val title: String, val artist: String, val creator: String, val version: String, val keys: Int, val notes: Int)

    class Rank(val id: String, val name: String, val score: Int, val acc: Float, val maxCombo: Int, val failed: Boolean, val left: Boolean)

    interface Listener {
        fun onStatus(text: String) {}
        fun onRoom() {}
        fun onScores() {}
        fun onStart() {}
        fun onResults() {}
        fun onError(msg: String) {}
    }

    private val main = Handler(Looper.getMainLooper())
    var listener: Listener? = null
    private var ws: WsClient? = null

    @Volatile var connected = false
    @Volatile var connecting = false
    var myId = ""
    var code = ""
    var hostId = ""
    var state = "lobby"
    var chart: ChartInfo? = null
    val players = ArrayList<Player>()
    var results: List<Rank>? = null
    var offsetMs = 0L           // jam server - jam HP (ms)
    var startNano = 0L          // System.nanoTime() saat detik 0 lagu (semua pemain disamakan)
    var inGame = false          // GameActivity Versus sedang terbuka
    private var bestRtt = Long.MAX_VALUE
    private var keepAlive: Runnable? = null

    val inRoom: Boolean get() = code.isNotEmpty()
    val isHost: Boolean get() = inRoom && hostId == myId
    val me: Player? get() = players.firstOrNull { it.id == myId }

    fun displayName(): String = Settings.vsName.ifBlank { OsuAccount.name }.ifBlank { "Pemain" }

    /** Rapikan alamat yang diketik pengguna: tambah wss:// (atau ws:// untuk IP / localhost), ganti http(s):// ke ws(s)://. */
    fun normalizeUrl(raw: String): String {
        var u = raw.trim()
        if (u.isEmpty()) return u
        u = u.replace("https://", "wss://").replace("http://", "ws://")
        if (!u.startsWith("ws://") && !u.startsWith("wss://")) {
            val host = u.substringBefore('/').substringBefore(':')
            val local = host == "localhost" || Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host)
            u = (if (local) "ws://" else "wss://") + u
        }
        return u
    }

    // ---------- koneksi ----------
    fun connect() {
        if (connected || connecting) return
        val url = normalizeUrl(Settings.vsServer)
        if (url.isEmpty()) {
            post { listener?.onStatus(L.t("Alamat server belum diisi", "Server address not set")) }
            return
        }
        connecting = true
        bestRtt = Long.MAX_VALUE
        post { listener?.onStatus(L.t("Menghubungkan…", "Connecting…")) }
        val c = WsClient(url, this)
        ws = c
        c.connect()
    }

    fun disconnect() {
        keepAlive?.let { main.removeCallbacks(it) }
        keepAlive = null
        val c = ws
        ws = null
        connected = false
        connecting = false
        resetRoom()
        c?.close()
    }

    private fun resetRoom() {
        code = ""
        hostId = ""
        state = "lobby"
        chart = null
        players.clear()
        results = null
        inGame = false
    }

    private fun post(r: () -> Unit) {
        main.post(r)
    }

    private fun send(o: JSONObject) {
        ws?.send(o.toString())
    }

    override fun onOpen() {
        val o = JSONObject().put("t", "hello").put("name", displayName()).put("avatar", OsuAccount.avatar)
        send(o)
    }

    override fun onClosed(reason: String) {
        post {
            val was = connected || connecting
            connected = false
            connecting = false
            ws = null
            keepAlive?.let { main.removeCallbacks(it) }
            keepAlive = null
            val hadRoom = inRoom
            resetRoom()
            if (was) {
                listener?.onStatus(L.t("Terputus: $reason", "Disconnected: $reason"))
                if (hadRoom) listener?.onRoom()
            }
        }
    }

    override fun onText(text: String) {
        val m = try {
            JSONObject(text)
        } catch (e: Exception) {
            return
        }
        post { handle(m) }
    }

    private fun pingNow() {
        send(JSONObject().put("t", "ping").put("c", System.currentTimeMillis()))
    }

    private fun handle(m: JSONObject) {
        when (m.optString("t")) {
            "hello" -> {
                myId = m.optString("id")
                connected = true
                connecting = false
                // ukur selisih jam server (beberapa kali ping, ambil yang paling cepat) supaya mulai bersamaan
                for (i in 0 until 4) main.postDelayed({ pingNow() }, i * 200L)
                val ka = object : Runnable {
                    override fun run() {
                        if (!connected) return
                        pingNow()
                        main.postDelayed(this, 20000)
                    }
                }
                keepAlive = ka
                main.postDelayed(ka, 20000)
                listener?.onStatus(L.t("Terhubung", "Connected"))
            }
            "pong" -> {
                val c = m.optLong("c")
                val s = m.optLong("s")
                val now = System.currentTimeMillis()
                val rtt = now - c
                if (rtt in 0 until bestRtt) {
                    bestRtt = rtt
                    offsetMs = s - (c + rtt / 2)
                }
            }
            "room" -> {
                code = m.optString("code")
                hostId = m.optString("host")
                state = m.optString("state", "lobby")
                val ch = m.optJSONObject("chart")
                chart = if (ch == null) null else ChartInfo(
                    ch.optInt("setId"), ch.optString("title"), ch.optString("artist"), ch.optString("creator"),
                    ch.optString("version"), ch.optInt("keys", 4), ch.optInt("notes")
                )
                val arr = m.optJSONArray("players") ?: JSONArray()
                val keep = HashMap<String, Player>()
                for (p in players) keep[p.id] = p
                players.clear()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val p = keep[o.optString("id")] ?: Player(o.optString("id"))
                    p.name = o.optString("name")
                    p.avatar = o.optString("avatar")
                    p.ready = o.optBoolean("ready")
                    p.state = o.optString("state", "lobby")
                    p.finished = p.state == "finished"
                    p.score = o.optInt("score")
                    p.acc = o.optDouble("acc", 100.0).toFloat()
                    p.combo = o.optInt("combo")
                    p.hp = o.optDouble("hp", 1.0).toFloat()
                    p.prog = o.optDouble("prog", 0.0).toFloat()
                    players.add(p)
                }
                listener?.onRoom()
            }
            "left" -> {
                resetRoom()
                listener?.onRoom()
            }
            "start" -> {
                val at = m.optLong("at")
                val serverNowEst = System.currentTimeMillis() + offsetMs
                startNano = System.nanoTime() + (at - serverNowEst) * 1_000_000L
                results = null
                listener?.onStart()
            }
            "scores" -> {
                val arr = m.optJSONArray("p") ?: return
                for (i in 0 until arr.length()) {
                    val a = arr.optJSONArray(i) ?: continue
                    val p = players.firstOrNull { it.id == a.optString(0) } ?: continue
                    p.score = a.optInt(1)
                    p.acc = a.optDouble(2, 100.0).toFloat()
                    p.combo = a.optInt(3)
                    p.hp = a.optDouble(4, 1.0).toFloat()
                    p.prog = a.optDouble(5, 0.0).toFloat()
                    p.finished = a.optInt(6) == 1
                }
                listener?.onScores()
            }
            "results" -> {
                val arr = m.optJSONArray("ranking") ?: JSONArray()
                val out = ArrayList<Rank>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    out.add(
                        Rank(
                            o.optString("id"), o.optString("name"), o.optInt("score"), o.optDouble("acc", 0.0).toFloat(),
                            o.optInt("maxCombo"), o.optBoolean("failed"), o.optBoolean("left")
                        )
                    )
                }
                results = out
                listener?.onResults()
            }
            "error" -> listener?.onError(m.optString("msg"))
        }
    }

    // ---------- aksi ----------
    fun createRoom() = send(JSONObject().put("t", "create"))
    fun joinRoom(c: String) = send(JSONObject().put("t", "join").put("code", c.trim().uppercase()))
    fun leaveRoom() {
        send(JSONObject().put("t", "leave"))
        resetRoom()
    }

    fun setReady(r: Boolean) = send(JSONObject().put("t", "ready").put("ready", r))
    fun start() = send(JSONObject().put("t", "start"))

    fun setChart(setId: Int, bm: Beatmap) {
        send(
            JSONObject().put("t", "chart").put("setId", setId).put("title", bm.title).put("artist", bm.artist)
                .put("creator", bm.creator).put("version", bm.version).put("keys", bm.keys).put("notes", bm.noteCount)
        )
    }

    fun sendScore(score: Int, acc: Float, combo: Int, hp: Float, prog: Float) {
        send(
            JSONObject().put("t", "score").put("score", score).put("acc", acc.toDouble()).put("combo", combo)
                .put("hp", hp.toDouble()).put("prog", prog.toDouble())
        )
    }

    fun sendFinish(r: Result) {
        send(
            JSONObject().put("t", "finish").put("score", r.score).put("acc", r.acc.toDouble()).put("maxCombo", r.maxCombo)
                .put("failed", r.failed).put("counts", JSONArray(r.counts.toList()))
        )
    }

    // ---------- chart ----------
    /** ID set osu! sebuah chart: dari nama folder unduhan (dl_123) atau BeatmapSetID di file .osu. 0 = tidak ada. */
    fun setIdOf(bm: Beatmap): Int {
        val n = bm.dir.name
        if (n.startsWith("dl_")) n.removePrefix("dl_").toIntOrNull()?.let { if (it > 0) return it }
        return if (bm.setId > 0) bm.setId else 0
    }

    /** Cari chart yang sama (set + diff) di perangkat ini. Null = belum ada, harus diunduh. */
    fun findLocal(c: Context, ci: ChartInfo): Beatmap? {
        for (s in Library.scanSets(c)) {
            val byDir = s.dir.name == "dl_${ci.setId}"
            for (m in s.maps) {
                if ((byDir || m.setId == ci.setId) && m.keys == ci.keys && m.version == ci.version) return m
            }
        }
        for (s in Library.scanSets(c)) {
            val byDir = s.dir.name == "dl_${ci.setId}"
            for (m in s.maps) if ((byDir || m.setId == ci.setId) && m.keys == ci.keys) return m
        }
        return null
    }

    // ---------- papan skor di layar main ----------
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG)

    fun drawBoard(cv: Canvas, w: Float, h: Float, dens: Float) {
        if (players.size < 2) return
        val sorted = players.sortedByDescending { it.score }
        val x = 12f * dens
        var y = 96f * dens
        val rowH = 22f * dens
        bp.typeface = Typeface.DEFAULT_BOLD
        bp.textSize = 12f * dens
        for ((i, p) in sorted.withIndex().take(8)) {
            val mine = p.id == myId
            bp.style = Paint.Style.FILL
            bp.color = if (mine) 0x66FF5FA2 else 0x55000000
            cv.drawRoundRect(x, y, x + 168f * dens, y + rowH - 3f * dens, 8f * dens, 8f * dens, bp)
            bp.color = if (p.finished) 0xAAFFFFFF.toInt() else 0xFFFFFFFF.toInt()
            bp.textAlign = Paint.Align.LEFT
            var nm = p.name
            while (nm.length > 3 && bp.measureText(nm) > 84f * dens) nm = nm.dropLast(1)
            cv.drawText("${i + 1}", x + 6f * dens, y + 14f * dens, bp)
            cv.drawText(nm, x + 20f * dens, y + 14f * dens, bp)
            bp.textAlign = Paint.Align.RIGHT
            cv.drawText(if (p.finished) L.t("SELESAI", "DONE") else p.score.toString(), x + 163f * dens, y + 14f * dens, bp)
            y += rowH
        }
    }
}
