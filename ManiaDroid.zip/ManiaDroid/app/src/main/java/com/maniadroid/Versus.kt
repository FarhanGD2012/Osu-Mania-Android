package com.maniadroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Multiplayer ManiaDroid (tanpa akun). Satu HP menjadi host (membuat room dan menjalankan [MpHub]); HP lain bergabung lewat
 * Wi-Fi / hotspot (LAN, tanpa internet) atau lewat internet (relay MQTT publik). Jumlah pemain tidak dibatasi.
 * Semua callback ke [listener] berjalan di thread utama.
 */
object Versus {
    class Player(val id: String) {
        var name = ""
        var team = 0
        var ready = false
        var state = "lobby"
        var score = 0
        var acc = 100f
        var combo = 0
        var hp = 1f
        var prog = 0f
        var finished = false
    }

    class ChartInfo(
        val ck: String, val setId: Int, val title: String, val artist: String, val creator: String,
        val version: String, val keys: Int, val notes: Int, val ownerId: String, val ownerName: String, val ownerIp: String
    )

    class Rank(
        val id: String, val name: String, val team: Int, val score: Int, val acc: Float, val maxCombo: Int,
        val failed: Boolean, val left: Boolean
    )

    interface Listener {
        fun onStatus(text: String) {}
        fun onRoom() {}
        fun onScores() {}
        fun onRoundStart() {}
        fun onResults() {}
        fun onCountdown() {}
        fun onError(msg: String) {}
        fun onClosed(reason: String) {}
    }

    private interface Link {
        fun send(o: JSONObject)
        fun close()
    }

    val matchNames get() = listOf("Head-to-head", "Team versus")
    val queueNames get() = listOf(L.t("Host saja", "Host only"), L.t("Semua pemain", "All players"), L.t("Semua pemain (bergiliran)", "All players (round robin)"))
    val winNames get() = listOf(L.t("Skor", "Score"), L.t("Akurasi", "Accuracy"), L.t("Combo tertinggi", "Max combo"))
    val teamNames get() = listOf(L.t("Merah", "Red"), L.t("Biru", "Blue"))
    val TEAM_COLORS = intArrayOf(0xFFFF5A6E.toInt(), 0xFF4DA3FF.toInt())

    private val main = Handler(Looper.getMainLooper())
    var listener: Listener? = null
    private lateinit var app: Context

    // ---- status koneksi & room ----
    @Volatile var connected = false
    @Volatile var connecting = false
    var status = ""
    var myId = ""
    var code = ""
    var hostId = ""
    var roomName = ""
    var state = "lobby"
    var matchType = 0
    var queueMode = 0
    var winCond = 0
    var autoStart = 0
    var maxPlayers = 0
    var hasPassword = false
    var listed = true
    var viaInternet = false
    var roomPassword = ""     // hanya diketahui host (dipakai dialog pengaturan room)
    var round = 0
    val players = ArrayList<Player>()
    val queue = ArrayList<ChartInfo>()
    var results: List<Rank>? = null
    var teamTotals: DoubleArray? = null
    var resultWc = 0
    var resultMt = 0
    var offsetMs = 0L          // jam host - jam HP ini (ms)
    var startNano = 0L         // System.nanoTime() saat detik 0 lagu (semua pemain disamakan)
    var inGame = false
    var imPlaying = false      // ikut ronde yang sedang berjalan
    var countdownAt = 0L       // jam HP ini (ms) saat mulai otomatis; 0 = tidak ada
    var hostIp: String? = null // alamat HP host bila bergabung lewat LAN
    private var bestRtt = Long.MAX_VALUE
    private var opGen = 0          // naik tiap batal / keluar: hasil thread latar yang basi diabaikan
    private var pingTask: Runnable? = null

    // ---- host ----
    private var hub: MpHub? = null
    private var link: Link? = null
    private var lanServer: LanServer? = null
    private var beacon: LanBeacon? = null
    private var chartServer: ChartServer? = null
    private var mqtt: MqttLite? = null
    private var clientId = ""
    private val sharedDirs = HashMap<String, File>()

    val inRoom: Boolean get() = connected && code.isNotEmpty()
    val isHost: Boolean get() = inRoom && hostId == myId
    val me: Player? get() = players.firstOrNull { it.id == myId }
    val chart: ChartInfo? get() = queue.firstOrNull()

    fun init(c: Context) {
        if (!::app.isInitialized) app = c.applicationContext
    }

    fun displayName(): String {
        // sudah masuk ke akun lokal: pakai nama akun
        Accounts.current()?.let { return it.name.take(24) }
        var n = Settings.vsName.trim()
        if (n.isEmpty()) {
            n = "Pemain" + (100 + java.util.Random().nextInt(900))
            Settings.vsName = n
        }
        return n.take(24)
    }

    private fun post(r: () -> Unit) {
        main.post(r)
    }

    private fun status(s: String) {
        status = s
        listener?.onStatus(s)
    }

    // ============================================================ HOST
    /** Buat room. Berjalan di thread latar; hasilnya lewat listener (onRoom bila berhasil, onClosed / onError bila gagal). */
    fun host(c: Context, st: MpSettings) {
        init(c)
        if (connected || connecting) return
        connecting = true
        val gen = ++opGen
        status(L.t("Membuat room…", "Creating room…"))
        Thread {
            var mq: MqttLite? = null
            var code = ""
            var note = ""
            if (st.internet) {
                for (i in MpConst.BROKERS.indices) {
                    val cd = MpConst.newCode(i)
                    val m = MqttLite("mdh-$cd" + java.util.Random().nextInt(9999))
                    try {
                        val b = MpConst.BROKERS[i]
                        m.connect(b.first, b.second, if (st.listed) MpConst.lobbyTopic(cd) else null)
                        m.subscribe(MpConst.upTopic(cd))
                        mq = m
                        code = cd
                        break
                    } catch (e: Exception) {
                        try {
                            m.close()
                        } catch (x: Exception) {
                        }
                    }
                }
                if (mq == null) {
                    st.internet = false
                    note = L.t("Tidak bisa terhubung ke internet; room hanya untuk jaringan lokal.", "Could not reach the internet; room is local-network only.")
                }
            }
            if (code.isEmpty()) code = MpConst.newCode(0)
            val lanRef = arrayOfNulls<LanServer>(1)
            val h = MpHub(code, st, displayName(), { s -> post { try { onMessage(JSONObject(s)) } catch (e: Exception) { } } }, mq, { lanRef[0]?.port ?: 0 })
            val lan = LanServer({ cn, line -> h.fromLan(cn, line) }, { cn -> h.onLanDrop(cn) })
            lanRef[0] = lan
            val lp = lan.start()
            val bc = LanBeacon { h.beacon }
            if (lp > 0) bc.start()
            val cs = ChartServer { key -> serveZip(key) }
            cs.start()
            if (mq != null) {
                val up = MpConst.upTopic(code)
                mq.listener = object : MqttLite.Listener {
                    override fun onMessage(topic: String, payload: ByteArray) {
                        if (topic == up) h.fromMqtt(payload)
                    }

                    override fun onClosed(reason: String) {
                        post { if (hub === h) status(L.t("Koneksi internet terputus (pemain lewat Wi-Fi tetap jalan)", "Internet connection lost (Wi-Fi players keep going)")) }
                    }
                }
            }
            post {
                if (gen != opGen) { // dibatalkan saat room sedang dibuat
                    h.close()
                    lan.stop()
                    bc.stop()
                    cs.stop()
                    return@post
                }
                hub = h
                lanServer = lan
                beacon = bc
                chartServer = cs
                mqtt = mq
                link = object : Link {
                    override fun send(o: JSONObject) = h.fromLocal(o)
                    override fun close() {}
                }
                myId = MpHub.LOCAL_ID
                hostIp = null
                viaInternet = st.internet
                roomPassword = st.password
                connected = true
                connecting = false
                offsetMs = 0
                status(if (note.isNotEmpty()) note else L.t("Room dibuat", "Room created"))
                listener?.onRoom()
                if (lp <= 0) listener?.onError(L.t("Port jaringan lokal tidak bisa dibuka; hanya internet yang tersedia.", "Could not open the local network port; only internet is available."))
            }
        }.start()
    }

    // ============================================================ GABUNG
    fun joinLan(c: Context, ip: String, port: Int, password: String) {
        init(c)
        if (connected || connecting) return
        connecting = true
        val gen = ++opGen
        status(L.t("Menghubungkan ke $ip…", "Connecting to $ip…"))
        Thread {
            try {
                val cn = LanClient.connect(ip, port, 4000,
                    { line -> post { try { onMessage(JSONObject(line)) } catch (e: Exception) { } } },
                    { post { if (connected || connecting) linkDown(L.t("Koneksi ke host terputus", "Connection to host lost")) } })
                val lk = object : Link {
                    override fun send(o: JSONObject) = cn.send(o.toString())
                    override fun close() = cn.closeSoft() // pesan "leave" yang masih antre sempat terkirim
                }
                post {
                    if (gen != opGen) {
                        cn.close()
                        return@post
                    }
                    link = lk
                    hostIp = ip
                    viaInternet = false
                    lk.send(JSONObject().put("t", "hello").put("name", displayName()).put("pw", password))
                    main.postDelayed({
                        if (connecting && link === lk) linkDown(L.t("Host tidak menjawab", "Host did not answer"))
                    }, 6000)
                }
            } catch (e: Exception) {
                post {
                    if (gen != opGen) return@post
                    connecting = false
                    listener?.onClosed(L.t("Tidak bisa terhubung ke $ip. Pastikan satu Wi-Fi / hotspot dan room masih ada.", "Could not connect to $ip. Make sure you are on the same Wi-Fi / hotspot and the room still exists."))
                }
            }
        }.start()
    }

    fun joinInternet(c: Context, rawCode: String, password: String) {
        init(c)
        if (connected || connecting) return
        val cd = rawCode.trim().uppercase()
        val bi = MpConst.brokerIndexOf(cd)
        if (cd.length != 6 || bi < 0) {
            listener?.onError(L.t("Kode room tidak valid (6 karakter, contoh A7K2QM)", "Invalid room code (6 characters, e.g. A7K2QM)"))
            return
        }
        connecting = true
        val gen = ++opGen
        status(L.t("Menghubungkan lewat internet…", "Connecting over the internet…"))
        clientId = "mdc" + java.lang.Long.toHexString(java.util.Random().nextLong()).take(10)
        Thread {
            val m = MqttLite("mdc-$clientId")
            try {
                val b = MpConst.BROKERS[bi]
                m.connect(b.first, b.second, null)
                val down = MpConst.downTopic(cd)
                m.listener = object : MqttLite.Listener {
                    override fun onMessage(topic: String, payload: ByteArray) {
                        if (topic != down) return
                        try {
                            val o = JSONObject(String(payload, Charsets.UTF_8))
                            val to = o.optString("to")
                            if (to.isNotEmpty() && to != clientId) return
                            post { onMessage(o) }
                        } catch (e: Exception) {
                        }
                    }

                    override fun onClosed(reason: String) {
                        post { if (mqtt === m && (connected || connecting)) linkDown(L.t("Koneksi internet terputus", "Internet connection lost")) }
                    }
                }
                m.subscribe(down)
                val lk = object : Link {
                    override fun send(o: JSONObject) {
                        try {
                            m.publish(MpConst.upTopic(cd), o.put("id", clientId).toString())
                        } catch (e: Exception) {
                        }
                    }

                    override fun close() = m.close()
                }
                post {
                    if (gen != opGen) {
                        m.close()
                        return@post
                    }
                    mqtt = m
                    link = lk
                    hostIp = null
                    viaInternet = true
                    myId = clientId
                    lk.send(JSONObject().put("t", "hello").put("name", displayName()).put("pw", password))
                    main.postDelayed({
                        if (connecting && link === lk) linkDown(L.t("Room $cd tidak ditemukan atau host tidak menjawab", "Room $cd not found or host not answering"))
                    }, 9000)
                }
            } catch (e: Exception) {
                try {
                    m.close()
                } catch (x: Exception) {
                }
                post {
                    if (gen != opGen) return@post
                    connecting = false
                    listener?.onClosed(L.t("Tidak bisa terhubung ke internet (${e.message ?: "gagal"})", "Could not connect to the internet (${e.message ?: "failed"})"))
                }
            }
        }.start()
    }

    // ============================================================ KELUAR
    private fun linkDown(reason: String) {
        teardown()
        listener?.onClosed(reason)
    }

    fun leave() {
        try {
            if (hub == null) link?.send(JSONObject().put("t", "leave"))
        } catch (e: Exception) {
        }
        teardown()
    }

    private fun teardown() {
        opGen++
        pingTask?.let { main.removeCallbacks(it) }
        pingTask = null
        try {
            hub?.close()
        } catch (e: Exception) {
        }
        try {
            link?.close()
        } catch (e: Exception) {
        }
        try {
            beacon?.stop()
            lanServer?.stop()
            chartServer?.stop()
        } catch (e: Exception) {
        }
        if (hub == null) try {
            mqtt?.close()
        } catch (e: Exception) {
        }
        hub = null
        link = null
        beacon = null
        lanServer = null
        chartServer = null
        mqtt = null
        connected = false
        connecting = false
        code = ""
        hostId = ""
        state = "lobby"
        players.clear()
        queue.clear()
        results = null
        teamTotals = null
        inGame = false
        imPlaying = false
        countdownAt = 0
        round = 0
        myId = ""
        sharedDirs.clear()
    }

    // ============================================================ PESAN MASUK (thread utama)
    private fun pingNow() {
        link?.send(JSONObject().put("t", "ping").put("c", System.currentTimeMillis()))
    }

    private fun startPings() {
        pingTask?.let { main.removeCallbacks(it) }
        bestRtt = Long.MAX_VALUE
        for (i in 0 until 4) main.postDelayed({ if (connected) pingNow() }, i * 250L)
        val t = object : Runnable {
            override fun run() {
                if (!connected) return
                pingNow()
                main.postDelayed(this, 5000)
            }
        }
        pingTask = t
        main.postDelayed(t, 5000)
    }

    private fun onMessage(m: JSONObject) {
        when (m.optString("t")) {
            "welcome" -> {
                if (hub == null) myId = m.optString("id", myId)
                connected = true
                connecting = false
                offsetMs = 0
                if (hub == null) startPings()
                status(L.t("Terhubung", "Connected"))
            }
            "pong" -> {
                val c = m.optLong("c")
                val s = m.optLong("s")
                val now = System.currentTimeMillis()
                val rtt = now - c
                if (rtt in 0 until bestRtt) {
                    bestRtt = rtt
                    offsetMs = s - (c + rtt / 2)
                }
            }
            "room" -> {
                if (!connected && !connecting) return
                code = m.optString("code")
                roomName = m.optString("name")
                hostId = m.optString("host")
                state = m.optString("st", "lobby")
                matchType = m.optInt("mt")
                queueMode = m.optInt("qm")
                winCond = m.optInt("wc")
                autoStart = m.optInt("as")
                maxPlayers = m.optInt("mx")
                hasPassword = m.optBoolean("pw")
                listed = m.optBoolean("ls", true)
                round = m.optInt("round")
                if (hub != null) connected = true
                val arr = m.optJSONArray("players") ?: JSONArray()
                val keep = HashMap<String, Player>()
                for (p in players) keep[p.id] = p
                players.clear()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val p = keep[o.optString("id")] ?: Player(o.optString("id"))
                    p.name = o.optString("n")
                    p.team = o.optInt("tm")
                    p.ready = o.optBoolean("rd")
                    p.state = o.optString("s", "lobby")
                    p.finished = p.state == "finished"
                    p.score = o.optInt("sc")
                    p.acc = o.optDouble("ac", 100.0).toFloat()
                    p.combo = o.optInt("cb")
                    p.hp = o.optDouble("hp", 1.0).toFloat()
                    p.prog = o.optDouble("pr", 0.0).toFloat()
                    players.add(p)
                }
                queue.clear()
                val qa = m.optJSONArray("queue") ?: JSONArray()
                for (i in 0 until qa.length()) {
                    val o = qa.optJSONObject(i) ?: continue
                    queue.add(
                        ChartInfo(
                            o.optString("ck"), o.optInt("sid"), o.optString("ti"), o.optString("ar"), o.optString("cr"),
                            o.optString("v"), o.optInt("k", 4), o.optInt("n"), o.optString("o"), o.optString("on"), o.optString("oi")
                        )
                    )
                }
                listener?.onRoom()
            }
            "cd" -> {
                val at = m.optLong("at")
                countdownAt = if (at == 0L) 0L else at - offsetMs
                listener?.onCountdown()
            }
            "start" -> {
                val at = m.optLong("at")
                val parts = m.optJSONArray("parts") ?: JSONArray()
                var mine = false
                for (i in 0 until parts.length()) if (parts.optString(i) == myId) mine = true
                imPlaying = mine
                countdownAt = 0
                val hostNowEst = System.currentTimeMillis() + offsetMs
                startNano = System.nanoTime() + (at - hostNowEst) * 1_000_000L
                results = null
                teamTotals = null
                listener?.onRoundStart()
            }
            "scores" -> {
                val arr = m.optJSONArray("p") ?: return
                for (i in 0 until arr.length()) {
                    val a = arr.optJSONArray(i) ?: continue
                    val p = players.firstOrNull { it.id == a.optString(0) } ?: continue
                    p.score = a.optInt(1)
                    p.acc = a.optDouble(2, 100.0).toFloat()
                    p.combo = a.optInt(3)
                    p.hp = a.optDouble(4, 1.0).toFloat()
                    p.prog = a.optDouble(5, 0.0).toFloat()
                    p.finished = a.optInt(6) == 1
                }
                listener?.onScores()
            }
            "results" -> {
                val arr = m.optJSONArray("ranking") ?: JSONArray()
                val out = ArrayList<Rank>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    out.add(
                        Rank(
                            o.optString("id"), o.optString("name"), o.optInt("team"), o.optInt("score"), o.optDouble("acc", 0.0).toFloat(),
                            o.optInt("maxCombo"), o.optBoolean("failed"), o.optBoolean("left")
                        )
                    )
                }
                resultWc = m.optInt("wc")
                resultMt = m.optInt("mt")
                val tj = m.optJSONArray("teams")
                teamTotals = if (tj == null) null else doubleArrayOf(tj.optDouble(0), tj.optDouble(1))
                results = out
                listener?.onResults()
            }
            "error" -> {
                val msg = m.optString("msg")
                if (m.optBoolean("fatal")) {
                    teardown()
                    listener?.onClosed(msg)
                } else listener?.onError(msg)
            }
            "kicked" -> {
                teardown()
                listener?.onClosed(L.t("Kamu dikeluarkan dari room", "You were removed from the room"))
            }
            "closed" -> {
                if (hub == null) {
                    teardown()
                    listener?.onClosed(L.t("Host menutup room", "The host closed the room"))
                }
            }
            "left" -> teardown()
        }
    }

    // ============================================================ AKSI
    private fun send(o: JSONObject) {
        link?.send(o)
    }

    fun setReady(r: Boolean) = send(JSONObject().put("t", "ready").put("ready", r))
    fun start() = send(JSONObject().put("t", "start"))
    fun setTeam(t: Int) = send(JSONObject().put("t", "team").put("team", t))
    fun removeQueue(i: Int) = send(JSONObject().put("t", "unq").put("i", i))
    fun kick(id: String) = send(JSONObject().put("t", "kick").put("id", id))
    fun updateSettings(o: JSONObject) {
        if (o.has("pw")) roomPassword = o.optString("pw")
        send(o.put("t", "settings"))
    }

    fun sendScore(score: Int, acc: Float, combo: Int, hp: Float, prog: Float) {
        send(
            JSONObject().put("t", "score").put("score", score).put("acc", acc.toDouble()).put("combo", combo)
                .put("hp", hp.toDouble()).put("prog", prog.toDouble())
        )
    }

    fun sendFinish(r: Result) {
        send(
            JSONObject().put("t", "finish").put("score", r.score).put("acc", r.acc.toDouble()).put("maxCombo", r.maxCombo)
                .put("failed", r.failed).put("counts", JSONArray(r.counts.toList()))
        )
    }

    // ============================================================ CHART
    /** Kunci isi chart: sama di semua HP selama isi chart sama (dipakai sebagai nama transfer LAN). */
    fun chartKey(bm: Beatmap): String {
        val raw = "${bm.title}|${bm.artist}|${bm.creator}|${bm.version}|${bm.keys}|${bm.noteCount}"
        val d = MessageDigest.getInstance("MD5").digest(raw.toByteArray(Charsets.UTF_8))
        return d.joinToString("") { "%02x".format(it) }.take(20)
    }

    /** ID set osu! sebuah chart: dari nama folder unduhan (dl_123) atau BeatmapSetID di file .osu. 0 = tidak ada. */
    fun setIdOf(bm: Beatmap): Int {
        val n = bm.dir.name
        if (n.startsWith("dl_")) n.removePrefix("dl_").toIntOrNull()?.let { if (it > 0) return it }
        return if (bm.setId > 0) bm.setId else 0
    }

    /** Ajukan chart ke room (host: mengganti chart; mode semua pemain: menambah ke antrean). */
    fun addChart(c: Context, bm: Beatmap) {
        init(c)
        val ck = chartKey(bm)
        sharedDirs[ck] = bm.dir
        if (chartServer == null) {
            val cs = ChartServer { key -> serveZip(key) }
            cs.start()
            chartServer = cs
        }
        send(
            JSONObject().put("t", "chart").put("ck", ck).put("sid", setIdOf(bm)).put("ti", bm.title).put("ar", bm.artist)
                .put("cr", bm.creator).put("v", bm.version).put("k", bm.keys).put("n", bm.noteCount)
        )
    }

    private fun serveZip(key: String): File? {
        val dir = sharedDirs[key] ?: return null
        if (!::app.isInitialized) return null
        synchronized(this) {
            val z = File(app.cacheDir, "mp_$key.zip")
            if (z.isFile && z.length() > 0) return z
            return try {
                ZipOutputStream(FileOutputStream(z)).use { zo ->
                    zo.setLevel(Deflater.BEST_SPEED)
                    for (f in dir.walkTopDown().maxDepth(3)) {
                        if (!f.isFile) continue
                        zo.putNextEntry(ZipEntry(f.relativeTo(dir).path.replace('\\', '/')))
                        FileInputStream(f).use { it.copyTo(zo, 65536) }
                        zo.closeEntry()
                    }
                }
                z
            } catch (e: Exception) {
                z.delete()
                null
            }
        }
    }

    /** Cari chart yang sama di perangkat ini. Null = belum ada. Panggil dari thread latar. */
    fun findLocal(c: Context, ci: ChartInfo): Beatmap? {
        val sets = Library.scanSets(c)
        if (ci.setId > 0) for (s in sets) {
            val byDir = s.dir.name == "dl_${ci.setId}"
            for (m in s.maps) if ((byDir || m.setId == ci.setId) && m.keys == ci.keys && m.version == ci.version) return m
        }
        for (s in sets) for (m in s.maps) {
            if (m.keys == ci.keys && m.version == ci.version && m.title == ci.title && m.artist == ci.artist &&
                m.creator == ci.creator && m.noteCount == ci.notes
            ) return m
        }
        if (ci.setId > 0) for (s in sets) {
            val byDir = s.dir.name == "dl_${ci.setId}"
            for (m in s.maps) if ((byDir || m.setId == ci.setId) && m.keys == ci.keys) return m
        }
        return null
    }

    /**
     * Ambil chart yang belum ada: pertama langsung dari HP pemilihnya lewat Wi-Fi / hotspot (cepat, tanpa internet),
     * kalau tidak bisa dan chart punya ID osu!, unduh dari mirror. Panggil dari thread latar; lempar Exception bila gagal.
     */
    fun fetchChart(c: Context, ci: ChartInfo, progress: (String) -> Unit) {
        val ips = ArrayList<String>()
        if (ci.ownerIp.isNotEmpty()) ips.add(ci.ownerIp)
        hostIp?.let { if (!ips.contains(it)) ips.add(it) }
        val tmp = File(c.cacheDir, "mp_${ci.ck}.osz")
        try {
            for (ip in ips) {
                progress(L.t("Mengambil dari $ip…", "Fetching from $ip…"))
                val ok = ChartFetch.fetch(ip, MpConst.FILE_PORT, ci.ck, tmp) { got, total ->
                    progress(String.format(java.util.Locale.US, "%05.2f%%", got * 100.0 / total))
                }
                if (ok) {
                    progress(L.t("Mengimpor…", "Importing…"))
                    val n = Library.importOsz(c, "mp_${ci.ck}") { FileInputStream(tmp) }
                    if (n > 0) return
                }
            }
        } finally {
            tmp.delete()
        }
        if (ci.setId > 0) {
            Downloader.download(c, ci.setId, progress)
            return
        }
        throw java.io.IOException(L.t("Chart ini tidak bisa diambil: tidak ada jalur LAN ke pemiliknya dan chart tidak punya ID osu!", "Cannot fetch this chart: no LAN route to its owner and it has no osu! ID"))
    }

    // ============================================================ PAPAN SKOR DI LAYAR MAIN
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun metricOf(p: Player): Double = when (winCond) {
        1 -> p.acc.toDouble()
        2 -> p.combo.toDouble()
        else -> p.score.toDouble()
    }

    private fun metricText(p: Player): String = when (winCond) {
        1 -> String.format(java.util.Locale.US, "%.2f%%", p.acc)
        2 -> "${p.combo}x"
        else -> p.score.toString()
    }

    fun drawBoard(cv: Canvas, w: Float, h: Float, dens: Float) {
        val live = players.filter { it.state != "lobby" }
        if (live.size < 2) return
        val sorted = live.sortedByDescending { metricOf(it) }
        val x = 12f * dens
        var y = 96f * dens
        val rowH = 22f * dens
        bp.typeface = Typeface.DEFAULT_BOLD
        bp.textSize = 12f * dens
        val maxRows = 7
        val shown = ArrayList<Pair<Int, Player>>()
        for ((i, p) in sorted.withIndex()) if (i < maxRows) shown.add(Pair(i, p))
        val mi = sorted.indexOfFirst { it.id == myId }
        if (mi >= maxRows) shown.add(Pair(mi, sorted[mi]))
        if (matchType == 1) {
            val t0 = live.filter { it.team == 0 }.sumOf { metricOf(it) } / (if (winCond == 1) maxOf(1, live.count { it.team == 0 }) else 1)
            val t1 = live.filter { it.team == 1 }.sumOf { metricOf(it) } / (if (winCond == 1) maxOf(1, live.count { it.team == 1 }) else 1)
            bp.style = Paint.Style.FILL
            bp.color = 0x66000000
            cv.drawRoundRect(x, y, x + 168f * dens, y + rowH - 3f * dens, 8f * dens, 8f * dens, bp)
            bp.textAlign = Paint.Align.LEFT
            bp.color = TEAM_COLORS[0]
            cv.drawText(fmtTeam(t0), x + 8f * dens, y + 14f * dens, bp)
            bp.textAlign = Paint.Align.RIGHT
            bp.color = TEAM_COLORS[1]
            cv.drawText(fmtTeam(t1), x + 163f * dens, y + 14f * dens, bp)
            y += rowH
        }
        for ((i, p) in shown) {
            val mine = p.id == myId
            bp.style = Paint.Style.FILL
            bp.color = if (mine) 0x66FF5FA2 else 0x55000000
            cv.drawRoundRect(x, y, x + 168f * dens, y + rowH - 3f * dens, 8f * dens, 8f * dens, bp)
            if (matchType == 1) {
                bp.color = TEAM_COLORS[p.team.coerceIn(0, 1)]
                cv.drawRoundRect(x, y, x + 4f * dens, y + rowH - 3f * dens, 2f * dens, 2f * dens, bp)
            }
            bp.color = if (p.finished) 0xAAFFFFFF.toInt() else 0xFFFFFFFF.toInt()
            bp.textAlign = Paint.Align.LEFT
            var nm = p.name
            while (nm.length > 3 && bp.measureText(nm) > 78f * dens) nm = nm.dropLast(1)
            cv.drawText("${i + 1}", x + 8f * dens, y + 14f * dens, bp)
            cv.drawText(nm, x + 24f * dens, y + 14f * dens, bp)
            bp.textAlign = Paint.Align.RIGHT
            cv.drawText(if (p.finished) L.t("SELESAI", "DONE") else metricText(p), x + 163f * dens, y + 14f * dens, bp)
            y += rowH
        }
    }

    private fun fmtTeam(v: Double): String = when (winCond) {
        1 -> String.format(java.util.Locale.US, "%.2f%%", v)
        2 -> "${v.toInt()}x"
        else -> v.toInt().toString()
    }
}
