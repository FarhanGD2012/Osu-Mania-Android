package com.maniadroid

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Layar hasil Versus di atas game: "menunggu pemain lain" lalu papan peringkat akhir. */
class VersusResultOverlay(ctx: Context, private val onBack: () -> Unit) : FrameLayout(ctx) {
    private val list = LinearLayout(ctx)
    private val title: TextView
    private val sub: TextView
    private val btn: TextView
    private fun dp(v: Int) = Ui.dp(context, v)

    init {
        isClickable = true // penelan sentuhan: jangan tembus ke game di bawahnya
        setBackgroundColor(0xEB0B0A12.toInt())
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20), dp(16), dp(20), dp(16))
        box.background = Ui.rounded(0xCC15142A.toInt(), dp(20).toFloat())
        title = Ui.text(ctx, "Selesai!", 26f, Color.WHITE, true)
        sub = Ui.text(ctx, "Menunggu pemain lain selesai…", 13f, Ui.ACCENT, true)
        box.addView(title)
        box.addView(sub, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = dp(2) })
        list.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        box.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f).also { it.topMargin = dp(10) })
        btn = Ui.text(ctx, "Kembali ke lobi", 15f, Color.WHITE, true)
        btn.gravity = Gravity.CENTER
        btn.background = Ui.ripple(Ui.lazerFill(Ui.ACCENT, dp(24).toFloat(), false, ctx))
        btn.setOnClickListener { onBack() }
        box.addView(btn, LinearLayout.LayoutParams(-1, dp(46)).also { it.topMargin = dp(10) })
        val w = minOf(dp(560), ctx.resources.displayMetrics.widthPixels - dp(40))
        val h = ctx.resources.displayMetrics.heightPixels - dp(30)
        addView(box, LayoutParams(w, h, Gravity.CENTER))
    }

    fun waiting(score: Int, acc: Float) {
        title.text = L.t("Selesai!", "Finished!")
        sub.text = L.t("Skormu $score  ·  ${String.format(java.util.Locale.US, "%.2f", acc)}%  —  menunggu pemain lain…", "Your score $score  ·  ${String.format(java.util.Locale.US, "%.2f", acc)}%  —  waiting for others…")
    }

    fun show(ranks: List<Versus.Rank>, myId: String) {
        title.text = L.t("Hasil Versus", "Versus results")
        val mine = ranks.indexOfFirst { it.id == myId }
        sub.text = if (mine == 0 && ranks.size > 1) L.t("Kamu juara 1!", "You won!") else if (mine >= 0) L.t("Peringkatmu: #${mine + 1}", "Your rank: #${mine + 1}") else ""
        list.removeAllViews()
        for ((i, r) in ranks.withIndex()) {
            val row = LinearLayout(context)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(8), dp(12), dp(8))
            row.background = Ui.rounded(if (r.id == myId) 0x50FF5FA2 else 0x40FFFFFF, dp(14).toFloat())
            val medal = when (i) {
                0 -> 0xFFFFD34D.toInt()
                1 -> 0xFFD0D4E0.toInt()
                2 -> 0xFFD9915A.toInt()
                else -> 0xFF9A9AB0.toInt()
            }
            row.addView(Ui.text(context, "#${i + 1}", 18f, medal, true), LinearLayout.LayoutParams(dp(46), -2))
            val col = LinearLayout(context)
            col.orientation = LinearLayout.VERTICAL
            col.addView(Ui.text(context, r.name, 15f, Color.WHITE, true).also { it.maxLines = 1; it.ellipsize = android.text.TextUtils.TruncateAt.END })
            val tag = if (r.left) L.t("keluar di tengah lagu", "left mid-song") else if (r.failed) L.t("gagal (HP habis)", "failed") else ""
            col.addView(
                Ui.text(context, String.format(java.util.Locale.US, "%.2f%%  ·  combo %d", r.acc, r.maxCombo) + (if (tag.isNotEmpty()) "  ·  $tag" else ""), 11.5f, Ui.SUB)
            )
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Ui.text(context, String.format(java.util.Locale.US, "%07d", r.score), 18f, Color.WHITE, true))
            list.addView(row, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = dp(6) })
        }
    }
}
