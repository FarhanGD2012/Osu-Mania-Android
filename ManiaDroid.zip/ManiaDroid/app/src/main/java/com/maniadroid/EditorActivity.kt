package com.maniadroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale

object EditorIO {
    fun noteLine(n: ENote, keys: Int): String {
        val x = (n.col * 512 + 256) / keys
        return if (n.end > n.time) "$x,192,${n.time},128,0,${n.end}:0:0:0:0:" else "$x,192,${n.time},1,0,0:0:0:0:"
    }

    private fun timingLine(base: List<String>?, offset: Double, beatLength: Double): String {
        val q = (base ?: listOf("0", "500", "4", "2", "0", "100", "1", "0")).toMutableList()
        q[0] = Math.round(offset).toString()
        q[1] = String.format(Locale.US, "%.10f", beatLength)
        return q.joinToString(",")
    }

    /** Susun ulang isi .osu: hanya [HitObjects] (dan titik timing pertama bila diubah) yang berganti. */
    fun build(
        raw: List<String>, notes: List<ENote>, keys: Int, newVersion: String?,
        timingChanged: Boolean, offset: Double, beatLength: Double
    ): String {
        val out = StringBuilder()
        var section = ""
        var wroteHO = false
        var timingDone = false
        for ((idx, line0) in raw.withIndex()) {
            val line = if (idx == 0) line0.removePrefix("\uFEFF") else line0
            val t = line.trim()
            if (t.startsWith("[") && t.endsWith("]")) {
                if (section == "[TimingPoints]" && timingChanged && !timingDone) {
                    out.append(timingLine(null, offset, beatLength)).append('\n')
                    timingDone = true
                }
                section = t
                out.append(line).append('\n')
                if (section == "[HitObjects]") {
                    for (n in notes) out.append(noteLine(n, keys)).append('\n')
                    wroteHO = true
                }
                continue
            }
            when (section) {
                "[HitObjects]" -> {
                }
                "[Metadata]" -> {
                    if (newVersion != null && t.startsWith("Version:")) out.append("Version:").append(newVersion).append('\n')
                    else out.append(line).append('\n')
                }
                "[TimingPoints]" -> {
                    val p = t.split(',')
                    val uninh = p.size < 7 || p[6].trim() == "1"
                    if (timingChanged && !timingDone && t.isNotEmpty() && !t.startsWith("//") && p.size >= 2 && uninh) {
                        out.append(timingLine(p, offset, beatLength)).append('\n')
                        timingDone = true
                    } else out.append(line).append('\n')
                }
                else -> out.append(line).append('\n')
            }
        }
        if (!wroteHO) {
            out.append("\n[HitObjects]\n")
            for (n in notes) out.append(noteLine(n, keys)).append('\n')
        }
        return out.toString()
    }
}

class EditorActivity : Activity() {
    private lateinit var view: EditorView
    private var mp: MediaPlayer? = null
    private lateinit var file: File
    private var raw: List<String> = emptyList()
    private var keys = 4
    private var timingChanged = false
    private var dirty = false
    private var testFile: File? = null
    private var meta: Beatmap? = null
    private lateinit var playChip: TextView

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        Sfx.init(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val path = intent.getStringExtra("osu")
        if (path == null) {
            finish()
            return
        }
        file = File(path)
        val bm = Beatmap.parse(file, true)
        if (bm == null) {
            Toast.makeText(this, "Chart tidak bisa dibuka", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        meta = bm
        keys = bm.keys
        raw = file.readLines(Charsets.UTF_8)
        val audio = Library.findFile(bm.dir, bm.audio)
        if (audio == null) {
            Toast.makeText(this, "File audio tidak ditemukan", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val player = MediaPlayer()
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            player.setDataSource(audio.path)
            player.prepare()
            val v = Settings.musicVol / 100f
            player.setVolume(v, v)
        } catch (e: Exception) {
            Toast.makeText(this, "Audio gagal dibuka: ${e.message}", Toast.LENGTH_LONG).show()
            player.release()
            finish()
            return
        }
        mp = player

        val list = ArrayList<ENote>()
        for (n in bm.notes) list.add(ENote(n.col, n.time, n.endTime))
        view = EditorView(this, keys, list, player, player.duration)
        view.beatLength = bm.beatLength
        view.offset = bm.timingOffset
        view.pos = if (list.isNotEmpty()) (list[0].time - 1000.0).coerceAtLeast(0.0) else 0.0
        view.onChange = { dirty = true }
        view.onPlayState = { playing -> playChip.text = if (playing) "⏸" else "▶" }

        val root = FrameLayout(this)
        root.addView(view, Ui.matchParams())
        root.addView(toolbar(), FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        setContentView(root)
        view.begin()
    }

    private fun chip(text: String, onClick: (TextView) -> Unit): TextView {
        val t = Ui.text(this, text, 13f, Ui.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(8), dp(14), dp(8))
        t.background = Ui.ripple(Ui.rounded(Ui.CARD2, dp(18).toFloat()))
        t.setOnClickListener { onClick(t) }
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.rightMargin = dp(6)
        t.layoutParams = lp
        return t
    }

    private fun toolbar(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(6), dp(8), dp(6))
        playChip = chip("▶") { view.togglePlay() }
        row.addView(playChip)
        row.addView(chip("Snap 1/${view.divs[view.divIdx]}") { t ->
            view.divIdx = (view.divIdx + 1) % view.divs.size
            t.text = "Snap 1/${view.divs[view.divIdx]}"
        })
        row.addView(chip("Tap") { t ->
            view.mode = (view.mode + 1) % 3
            t.text = arrayOf("Tap", "Hold", "Hapus")[view.mode]
        })
        val zooms = floatArrayOf(0.5f, 0.75f, 1f, 1.5f, 2f, 3f)
        var zi = 2
        row.addView(chip("Zoom 1×") { t ->
            zi = (zi + 1) % zooms.size
            view.zoom = zooms[zi]
            t.text = "Zoom ${zooms[zi]}×"
        })
        val rates = floatArrayOf(1f, 0.75f, 0.5f)
        var ri = 0
        row.addView(chip("Tempo 1×") { t ->
            ri = (ri + 1) % rates.size
            view.rate = rates[ri]
            t.text = "Tempo ${rates[ri]}×"
            if (view.playing) {
                view.pausePlayback()
                view.togglePlay()
            }
        })
        row.addView(chip("Tik ✓") { t ->
            view.tickOn = !view.tickOn
            t.text = if (view.tickOn) "Tik ✓" else "Tik ✗"
        })
        row.addView(chip("BPM / Offset") { timingDialog() })
        row.addView(chip("↶ Urungkan") { view.undoLast() })
        row.addView(chip("▶ Uji") { testPlay() })
        row.addView(chip("💾 Simpan") { saveDialog(false) })
        row.addView(chip("✕") { tryExit() })
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.setBackgroundColor(0xCC11111B.toInt())
        hs.addView(row)
        return hs
    }

    private fun timingDialog() {
        view.pausePlayback()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(12), dp(18), dp(4))
        box.addView(Ui.text(this, "BPM", 12f, Ui.SUB))
        val bpmE = EditText(this)
        bpmE.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        bpmE.setText(String.format(Locale.US, "%.3f", 60000.0 / view.beatLength))
        bpmE.setTextColor(Ui.TEXT)
        box.addView(bpmE)
        box.addView(Ui.text(this, "Offset beat pertama (ms)", 12f, Ui.SUB))
        val offE = EditText(this)
        offE.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED or InputType.TYPE_NUMBER_FLAG_DECIMAL
        offE.setText(Math.round(view.offset).toString())
        offE.setTextColor(Ui.TEXT)
        box.addView(offE)
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Timing (grid beat)")
            .setView(box)
            .setPositiveButton("Terapkan") { _, _ ->
                val bpm = bpmE.text.toString().toDoubleOrNull()
                val off = offE.text.toString().toDoubleOrNull()
                if (bpm != null && bpm in 20.0..999.0) view.beatLength = 60000.0 / bpm
                if (off != null) view.offset = off
                timingChanged = true
                dirty = true
            }
            .setNeutralButton("Offset = posisi sekarang") { _, _ ->
                view.offset = view.pos
                timingChanged = true
                dirty = true
                Toast.makeText(this, "Offset diset ke posisi sekarang", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun buildText(newVersion: String?): String =
        EditorIO.build(raw, view.notes, keys, newVersion, timingChanged, view.offset, view.beatLength)

    private fun testPlay() {
        view.pausePlayback()
        if (view.notes.isEmpty()) {
            Toast.makeText(this, "Belum ada note untuk diuji", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val f = File(file.parentFile, "zz_editor_test.tmp")
            f.writeText(buildText(null), Charsets.UTF_8)
            testFile = f
            startActivity(Intent(this, GameActivity::class.java).putExtra("osu", f.path))
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menyiapkan uji: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveDialog(exitAfter: Boolean) {
        view.pausePlayback()
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Simpan chart")
            .setItems(arrayOf("Simpan (timpa chart ini)", "Simpan sebagai tingkat kesulitan baru…")) { _, i ->
                if (i == 0) {
                    doSave(file, null)
                    if (exitAfter) finish()
                } else {
                    val e = EditText(this)
                    e.setText("${meta?.version ?: "Normal"} (edit)")
                    e.setTextColor(Ui.TEXT)
                    e.setSingleLine(true)
                    val box = LinearLayout(this)
                    box.setPadding(dp(18), dp(10), dp(18), 0)
                    box.addView(e, LinearLayout.LayoutParams(-1, -2))
                    AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                        .setTitle("Nama tingkat kesulitan")
                        .setView(box)
                        .setPositiveButton("Simpan") { _, _ ->
                            val ver = e.text.toString().trim().ifEmpty { "Edit" }
                            val m = meta
                            val base = if (m != null) "${m.artist} - ${m.title} (${m.creator}) [$ver]" else ver
                            val target = File(file.parentFile, Library.safeName(base) + ".osu")
                            doSave(target, ver)
                            if (exitAfter) finish()
                        }
                        .setNegativeButton("Batal", null)
                        .show()
                }
            }
            .show()
    }

    private fun doSave(target: File, newVersion: String?) {
        try {
            val text = buildText(newVersion)
            target.writeText(text, Charsets.UTF_8)
            if (target != file) {
                file = target
                raw = text.lines()
                meta = Beatmap.parse(file, false)
            } else {
                raw = text.lines()
            }
            timingChanged = false
            dirty = false
            Toast.makeText(this, "Tersimpan: ${target.name}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun tryExit() {
        view.pausePlayback()
        if (!dirty) {
            finish()
            return
        }
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Ada perubahan belum disimpan")
            .setPositiveButton("Simpan") { _, _ -> saveDialog(true) }
            .setNegativeButton("Buang") { _, _ -> finish() }
            .setNeutralButton("Batal", null)
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        tryExit()
    }

    override fun onPause() {
        super.onPause()
        if (::view.isInitialized) view.pausePlayback()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::view.isInitialized) view.destroy()
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        testFile?.delete()
    }
}
