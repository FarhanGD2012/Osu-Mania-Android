package com.maniadroid

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/**
 * Pratinjau note: menggambar note jatuh dari satu chart (file .osu yang diambil sekilas dari mirror, tanpa mengunduh
 * seluruh set) selaras dengan cuplikan lagu. Memakai warna / gambar note yang sama dengan permainan.
 */
class NotePreviewView(ctx: Context) : View(ctx) {
    private var bm: Beatmap? = null
    private var startMs = 0.0
    private var clock: (() -> Double)? = null
    private var bmps = arrayOfNulls<Bitmap>(0)
    private var bodies = IntArray(0)
    private var bw = 0
    private var idx = 0
    private var lastT = 0.0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val d = resources.displayMetrics.density
    var message: String = ""
        set(v) {
            field = v
            invalidate()
        }

    fun setChart(b: Beatmap?, start: Double, clk: () -> Double) {
        bm = b
        startMs = start
        clock = clk
        idx = 0
        lastT = 0.0
        bw = 0
        invalidate()
    }

    private fun build(w: Int, h: Int, keys: Int): Float {
        val lane = min(w / keys.toFloat(), h * 0.2f)
        val nd = (lane * 0.84f).toInt().coerceAtLeast(8)
        if (bw != nd || bmps.size != keys) {
            bw = nd
            bmps = arrayOfNulls(keys)
            bodies = IntArray(keys)
            for (c in 0 until keys) {
                bmps[c] = try {
                    NoteSkin.make(context, keys, c, nd, nd, true)
                } catch (e: Throwable) {
                    null
                }
                bodies[c] = NoteSkin.bodyColor(context, keys, c)
            }
        }
        return lane
    }

    override fun onDraw(cv: Canvas) {
        val w = width
        val h = height
        p.style = Paint.Style.FILL
        p.color = 0xFF000000.toInt()
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        val b = bm
        val ck = clock
        if (b == null || ck == null || b.notes.isEmpty()) {
            p.color = 0xFF9A9AB0.toInt()
            p.textAlign = Paint.Align.CENTER
            p.textSize = 13f * d
            cv.drawText(message, w / 2f, h / 2f, p)
            postInvalidateOnAnimation()
            return
        }
        val keys = b.keys
        val lane = build(w, h, keys)
        val fieldW = lane * keys
        val fx = (w - fieldW) / 2f
        val hitY = h * 0.84f
        val t = startMs + ck()
        if (t < lastT - 80) idx = 0
        lastT = t
        val ns = b.notes
        while (idx < ns.size && ns[idx].endTime < t - 120) idx++
        val scrollMs = 850.0
        val pxMs = hitY / scrollMs
        // garis luar
        p.color = 0x3CFFFFFF
        cv.drawRect(fx - 1f, 0f, fx + 1f, h.toFloat(), p)
        cv.drawRect(fx + fieldW - 1f, 0f, fx + fieldW + 1f, h.toFloat(), p)
        // bulatan kosong
        val rr = bw / 2f
        p.style = Paint.Style.STROKE
        p.strokeWidth = max(2f * d, rr * 0.12f)
        p.color = 0xAAFFFFFF.toInt()
        for (c in 0 until keys) cv.drawCircle(fx + c * lane + lane / 2f, hitY, rr - p.strokeWidth / 2f, p)
        p.style = Paint.Style.FILL
        var i = idx
        while (i < ns.size) {
            val n = ns[i]
            i++
            if ((n.time - t) * pxMs > hitY + bw) break
            val cx = fx + n.col * lane + lane / 2f
            val yHead = (hitY - (n.time - t) * pxMs).toFloat()
            if (n.isHold) {
                val yTail = (hitY - (n.endTime - t) * pxMs).toFloat()
                val bwid = bw * 0.56f
                p.color = (bodies[n.col] and 0x00FFFFFF) or (130 shl 24)
                rect.set(cx - bwid / 2f, min(yHead, yTail), cx + bwid / 2f, max(yHead, yTail))
                cv.drawRoundRect(rect, bwid / 2f, bwid / 2f, p)
            }
            val bmp = bmps.getOrNull(n.col)
            if (bmp != null) cv.drawBitmap(bmp, cx - bmp.width / 2f, yHead - bmp.height / 2f, null)
        }
        postInvalidateOnAnimation()
    }
}

/**
 * Layar "Preview" untuk satu beatmapset di daftar Unduh: cuplikan lagu otomatis diputar, daftar diff (SR, jumlah note, BPM,
 * durasi), dan pratinjau note jatuh dari diff yang dipilih. Bisa langsung Unduh dari sini.
 */
class MapPreview(
    private val a: Activity,
    private val r: Downloader.Remote,
    private val installed: Boolean,
    private val onDownload: () -> Unit
) {
    private lateinit var dlg: Dialog
    private var mp: MediaPlayer? = null
    private var mpReady = false
    private var audioFailed = false
    private var timerStart = 0L
    private var sel = -1
    private var loadToken = 0
    private lateinit var view: NotePreviewView
    private lateinit var status: TextView
    private lateinit var rows: LinearLayout
    private val diffs = r.diffs.sortedWith(compareBy({ it.keys }, { it.stars }))

    private fun dp(v: Int) = Ui.dp(a, v)

    private fun starColor(s: Float): Int = when {
        s < 2f -> 0xFF4CD08A.toInt()
        s < 2.7f -> 0xFF4DA3FF.toInt()
        s < 4f -> 0xFFFFC94D.toInt()
        s < 5.3f -> 0xFFFF8A4D.toInt()
        s < 6.5f -> 0xFFFF4D6A.toInt()
        else -> 0xFFB04DFF.toInt()
    }

    fun show() {
        val d = Dialog(a)
        dlg = d
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = FrameLayout(a)
        root.setBackgroundColor(0xFF0B0A12.toInt())
        val cover = ImageView(a)
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(cover, FrameLayout.LayoutParams(-1, -1))
        Img.load("https://assets.ppy.sh/beatmaps/${r.id}/covers/cover.jpg", cover)
        val dim = View(a)
        dim.setBackgroundColor(0xD00B0A12.toInt())
        root.addView(dim, FrameLayout.LayoutParams(-1, -1))

        val body = LinearLayout(a)
        body.orientation = LinearLayout.HORIZONTAL
        body.setPadding(dp(18), dp(14), dp(18), dp(12))
        root.addView(body, FrameLayout.LayoutParams(-1, -1))

        // ---- kiri: info + daftar diff + tombol ----
        val left = LinearLayout(a)
        left.orientation = LinearLayout.VERTICAL
        val title = Ui.text(a, if (r.title.isEmpty()) "Beatmapset #${r.id}" else r.title, 20f, Color.WHITE, true)
        title.maxLines = 2
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        left.addView(title)
        if (r.artist.isNotEmpty()) left.addView(Ui.text(a, r.artist, 13.5f, 0xFFE0E0EE.toInt()))
        if (r.creator.isNotEmpty()) left.addView(Ui.text(a, "mapper ${r.creator}", 12f, Ui.SUB))
        val stat = StringBuilder()
        if (r.status.isNotEmpty()) stat.append(r.status.uppercase()).append("   ")
        if (r.plays > 0) stat.append(L.t("${r.plays} dimainkan", "${r.plays} plays")).append("   ")
        if (r.favs > 0) stat.append(L.t("${r.favs} suka", "${r.favs} favourites"))
        if (stat.isNotBlank()) {
            val st = Ui.text(a, stat.toString().trim(), 11.5f, Ui.ACCENT, true)
            left.addView(st, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = dp(4) })
        }
        rows = LinearLayout(a)
        rows.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(rows)
        left.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f).also { it.topMargin = dp(10) })
        if (diffs.isEmpty()) {
            left.addView(
                Ui.text(a, "Detail diff tidak tersedia untuk hasil ini. Cuplikan lagu tetap diputar.", 12f, Ui.SUB),
                LinearLayout.LayoutParams(-1, 0, 1f).also { it.topMargin = dp(10) }
            )
        }
        val btns = LinearLayout(a)
        btns.orientation = LinearLayout.HORIZONTAL
        val dl = Ui.button(a, if (installed) "Terpasang" else "Unduh", !installed, 14) {
            if (!installed) {
                close()
                onDownload()
            }
        }
        dl.isEnabled = !installed
        val cl = Ui.button(a, "Tutup", false, 14) { close() }
        btns.addView(dl, LinearLayout.LayoutParams(0, dp(44), 1.4f))
        btns.addView(cl, LinearLayout.LayoutParams(0, dp(44), 1f).also { it.leftMargin = dp(8) })
        left.addView(btns, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(8) })
        body.addView(left, LinearLayout.LayoutParams(0, -1, 0.47f))

        // ---- kanan: pratinjau note ----
        val right = LinearLayout(a)
        right.orientation = LinearLayout.VERTICAL
        view = NotePreviewView(a)
        view.background = Ui.rounded(Color.BLACK, dp(16).toFloat())
        view.clipToOutline = true
        view.message = L.t("Pilih diff untuk melihat note", "Pick a difficulty to see the notes")
        right.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        status = Ui.text(a, "", 11.5f, Ui.SUB)
        status.gravity = Gravity.CENTER
        right.addView(status, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(6) })
        body.addView(right, LinearLayout.LayoutParams(0, -1, 0.53f).also { it.leftMargin = dp(16) })

        buildRows()
        d.setContentView(root)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.BLACK))
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        }
        d.setOnDismissListener { releaseAudio() }
        d.showImmersive(a)
        startAudio(0)
        if (diffs.isNotEmpty()) select(diffs.size / 2)
    }

    private fun close() {
        try {
            dlg.dismiss()
        } catch (e: Exception) {
        }
    }

    private fun buildRows() {
        rows.removeAllViews()
        for ((i, df) in diffs.withIndex()) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(10), dp(6), dp(10), dp(6))
            row.background = Ui.ripple(Ui.rounded(if (i == sel) 0x40FFFFFF else 0x20FFFFFF, dp(12).toFloat()))
            val chip = Ui.text(a, String.format(java.util.Locale.US, "%.1f", df.stars), 12f, Color.WHITE, true)
            chip.gravity = Gravity.CENTER
            chip.background = Ui.rounded(starColor(df.stars), dp(9).toFloat())
            row.addView(chip, LinearLayout.LayoutParams(dp(40), dp(24)))
            val col = LinearLayout(a)
            col.orientation = LinearLayout.VERTICAL
            val name = Ui.text(a, "${df.keys}K  ${df.version}", 13.5f, Color.WHITE, i == sel)
            name.maxLines = 1
            name.ellipsize = android.text.TextUtils.TruncateAt.END
            col.addView(name)
            val len = String.format(java.util.Locale.US, "%d:%02d", df.length / 60, df.length % 60)
            val meta = Ui.text(
                a,
                String.format(java.util.Locale.US, "%d note · %.0f BPM · %s · OD %.1f · HP %.1f", df.notes, df.bpm, len, df.od, df.hp),
                10.5f, Ui.SUB
            )
            meta.maxLines = 1
            meta.ellipsize = android.text.TextUtils.TruncateAt.END
            col.addView(meta)
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = dp(10) })
            row.setOnClickListener { select(i) }
            rows.addView(row, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = dp(5) })
        }
    }

    private fun select(i: Int) {
        if (i !in diffs.indices) return
        sel = i
        buildRows()
        val df = diffs[i]
        val token = ++loadToken
        view.setChart(null, 0.0) { 0.0 }
        view.message = L.t("Memuat note…", "Loading notes…")
        if (df.id <= 0) {
            view.message = L.t("Note tidak tersedia untuk diff ini", "Notes unavailable for this difficulty")
            return
        }
        Thread {
            val f = Downloader.fetchOsu(df.id, a.cacheDir)
            val b = if (f != null) try {
                Beatmap.parse(f, true)
            } catch (e: Throwable) {
                null
            } else null
            var start = 0.0
            if (b != null && f != null) {
                val m = Regex("PreviewTime\\s*:\\s*(-?\\d+)").find(try { f.readText() } catch (e: Exception) { "" })
                val pt = m?.groupValues?.get(1)?.toIntOrNull() ?: -1
                start = if (pt > 0) pt.toDouble() else b.notes.getOrNull((b.notes.size * 0.4).toInt())?.time?.toDouble() ?: 0.0
            }
            a.runOnUiThread {
                if (token != loadToken) return@runOnUiThread
                if (b == null || b.notes.isEmpty()) {
                    view.message = L.t("Note tidak bisa dimuat (server tidak menjawab)", "Could not load notes (server did not answer)")
                } else {
                    timerStart = SystemClock.uptimeMillis()
                    view.setChart(b, start) { clockMs() }
                }
            }
        }.start()
    }

    /** Posisi (ms) di dalam cuplikan: dari pemutar audio bila jalan, jika tidak dari timer (audio gagal / belum siap). */
    private fun clockMs(): Double {
        val m = mp
        if (m != null && mpReady && !audioFailed) {
            return try {
                m.currentPosition.toDouble()
            } catch (e: Exception) {
                (SystemClock.uptimeMillis() - timerStart).toDouble()
            }
        }
        return ((SystemClock.uptimeMillis() - timerStart) % 12000L).toDouble()
    }

    private fun startAudio(i: Int) {
        val urls = Downloader.previewAudioUrls(r.id)
        if (i >= urls.size) {
            audioFailed = true
            status.text = L.t("Cuplikan lagu tidak tersedia (note tetap bisa dilihat)", "Song preview unavailable (notes still shown)")
            return
        }
        status.text = L.t("Memuat cuplikan lagu…", "Loading song preview…")
        releaseAudio()
        val m = MediaPlayer()
        mp = m
        mpReady = false
        try {
            m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            val v = Settings.musicGain
            m.setVolume(v, v)
            m.setDataSource(urls[i])
            m.isLooping = true
            m.setOnPreparedListener {
                if (mp === it) {
                    mpReady = true
                    try {
                        it.start()
                    } catch (e: Exception) {
                    }
                    status.text = L.t("Cuplikan lagu diputar", "Playing song preview")
                }
            }
            m.setOnErrorListener { _, _, _ ->
                if (mp === m) startAudio(i + 1)
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            startAudio(i + 1)
        }
    }

    private fun releaseAudio() {
        val m = mp ?: return
        mp = null
        mpReady = false
        try {
            m.release()
        } catch (e: Exception) {
        }
    }
}
