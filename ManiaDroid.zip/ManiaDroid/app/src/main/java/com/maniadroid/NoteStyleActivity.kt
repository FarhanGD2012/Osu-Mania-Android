package com.maniadroid

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/** Pratinjau lane + note: dipakai di layar Gaya note. Ketuk sebuah lane untuk memilih kolomnya. */
private class NotePreview(ctx: Context, private val onSelect: (Int) -> Unit) : View(ctx) {
    var keys = 4
    var selected = 0
    private val bmps = arrayOfNulls<Bitmap>(10)
    private val body = IntArray(10)
    private var circle = true
    private var argon = false
    private var laneW = 0f
    private var fieldX = 0f
    private var noteW = 0f
    private var noteH = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()
    private val d = ctx.resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) = rebuild()

    fun rebuild() {
        if (width <= 0 || height <= 0) return
        circle = Settings.noteShape == 0
        argon = Settings.noteShape == 2
        val wf = width.toFloat()
        val hf = height.toFloat()
        laneW = min(wf / keys, hf * 0.30f)
        fieldX = (wf - laneW * keys) / 2f
        val noteD = min(laneW * 0.84f, hf * 0.17f)
        noteH = if (argon) max(min(laneW * 0.7f, hf * 0.15f), 18f * d) else if (circle) noteD else min(max(laneW * 0.38f, 22f * d), 56f * d)
        noteW = if (argon) laneW * 0.97f else if (circle) noteD else laneW * 0.88f
        for (c in 0 until keys) {
            bmps[c] = NoteSkin.makeStyle(context, keys, c, noteW.toInt(), noteH.toInt(), if (argon) 2 else if (circle) 0 else 1, false)
            body[c] = NoteSkin.bodyColor(context, keys, c)
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN && laneW > 0f) {
            val c = ((e.x - fieldX) / laneW).toInt()
            if (c in 0 until keys) onSelect(c)
            return true
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = 0xB3090811.toInt()
        cv.drawRoundRect(0f, 0f, w, h, 18f * d, 18f * d, p)
        if (laneW <= 0f) return
        val hitY = h * 0.84f
        for (c in 0 until keys) {
            val x = fieldX + c * laneW
            if (c == selected) {
                p.color = 0x22FFFFFF
                cv.drawRect(x, 0f, x + laneW, h, p)
            }
            p.color = 0x3CFFFFFF
            cv.drawRect(x - 0.5f * d, 0f, x + 0.5f * d, h, p)
        }
        p.color = 0x3CFFFFFF
        val xe = fieldX + keys * laneW
        cv.drawRect(xe - 0.5f * d, 0f, xe + 0.5f * d, h, p)

        for (c in 0 until keys) {
            val cx = fieldX + c * laneW + laneW / 2f
            // contoh hold: badan + kepala
            val headY = h * 0.58f
            val bw = if (argon) noteW else if (circle) noteH * 0.56f else laneW * 0.56f
            p.style = Paint.Style.FILL
            p.color = (body[c] and 0x00FFFFFF) or (150 shl 24)
            rect.set(cx - bw / 2f, h * 0.34f, cx + bw / 2f, headY)
            cv.drawRoundRect(rect, bw / 2f, bw / 2f, p)
            val bmp = bmps[c] ?: continue
            cv.drawBitmap(bmp, cx - bmp.width / 2f, headY - bmp.height / 2f, bp)
            // contoh note biasa
            cv.drawBitmap(bmp, cx - bmp.width / 2f, h * 0.16f - bmp.height / 2f, bp)
            // reseptor kosong
            p.style = Paint.Style.STROKE
            p.strokeWidth = max(2f * d, noteH * 0.06f)
            p.color = if (c == selected) Color.WHITE else 0xAAFFFFFF.toInt()
            if (circle) {
                cv.drawCircle(cx, hitY, noteH / 2f - p.strokeWidth / 2f, p)
            } else {
                rect.set(cx - noteW / 2f, hitY - noteH / 2f, cx + noteW / 2f, hitY + noteH / 2f)
                cv.drawRoundRect(rect, noteH * 0.28f, noteH * 0.28f, p)
            }
            // nomor kolom
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.textSize = 12f * d
            p.color = if (c == selected) Ui.ACCENT else 0x99FFFFFF.toInt()
            cv.drawText("${c + 1}", cx, h - 8f * d, p)
        }
    }
}

/**
 * Gaya note: ubah warna dan pasang gambar kustom untuk setiap note (per kolom, terpisah untuk tiap mode key).
 * Pratinjau di kiri langsung ikut berubah.
 */
class NoteStyleActivity : BaseActivity() {
    private var keys = 4
    private var col = 0
    private lateinit var preview: NotePreview
    private lateinit var chips: LinearLayout
    private lateinit var card: LinearLayout
    private lateinit var modeDd: LazerDropdown

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        keys = Settings.sp.getInt("noteStyleKeys", 4).coerceIn(1, 10)

        val root = FrameLayout(this)
        val backdrop = MenuBackdrop(this)
        root.addView(backdrop, Ui.matchParams())
        val dim = View(this)
        dim.setBackgroundColor(0x77000000)
        root.addView(dim, Ui.matchParams())

        val main = LinearLayout(this)
        main.orientation = LinearLayout.HORIZONTAL
        main.setPadding(dp(16), dp(LazerBack.H_DP + 10), dp(16), dp(12))
        root.addView(main, Ui.matchParams())

        preview = NotePreview(this) { c ->
            col = c
            refreshAll()
        }
        main.addView(preview, LinearLayout.LayoutParams(0, -1, 0.42f))

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(18), 0, dp(4), dp(24))
        sv.addView(content, FrameLayout.LayoutParams(-1, -2))
        val sp = LinearLayout.LayoutParams(0, -1, 0.58f)
        main.addView(sv, sp)

        // baris mode key
        modeDd = LazerDropdown(this, "${keys}K")
        modeDd.setOnClickListener {
            val opts = (1..10).map { "${it}K" }
            LDialog.pick(this, "Mode key", opts, keys - 1) { i ->
                keys = i + 1
                Settings.sp.edit().putInt("noteStyleKeys", keys).apply()
                col = min(col, keys - 1)
                modeDd.text = "${keys}K"
                refreshAll()
            }
        }
        content.addView(row("Mode key", modeDd), lp(0))

        // bentuk note (sama dengan Pengaturan > Note)
        val shapeOpts = listOf("Bulat", "Persegi panjang", "osu!lazer (Argon)").map { L.t(it) }
        val shapeDd = LazerDropdown(this, shapeOpts[Settings.noteShape.coerceIn(0, 2)])
        shapeDd.setOnClickListener {
            LDialog.pick(this, "Bentuk note", shapeOpts, Settings.noteShape.coerceIn(0, 2)) { i ->
                Settings.noteShape = i
                shapeDd.text = shapeOpts[i]
                refreshAll()
            }
        }
        content.addView(row("Bentuk note", shapeDd), lp(6))

        content.addView(Ui.text(this, "Kolom", 13f, Ui.SUB), lp(14))
        chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips)
        content.addView(hs, lp(6))

        card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(12), dp(14), dp(14))
        card.background = Ui.rounded(0x66181826, dp(14).toFloat())
        content.addView(card, lp(10))

        content.addView(
            Ui.text(this, "Warna dan gambar diatur per kolom, terpisah untuk tiap mode key. Kolom dihitung dari kiri.", 11.5f, Ui.SUB),
            lp(10)
        )

        // pojok kiri atas: kembali + judul
        root.addView(
            LazerBack(this) { finish() },
            FrameLayout.LayoutParams(dp(LazerBack.W_DP), dp(LazerBack.H_DP), Gravity.TOP or Gravity.START)
        )
        root.addView(LazerTitle(this, L.t("Gaya note"), L.t("skin", "skin")), LazerTitle.params(this))

        setContentView(root)
        refreshAll()
    }

    private fun lp(top: Int): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(-1, -2)
        l.topMargin = dp(top)
        return l
    }

    private fun row(label: String, v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(Ui.text(this, label, 14f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(v, LinearLayout.LayoutParams(dp(170), -2))
        return r
    }

    private fun refreshAll() {
        preview.keys = keys
        preview.selected = col
        preview.rebuild()
        buildChips()
        buildCard()
    }

    private fun buildChips() {
        chips.removeAllViews()
        for (c in 0 until keys) {
            val on = c == col
            val t = Ui.text(this, "${c + 1}", 14f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.background = Ui.ripple(Ui.rounded(if (on) Ui.ACCENT else Ui.CARD2, dp(12).toFloat()))
            t.setOnClickListener {
                col = c
                refreshAll()
            }
            val lp = LinearLayout.LayoutParams(dp(42), dp(36))
            lp.rightMargin = dp(6)
            chips.addView(t, lp)
        }
    }

    private fun swatch(color: Int, selected: Boolean, onClick: () -> Unit): View {
        val v = View(this)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        g.setStroke(dp(if (selected) 3 else 1), if (selected) Color.WHITE else 0x55FFFFFF)
        v.background = g
        v.setOnClickListener { onClick() }
        return v
    }

    private fun smallButton(label: String, kind: Int = 0, onClick: () -> Unit): TextView {
        val bg = when (kind) {
            1 -> Ui.ACCENT
            2 -> 0xFF4A2332.toInt()
            else -> 0xFF2B2A3A.toInt()
        }
        val t = Ui.text(this, label, 13f, if (kind == 2) 0xFFFF9AA8.toInt() else Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(10), dp(14), dp(10))
        t.background = Ui.ripple(Ui.rounded(bg, dp(10).toFloat()))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildCard() {
        card.removeAllViews()
        card.addView(Ui.text(this, L.t("Kolom ${col + 1}", "Column ${col + 1}"), 16f, Color.WHITE, true))

        card.addView(Ui.text(this, "Warna", 12f, Ui.SUB), lp(10))
        val cur = NoteSkin.color(keys, col)
        val sw = LinearLayout(this)
        sw.orientation = LinearLayout.HORIZONTAL
        sw.gravity = Gravity.CENTER_VERTICAL
        for (c in NoteSkin.PALETTE) {
            val lpS = LinearLayout.LayoutParams(dp(30), dp(30))
            lpS.rightMargin = dp(8)
            sw.addView(swatch(c, c == cur) {
                Settings.setNoteColor(keys, col, c)
                refreshAll()
            }, lpS)
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(sw)
        card.addView(hs, lp(6))

        val r1 = LinearLayout(this)
        r1.orientation = LinearLayout.HORIZONTAL
        r1.addView(smallButton("Warna kustom…") { pickColor(cur) { c ->
            Settings.setNoteColor(keys, col, c)
            refreshAll()
        } }, LinearLayout.LayoutParams(-2, -2))
        card.addView(r1, lp(10))

        val hasImg = NoteSkin.hasImage(this, keys, col)
        card.addView(Ui.text(this, "Gambar", 12f, Ui.SUB), lp(14))
        val r2 = LinearLayout(this)
        r2.orientation = LinearLayout.HORIZONTAL
        r2.addView(smallButton("Pilih gambar…", 1) { pickImage() }, LinearLayout.LayoutParams(-2, -2))
        if (hasImg) {
            val dl = LinearLayout.LayoutParams(-2, -2)
            dl.leftMargin = dp(8)
            r2.addView(smallButton("Hapus gambar") {
                NoteSkin.clearImage(this, keys, col)
                refreshAll()
            }, dl)
        }
        card.addView(r2, lp(6))

        val r3 = LinearLayout(this)
        r3.orientation = LinearLayout.HORIZONTAL
        r3.addView(smallButton("Kembalikan kolom ini ke bawaan", 2) {
            NoteSkin.resetColumn(this, keys, col)
            refreshAll()
        }, LinearLayout.LayoutParams(-2, -2))
        val al = LinearLayout.LayoutParams(-2, -2)
        al.leftMargin = dp(8)
        r3.addView(smallButton(L.t("Reset semua kolom (${keys}K)", "Reset all columns (${keys}K)"), 2) {
            LDialog.confirm(
                this, L.t("Reset semua kolom (${keys}K)?", "Reset all columns (${keys}K)?"),
                L.t("Warna dan gambar kustom semua kolom mode ${keys}K akan dihapus.", "Custom colors and images of every ${keys}K column will be removed."),
                "Reset"
            ) {
                for (c in 0 until keys) NoteSkin.resetColumn(this, keys, c)
                refreshAll()
            }
        }, al)
        card.addView(r3, lp(14))
    }

    // ---------- pemilih warna ----------
    private fun pickColor(initial: Int, onPick: (Int) -> Unit) {
        val (dlg, box) = LDialog.make(this, 400)
        LDialog.title(this, box, "Warna kustom")
        val hsv = FloatArray(3)
        Color.colorToHSV(initial, hsv)

        val sample = View(this)
        val sg = GradientDrawable()
        sg.cornerRadius = dp(12).toFloat()
        sg.setStroke(dp(1), 0x55FFFFFF)
        fun paint() {
            sg.setColor(Color.HSVToColor(hsv))
            sample.background = sg
            sample.invalidate()
        }
        paint()
        box.addView(sample, lp(10).also { it.height = dp(38) })

        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        fun slider(label: String, max: Int, value: Int, set: (Int) -> Unit) {
            val top = LinearLayout(this)
            top.orientation = LinearLayout.HORIZONTAL
            top.addView(Ui.text(this, label, 13f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
            val vt = Ui.text(this, value.toString(), 12.5f, Ui.ACCENT, true)
            top.addView(vt, LinearLayout.LayoutParams(-2, -2))
            inner.addView(top, lp(10))
            inner.addView(LazerSlider(this, 0, max, value) {
                vt.text = it.toString()
                set(it)
                paint()
            }, LinearLayout.LayoutParams(-1, -2))
        }
        slider("Rona", 360, hsv[0].toInt()) { hsv[0] = it.toFloat() }
        slider("Kepekatan", 100, (hsv[1] * 100).toInt()) { hsv[1] = it / 100f }
        slider("Kecerahan", 100, (hsv[2] * 100).toInt()) { hsv[2] = it / 100f }
        val maxH = (resources.displayMetrics.heightPixels - dp(220)).coerceAtLeast(dp(120))
        val sv = CappedScroll(this, maxH)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(inner)
        box.addView(sv, lp(0))

        LDialog.buttons(
            this, box,
            LDialog.textButton(this, "Batal", false) { dlg.dismiss() },
            LDialog.textButton(this, "Pilih", true) {
                dlg.dismiss()
                onPick(Color.HSVToColor(hsv))
            }
        )
        dlg.showImmersive(this)
    }

    // ---------- gambar kustom ----------
    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        @Suppress("DEPRECATION")
        startActivityForResult(i, 31)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 31 || res != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        val k = keys
        val c = col
        Thread {
            val ok = NoteSkin.importImage(this, uri, k, c)
            runOnUiThread {
                if (ok) refreshAll()
                Toast.makeText(this, if (ok) "Gambar note dipasang" else "Gagal memasang gambar", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }
}
