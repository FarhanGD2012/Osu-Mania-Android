package com.maniadroid

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

/** Pemutar musik menu: daftar lagu tambahan pengguna + (opsional) lagu dari chart. Lanjut otomatis ke lagu berikutnya. */
object MenuMusic {
    class Track(val path: String, val title: String)

    var tracks: List<Track> = emptyList()
        private set
    var current: Track? = null
        private set
    var onChange: ((Track) -> Unit)? = null

    private var mp: MediaPlayer? = null
    private var idx = -1
    private var prepared = false
    private var wantPlay = false
    private var errors = 0
    private var appCtx: Context? = null

    // data denyut lagu (untuk logo yang berdenyut mengikuti musik)
    @Volatile
    private var env: BeatEnv.Env? = null
    private var posMs = 0
    private var posNano = 0L

    val isPlaying: Boolean
        get() = try {
            mp?.isPlaying == true
        } catch (e: Exception) {
            false
        }

    /**
     * Kekuatan denyut 0..1 pada posisi lagu saat ini (dipanggil tiap frame oleh logo).
     * -1 = belum ada data (lagu belum selesai dianalisis / format tidak didukung).
     */
    fun level(): Float {
        val p = mp ?: return -1f
        if (!prepared) return -1f
        val now = System.nanoTime()
        val playing = try {
            p.isPlaying
        } catch (e: Exception) {
            false
        }
        val pos = try {
            p.currentPosition
        } catch (e: Exception) {
            posMs
        }
        if (!playing) {
            posMs = pos
            posNano = now
            return if (env == null) -1f else 0f
        }
        if (pos != posMs) {
            posMs = pos
            posNano = now
        }
        val e = env ?: return -1f
        return e.at(posMs + (now - posNano) / 1e6 + 30.0)
    }

    /** Posisi lagu saat ini 0..1 (untuk garis kemajuan di bar lagu menu). */
    fun progress(): Float {
        val p = mp ?: return 0f
        if (!prepared) return 0f
        return try {
            val d = p.duration
            if (d > 0) (p.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
        } catch (e: Exception) {
            0f
        }
    }

    private fun analyzeAsync(t: Track, p: MediaPlayer) {
        val dir = appCtx?.cacheDir ?: return
        Thread {
            val e = BeatEnv.load(dir, t.path)
            if (mp === p) env = e
        }.start()
    }

    /** Susun ulang daftar lagu. Panggil di thread latar (memindai chart). */
    fun refresh(c: Context) {
        appCtx = c.applicationContext
        val list = ArrayList<Track>()
        val seen = HashSet<String>()
        for (f in Library.menuMusicDir(c).listFiles().orEmpty().sortedBy { it.name }) {
            if (f.isFile && seen.add(f.path)) list.add(Track(f.path, f.nameWithoutExtension))
        }
        if (Settings.menuMusicCharts) {
            for (s in Library.scanSets(c)) {
                val m = s.maps.first()
                val f = Library.findFile(m.dir, m.audio) ?: continue
                if (seen.add(f.path)) list.add(Track(f.path, "${s.artist} - ${s.title}"))
            }
        }
        tracks = list
        if (idx >= tracks.size) idx = -1
    }

    private fun applyVolume() {
        val v = Settings.musicVol / 100f
        try {
            mp?.setVolume(v, v)
        } catch (e: Exception) {
        }
    }

    fun start(c: Context) {
        appCtx = c.applicationContext
        if (!Settings.menuMusic || tracks.isEmpty()) {
            stop()
            return
        }
        wantPlay = true
        val p = mp
        if (p != null) {
            if (prepared) {
                applyVolume()
                try {
                    if (!p.isPlaying) p.start()
                } catch (e: Exception) {
                }
            }
            return
        }
        playIndex(if (idx in tracks.indices) idx else (Math.random() * tracks.size).toInt())
    }

    fun pause() {
        wantPlay = false
        try {
            mp?.pause()
        } catch (e: Exception) {
        }
    }

    fun stop() {
        wantPlay = false
        release()
    }

    fun toggle(c: Context) {
        if (isPlaying) pause() else start(c)
    }

    fun next() {
        if (tracks.isEmpty()) return
        wantPlay = true
        playIndex((idx + 1) % tracks.size)
    }

    fun prev() {
        if (tracks.isEmpty()) return
        wantPlay = true
        playIndex((idx - 1 + tracks.size) % tracks.size)
    }

    private fun release() {
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
        prepared = false
        env = null
    }

    private fun playIndex(i: Int) {
        release()
        if (tracks.isEmpty()) return
        idx = i.coerceIn(0, tracks.size - 1)
        val t = tracks[idx]
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            p.setDataSource(t.path)
            p.setOnPreparedListener { m ->
                prepared = true
                errors = 0
                current = t
                posMs = 0
                posNano = System.nanoTime()
                analyzeAsync(t, m)
                applyVolume()
                if (wantPlay) {
                    try {
                        m.start()
                    } catch (e: Exception) {
                    }
                }
                onChange?.invoke(t)
            }
            p.setOnCompletionListener { next() } // lagu habis -> lagu berikutnya + popup
            p.setOnErrorListener { _, _, _ ->
                errors++
                if (errors < tracks.size) next() else stop()
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            errors++
            release()
            if (errors < tracks.size) next() else stop()
        }
    }
}
