package com.maniadroid

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Window
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Dialog yang menunggu satu tombol (keyboard / controller / trigger / D-Pad) lalu mengembalikan kodenya. */
class CaptureDialog(ctx: Context, title: String, private val onCode: (Int) -> Unit) :
    Dialog(ctx, android.R.style.Theme_DeviceDefault_Dialog) {
    private val st = PadState()

    init {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d + 0.5f).toInt()
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(22), dp(18), dp(22), dp(14))
        box.addView(Ui.text(ctx, title, 18f, Ui.TEXT, true))
        val hint = Ui.text(
            ctx,
            "Tekan tombol keyboard atau controller apa saja\n(L1, L2, R1, R2, D-Pad, A/B/X/Y, …).",
            13f, Ui.SUB
        )
        hint.setPadding(0, dp(8), 0, dp(14))
        box.addView(hint)
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val clear = Ui.button(ctx, "Kosongkan", false) {
            onCode(0)
            dismiss()
        }
        val cancel = Ui.button(ctx, "Batal", false) { dismiss() }
        row.addView(clear, LinearLayout.LayoutParams(0, -2, 1f))
        val cp = LinearLayout.LayoutParams(0, -2, 1f)
        cp.leftMargin = dp(8)
        row.addView(cancel, cp)
        box.addView(row)
        setContentView(box)
        window?.setBackgroundDrawable(Ui.rounded(0xFF171724.toInt(), dp(22).toFloat()))
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                dismiss()
                return true
            }
            if (Input.isSystemKey(e.keyCode)) return super.dispatchKeyEvent(e)
            onCode(e.keyCode)
            dismiss()
        }
        return true
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        if (Input.isJoystickMove(ev)) {
            val s = Input.axisStates(ev)
            for (i in s.indices) {
                if (st.axisSet(Input.AXIS_CODES[i], s[i]) > 0) {
                    onCode(Input.AXIS_CODES[i])
                    dismiss()
                    return true
                }
            }
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }
}

/** Atur tombol tiap kolom (2 slot per kolom) untuk keyboard dan controller. */
class KeysActivity : Activity() {
    private var keys = 4
    private lateinit var rows: LinearLayout
    private lateinit var chips: LinearLayout

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        val sv = ScrollView(this)
        sv.background = Ui.bgGradient()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(16), dp(18), dp(28))
        sv.addView(box)
        setContentView(sv)

        box.addView(Ui.text(this, "Atur tombol", 26f, Ui.TEXT, true))
        box.addView(
            Ui.text(
                this,
                "Pilih jumlah key, lalu ketuk sebuah tombol di bawah dan tekan tombol di controller/keyboard. " +
                        "Tiap kolom punya 2 tombol (Tombol 1 & 2). Semua tombol bisa dipakai, termasuk L1, L2, R1, R2.",
                12f, Ui.SUB
            )
        )
        chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips)
        val hp = LinearLayout.LayoutParams(-1, -2)
        hp.topMargin = dp(12)
        box.addView(hs, hp)
        rows = LinearLayout(this)
        rows.orientation = LinearLayout.VERTICAL
        val rp = LinearLayout.LayoutParams(-1, -2)
        rp.topMargin = dp(6)
        box.addView(rows, rp)
        val reset = Ui.button(this, "Reset tombol (${keys}K) ke default", false) {}
        reset.setOnClickListener {
            Bindings.reset(keys)
            refresh()
        }
        val resetP = LinearLayout.LayoutParams(-1, -2)
        resetP.topMargin = dp(14)
        box.addView(reset, resetP)
        resetBtn = reset
        refresh()
    }

    private lateinit var resetBtn: TextView

    private fun refresh() {
        chips.removeAllViews()
        for (k in 1..10) {
            val c = Ui.text(this, "${k}K", 14f, Ui.TEXT, true)
            c.gravity = Gravity.CENTER
            c.setPadding(dp(16), dp(8), dp(16), dp(8))
            c.background = Ui.rounded(if (k == keys) Ui.ACCENT else Ui.CARD2, dp(18).toFloat())
            c.setOnClickListener {
                keys = k
                refresh()
            }
            val lp = LinearLayout.LayoutParams(-2, -2)
            lp.rightMargin = dp(6)
            chips.addView(c, lp)
        }
        resetBtn.text = "Reset tombol (${keys}K) ke default"
        rows.removeAllViews()
        for (col in 0 until keys) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(14), dp(8), dp(10), dp(8))
            row.background = Ui.rounded(0x99181826.toInt(), dp(16).toFloat())
            val label = Ui.text(this, Bindings.laneLabel(keys, col), 14f, Ui.TEXT, true)
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1.2f))
            for (slot in 0..1) {
                val code = Bindings.get(keys, col, slot)
                val btn = Ui.button(this, "${slot + 1}: ${Input.name(code)}", slot == 1 && code != 0) {}
                btn.setOnClickListener {
                    CaptureDialog(this, "${Bindings.laneLabel(keys, col)} — tombol ${slot + 1}") { c ->
                        Bindings.set(keys, col, slot, c)
                        refresh()
                    }.show()
                }
                val bp = LinearLayout.LayoutParams(0, -2, 1f)
                bp.leftMargin = dp(8)
                row.addView(btn, bp)
            }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(8)
            rows.addView(row, lp)
        }
    }
}
