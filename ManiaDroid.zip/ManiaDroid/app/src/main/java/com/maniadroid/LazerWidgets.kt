package com.maniadroid

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.Window
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

/** Campur dua warna: t = 0 -> a, t = 1 -> b. */
fun mixColor(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    return Color.argb(
        (Color.alpha(a) + (Color.alpha(b) - Color.alpha(a)) * k).roundToInt(),
        (Color.red(a) + (Color.red(b) - Color.red(a)) * k).roundToInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).roundToInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).roundToInt()
    )
}

/** ScrollView yang tingginya dibatasi, supaya panel tidak melebihi layar landscape. */
class CappedScroll(c: Context, private val maxH: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/** Saklar ala osu!lazer: jalur lonjong, bulatan putih geser; menyala = pink. */
class LazerSwitch(ctx: Context, checked: Boolean, private val onChange: (Boolean) -> Unit) : View(ctx) {
    var checked: Boolean = checked
        private set
    private var pos = if (checked) 1f else 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ev = ArgbEvaluator()
    private var anim: ValueAnimator? = null
    private val d = ctx.resources.displayMetrics.density

    init {
        isClickable = true
        setOnClickListener { toggle() }
    }

    fun toggle() = set(!checked, true)

    fun set(v: Boolean, notify: Boolean) {
        if (v == checked) return
        checked = v
        anim?.cancel()
        val a = ValueAnimator.ofFloat(pos, if (v) 1f else 0f)
        a.duration = 140
        a.addUpdateListener {
            pos = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
        if (notify) onChange(v)
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((44 * d).toInt(), (24 * d).toInt())
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = ev.evaluate(pos, 0xFF3B3A4A.toInt(), Ui.ACCENT) as Int
        cv.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, p)
        p.color = Color.WHITE
        cv.drawCircle(h / 2f + (w - h) * pos, h / 2f, h / 2f - 3f * d, p)
    }
}

/** Slider ala osu!lazer: jalur tipis, isian pink, bulatan putih. Ketuk di jalur = langsung loncat ke nilai itu. */
class LazerSlider(
    ctx: Context,
    private val min: Int,
    private val max: Int,
    value: Int,
    private val onChanged: (Int) -> Unit
) : View(ctx) {
    var value: Int = value.coerceIn(min, max)
        private set
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var grow = 0f
    private var anim: ValueAnimator? = null

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(resolveSize((200 * d).toInt(), w), (32 * d).toInt())
    }

    private fun padX() = 10f * d

    private fun setFromX(x: Float) {
        val l = padX()
        val r = width - padX()
        val f = ((x - l) / (r - l)).coerceIn(0f, 1f)
        val v = min + (f * (max - min)).roundToInt()
        if (v != value) {
            value = v
            invalidate()
            onChanged(v)
        }
    }

    private fun animGrow(to: Float) {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(grow, to)
        a.duration = 120
        a.addUpdateListener {
            grow = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) {
                    val dx = abs(e.x - downX)
                    val dy = abs(e.y - downY)
                    if (dx > slop && dx > dy) {
                        dragging = true
                        parent?.requestDisallowInterceptTouchEvent(true)
                        animGrow(1f)
                    }
                }
                if (dragging) setFromX(e.x)
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) setFromX(e.x)
                dragging = false
                animGrow(0f)
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                animGrow(0f)
            }
        }
        return true
    }

    override fun onDraw(cv: Canvas) {
        val l = padX()
        val r = width - padX()
        val cy = height / 2f
        val th = 4f * d
        val f = if (max > min) (value - min).toFloat() / (max - min) else 0f
        val x = l + (r - l) * f
        p.style = Paint.Style.FILL
        p.color = 0x33FFFFFF
        cv.drawRoundRect(l, cy - th / 2f, r, cy + th / 2f, th / 2f, th / 2f, p)
        p.color = Ui.ACCENT
        cv.drawRoundRect(l, cy - th / 2f, x, cy + th / 2f, th / 2f, th / 2f, p)
        if (grow > 0.01f) {
            p.color = Color.argb((70 * grow).toInt(), 255, 0x66, 0xAA)
            cv.drawCircle(x, cy, (13f + 4f * grow) * d, p)
        }
        p.color = Color.WHITE
        cv.drawCircle(x, cy, (7f + 2f * grow) * d, p)
    }
}

/** Kotak pilihan ala dropdown osu!lazer: nilai terpilih + segitiga kecil. Diketuk untuk membuka daftar. */
class LazerDropdown(ctx: Context, label: String) : TextView(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val d = ctx.resources.displayMetrics.density

    init {
        setText(label)
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        gravity = Gravity.CENTER_VERTICAL
        setPadding((14 * d).toInt(), (9 * d).toInt(), (34 * d).toInt(), (9 * d).toInt())
        background = Ui.ripple(Ui.rounded(0xFF2B2A3A.toInt(), 10f * d))
        isClickable = true
    }

    override fun onDraw(cv: Canvas) {
        super.onDraw(cv)
        val cx = width - 18f * d
        val cy = height / 2f
        path.reset()
        path.moveTo(cx - 4.5f * d, cy - 2f * d)
        path.lineTo(cx + 4.5f * d, cy - 2f * d)
        path.lineTo(cx, cy + 3f * d)
        path.close()
        p.style = Paint.Style.FILL
        p.color = Ui.ACCENT
        cv.drawPath(path, p)
    }
}

/**
 * Tombol menu utama ala osu!lazer: jajar genjang berwarna dengan ikon + label.
 * Kilat putih saat disentuh HANYA muncul di dalam bentuknya.
 */
class MenuButton(ctx: Context, kind: Int, label: String, private val color: Int, onClick: () -> Unit) : LinearLayout(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val path = Path()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var shader: Shader? = null
    private var flash = 0f
    private var anim: ValueAnimator? = null

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setWillNotDraw(false)
        addView(IconView(ctx, kind, Color.WHITE), LayoutParams((26 * d).toInt(), (26 * d).toInt()))
        val t = Ui.text(ctx, label, 11.5f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        val lp = LayoutParams(-2, -2)
        lp.topMargin = (5 * d).toInt()
        addView(t, lp)
        isClickable = true
        setOnClickListener { onClick() }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val k = h * 0.16f
        val g = 1.5f * d
        path.reset()
        path.moveTo(k + g, 0f)
        path.lineTo(w - g, 0f)
        path.lineTo(w - k - g, h.toFloat())
        path.lineTo(g, h.toFloat())
        path.close()
        shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            mixColor(color, Color.WHITE, 0.10f), mixColor(color, Color.BLACK, 0.22f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(cv: Canvas) {
        p.style = Paint.Style.FILL
        // PENTING: warna paint harus opak saat menggambar dengan shader. Alpha paint ikut mengalikan hasil shader,
        // dan sisa alpha kecil dari kilat putih sebelumnya membuat tombol hampir transparan (tampak hitam) selamanya.
        p.color = Color.WHITE
        p.shader = shader
        cv.drawPath(path, p)
        if (flash > 0.01f) {
            p.shader = null
            p.color = Color.argb((flash * 110f).toInt().coerceIn(0, 255), 255, 255, 255)
            cv.drawPath(path, p)
        }
        p.shader = null
    }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(flash, if (pressed) 1f else 0f)
        a.duration = if (pressed) 70 else 260
        a.addUpdateListener {
            flash = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }
}

/**
 * Tombol kembali ala osu!lazer: jajar genjang pink menempel di pojok kiri atas layar
 * (sisi kiri rata, sisi kanan miring), berisi panah dan tulisan "Kembali".
 */
class LazerBack(ctx: Context, onClick: () -> Unit) : LinearLayout(ctx) {
    companion object {
        const val W_DP = 118
        const val H_DP = 42
    }

    private val d = ctx.resources.displayMetrics.density
    private val path = Path()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var shader: Shader? = null
    private var flash = 0f
    private var anim: ValueAnimator? = null

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setWillNotDraw(false)
        setPadding((12 * d).toInt(), 0, (18 * d).toInt(), 0)
        addView(IconView(ctx, IconView.BACK, Color.WHITE), LayoutParams((18 * d).toInt(), (18 * d).toInt()))
        val t = Ui.text(ctx, "Kembali", 14f, Color.WHITE, true)
        t.maxLines = 1
        val lp = LayoutParams(-2, -2)
        lp.leftMargin = (6 * d).toInt()
        addView(t, lp)
        isClickable = true
        setOnClickListener { onClick() }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val k = h * 0.34f
        path.reset()
        path.moveTo(0f, 0f)
        path.lineTo(w.toFloat(), 0f)
        path.lineTo(w - k, h.toFloat())
        path.lineTo(0f, h.toFloat())
        path.close()
        shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            mixColor(Ui.ACCENT, Color.WHITE, 0.06f), mixColor(Ui.ACCENT, Color.BLACK, 0.30f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(cv: Canvas) {
        p.style = Paint.Style.FILL
        // PENTING: warna paint harus opak saat menggambar dengan shader. Alpha paint ikut mengalikan hasil shader,
        // dan sisa alpha kecil dari kilat putih sebelumnya membuat tombol hampir transparan (tampak hitam) selamanya.
        p.color = Color.WHITE
        p.shader = shader
        cv.drawPath(path, p)
        if (flash > 0.01f) {
            p.shader = null
            p.color = Color.argb((flash * 110f).toInt().coerceIn(0, 255), 255, 255, 255)
            cv.drawPath(path, p) // kilat putih hanya di dalam bentuk tombol
        }
        p.shader = null
    }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(flash, if (pressed) 1f else 0f)
        a.duration = if (pressed) 70 else 260
        a.addUpdateListener {
            flash = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }
}

/** Garis kemajuan tipis (dipakai di bar lagu menu). */
class ProgressLine(ctx: Context) : View(ctx) {
    var frac = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val h = height.toFloat()
        p.color = 0x28FFFFFF
        cv.drawRoundRect(0f, 0f, width.toFloat(), h, h / 2f, h / 2f, p)
        p.color = Ui.ACCENT
        cv.drawRoundRect(0f, 0f, width * frac, h, h / 2f, h / 2f, p)
    }
}

/** Dialog bergaya osu!lazer: panel gelap membulat, tombol teks di kanan bawah. */
object LDialog {
    private fun dp(c: Context, v: Int) = Ui.dp(c, v)

    fun make(a: Activity, widthDp: Int = 360): Pair<Dialog, LinearLayout> {
        val tracker = UiTouchTracker(a)
        val dlg = object : Dialog(a) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                try {
                    window?.decorView?.let { tracker.onTouch(it, ev) }
                } catch (e: Exception) {
                }
                return super.dispatchTouchEvent(ev)
            }
        }
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(a)
        box.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xF51F1C36.toInt(), 0xF5121120.toInt())
        )
        bg.cornerRadius = dp(a, 18).toFloat()
        bg.setStroke(dp(a, 1), 0x30FFFFFF)
        box.background = bg
        box.setPadding(dp(a, 20), dp(a, 16), dp(a, 20), dp(a, 12))
        dlg.setContentView(box)
        dlg.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout(
                min(dp(a, widthDp), a.resources.displayMetrics.widthPixels - dp(a, 32)),
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            w.setDimAmount(0.6f)
        }
        return Pair(dlg, box)
    }

    fun textButton(c: Context, label: String, primary: Boolean, onClick: () -> Unit): TextView {
        val t = Ui.text(c, label, 14f, if (primary) Ui.ACCENT else Ui.TEXT, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 10))
        t.background = Ui.ripple(Ui.rounded(Color.TRANSPARENT, dp(c, 10).toFloat()))
        t.setOnClickListener { onClick() }
        return t
    }

    fun title(a: Activity, box: LinearLayout, s: String) {
        val t = Ui.text(a, s, 17f, Color.WHITE, true)
        t.maxLines = 2
        t.ellipsize = TextUtils.TruncateAt.END
        box.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    fun buttons(a: Activity, box: LinearLayout, vararg b: View) {
        val row = LinearLayout(a)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.END
        for (v in b) row.addView(v, LinearLayout.LayoutParams(-2, -2))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(a, 10)
        box.addView(row, lp)
    }

    fun confirm(a: Activity, title: String, message: String, ok: String, onOk: () -> Unit) {
        val (dlg, box) = make(a)
        title(a, box, title)
        val m = Ui.text(a, message, 14f, Ui.SUB)
        val mp = LinearLayout.LayoutParams(-1, -2)
        mp.topMargin = dp(a, 8)
        box.addView(m, mp)
        buttons(
            a, box,
            textButton(a, "Batal", false) { dlg.dismiss() },
            textButton(a, ok, true) {
                dlg.dismiss()
                onOk()
            }
        )
        dlg.showImmersive(a)
    }

    /** Daftar pilihan satu-satu. cur = indeks terpilih (-1 = tidak ada yang ditandai). */
    fun pick(a: Activity, title: String, opts: List<String>, cur: Int, onPick: (Int) -> Unit) {
        val (dlg, box) = make(a, 380)
        title(a, box, title)
        val list = LinearLayout(a)
        list.orientation = LinearLayout.VERTICAL
        for ((i, o) in opts.withIndex()) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(a, 6), 0, dp(a, 6), 0)
            row.background = Ui.ripple(Ui.rounded(Color.TRANSPARENT, dp(a, 10).toFloat()))
            val dot = object : View(a) {
                private val q = Paint(Paint.ANTI_ALIAS_FLAG)
                override fun onDraw(cv: Canvas) {
                    val cx = width / 2f
                    val cy = height / 2f
                    val r = min(width, height) / 2f - 1f
                    q.style = Paint.Style.STROKE
                    q.strokeWidth = 2f
                    q.color = if (i == cur) Ui.ACCENT else 0x66FFFFFF
                    cv.drawCircle(cx, cy, r, q)
                    if (i == cur) {
                        q.style = Paint.Style.FILL
                        q.color = Ui.ACCENT
                        cv.drawCircle(cx, cy, r * 0.5f, q)
                    }
                }
            }
            row.addView(dot, LinearLayout.LayoutParams(dp(a, 18), dp(a, 18)))
            val t = Ui.text(a, o, 14f, if (i == cur) Color.WHITE else 0xFFCFCFE0.toInt(), i == cur)
            t.maxLines = 2
            val tp = LinearLayout.LayoutParams(0, -2, 1f)
            tp.leftMargin = dp(a, 12)
            row.addView(t, tp)
            row.setOnClickListener {
                dlg.dismiss()
                onPick(i)
            }
            list.addView(row, LinearLayout.LayoutParams(-1, dp(a, 46)))
        }
        val maxH = (a.resources.displayMetrics.heightPixels - dp(a, 150)).coerceAtLeast(dp(a, 120))
        val sv = CappedScroll(a, maxH)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        val sp = LinearLayout.LayoutParams(-1, -2)
        sp.topMargin = dp(a, 8)
        box.addView(sv, sp)
        buttons(a, box, textButton(a, "Tutup", false) { dlg.dismiss() })
        dlg.showImmersive(a)
    }
}
