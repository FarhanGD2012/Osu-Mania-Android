package com.maniadroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Tampilan note yang minimalis (warna rata + garis tepi tipis, tanpa gradasi / kilap).
 * Warna dan gambar kustom diatur per kolom, terpisah untuk tiap mode key (Pengaturan > Note).
 */
object NoteSkin {
    const val WHITE = 0xFFF2F2F7.toInt()
    const val BLUE = 0xFF5BB8FF.toInt()
    const val YELLOW = 0xFFFFD84D.toInt()

    /** Warna cepat pilih di layar Gaya note. */
    val PALETTE = intArrayOf(
        0xFFF2F2F7.toInt(), 0xFF5BB8FF.toInt(), 0xFFFFD84D.toInt(), 0xFFFF5FA2.toInt(),
        0xFFFF5A5A.toInt(), 0xFFFF9F4D.toInt(), 0xFF7DDC6A.toInt(), 0xFF4DD0C8.toInt(),
        0xFFB38CFF.toInt(), 0xFF8A93A6.toInt(), 0xFF2B2B3A.toInt(), 0xFFFFFFFF.toInt()
    )

    /** Pola bawaan: kolom luar putih, berikutnya biru, bergantian; kolom tengah (key ganjil) kuning. */
    fun defaultColor(keys: Int, c: Int): Int {
        if (keys % 2 == 1 && c == keys / 2) return YELLOW
        return if (min(c, keys - 1 - c) % 2 == 0) WHITE else BLUE
    }

    // ---- warna bawaan skin osu!lazer (Argon), per jumlah key ----
    private val A_Y = 0xFFFFC528.toInt()
    private val A_O = 0xFFFC6D01.toInt()
    private val A_P = 0xFFD5235A.toInt()
    private val A_U = 0xFFCB3CEC.toInt()
    private val A_C = 0xFF48C6FF.toInt()
    private val A_G = 0xFF64C05C.toInt()
    private val A_S = 0xFFA96AFF.toInt()

    private fun argonLayout(keys: Int): IntArray? = when (keys) {
        1 -> intArrayOf(A_Y)
        2 -> intArrayOf(A_G, A_C)
        3 -> intArrayOf(A_G, A_S, A_C)
        4 -> intArrayOf(A_Y, A_O, A_P, A_U)
        5 -> intArrayOf(A_P, A_O, A_Y, A_G, A_C)
        6 -> intArrayOf(A_P, A_O, A_G, A_C, A_O, A_P)
        7 -> intArrayOf(A_P, A_O, A_P, A_S, A_P, A_O, A_P)
        8 -> intArrayOf(A_U, A_P, A_O, A_G, A_C, A_O, A_P, A_U)
        9 -> intArrayOf(A_U, A_P, A_O, A_Y, A_S, A_Y, A_O, A_P, A_U)
        10 -> intArrayOf(A_U, A_P, A_O, A_Y, A_G, A_C, A_Y, A_O, A_P, A_U)
        else -> null
    }

    fun argonColor(keys: Int, c: Int): Int {
        val l = argonLayout(keys)
        if (l != null) return l[c.coerceIn(0, l.size - 1)]
        val cycle = intArrayOf(A_Y, A_O, A_P, A_U, A_C, A_G)
        return cycle[c % cycle.size]
    }

    fun color(keys: Int, c: Int): Int =
        Settings.noteColor(keys, c) ?: if (Settings.noteShape == 2) argonColor(keys, c) else defaultColor(keys, c)

    fun lighten(color: Int, k: Float): Int = mix(color, Color.WHITE, k)
    fun darkenTo(color: Int, k: Float): Int = mix(color, Color.BLACK, k)
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt().coerceIn(0, 255),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt().coerceIn(0, 255),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt().coerceIn(0, 255)
    )

    fun imageFile(ctx: Context, keys: Int, c: Int): File = File(ctx.filesDir, "note_${keys}_$c.png")

    fun hasImage(ctx: Context, keys: Int, c: Int): Boolean = imageFile(ctx, keys, c).let { it.isFile && it.length() > 0 }

    fun clearImage(ctx: Context, keys: Int, c: Int) {
        imageFile(ctx, keys, c).delete()
    }

    // ---- trail note (badan hold): gambar kustom per kolom ----
    fun trailImageFile(ctx: Context, keys: Int, c: Int): File = File(ctx.filesDir, "trail_${keys}_$c.png")

    fun hasTrailImage(ctx: Context, keys: Int, c: Int): Boolean = trailImageFile(ctx, keys, c).let { it.isFile && it.length() > 0 }

    fun clearTrailImage(ctx: Context, keys: Int, c: Int) {
        trailImageFile(ctx, keys, c).delete()
    }

    /** Kembalikan satu kolom ke bawaan (warna + gambar note, warna + gambar trail). */
    fun resetColumn(ctx: Context, keys: Int, c: Int) {
        Settings.setNoteColor(keys, c, null)
        Settings.setTrailColor(keys, c, null)
        clearImage(ctx, keys, c)
        clearTrailImage(ctx, keys, c)
    }

    /** Kembalikan hanya trail satu kolom ke bawaan. */
    fun resetTrail(ctx: Context, keys: Int, c: Int) {
        Settings.setTrailColor(keys, c, null)
        clearTrailImage(ctx, keys, c)
    }

    /** Isi warna trail: warna kustom bila ada, kalau tidak warna bawaan (skin Argon: warna kolom digelapkan). */
    fun trailFill(ctx: Context, keys: Int, c: Int, argon: Boolean): Int =
        Settings.trailColor(keys, c) ?: if (argon) darkenTo(bodyColor(ctx, keys, c), 0.6f) else bodyColor(ctx, keys, c)

    /**
     * Shader gambar trail: gambar diskalakan selebar badan hold lalu diulang ke bawah mengikuti panjang trail.
     * Null bila kolom ini tidak punya gambar trail. Posisi pola diatur lewat setLocalMatrix saat menggambar.
     */
    fun trailShader(ctx: Context, keys: Int, c: Int, widthPx: Int): BitmapShader? {
        val f = trailImageFile(ctx, keys, c)
        if (!f.isFile || f.length() == 0L || widthPx < 4) return null
        return try {
            val src = BitmapFactory.decodeFile(f.path) ?: return null
            val k = widthPx.toFloat() / src.width
            val h = (src.height * k).roundToInt().coerceIn(8, 1400)
            val bmp = Bitmap.createScaledBitmap(src, widthPx, h, true)
            BitmapShader(bmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        } catch (e: Throwable) {
            null
        }
    }

    /** Salin gambar pilihan pengguna (diperkecil, maksimal 512 px) sebagai gambar note satu kolom. Panggil dari thread latar. */
    fun importImage(ctx: Context, uri: Uri, keys: Int, c: Int): Boolean = importTo(ctx, uri, imageFile(ctx, keys, c))

    /** Sama seperti importImage, untuk gambar trail (badan hold). */
    fun importTrailImage(ctx: Context, uri: Uri, keys: Int, c: Int): Boolean = importTo(ctx, uri, trailImageFile(ctx, keys, c))

    private fun importTo(ctx: Context, uri: Uri, dest: File): Boolean {
        try {
            val cr = ctx.contentResolver
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            if (o.outWidth <= 0 || o.outHeight <= 0) return false
            var s = 1
            while (max(o.outWidth, o.outHeight) / (s * 2) >= 512) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val src = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return false
            val big = max(src.width, src.height)
            val out = if (big > 512) {
                val k = 512f / big
                Bitmap.createScaledBitmap(src, max(1, (src.width * k).roundToInt()), max(1, (src.height * k).roundToInt()), true)
            } else src
            FileOutputStream(dest).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            return true
        } catch (e: Throwable) {
            return false
        }
    }

    private fun loadImage(ctx: Context, keys: Int, c: Int): Bitmap? {
        val f = imageFile(ctx, keys, c)
        if (!f.isFile || f.length() == 0L) return null
        return try {
            BitmapFactory.decodeFile(f.path)
        } catch (e: Throwable) {
            null
        }
    }

    private fun darken(color: Int, k: Float): Int =
        Color.rgb((Color.red(color) * k).toInt(), (Color.green(color) * k).toInt(), (Color.blue(color) * k).toInt())

    private fun luminance(color: Int): Float =
        (0.299f * Color.red(color) + 0.587f * Color.green(color) + 0.114f * Color.blue(color)) / 255f

    /** Warna badan hold: warna kolom, atau rata-rata warna gambar bila kolom memakai gambar. */
    fun bodyColor(ctx: Context, keys: Int, c: Int): Int {
        val img = loadImage(ctx, keys, c) ?: return color(keys, c)
        return try {
            val px = Bitmap.createScaledBitmap(img, 1, 1, true).getPixel(0, 0)
            Color.rgb(Color.red(px), Color.green(px), Color.blue(px))
        } catch (e: Throwable) {
            color(keys, c)
        }
    }

    /**
     * Gambar satu note berukuran w x h. circle = bulat, selain itu persegi panjang membulat kecil.
     * Tanpa gambar kustom: warna rata + garis tepi tipis (putih; abu-abu muda untuk note yang sangat terang).
     */
    fun make(ctx: Context, keys: Int, c: Int, w: Int, h: Int, circle: Boolean): Bitmap =
        makeStyle(ctx, keys, c, w, h, if (circle) 0 else 1, false)

    /** style: 0 bulat, 1 persegi panjang, 2 osu!lazer (Argon). flip = upscroll (bagian berwarna di sisi atas). */
    fun makeStyle(ctx: Context, keys: Int, c: Int, w: Int, h: Int, style: Int, flip: Boolean): Bitmap {
        if (style == 2) return argon(ctx, keys, c, w, h, flip)
        val circle = style == 0
        return makeClassic(ctx, keys, c, w, h, circle)
    }

    /**
     * Note ala skin Argon osu!lazer (ArgonNotePiece): kotak membulat kecil, dasar gradasi hitam, badan berwarna
     * (gradasi terang ke warna kolom) setinggi 82%, garis putih membulat di tepi hit, dan tanda panah di tengah.
     */
    private fun argon(ctx: Context, keys: Int, c: Int, w: Int, h: Int, flip: Boolean): Bitmap {
        val bw = max(w, 6)
        val bh = max(h, 6)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        if (flip) cv.scale(1f, -1f, bw / 2f, bh / 2f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val accent = color(keys, c)
        val img = loadImage(ctx, keys, c)
        val rad = max(2f, bh * 3.4f / 42f)
        val full = RectF(0f, 0f, bw.toFloat(), bh.toFloat())
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, bh.toFloat(), 0x00000000, 0xFF000000.toInt(), Shader.TileMode.CLAMP)
        cv.drawRoundRect(full, rad, rad, p)
        val top = bh * (1f - 0.82f)
        val box = RectF(0f, top, bw.toFloat(), bh.toFloat())
        if (img != null) {
            cv.save()
            val clip = Path()
            clip.addRoundRect(box, rad, rad, Path.Direction.CW)
            cv.clipPath(clip)
            val dstAspect = box.width() / box.height()
            val srcAspect = img.width.toFloat() / img.height
            val src = Rect()
            if (srcAspect > dstAspect) {
                val sw = (img.height * dstAspect).roundToInt()
                src.set((img.width - sw) / 2, 0, (img.width + sw) / 2, img.height)
            } else {
                val sh = (img.width / dstAspect).roundToInt()
                src.set(0, (img.height - sh) / 2, img.width, (img.height + sh) / 2)
            }
            p.shader = null
            cv.drawBitmap(img, src, box, p)
            cv.restore()
        } else {
            p.shader = LinearGradient(0f, top, 0f, bh.toFloat(), lighten(accent, 0.1f), accent, Shader.TileMode.CLAMP)
            cv.drawRoundRect(box, rad, rad, p)
        }
        p.shader = null
        p.color = Color.WHITE
        cv.drawRoundRect(RectF(0f, bh - rad * 2f, bw.toFloat(), bh.toFloat()), rad, rad, p)
        if (img == null) {
            // tanda panah ke bawah (AngleDown yang dipipihkan 0,7x)
            val iw = bh * 20f / 42f
            val ih = iw * 0.7f * 0.55f
            val cx = bw / 2f
            val cy = bh / 2f + bh * 4f / 42f - bh * 0.02f
            p.style = Paint.Style.STROKE
            p.strokeWidth = max(1.5f, bh * 0.07f)
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.color = Color.WHITE
            val ch = Path()
            ch.moveTo(cx - iw * 0.36f, cy - ih)
            ch.lineTo(cx, cy + ih)
            ch.lineTo(cx + iw * 0.36f, cy - ih)
            cv.drawPath(ch, p)
        }
        return bmp
    }

    private fun makeClassic(ctx: Context, keys: Int, c: Int, w: Int, h: Int, circle: Boolean): Bitmap {
        val bw = max(w, 4)
        val bh = max(h, 4)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val base = color(keys, c)
        val img = loadImage(ctx, keys, c)
        val stroke = max(1.5f, min(bw, bh) * 0.075f)
        val box = RectF(stroke / 2f, stroke / 2f, bw - stroke / 2f, bh - stroke / 2f)
        val radius = if (circle) min(box.width(), box.height()) / 2f else min(box.height() * 0.28f, box.width() * 0.2f)
        val shape = Path()
        if (circle) shape.addOval(box, Path.Direction.CW) else shape.addRoundRect(box, radius, radius, Path.Direction.CW)

        if (img != null) {
            // gambar kustom: isi bentuk note dengan potongan tengah gambar
            cv.save()
            cv.clipPath(shape)
            val dstAspect = box.width() / box.height()
            val srcAspect = img.width.toFloat() / img.height
            val src = Rect()
            if (srcAspect > dstAspect) {
                val sw = (img.height * dstAspect).roundToInt()
                src.set((img.width - sw) / 2, 0, (img.width + sw) / 2, img.height)
            } else {
                val sh = (img.width / dstAspect).roundToInt()
                src.set(0, (img.height - sh) / 2, img.width, (img.height + sh) / 2)
            }
            cv.drawBitmap(img, src, box, p)
            cv.restore()
        } else {
            p.style = Paint.Style.FILL
            p.color = base
            cv.drawPath(shape, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = stroke
        p.color = if (img == null && luminance(base) > 0.8f) darken(base, 0.72f) else Color.WHITE
        cv.drawPath(shape, p)
        return bmp
    }
}
