package com.maniadroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Tampilan note yang minimalis (warna rata + garis tepi tipis, tanpa gradasi / kilap).
 * Warna dan gambar kustom diatur per kolom, terpisah untuk tiap mode key (Pengaturan > Note).
 */
object NoteSkin {
    const val WHITE = 0xFFF2F2F7.toInt()
    const val BLUE = 0xFF5BB8FF.toInt()
    const val YELLOW = 0xFFFFD84D.toInt()

    /** Warna cepat pilih di layar Gaya note. */
    val PALETTE = intArrayOf(
        0xFFF2F2F7.toInt(), 0xFF5BB8FF.toInt(), 0xFFFFD84D.toInt(), 0xFFFF5FA2.toInt(),
        0xFFFF5A5A.toInt(), 0xFFFF9F4D.toInt(), 0xFF7DDC6A.toInt(), 0xFF4DD0C8.toInt(),
        0xFFB38CFF.toInt(), 0xFF8A93A6.toInt(), 0xFF2B2B3A.toInt(), 0xFFFFFFFF.toInt()
    )

    /** Pola bawaan: kolom luar putih, berikutnya biru, bergantian; kolom tengah (key ganjil) kuning. */
    fun defaultColor(keys: Int, c: Int): Int {
        if (keys % 2 == 1 && c == keys / 2) return YELLOW
        return if (min(c, keys - 1 - c) % 2 == 0) WHITE else BLUE
    }

    fun color(keys: Int, c: Int): Int = Settings.noteColor(keys, c) ?: defaultColor(keys, c)

    fun imageFile(ctx: Context, keys: Int, c: Int): File = File(ctx.filesDir, "note_${keys}_$c.png")

    fun hasImage(ctx: Context, keys: Int, c: Int): Boolean = imageFile(ctx, keys, c).let { it.isFile && it.length() > 0 }

    fun clearImage(ctx: Context, keys: Int, c: Int) {
        imageFile(ctx, keys, c).delete()
    }

    /** Kembalikan satu kolom ke bawaan (warna + gambar). */
    fun resetColumn(ctx: Context, keys: Int, c: Int) {
        Settings.setNoteColor(keys, c, null)
        clearImage(ctx, keys, c)
    }

    /** Salin gambar pilihan pengguna (diperkecil, maksimal 512 px) sebagai gambar note satu kolom. Panggil dari thread latar. */
    fun importImage(ctx: Context, uri: Uri, keys: Int, c: Int): Boolean {
        try {
            val cr = ctx.contentResolver
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            if (o.outWidth <= 0 || o.outHeight <= 0) return false
            var s = 1
            while (max(o.outWidth, o.outHeight) / (s * 2) >= 512) s *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = s
            val src = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return false
            val big = max(src.width, src.height)
            val out = if (big > 512) {
                val k = 512f / big
                Bitmap.createScaledBitmap(src, max(1, (src.width * k).roundToInt()), max(1, (src.height * k).roundToInt()), true)
            } else src
            FileOutputStream(imageFile(ctx, keys, c)).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            return true
        } catch (e: Throwable) {
            return false
        }
    }

    private fun loadImage(ctx: Context, keys: Int, c: Int): Bitmap? {
        val f = imageFile(ctx, keys, c)
        if (!f.isFile || f.length() == 0L) return null
        return try {
            BitmapFactory.decodeFile(f.path)
        } catch (e: Throwable) {
            null
        }
    }

    private fun darken(color: Int, k: Float): Int =
        Color.rgb((Color.red(color) * k).toInt(), (Color.green(color) * k).toInt(), (Color.blue(color) * k).toInt())

    private fun luminance(color: Int): Float =
        (0.299f * Color.red(color) + 0.587f * Color.green(color) + 0.114f * Color.blue(color)) / 255f

    /** Warna badan hold: warna kolom, atau rata-rata warna gambar bila kolom memakai gambar. */
    fun bodyColor(ctx: Context, keys: Int, c: Int): Int {
        val img = loadImage(ctx, keys, c) ?: return color(keys, c)
        return try {
            val px = Bitmap.createScaledBitmap(img, 1, 1, true).getPixel(0, 0)
            Color.rgb(Color.red(px), Color.green(px), Color.blue(px))
        } catch (e: Throwable) {
            color(keys, c)
        }
    }

    /**
     * Gambar satu note berukuran w x h. circle = bulat, selain itu persegi panjang membulat kecil.
     * Tanpa gambar kustom: warna rata + garis tepi tipis (putih; abu-abu muda untuk note yang sangat terang).
     */
    fun make(ctx: Context, keys: Int, c: Int, w: Int, h: Int, circle: Boolean): Bitmap {
        val bw = max(w, 4)
        val bh = max(h, 4)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val base = color(keys, c)
        val img = loadImage(ctx, keys, c)
        val stroke = max(1.5f, min(bw, bh) * 0.075f)
        val box = RectF(stroke / 2f, stroke / 2f, bw - stroke / 2f, bh - stroke / 2f)
        val radius = if (circle) min(box.width(), box.height()) / 2f else min(box.height() * 0.28f, box.width() * 0.2f)
        val shape = Path()
        if (circle) shape.addOval(box, Path.Direction.CW) else shape.addRoundRect(box, radius, radius, Path.Direction.CW)

        if (img != null) {
            // gambar kustom: isi bentuk note dengan potongan tengah gambar
            cv.save()
            cv.clipPath(shape)
            val dstAspect = box.width() / box.height()
            val srcAspect = img.width.toFloat() / img.height
            val src = Rect()
            if (srcAspect > dstAspect) {
                val sw = (img.height * dstAspect).roundToInt()
                src.set((img.width - sw) / 2, 0, (img.width + sw) / 2, img.height)
            } else {
                val sh = (img.width / dstAspect).roundToInt()
                src.set(0, (img.height - sh) / 2, img.width, (img.height + sh) / 2)
            }
            cv.drawBitmap(img, src, box, p)
            cv.restore()
        } else {
            p.style = Paint.Style.FILL
            p.color = base
            cv.drawPath(shape, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = stroke
        p.color = if (img == null && luminance(base) > 0.8f) darken(base, 0.72f) else Color.WHITE
        cv.drawPath(shape, p)
        return bmp
    }
}
