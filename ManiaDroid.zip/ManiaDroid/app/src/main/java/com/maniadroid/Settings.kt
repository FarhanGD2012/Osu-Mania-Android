package com.maniadroid

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

object Settings {
    lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("maniadroid", Context.MODE_PRIVATE)
            // skin note osu!lazer (Argon) jadi bawaan; pengguna lama dipindahkan sekali (bisa diganti lagi di Pengaturan > Note)
            if (!sp.getBoolean("skinArgonMigrated", false)) {
                sp.edit().putInt("noteShape", 2).putBoolean("skinArgonMigrated", true).apply()
            }
            // pengguna lama yang sudah memasang gambar background: tetap pakai gambar itu untuk menu
            if (!sp.contains("menuBg")) {
                val f = java.io.File(c.applicationContext.filesDir, "custom_bg")
                if (f.isFile && f.length() > 0) sp.edit().putInt("menuBg", 2).apply()
            }
        }
    }

    val ready: Boolean get() = ::sp.isInitialized

    private class IntP(val k: String, val d: Int) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = Settings.sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            Settings.sp.edit().putInt(k, value).apply()
        }
    }

    private class BoolP(val k: String, val d: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = Settings.sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            Settings.sp.edit().putBoolean(k, value).apply()
        }
    }

    private class StrP(val k: String, val d: String) : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = Settings.sp.getString(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
            Settings.sp.edit().putString(k, value).apply()
        }
    }

    // --- Bahasa ---
    var language by IntP("language", 0)             // 0 Indonesia, 1 English (juga menerjemahkan MISS / EARLY / LATE saat bermain)
    // --- Gameplay ---
    var scrollSpeed by IntP("scrollSpeed", 20)      // 1..40
    var upscroll by BoolP("upscroll", false)
    var hitPos by IntP("hitPos", 85)                // 70..95 (% tinggi layar)
    var colWidth by IntP("colWidth", 100)           // 60..150 (%)
    var noFail by BoolP("noFail", false)
    var noteShape by IntP("noteShape", 2)           // 0 bulat, 1 persegi panjang, 2 osu!lazer (Argon)
    var resumeRewind by IntP("resumeRewind", 2)     // 0..5 detik: musik mundur saat lanjut dari jeda (note yang sudah kena tetap hilang)
    var resumeCountdown by BoolP("resumeCountdown", true) // hitung mundur 3-2-1 sebelum lanjut, seperti Clone Hero
    var keyCounter by BoolP("keyCounter", false)    // hitungan tekan per kolom di bawah garis hit (key counter osu!lazer)
    var pauseOnLeave by BoolP("pauseOnLeave", true) // jeda otomatis saat game ditinggalkan (jendela kehilangan fokus)
    var colLight by BoolP("colLight", true)         // kolom menyala saat ditekan (skin Argon)
    var selectPreview by BoolP("selectPreview", true) // putar cuplikan lagu saat memilih chart
    // --- Timing ---
    var offset by IntP("offset", 0)                 // -300..300 ms (sentuhan)
    var padOffset by IntP("padOffset", 0)           // -300..300 ms (controller / keyboard)
    // --- Audio ---
    var masterVol by IntP("masterVol", 100)         // volume utama (mengalikan semua volume lain), seperti osu!lazer
    var musicVol by IntP("musicVol", 80)
    var sfxVol by IntP("sfxVol", 60)
    var uiSound by BoolP("uiSound", true)           // suara saat tombol menu ditekan
    var uiVol by IntP("uiVol", 70)                  // volume suara tombol 0..100
    // --- Visual ---
    var bgDim by IntP("bgDim", 35)
    var bgBlur by IntP("bgBlur", 0)                 // 0..100 blur gambar / video background saat main (Android 12+)
    var laneOpacity by IntP("laneOpacity", 0)      // 0..100 (% gelap panel lane)
    var chartBgImage by BoolP("chartBgImage", false) // gambar BG chart yang TIDAK punya video (default hitam)
    var showBg by BoolP("showBg", true)
    var showVideo by BoolP("showVideo", true)
    var introEnabled by BoolP("introEnabled", true)  // intro ala osu!lazer saat membuka game
    var menuBg by IntP("menuBg", 0)                 // latar menu: 0 bawaan osu!lazer (segitiga), 1 hitam polos, 2 gambar sendiri
    var themeHue by IntP("themeHue", 290)           // 0..360, warna latar bawaan
    var bgTriangles by BoolP("bgTriangles", true)   // segitiga latar bergerak
    var showCombo by BoolP("showCombo", true)        // angka combo di tengah layar
    var showJudge by BoolP("showJudge", true)        // tulisan MAX / 300 / Meleset ...
    var showAcc by BoolP("showAcc", true)            // skor + akurasi (kanan atas)
    var showHp by BoolP("showHp", true)              // persen lagu + HP (kiri atas)
    var hitError by BoolP("hitError", true)          // bar kesalahan timing di bawah layar
    var hitEffect by BoolP("hitEffect", true)        // cincin cahaya di bulatan saat note kena
    var hudScale by IntP("hudScale", 100)            // 70..150 (%)
    var showFps by BoolP("showFps", false)
    var highRefresh by BoolP("highRefresh", true)    // minta refresh rate layar tertinggi saat bermain
    var pauseButton by BoolP("pauseButton", true)    // tombol jeda di layar (Back / tombol Start tetap bisa menjeda)
    var lockEdge by BoolP("lockEdge", true)          // cegah gestur tepi layar (Back) menelan sentuhan kolom paling kiri / kanan
    // --- Input ---
    var haptic by BoolP("haptic", false)
    var orientation by IntP("orientation", 1)       // 0 portrait, 1 landscape, 2 otomatis
    // --- Musik menu ---
    var menuMusic by BoolP("menuMusic", true)
    var menuMusicCharts by BoolP("menuMusicCharts", true)
    // --- Unduhan ---
    var mirror by IntP("mirror", 0)                 // 0 otomatis, 1.. = mirror tertentu diprioritaskan
    var dlVideo by BoolP("dlVideo", true)
    var dlConnections by IntP("dlConnections", 4)   // 1..8 koneksi paralel per unduhan (lebih cepat jika mirror membatasi per koneksi)
    var dlFastMirror by BoolP("dlFastMirror", true)  // mirror yang terakhir berhasil dicoba lebih dulu
    var dlSort by IntP("dlSort", 0)                 // urutan hasil unduhan (lihat Downloader.SORT_NAMES)
    var dlPeriod by IntP("dlPeriod", 0)             // periode (lihat Downloader.PERIOD_NAMES)
    // --- Multiplayer (tanpa akun) ---
    var vsName by StrP("vsName", "")                // nama pemain di Multiplayer (kosong = dibuatkan otomatis)
    var vsAutoReady by BoolP("vsAutoReady", false)  // langsung "Siap" begitu chart room sudah ada di HP

    // --- Gaya note: warna & gambar kustom per kolom, terpisah untuk tiap mode key (1K..10K) ---
    fun noteColor(keys: Int, col: Int): Int? =
        if (sp.contains("ncol_${keys}_$col")) sp.getInt("ncol_${keys}_$col", 0) else null

    fun setNoteColor(keys: Int, col: Int, color: Int?) {
        val e = sp.edit()
        if (color == null) e.remove("ncol_${keys}_$col") else e.putInt("ncol_${keys}_$col", color)
        e.apply()
    }

    // --- Trail note (badan hold): warna kustom per kolom, terpisah untuk tiap mode key ---
    fun trailColor(keys: Int, col: Int): Int? =
        if (sp.contains("tcol_${keys}_$col")) sp.getInt("tcol_${keys}_$col", 0) else null

    fun setTrailColor(keys: Int, col: Int, color: Int?) {
        val e = sp.edit()
        if (color == null) e.remove("tcol_${keys}_$col") else e.putInt("tcol_${keys}_$col", color)
        e.apply()
    }

    /** Volume nyata = volume bagian x volume utama (0..1). */
    val musicGain: Float get() = (musicVol * masterVol / 10000f).coerceIn(0f, 1f)
    val sfxGain: Float get() = (sfxVol * masterVol / 10000f).coerceIn(0f, 1f)
    val uiGain: Float get() = (uiVol * masterVol / 10000f).coerceIn(0f, 1f)

    fun best(key: String): Int = sp.getInt("best_$key", 0)

    fun saveBest(key: String, v: Int) {
        if (v > best(key)) sp.edit().putInt("best_$key", v).apply()
    }

    fun reset() {
        val e = sp.edit()
        for (k in sp.all.keys) if (!k.startsWith("best_") && k != "vsName") e.remove(k)
        e.apply()
    }
}
