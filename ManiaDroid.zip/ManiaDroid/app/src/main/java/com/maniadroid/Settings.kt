package com.maniadroid

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

object Settings {
    lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("maniadroid", Context.MODE_PRIVATE)
            // pengguna lama yang sudah memasang gambar background: tetap pakai gambar itu untuk menu
            if (!sp.contains("menuBg")) {
                val f = java.io.File(c.applicationContext.filesDir, "custom_bg")
                if (f.isFile && f.length() > 0) sp.edit().putInt("menuBg", 2).apply()
            }
        }
    }

    val ready: Boolean get() = ::sp.isInitialized

    private class IntP(val k: String, val d: Int) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = Settings.sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            Settings.sp.edit().putInt(k, value).apply()
        }
    }

    private class BoolP(val k: String, val d: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = Settings.sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            Settings.sp.edit().putBoolean(k, value).apply()
        }
    }

    // --- Bahasa ---
    var language by IntP("language", 0)             // 0 Indonesia, 1 English (juga menerjemahkan MISS / EARLY / LATE saat bermain)
    // --- Gameplay ---
    var scrollSpeed by IntP("scrollSpeed", 20)      // 1..40
    var upscroll by BoolP("upscroll", false)
    var hitPos by IntP("hitPos", 85)                // 70..95 (% tinggi layar)
    var colWidth by IntP("colWidth", 100)           // 60..150 (%)
    var noFail by BoolP("noFail", false)
    var noteShape by IntP("noteShape", 0)           // 0 bulat, 1 persegi panjang
    var resumeRewind by IntP("resumeRewind", 2)     // 0..5 detik: musik mundur saat lanjut dari jeda (note yang sudah kena tetap hilang)
    var resumeCountdown by BoolP("resumeCountdown", true) // hitung mundur 3-2-1 sebelum lanjut, seperti Clone Hero
    // --- Timing ---
    var offset by IntP("offset", 0)                 // -300..300 ms (sentuhan)
    var padOffset by IntP("padOffset", 0)           // -300..300 ms (controller / keyboard)
    // --- Audio ---
    var musicVol by IntP("musicVol", 80)
    var sfxVol by IntP("sfxVol", 60)
    // --- Visual ---
    var bgDim by IntP("bgDim", 35)
    var laneOpacity by IntP("laneOpacity", 0)      // 0..100 (% gelap panel lane)
    var chartBgImage by BoolP("chartBgImage", false) // gambar BG chart yang TIDAK punya video (default hitam)
    var showBg by BoolP("showBg", true)
    var showVideo by BoolP("showVideo", true)
    var introEnabled by BoolP("introEnabled", true)  // intro ala osu!lazer saat membuka game
    var menuBg by IntP("menuBg", 0)                 // latar menu: 0 bawaan osu!lazer (segitiga), 1 hitam polos, 2 gambar sendiri
    var themeHue by IntP("themeHue", 290)           // 0..360, warna latar bawaan
    var bgTriangles by BoolP("bgTriangles", true)   // segitiga latar bergerak
    // --- Input ---
    var haptic by BoolP("haptic", false)
    var orientation by IntP("orientation", 1)       // 0 portrait, 1 landscape, 2 otomatis
    // --- Musik menu ---
    var menuMusic by BoolP("menuMusic", true)
    var menuMusicCharts by BoolP("menuMusicCharts", true)
    // --- Unduhan ---
    var mirror by IntP("mirror", 0)                 // 0 otomatis, 1.. = mirror tertentu diprioritaskan
    var dlVideo by BoolP("dlVideo", true)

    // --- Gaya note: warna & gambar kustom per kolom, terpisah untuk tiap mode key (1K..10K) ---
    fun noteColor(keys: Int, col: Int): Int? =
        if (sp.contains("ncol_${keys}_$col")) sp.getInt("ncol_${keys}_$col", 0) else null

    fun setNoteColor(keys: Int, col: Int, color: Int?) {
        val e = sp.edit()
        if (color == null) e.remove("ncol_${keys}_$col") else e.putInt("ncol_${keys}_$col", color)
        e.apply()
    }

    fun best(key: String): Int = sp.getInt("best_$key", 0)

    fun saveBest(key: String, v: Int) {
        if (v > best(key)) sp.edit().putInt("best_$key", v).apply()
    }

    fun reset() {
        val e = sp.edit()
        for (k in sp.all.keys) if (!k.startsWith("best_")) e.remove(k)
        e.apply()
    }
}
