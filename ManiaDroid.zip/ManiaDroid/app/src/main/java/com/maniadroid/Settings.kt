package com.maniadroid

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

object Settings {
    lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            sp = c.applicationContext.getSharedPreferences("maniadroid", Context.MODE_PRIVATE)
        }
    }

    private class IntP(val k: String, val d: Int) : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = Settings.sp.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
            Settings.sp.edit().putInt(k, value).apply()
        }
    }

    private class BoolP(val k: String, val d: Boolean) : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = Settings.sp.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            Settings.sp.edit().putBoolean(k, value).apply()
        }
    }

    // --- Gameplay ---
    var scrollSpeed by IntP("scrollSpeed", 20)      // 1..40
    var upscroll by BoolP("upscroll", false)
    var hitPos by IntP("hitPos", 85)                // 70..95 (% tinggi layar)
    var colWidth by IntP("colWidth", 100)           // 60..150 (%)
    var noFail by BoolP("noFail", false)
    // --- Timing ---
    var offset by IntP("offset", 0)                 // -300..300 ms
    // --- Audio ---
    var musicVol by IntP("musicVol", 80)
    var sfxVol by IntP("sfxVol", 60)
    // --- Visual ---
    var bgDim by IntP("bgDim", 70)
    var showBg by BoolP("showBg", true)
    var showVideo by BoolP("showVideo", true)
    // --- Input ---
    var haptic by BoolP("haptic", false)
    var orientation by IntP("orientation", 0)       // 0 portrait, 1 landscape, 2 otomatis
    // --- Unduhan ---
    var mirror by IntP("mirror", 0)                 // 0 Nerinyan, 1 Catboy
    var dlVideo by BoolP("dlVideo", true)

    fun best(key: String): Int = sp.getInt("best_$key", 0)

    fun saveBest(key: String, v: Int) {
        if (v > best(key)) sp.edit().putInt("best_$key", v).apply()
    }

    fun reset() {
        val e = sp.edit()
        for (k in sp.all.keys) if (!k.startsWith("best_")) e.remove(k)
        e.apply()
    }
}
