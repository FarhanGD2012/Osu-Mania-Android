package com.maniadroid

import java.io.File

class Note(val col: Int, val time: Int, val endTime: Int) {
    val isHold: Boolean get() = endTime > time
    var finished = false
    var holding = false
    var missed = false
}

class Beatmap(val file: File) {
    val dir: File get() = file.parentFile!!
    var title = ""
    var artist = ""
    var version = ""
    var creator = ""
    var audio = ""
    var keys = 4
    var od = 5f
    var mode = 0
    var bg: String? = null
    var video: String? = null
    var videoOffset = 0
    var noteCount = 0
    var hp = 5f
    var hasTiming = false
    var timingOffset = 0.0
    var beatLength = 500.0
    var bpmMin = 120.0
    var bpmMax = 120.0
    var firstTime = Int.MAX_VALUE
    var lastTime = 0
    val bpmText: String
        get() = if (!hasTiming) "-" else if (bpmMax - bpmMin < 1.0) "${Math.round(60000.0 / beatLength)} BPM"
        else "${Math.round(bpmMin)}–${Math.round(bpmMax)} BPM"
    val lengthText: String
        get() {
            val sec = (if (lastTime > 0) lastTime else 0) / 1000
            return String.format(java.util.Locale.US, "%d:%02d", sec / 60, sec % 60)
        }
    val nps: Float get() = if (lastTime > firstTime) noteCount * 1000f / (lastTime - firstTime) else 0f
    val notes = ArrayList<Note>()

    private fun kv(l: String): Pair<String, String>? {
        val i = l.indexOf(':')
        if (i < 0) return null
        return Pair(l.substring(0, i).trim(), l.substring(i + 1).trim())
    }

    private fun handle(section: String, l: String, withNotes: Boolean) {
        when (section) {
            "[General]" -> {
                val p = kv(l) ?: return
                when (p.first) {
                    "AudioFilename" -> audio = p.second
                    "Mode" -> mode = p.second.toIntOrNull() ?: 0
                }
            }
            "[Metadata]" -> {
                val p = kv(l) ?: return
                when (p.first) {
                    "Title" -> title = p.second
                    "Artist" -> artist = p.second
                    "Version" -> version = p.second
                    "Creator" -> creator = p.second
                }
            }
            "[Difficulty]" -> {
                val p = kv(l) ?: return
                when (p.first) {
                    "CircleSize" -> keys = (p.second.toFloatOrNull() ?: 4f).toInt().coerceIn(1, 10)
                    "OverallDifficulty" -> od = p.second.toFloatOrNull() ?: 5f
                    "HPDrainRate" -> hp = p.second.toFloatOrNull() ?: 5f
                }
            }
            "[Events]" -> {
                val p = l.split(',')
                if (p.size >= 3) {
                    val name = p[2].trim().trim('"')
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if ((p[0] == "Video" || p[0] == "1") && ext in VIDEO_EXT) {
                        video = name
                        videoOffset = p[1].trim().toIntOrNull() ?: 0
                    } else if (p[0] == "0" && ext in IMG_EXT && bg == null) {
                        bg = name
                    }
                }
            }
            "[TimingPoints]" -> {
                val p = l.split(',')
                if (p.size >= 2) {
                    val t = p[0].trim().toDoubleOrNull()
                    val bl = p[1].trim().toDoubleOrNull()
                    val uninh = if (p.size > 6) p[6].trim() else "1"
                    if (t != null && bl != null && bl > 0 && uninh == "1") {
                        val bpm = 60000.0 / bl
                        if (!hasTiming) {
                            hasTiming = true
                            timingOffset = t
                            beatLength = bl
                            bpmMin = bpm
                            bpmMax = bpm
                        } else {
                            if (bpm < bpmMin) bpmMin = bpm
                            if (bpm > bpmMax) bpmMax = bpm
                        }
                    }
                }
            }
            "[HitObjects]" -> {
                noteCount++
                val i1 = l.indexOf(',')
                val i2 = l.indexOf(',', i1 + 1)
                val i3 = l.indexOf(',', i2 + 1)
                if (i1 > 0 && i2 > i1 && i3 > i2) {
                    val tm = l.substring(i2 + 1, i3).trim().toIntOrNull()
                    if (tm != null) {
                        if (tm < firstTime) firstTime = tm
                        if (tm > lastTime) lastTime = tm
                    }
                }
                if (withNotes) addNote(l)
            }
        }
    }

    private fun addNote(l: String) {
        val p = l.split(',')
        if (p.size < 5) return
        val x = p[0].trim().toIntOrNull() ?: return
        val t = p[2].trim().toIntOrNull() ?: return
        val type = p[3].trim().toIntOrNull() ?: return
        val col = (x * keys / 512).coerceIn(0, keys - 1)
        if ((type and 128) != 0) {
            val end = p.getOrNull(5)?.substringBefore(':')?.trim()?.toIntOrNull() ?: t
            notes.add(Note(col, t, if (end > t) end else t))
        } else if ((type and 1) != 0) {
            notes.add(Note(col, t, t))
        }
    }

    companion object {
        private val VIDEO_EXT = setOf("mp4", "avi", "flv", "mkv", "wmv", "mov", "webm", "m4v", "mpg", "mpeg", "3gp")
        private val IMG_EXT = setOf("jpg", "jpeg", "png", "bmp", "webp")

        /** Mengembalikan null jika bukan chart osu!mania (Mode: 3) atau file rusak. */
        fun parse(file: File, withNotes: Boolean): Beatmap? {
            val b = Beatmap(file)
            try {
                var section = ""
                file.bufferedReader(Charsets.UTF_8).use { r ->
                    var first = true
                    while (true) {
                        val raw = r.readLine() ?: break
                        var l = raw.trim()
                        if (first) {
                            l = l.removePrefix("\uFEFF")
                            first = false
                        }
                        if (l.isEmpty() || l.startsWith("//")) continue
                        if (l.startsWith("[")) {
                            section = l
                            continue
                        }
                        b.handle(section, l, withNotes)
                    }
                }
            } catch (e: Exception) {
                return null
            }
            if (b.mode != 3 || b.audio.isEmpty()) return null
            b.notes.sortBy { it.time }
            return b
        }
    }
}
