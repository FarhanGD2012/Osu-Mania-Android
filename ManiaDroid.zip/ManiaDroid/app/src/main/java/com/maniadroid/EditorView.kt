package com.maniadroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class ENote(var col: Int, var time: Int, var end: Int)

/** Kanvas editor chart: geser untuk menggulir, ketuk untuk menaruh/menghapus note (menempel ke grid beat). */
class EditorView(
    ctx: Context,
    private val keys: Int,
    val notes: ArrayList<ENote>,
    private val mp: MediaPlayer,
    private val duration: Int
) : View(ctx), Choreographer.FrameCallback {

    val divs = intArrayOf(1, 2, 3, 4, 6, 8, 12, 16)
    var beatLength = 500.0
    var offset = 0.0
    var divIdx = 3
    var zoom = 1f
    var rate = 1f
    var tickOn = true
    var pos = 0.0
    var onChange: (() -> Unit)? = null
    var onPlayState: ((Boolean) -> Unit)? = null
    var onSync: ((Double) -> Unit)? = null   // dipanggil ~400 ms sekali saat memutar (untuk video BG)
    var onSeek: ((Double) -> Unit)? = null   // dipanggil setelah menggeser waktu (pratinjau frame video)
    var playing = false
        private set
    var mode = 0 // 0 tap, 1 hold, 2 hapus
        set(v) {
            field = v
            pendingCol = -1
            invalidate()
        }

    private val undo = ArrayList<List<ENote>>()
    private var pendingCol = -1
    private var pendingTime = 0
    private var ghostOn = false
    private var ghostCol = -1
    private var ghostTime = 0
    private var dragging = false
    private var downY = 0f
    private var lastY = 0f
    private var lastPos = 0
    private var lastNano = 0L
    private var tickIdx = 0
    private var destroyed = false
    private var lastFrameNs = 0L
    private var lastSyncAt = 0L

    // tahan lama + geser = membuat note panjang (hold)
    private val handler = Handler(Looper.getMainLooper())
    private val longRunnable = Runnable { startHoldDrag() }
    private var downX = 0f
    private var fingerY = 0f
    private var holdDrag = false
    private var holdCol = -1
    private var holdStart = 0
    private var holdEnd = 0

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val dens = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var laneW = 0f
    private var fieldX = 0f
    private var hitY = 0f

    private fun px(): Double = hitY / 1100.0 * zoom
    private fun step(): Double = beatLength / divs[divIdx]

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        laneW = min(w * 0.6f / keys, h * 0.22f)
        fieldX = (w - laneW * keys) / 2f
        hitY = h * 0.78f
    }

    fun begin() {
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun destroy() {
        destroyed = true
        Choreographer.getInstance().removeFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (destroyed) return
        val dtMs = if (lastFrameNs == 0L) 16.0 else ((frameTimeNanos - lastFrameNs) / 1e6).coerceIn(0.0, 60.0)
        lastFrameNs = frameTimeNanos
        if (holdDrag) { // gulir otomatis saat jari mendekati tepi atas/bawah
            val top = height * 0.22f
            val bottom = height * 0.88f
            if (fingerY < top) pos = clampPos(pos + dtMs * (top - fingerY) / top * 1.6 / zoom)
            else if (fingerY > bottom) pos = clampPos(pos - dtMs * (fingerY - bottom) / (height - bottom) * 1.6 / zoom)
            holdEnd = max(holdStart, snapTime(pos + (hitY - fingerY) / px()))
        }
        if (playing) {
            val nowMs = System.nanoTime() / 1_000_000L
            if (nowMs - lastSyncAt > 400) {
                lastSyncAt = nowMs
                onSync?.invoke(pos)
            }
            val now = System.nanoTime()
            val m = try {
                mp.currentPosition
            } catch (e: Exception) {
                lastPos
            }
            if (m != lastPos) {
                lastPos = m
                lastNano = now
            }
            pos = lastPos + (now - lastNano) / 1e6 * rate
            if (tickIdx > notes.size) tickIdx = notes.size
            while (tickIdx < notes.size && notes[tickIdx].time <= pos) {
                if (tickOn && notes[tickIdx].time > pos - 100) Sfx.play(max(0.3f, Settings.sfxVol / 100f))
                tickIdx++
            }
            if (pos >= duration) pausePlayback()
        }
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    // ---------- playback ----------
    private fun firstAfter(t: Double): Int {
        var i = 0
        while (i < notes.size && notes[i].time <= t) i++
        return i
    }

    fun togglePlay() {
        if (playing) pausePlayback() else startPlayback()
    }

    private fun startPlayback() {
        if (playing) return
        val start = max(0.0, pos)
        if (start >= duration) return
        mp.setOnSeekCompleteListener { m ->
            m.setOnSeekCompleteListener(null)
            try {
                m.start()
                if (Build.VERSION.SDK_INT >= 23) m.playbackParams = PlaybackParams().setSpeed(rate)
            } catch (e: Exception) {
            }
            lastPos = start.toInt()
            lastNano = System.nanoTime()
            pos = start
            tickIdx = firstAfter(pos)
            playing = true
            onPlayState?.invoke(true)
        }
        mp.seekTo(start.toInt())
    }

    fun pausePlayback() {
        if (!playing) return
        try {
            mp.pause()
        } catch (e: Exception) {
        }
        playing = false
        onPlayState?.invoke(false)
    }

    // ---------- editing ----------
    private fun snapTime(raw: Double): Int {
        val s = step()
        val k = Math.round((raw - offset) / s)
        return Math.round(offset + k * s).toInt()
    }

    private fun findAt(col: Int, t: Int): ENote? {
        val tol = max(12.0, step() * 0.45)
        for (n in notes) {
            if (n.col != col) continue
            if (abs(n.time - t) <= tol || (n.end > n.time && t >= n.time && t <= n.end)) return n
        }
        return null
    }

    private fun pushUndo() {
        undo.add(notes.map { ENote(it.col, it.time, it.end) })
        if (undo.size > 60) undo.removeAt(0)
    }

    fun undoLast() {
        if (undo.isEmpty()) return
        val last = undo.removeAt(undo.size - 1)
        notes.clear()
        notes.addAll(last)
        changed()
    }

    private fun changed() {
        notes.sortWith(compareBy({ it.time }, { it.col }))
        tickIdx = firstAfter(pos)
        onChange?.invoke()
        invalidate()
    }

    private fun colAt(x: Float): Int {
        if (x < fieldX) return -1
        val c = ((x - fieldX) / laneW).toInt()
        return if (c in 0 until keys) c else -1
    }

    private fun place(x: Float, y: Float) {
        val col = colAt(x)
        if (col < 0) return
        val t = snapTime(pos + (hitY - y) / px())
        if (t < 0) return
        val hit = findAt(col, t)
        if (hit != null) {
            pushUndo()
            notes.remove(hit)
            changed()
            return
        }
        when (mode) {
            0 -> {
                pushUndo()
                notes.add(ENote(col, t, t))
                changed()
            }
            1 -> {
                if (pendingCol == col && t > pendingTime) {
                    pushUndo()
                    notes.add(ENote(col, pendingTime, t))
                    pendingCol = -1
                    changed()
                } else {
                    pendingCol = col
                    pendingTime = t
                }
            }
        }
    }

    fun clampPos(v: Double): Double = v.coerceIn(-1500.0, duration.toDouble())

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                lastY = e.y
                fingerY = e.y
                dragging = false
                holdDrag = false
                ghostOn = true
                updateGhost(e.x, e.y)
                if (mode != 2) handler.postDelayed(longRunnable, 380)
            }
            MotionEvent.ACTION_MOVE -> {
                fingerY = e.y
                if (holdDrag) {
                    holdEnd = max(holdStart, snapTime(pos + (hitY - e.y) / px()))
                } else {
                    if (!dragging && abs(e.y - downY) > slop) {
                        dragging = true
                        ghostOn = false
                        handler.removeCallbacks(longRunnable)
                        if (playing) pausePlayback()
                    }
                    if (dragging) {
                        pos = clampPos(pos + (e.y - lastY) / px())
                        lastY = e.y
                    } else {
                        updateGhost(e.x, e.y)
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longRunnable)
                ghostOn = false
                if (holdDrag) {
                    commitHold()
                } else if (dragging) {
                    try {
                        mp.seekTo(max(0, pos.toInt()))
                    } catch (ex: Exception) {
                    }
                    onSeek?.invoke(pos)
                } else {
                    place(e.x, e.y)
                }
                holdDrag = false
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longRunnable)
                ghostOn = false
                dragging = false
                holdDrag = false
            }
        }
        return true
    }

    private fun startHoldDrag() {
        if (dragging || playing) return
        val col = colAt(downX)
        if (col < 0) return
        val t = snapTime(pos + (hitY - downY) / px())
        if (t < 0 || findAt(col, t) != null) return
        holdDrag = true
        holdCol = col
        holdStart = t
        holdEnd = t
        ghostOn = false
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun commitHold() {
        if (holdCol < 0) return
        pushUndo()
        notes.add(ENote(holdCol, holdStart, if (holdEnd > holdStart) holdEnd else holdStart))
        holdCol = -1
        changed()
    }

    private fun updateGhost(x: Float, y: Float) {
        ghostCol = colAt(x)
        ghostTime = snapTime(pos + (hitY - y) / px())
    }

    // ---------- drawing ----------
    private fun noteColor(c: Int): Int {
        if (keys % 2 == 1 && c == keys / 2) return 0xFFFFD84D.toInt()
        return if (min(c, keys - 1 - c) % 2 == 0) 0xFFF2F2F7.toInt() else 0xFF5BB8FF.toInt()
    }

    private fun yAt(t: Double): Float = (hitY - (t - pos) * px()).toFloat()

    private fun ball(cv: Canvas, cx: Float, cy: Float, r: Float, base: Int, a: Int) {
        val dark = Color.rgb((Color.red(base) * 0.62f).toInt(), (Color.green(base) * 0.62f).toInt(), (Color.blue(base) * 0.62f).toInt())
        p.style = Paint.Style.FILL
        p.color = (dark and 0x00FFFFFF) or (a shl 24)
        cv.drawCircle(cx, cy, r, p)
        p.color = (base and 0x00FFFFFF) or (a shl 24)
        cv.drawCircle(cx, cy, r * 0.76f, p)
    }

    private fun fmt(ms: Double): String {
        val neg = ms < 0
        val t = abs(ms).toLong()
        return String.format(Locale.US, "%s%d:%02d.%03d", if (neg) "-" else "", t / 60000, (t / 1000) % 60, t % 1000)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        cv.drawColor(0xB80B0B14.toInt())
        val fieldW = laneW * keys
        val px = px()
        val tTop = pos + hitY / px
        val tBottom = pos - (h - hitY) / px
        val r = min(laneW * 0.38f, h * 0.075f)

        p.style = Paint.Style.FILL
        for (c in 0 until keys) {
            p.color = if (c % 2 == 0) 0x14FFFFFF else 0x0AFFFFFF
            val x = fieldX + c * laneW
            cv.drawRect(x, 0f, x + laneW, h, p)
        }
        p.color = 0x44FFFFFF
        for (i in 0..keys) {
            val x = fieldX + i * laneW
            cv.drawRect(x - 1f, 0f, x + 1f, h, p)
        }

        // grid beat
        val st = step()
        val div = divs[divIdx].toLong()
        val k0 = floor((tBottom - offset) / st).toLong()
        val k1 = ceil((tTop - offset) / st).toLong()
        if (k1 - k0 < 1500) {
            p.textSize = 11f * dens
            p.textAlign = Paint.Align.RIGHT
            p.typeface = Typeface.DEFAULT
            for (k in k0..k1) {
                val t = offset + k * st
                val y = yAt(t)
                val isBeat = Math.floorMod(k, div) == 0L
                val isHalf = div % 2L == 0L && Math.floorMod(k, div / 2) == 0L
                if (isBeat) {
                    p.color = 0x99FFFFFF.toInt()
                    cv.drawRect(fieldX, y - 1f * dens, fieldX + fieldW, y + 1f * dens, p)
                    if (Math.floorMod(Math.floorDiv(k, div), 4L) == 0L) {
                        p.color = 0xAAC9C9DA.toInt()
                        cv.drawText(fmt(t), fieldX - 10f * dens, y + 4f * dens, p)
                    }
                } else if (isHalf) {
                    p.color = 0x55FFFFFF
                    cv.drawRect(fieldX, y - 0.5f * dens, fieldX + fieldW, y + 0.5f * dens, p)
                } else {
                    p.color = 0x30FFFFFF
                    cv.drawRect(fieldX, y - 0.5f * dens, fieldX + fieldW, y + 0.5f * dens, p)
                }
            }
        }

        // note
        for (n in notes) {
            if (n.end < tBottom - 50 || n.time > tTop + 50) continue
            val cx = fieldX + n.col * laneW + laneW / 2f
            val base = noteColor(n.col)
            val yh = yAt(n.time.toDouble())
            if (n.end > n.time) {
                val yt = yAt(n.end.toDouble())
                val bw = r * 1.1f
                p.style = Paint.Style.FILL
                p.color = (base and 0x00FFFFFF) or (150 shl 24)
                rect.set(cx - bw / 2f, min(yh, yt), cx + bw / 2f, max(yh, yt))
                cv.drawRoundRect(rect, bw / 2f, bw / 2f, p)
                p.color = (base and 0x00FFFFFF) or (255 shl 24)
                rect.set(cx - r, yt - 3f * dens, cx + r, yt + 3f * dens)
                cv.drawRoundRect(rect, 3f * dens, 3f * dens, p)
            }
            ball(cv, cx, yh, r, base, 255)
        }

        // pratinjau hold yang sedang ditarik
        if (holdDrag && holdCol >= 0) {
            val cx = fieldX + holdCol * laneW + laneW / 2f
            val y1 = yAt(holdStart.toDouble())
            val y2 = yAt(holdEnd.toDouble())
            val bw = r * 1.1f
            p.style = Paint.Style.FILL
            p.color = (noteColor(holdCol) and 0x00FFFFFF) or (150 shl 24)
            rect.set(cx - bw / 2f, min(y1, y2), cx + bw / 2f, max(y1, y2))
            cv.drawRoundRect(rect, bw / 2f, bw / 2f, p)
            ball(cv, cx, y1, r, noteColor(holdCol), 200)
            p.color = (noteColor(holdCol) and 0x00FFFFFF) or (255 shl 24)
            rect.set(cx - r, y2 - 3f * dens, cx + r, y2 + 3f * dens)
            cv.drawRoundRect(rect, 3f * dens, 3f * dens, p)
        }

        // hold tertunda + hantu
        if (mode == 1 && pendingCol >= 0) {
            val cx = fieldX + pendingCol * laneW + laneW / 2f
            ball(cv, cx, yAt(pendingTime.toDouble()), r, noteColor(pendingCol), 140)
        }
        if (ghostOn && ghostCol >= 0) {
            val cx = fieldX + ghostCol * laneW + laneW / 2f
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * dens
            p.color = if (mode == 2) 0xFFFF5A5A.toInt() else 0xFFFFFFFF.toInt()
            cv.drawCircle(cx, yAt(ghostTime.toDouble()), r, p)
            p.style = Paint.Style.FILL
        }

        // garis posisi sekarang
        p.style = Paint.Style.FILL
        p.color = Ui.ACCENT
        cv.drawRect(fieldX - 12f * dens, hitY - 1.5f * dens, fieldX + fieldW + 12f * dens, hitY + 1.5f * dens, p)

        // HUD
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.LEFT
        p.color = Color.WHITE
        p.textSize = 16f * dens
        cv.drawText(fmt(pos), 12f * dens, h - 56f * dens, p)
        p.typeface = Typeface.DEFAULT
        p.textSize = 12f * dens
        p.color = 0xFFC9C9DA.toInt()
        cv.drawText("Note: ${notes.size}   ·   Snap 1/${divs[divIdx]}   ·   ${String.format(Locale.US, "%.1f", 60000.0 / beatLength)} BPM", 12f * dens, h - 36f * dens, p)
        cv.drawText(when (mode) { 0 -> L.t("Mode: Tap (ketuk = taruh/hapus)", "Mode: Tap (tap = place/remove)"); 1 -> L.t("Mode: Hold (ketuk awal, lalu akhir)", "Mode: Hold (tap start, then end)"); else -> L.t("Mode: Hapus", "Mode: Erase") }, 12f * dens, h - 18f * dens, p)
        p.textAlign = Paint.Align.RIGHT
        cv.drawText(L.t("Geser = gulir waktu", "Drag = scroll time"), w - 12f * dens, h - 36f * dens, p)
    }
}
