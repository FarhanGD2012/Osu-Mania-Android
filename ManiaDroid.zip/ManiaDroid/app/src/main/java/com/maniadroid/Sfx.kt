package com.maniadroid

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** Suara klik: bawaan (dibuat sendiri) atau file buatan pengguna (filesDir/custom_hit). */
object Sfx {
    private var pool: SoundPool? = null
    private var id = 0

    fun init(c: Context) {
        if (pool != null) return
        build(c, null)
    }

    /** Muat ulang setelah pengguna mengganti / mengembalikan suara klik. */
    fun reload(c: Context, onLoaded: (() -> Unit)? = null) {
        pool?.release()
        pool = null
        build(c, onLoaded)
    }

    private fun build(c: Context, onLoaded: (() -> Unit)?) {
        val custom = File(c.filesDir, "custom_hit")
        val f = if (custom.isFile && custom.length() > 0) custom else {
            val d = File(c.cacheDir, "tap.wav")
            if (!d.exists()) writeWav(d)
            d
        }
        val p = SoundPool.Builder()
            .setMaxStreams(8)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        if (onLoaded != null) p.setOnLoadCompleteListener { _, _, _ -> onLoaded() }
        id = p.load(f.path, 1)
        pool = p
    }

    fun play(vol: Float) {
        pool?.play(id, vol, vol, 1, 0, 1f)
    }

    private fun writeWav(f: File) {
        val sr = 44100
        val n = sr * 60 / 1000
        val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + n * 2); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16)
        bb.putShort(1); bb.putShort(1); bb.putInt(sr); bb.putInt(sr * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(n * 2)
        val rnd = java.util.Random(1)
        for (i in 0 until n) {
            val env = exp(-i / 250.0)
            val s = (sin(2 * PI * 1100 * i / sr) * 0.55 + (rnd.nextDouble() * 2 - 1) * 0.25) * env
            bb.putShort((s * 32767).toInt().toShort())
        }
        f.writeBytes(bb.array())
    }
}
