package com.maniadroid

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/** Pengaturan ala osu!lazer: sidebar bagian di kiri, daftar pengaturan di kanan (bisa digulir), latar menu ikut tampil. */
class SettingsActivity : BaseActivity() {
    private class Sec(val title: String, val icon: Int) {
        lateinit var header: View
        lateinit var bar: View
        lateinit var label: TextView
        lateinit var icon_: IconView
    }

    private lateinit var backdrop: MenuBackdrop
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var side: LinearLayout
    private val secs = ArrayList<Sec>()
    private var active = -1

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)

        val root = FrameLayout(this)
        backdrop = MenuBackdrop(this)
        root.addView(backdrop, Ui.matchParams())
        val dim = View(this)
        dim.setBackgroundColor(0x55000000)
        root.addView(dim, Ui.matchParams())

        val main = LinearLayout(this)
        main.orientation = LinearLayout.HORIZONTAL
        root.addView(main, Ui.matchParams())

        // ---- sidebar ----
        val sidebar = LinearLayout(this)
        sidebar.orientation = LinearLayout.VERTICAL
        sidebar.setBackgroundColor(0xE0090811.toInt())
        val back = LinearLayout(this)
        back.orientation = LinearLayout.HORIZONTAL
        back.gravity = Gravity.CENTER_VERTICAL
        back.setPadding(dp(14), 0, dp(14), 0)
        back.background = Ui.ripple(Ui.rounded(Color.TRANSPARENT, 0f))
        back.addView(IconView(this, IconView.BACK, Ui.ACCENT), LinearLayout.LayoutParams(dp(18), dp(18)))
        val bt = Ui.text(this, "Kembali", 14f, Color.WHITE, true)
        val btp = LinearLayout.LayoutParams(-2, -2)
        btp.leftMargin = dp(8)
        back.addView(bt, btp)
        back.setOnClickListener { finish() }
        sidebar.addView(back, LinearLayout.LayoutParams(-1, dp(52)))

        side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        val sideScroll = ScrollView(this)
        sideScroll.isVerticalScrollBarEnabled = false
        sideScroll.addView(side)
        sidebar.addView(sideScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(sidebar, LinearLayout.LayoutParams(dp(156), -1))

        // ---- panel isi ----
        scroll = ScrollView(this)
        scroll.setBackgroundColor(0xB30B0A12.toInt())
        scroll.isVerticalScrollBarEnabled = false
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(24), dp(18), dp(24), dp(40))
        scroll.addView(content, FrameLayout.LayoutParams(-1, -2))
        main.addView(scroll, LinearLayout.LayoutParams(0, -1, 1f))
        scroll.setOnScrollChangeListener { _, _, y, _, _ -> updateActive(y) }

        setContentView(root)
        build()
        // ruang kosong di bawah supaya bagian terakhir bisa digulir sampai ke atas
        content.addView(View(this), LinearLayout.LayoutParams(-1, (resources.displayMetrics.heightPixels * 0.6f).toInt()))
        highlight(0)
    }

    override fun onResume() {
        super.onResume()
        backdrop.refresh()
    }

    // ---------- sidebar ----------
    private fun addSidebarItem(s: Sec, index: Int) {
        val it = LinearLayout(this)
        it.orientation = LinearLayout.HORIZONTAL
        it.gravity = Gravity.CENTER_VERTICAL
        it.background = Ui.ripple(Ui.rounded(Color.TRANSPARENT, 0f))
        s.bar = View(this)
        s.bar.setBackgroundColor(Color.TRANSPARENT)
        it.addView(s.bar, LinearLayout.LayoutParams(dp(3), dp(22)))
        s.icon_ = IconView(this, s.icon, 0xFF8C8AA6.toInt())
        val ip = LinearLayout.LayoutParams(dp(18), dp(18))
        ip.leftMargin = dp(12)
        it.addView(s.icon_, ip)
        s.label = Ui.text(this, s.title, 13f, 0xFF9C9AB4.toInt(), false)
        s.label.maxLines = 1
        s.label.ellipsize = TextUtils.TruncateAt.END
        val lp = LinearLayout.LayoutParams(0, -2, 1f)
        lp.leftMargin = dp(10)
        it.addView(s.label, lp)
        it.setOnClickListener {
            scroll.smoothScrollTo(0, (s.header.top - dp(10)).coerceAtLeast(0))
            highlight(index)
        }
        side.addView(it, LinearLayout.LayoutParams(-1, dp(42)))
    }

    private fun highlight(i: Int) {
        if (i == active || i !in secs.indices) return
        active = i
        for ((k, s) in secs.withIndex()) {
            val on = k == i
            s.bar.setBackgroundColor(if (on) Ui.ACCENT else Color.TRANSPARENT)
            s.label.setTextColor(if (on) Color.WHITE else 0xFF9C9AB4.toInt())
            s.icon_.tint = if (on) Ui.ACCENT else 0xFF8C8AA6.toInt()
            s.icon_.invalidate()
        }
    }

    private fun updateActive(y: Int) {
        var idx = 0
        for ((k, s) in secs.withIndex()) if (s.header.top <= y + dp(90)) idx = k
        highlight(idx)
    }

    // ---------- pembangun baris ----------
    private fun lp(top: Int): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(-1, -2)
        l.topMargin = dp(top)
        return l
    }

    private fun section(title: String, icon: Int) {
        val s = Sec(title, icon)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(Ui.text(this, title, 22f, Color.WHITE, true))
        val bar = View(this)
        bar.background = Ui.rounded(Ui.ACCENT, dp(2).toFloat())
        val bp = LinearLayout.LayoutParams(dp(34), dp(3))
        bp.topMargin = dp(6)
        box.addView(bar, bp)
        s.header = box
        content.addView(box, lp(if (secs.isEmpty()) 26 else 34))
        secs.add(s)
        addSidebarItem(s, secs.size - 1)
    }

    private fun labelColumn(label: String, desc: String?): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.addView(Ui.text(this, label, 14f, Color.WHITE))
        if (desc != null) {
            val d = Ui.text(this, desc, 11.5f, Ui.SUB)
            c.addView(d, lp(2))
        }
        return c
    }

    private fun toggle(label: String, value: Boolean, desc: String? = null, set: (Boolean) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(10), dp(8), dp(10))
        row.background = Ui.ripple(Ui.rounded(Color.TRANSPARENT, dp(10).toFloat()))
        row.addView(labelColumn(label, desc), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = LazerSwitch(this, value) { set(it) }
        val sp = LinearLayout.LayoutParams(-2, -2)
        sp.leftMargin = dp(14)
        row.addView(sw, sp)
        row.setOnClickListener { sw.toggle() }
        content.addView(row, lp(4))
    }

    private fun slider(label: String, min: Int, max: Int, value: Int, fmt: (Int) -> String, desc: String? = null, set: (Int) -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(8), dp(10), dp(8), dp(4))
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(Ui.text(this, label, 14f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        val vt = Ui.text(this, fmt(value), 13f, Ui.ACCENT, true)
        top.addView(vt, LinearLayout.LayoutParams(-2, -2))
        box.addView(top, LinearLayout.LayoutParams(-1, -2))
        val sl = LazerSlider(this, min, max, value) {
            vt.text = fmt(it)
            set(it)
        }
        box.addView(sl, lp(2))
        if (desc != null) box.addView(Ui.text(this, desc, 11.5f, Ui.SUB), lp(0))
        content.addView(box, lp(4))
    }

    private fun choice(label: String, opts0: List<String>, value: Int, desc: String? = null, set: (Int) -> Unit) {
        val opts = opts0.map { L.t(it) }
        var cur = value.coerceIn(0, opts.size - 1)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(8), dp(8), dp(8))
        row.addView(labelColumn(label, desc), LinearLayout.LayoutParams(0, -2, 1f))
        val dd = LazerDropdown(this, opts[cur])
        val dp1 = LinearLayout.LayoutParams(dp(190), -2)
        dp1.leftMargin = dp(14)
        row.addView(dd, dp1)
        val open = {
            LDialog.pick(this, label, opts, cur) { i ->
                cur = i
                dd.text = opts[i]
                set(i)
            }
        }
        dd.setOnClickListener { open() }
        content.addView(row, lp(4))
    }

    /** kind: 0 biasa, 1 utama (pink), 2 berbahaya (merah). */
    private fun action(label: String, kind: Int = 0, onClick: () -> Unit) {
        val bg = when (kind) {
            1 -> Ui.ACCENT
            2 -> 0xFF4A2332.toInt()
            else -> 0xFF2B2A3A.toInt()
        }
        val b = Ui.button(this, label, false, 10) { onClick() }
        b.background = Ui.ripple(Ui.rounded(bg, dp(10).toFloat()))
        b.setTextColor(if (kind == 2) 0xFFFF9AA8.toInt() else Color.WHITE)
        b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f)
        b.minHeight = dp(44)
        b.minimumHeight = dp(44)
        content.addView(b, lp(8))
    }

    private fun note(text: String) {
        content.addView(Ui.text(this, text, 11.5f, Ui.SUB), lp(8))
    }

    // ---------- isi ----------
    private fun build() {
        content.addView(Ui.text(this, "Pengaturan", 30f, Color.WHITE, true))
        content.addView(Ui.text(this, "Ubah cara Osu! Mania bekerja", 13f, Ui.ACCENT, true), lp(2))

        section("Bahasa / Language", IconView.GLOBE)
        choice(
            "Bahasa / Language", listOf("Indonesia", "English"), Settings.language,
            "Bahasa antarmuka dan tulisan saat bermain (Meleset, Terlalu cepat, Terlambat)"
        ) { i ->
            Settings.language = i
            recreate() // bangun ulang halaman ini dengan bahasa baru; layar lain menyusul saat dibuka
        }

        section("Gameplay", IconView.SLIDERS)
        slider("Kecepatan scroll", 1, 40, Settings.scrollSpeed, { it.toString() }) { Settings.scrollSpeed = it }
        toggle("Upscroll", Settings.upscroll, "Note datang dari bawah ke atas") { Settings.upscroll = it }
        slider("Posisi garis hit", 70, 95, Settings.hitPos, { "$it%" }) { Settings.hitPos = it }
        slider("Lebar kolom", 60, 150, Settings.colWidth, { "$it%" }) { Settings.colWidth = it }
        toggle("No Fail", Settings.noFail, "Tidak bisa gagal walau HP habis") { Settings.noFail = it }
        slider("Mundur saat lanjut dari jeda", 0, 5, Settings.resumeRewind, { if (it == 0) L.t("mati", "off") else L.t("$it dtk", "${it}s") }, "Musik mundur sedikit; note yang sudah kamu kena tetap hilang (seperti Clone Hero)") { Settings.resumeRewind = it }
        toggle("Hitung mundur 3-2-1", Settings.resumeCountdown, "Tampil sebelum permainan lanjut dari jeda") { Settings.resumeCountdown = it }

        section("Note", IconView.CIRCLE)
        choice("Bentuk note", listOf("Bulat", "Persegi panjang"), Settings.noteShape, "Bentuk note minimalis (warna rata + garis tepi tipis)") { Settings.noteShape = it }
        action("Atur warna & gambar note…", 1) { startActivity(Intent(this, NoteStyleActivity::class.java)) }
        note("Warna dan gambar kustom bisa dipasang satu per satu untuk tiap kolom, terpisah untuk tiap mode key.")

        section("Timing", IconView.SYNC)
        slider("Offset sentuhan", -300, 300, Settings.offset, { "$it ms" }, "Naikkan jika hit sering TERLAMBAT, turunkan jika sering TERLALU CEPAT") { Settings.offset = it }
        slider("Offset controller / keyboard", -300, 300, Settings.padOffset, { "$it ms" }) { Settings.padOffset = it }
        action("Sinkron otomatis (ketuk note, offset menyesuaikan)", 1) { startActivity(Intent(this, SyncActivity::class.java)) }

        section("Audio", IconView.SPEAKER)
        slider("Volume musik", 0, 100, Settings.musicVol, { "$it%" }) { Settings.musicVol = it }
        slider("Volume hitsound", 0, 100, Settings.sfxVol, { "$it%" }, "0 = hitsound mati") { Settings.sfxVol = it }
        toggle("Suara tombol", Settings.uiSound, "Bunyi klik saat menekan tombol di menu") {
            Settings.uiSound = it
            if (it) UiSound.play()
        }
        slider("Volume suara tombol", 0, 100, Settings.uiVol, { "$it%" }) { Settings.uiVol = it }
        action("Pilih suara klik sendiri (wav / ogg / mp3 pendek)") { pickFile("audio/*", 22, false) }
        action("Kembalikan suara klik bawaan") {
            File(filesDir, "custom_hit").delete()
            Sfx.reload(this) { Sfx.play(0.8f) }
            Toast.makeText(this, "Suara klik bawaan dipakai", Toast.LENGTH_SHORT).show()
        }
        action("Tes suara klik") { Sfx.play(max1(Settings.sfxVol / 100f)) }

        section("Musik menu", IconView.NOTE)
        toggle("Putar musik di menu utama", Settings.menuMusic) { Settings.menuMusic = it }
        toggle("Sertakan lagu dari chart", Settings.menuMusicCharts, "Lagu chart yang terpasang ikut diputar") { Settings.menuMusicCharts = it }
        action("Tambah lagu menu (bisa banyak sekaligus)") { pickFile("audio/*", 23, true) }
        action("Daftar lagu tambahan / hapus") { showMenuSongs() }

        section("Latar menu", IconView.IMAGE)
        choice(
            "Latar menu",
            listOf("Bawaan osu!lazer (segitiga)", "Hitam polos", "Gambar sendiri"),
            Settings.menuBg,
            "Pilihan langsung terlihat di belakang halaman ini"
        ) { i ->
            Settings.menuBg = i
            backdrop.refresh()
            if (i == 2 && Library.customBg(this) == null) pickFile("image/*", 21, false)
        }
        slider("Warna tema", 0, 360, Settings.themeHue, { "$it\u00B0" }, "Warna latar bawaan dan latar layar lain") {
            Settings.themeHue = it
            backdrop.redraw()
        }
        toggle("Segitiga bergerak", Settings.bgTriangles, "Matikan untuk menghemat baterai") {
            Settings.bgTriangles = it
            backdrop.refresh()
        }
        action("Pilih gambar background sendiri") { pickFile("image/*", 21, false) }
        action("Hapus gambar background") {
            File(filesDir, "custom_bg").delete()
            backdrop.refresh()
            Toast.makeText(this, "Gambar background dihapus", Toast.LENGTH_SHORT).show()
        }
        note("Gambar sendiri juga dipakai sebagai latar saat bermain chart yang tidak punya video.")

        section("Tampilan", IconView.DISPLAY)
        slider("Redup background", 0, 100, Settings.bgDim, { "$it%" }) { Settings.bgDim = it }
        slider("Kegelapan panel lane", 0, 100, Settings.laneOpacity, { "$it%" }) { Settings.laneOpacity = it }
        toggle("Tampilkan gambar background", Settings.showBg, "Untuk chart yang punya video") { Settings.showBg = it }
        toggle("Gambar BG chart untuk chart tanpa video", Settings.chartBgImage, "Bawaan: hitam seperti osu!mania") { Settings.chartBgImage = it }
        toggle("Putar video background", Settings.showVideo, "Jika ada dan formatnya didukung") { Settings.showVideo = it }
        toggle("Intro ala osu!lazer", Settings.introEnabled, "Diputar saat game dibuka") { Settings.introEnabled = it }

        section("Kontrol", IconView.GAMEPAD)
        toggle("Getar saat tap", Settings.haptic) { Settings.haptic = it }
        choice("Orientasi saat bermain", listOf("Portrait", "Landscape", "Otomatis"), Settings.orientation) { Settings.orientation = it }
        action("Atur tombol controller / keyboard") { startActivity(Intent(this, KeysActivity::class.java)) }

        section("Unduhan", IconView.DOWNLOAD)
        choice("Mirror utama", Downloader.names.toList(), Settings.mirror, "Mirror lain jadi cadangan") { Settings.mirror = it }
        toggle("Unduh chart beserta video", Settings.dlVideo, "File jauh lebih besar") { Settings.dlVideo = it }

        section("Data", IconView.TRASH)
        action("Hapus semua chart", 2) {
            LDialog.confirm(this, "Hapus semua chart?", "Semua chart yang sudah diimpor atau diunduh akan dihapus dari perangkat.", "Hapus") {
                Library.songsDir(this).deleteRecursively()
                Library.songsDir(this)
                Toast.makeText(this, "Semua chart dihapus", Toast.LENGTH_SHORT).show()
            }
        }
        action("Reset pengaturan ke default", 2) {
            Settings.reset()
            recreate()
        }
    }

    private fun max1(v: Float) = if (v < 0.3f) 0.3f else v

    private fun pickFile(type: String, req: Int, multiple: Boolean) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = type
        if (multiple) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        @Suppress("DEPRECATION")
        startActivityForResult(i, req)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        val uris = ArrayList<android.net.Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) uris.add(clip.getItemAt(k).uri)
        } else {
            val u = data.data
            if (u != null) uris.add(u)
        }
        if (uris.isEmpty()) return
        when (req) {
            21 -> Thread {
                val ok = Library.copyUri(this, uris[0], File(filesDir, "custom_bg"))
                runOnUiThread {
                    if (ok) {
                        Settings.menuBg = 2
                        backdrop.refresh()
                    }
                    Toast.makeText(this, if (ok) "Gambar background dipasang" else "Gagal memasang gambar", Toast.LENGTH_SHORT).show()
                }
            }.start()
            22 -> Thread {
                val dest = File(filesDir, "custom_hit")
                val ok = Library.copyUri(this, uris[0], dest)
                runOnUiThread {
                    if (!ok) {
                        Toast.makeText(this, "Gagal memasang suara klik", Toast.LENGTH_SHORT).show()
                    } else {
                        val big = dest.length() > 1_500_000
                        Sfx.reload(this) { Sfx.play(0.8f) }
                        Toast.makeText(
                            this,
                            if (big) "Terpasang, tapi file besar — pakai suara pendek (< 2 detik) supaya bisa dimainkan cepat"
                            else "Suara klik dipasang",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }.start()
            23 -> Thread {
                var n = 0
                for (u in uris) {
                    val name = Library.displayName(this, u) ?: "lagu_${System.currentTimeMillis()}.mp3"
                    if (Library.copyUri(this, u, File(Library.menuMusicDir(this), Library.safeName(name)))) n++
                }
                runOnUiThread { Toast.makeText(this, L.t("$n lagu ditambahkan ke musik menu", "$n songs added to menu music"), Toast.LENGTH_SHORT).show() }
            }.start()
        }
    }

    private fun showMenuSongs() {
        val files = Library.menuMusicDir(this).listFiles().orEmpty().filter { it.isFile }.sortedBy { it.name }
        if (files.isEmpty()) {
            Toast.makeText(this, "Belum ada lagu tambahan", Toast.LENGTH_SHORT).show()
            return
        }
        LDialog.pick(this, "Lagu tambahan (ketuk untuk menghapus)", files.map { it.nameWithoutExtension }, -1) { i ->
            LDialog.confirm(this, "Hapus lagu ini?", files[i].nameWithoutExtension, "Hapus") {
                files[i].delete()
                Toast.makeText(this, "Dihapus", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
