package com.maniadroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.Toast

class SettingsActivity : Activity() {
    private lateinit var box: LinearLayout
    private lateinit var card: LinearLayout

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        val sv = ScrollView(this)
        sv.background = Ui.bgGradient()
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(32))
        sv.addView(box)
        setContentView(sv)
        build()
    }

    private fun build() {
        box.addView(Ui.text(this, "Pengaturan", 26f, Ui.TEXT, true))

        section("Gameplay")
        slider("Kecepatan scroll", 1, 40, Settings.scrollSpeed, { it.toString() }) { Settings.scrollSpeed = it }
        toggle("Upscroll (note datang dari bawah ke atas)", Settings.upscroll) { Settings.upscroll = it }
        slider("Posisi garis hit", 70, 95, Settings.hitPos, { "$it%" }) { Settings.hitPos = it }
        slider("Lebar kolom", 60, 150, Settings.colWidth, { "$it%" }) { Settings.colWidth = it }
        choice("Bentuk note", arrayOf("Bulat", "Persegi panjang"), Settings.noteShape) { Settings.noteShape = it }
        toggle("No Fail (tidak bisa gagal)", Settings.noFail) { Settings.noFail = it }

        section("Timing")
        slider(
            "Offset sentuhan — naikkan jika hit sering LATE, turunkan jika sering EARLY",
            -300, 300, Settings.offset, { "$it ms" }
        ) { Settings.offset = it }
        slider(
            "Offset controller / keyboard",
            -300, 300, Settings.padOffset, { "$it ms" }
        ) { Settings.padOffset = it }
        action("⏱  Sinkron — ketuk note, offset otomatis") { startActivity(Intent(this, SyncActivity::class.java)) }

        section("Audio")
        slider("Volume musik", 0, 100, Settings.musicVol, { "$it%" }) { Settings.musicVol = it }
        slider("Volume hitsound (0 = mati)", 0, 100, Settings.sfxVol, { "$it%" }) { Settings.sfxVol = it }

        section("Tampilan")
        slider("Redup background", 0, 100, Settings.bgDim, { "$it%" }) { Settings.bgDim = it }
        slider("Kegelapan panel lane", 0, 100, Settings.laneOpacity, { "$it%" }) { Settings.laneOpacity = it }
        toggle("Tampilkan gambar background", Settings.showBg) { Settings.showBg = it }
        toggle("Putar video background (jika ada & formatnya didukung)", Settings.showVideo) { Settings.showVideo = it }

        section("Kontrol")
        toggle("Getar saat tap", Settings.haptic) { Settings.haptic = it }
        choice("Orientasi saat bermain", arrayOf("Portrait", "Landscape", "Otomatis"), Settings.orientation) {
            Settings.orientation = it
        }
        action("🎮  Atur tombol controller / keyboard") { startActivity(Intent(this, KeysActivity::class.java)) }

        section("Unduhan chart")
        choice("Mirror utama (sisanya jadi cadangan)", Downloader.names, Settings.mirror) { Settings.mirror = it }
        toggle("Unduh chart beserta video (file jauh lebih besar)", Settings.dlVideo) { Settings.dlVideo = it }

        section("Data")
        action("Hapus semua chart") {
            AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Hapus semua chart?")
                .setMessage("Semua chart yang sudah diimpor/diunduh akan dihapus dari perangkat.")
                .setPositiveButton("Hapus") { _, _ ->
                    Library.songsDir(this).deleteRecursively()
                    Library.songsDir(this)
                    Toast.makeText(this, "Semua chart dihapus", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Batal", null)
                .show()
        }
        action("Reset pengaturan ke default") {
            Settings.reset()
            recreate()
        }
    }

    private fun lp(top: Int): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(-1, -2)
        l.topMargin = dp(top)
        return l
    }

    private fun section(t: String) {
        box.addView(Ui.text(this, t.uppercase(), 12f, Ui.ACCENT, true), lp(20))
        card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(16), dp(8), dp(16), dp(14))
        card.background = Ui.rounded(0x99181826.toInt(), dp(18).toFloat())
        box.addView(card, lp(6))
    }

    private fun slider(label: String, min: Int, max: Int, value: Int, fmt: (Int) -> String, set: (Int) -> Unit) {
        val tv = Ui.text(this, "$label: ${fmt(value)}", 14f)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = value - min
        sb.progressTintList = ColorStateList.valueOf(Ui.ACCENT)
        sb.thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$label: ${fmt(min + p)}"
                if (fromUser) set(min + p)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        card.addView(tv, lp(12))
        card.addView(sb)
    }

    private fun toggle(label: String, value: Boolean, set: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = label
        sw.textSize = 14f
        sw.setTextColor(Ui.TEXT)
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, v -> set(v) }
        card.addView(sw, lp(12))
    }

    private fun choice(label: String, opts: Array<String>, value: Int, set: (Int) -> Unit) {
        var cur = value.coerceIn(0, opts.size - 1)
        val btn = Ui.button(this, "$label: ${opts[cur]}", false) {}
        btn.setOnClickListener {
            cur = (cur + 1) % opts.size
            set(cur)
            btn.text = "$label: ${opts[cur]}"
        }
        card.addView(btn, lp(12))
    }

    private fun action(label: String, onClick: () -> Unit) {
        card.addView(Ui.button(this, label, false, onClick), lp(12))
    }
}
