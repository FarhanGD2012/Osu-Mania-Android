package com.maniadroid

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.Toast

class SettingsActivity : Activity() {
    private lateinit var box: LinearLayout

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Ui.BG)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(32))
        sv.addView(box)
        setContentView(sv)
        build()
    }

    private fun build() {
        box.addView(Ui.text(this, "Pengaturan", 24f, Ui.TEXT, true))

        section("Gameplay")
        slider("Kecepatan scroll", 1, 40, Settings.scrollSpeed, { it.toString() }) { Settings.scrollSpeed = it }
        toggle("Upscroll (note turun dari atas ke bawah → naik dari bawah)", Settings.upscroll) { Settings.upscroll = it }
        slider("Posisi garis hit", 70, 95, Settings.hitPos, { "$it%" }) { Settings.hitPos = it }
        slider("Lebar kolom", 60, 150, Settings.colWidth, { "$it%" }) { Settings.colWidth = it }
        toggle("No Fail (tidak bisa gagal)", Settings.noFail) { Settings.noFail = it }

        section("Timing")
        slider("Offset audio (ms) — naikkan jika hit sering LATE, turunkan jika sering EARLY",
            -300, 300, Settings.offset, { "$it ms" }) { Settings.offset = it }

        section("Audio")
        slider("Volume musik", 0, 100, Settings.musicVol, { "$it%" }) { Settings.musicVol = it }
        slider("Volume hitsound (0 = mati)", 0, 100, Settings.sfxVol, { "$it%" }) { Settings.sfxVol = it }

        section("Tampilan")
        slider("Redup background", 0, 100, Settings.bgDim, { "$it%" }) { Settings.bgDim = it }
        toggle("Tampilkan gambar background", Settings.showBg) { Settings.showBg = it }
        toggle("Putar video background (jika chart punya & formatnya didukung)", Settings.showVideo) { Settings.showVideo = it }

        section("Kontrol")
        toggle("Getar saat tap", Settings.haptic) { Settings.haptic = it }
        choice("Orientasi layar", arrayOf("Portrait", "Landscape", "Otomatis"), Settings.orientation) { Settings.orientation = it }

        section("Unduhan chart")
        choice("Mirror unduhan", Downloader.mirrors, Settings.mirror) { Settings.mirror = it }
        toggle("Unduh chart beserta video (file jauh lebih besar)", Settings.dlVideo) { Settings.dlVideo = it }

        section("Data")
        box.addView(Ui.button(this, "Hapus semua chart") {
            AlertDialog.Builder(this)
                .setTitle("Hapus semua chart?")
                .setMessage("Semua chart yang sudah diimpor/diunduh akan dihapus dari perangkat.")
                .setPositiveButton("Hapus") { _, _ ->
                    Library.songsDir(this).deleteRecursively()
                    Library.songsDir(this)
                    Toast.makeText(this, "Semua chart dihapus", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Batal", null)
                .show()
        }, margin())
        box.addView(Ui.button(this, "Reset pengaturan ke default") {
            Settings.reset()
            recreate()
        }, margin())
    }

    private fun margin(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(10)
        return lp
    }

    private fun section(t: String) {
        val tv = Ui.text(this, t, 14f, Ui.ACCENT, true)
        tv.setPadding(0, dp(22), 0, dp(6))
        box.addView(tv)
    }

    private fun slider(label: String, min: Int, max: Int, value: Int, fmt: (Int) -> String, set: (Int) -> Unit) {
        val tv = Ui.text(this, "$label: ${fmt(value)}", 14f)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = value - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$label: ${fmt(min + p)}"
                if (fromUser) set(min + p)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(tv, margin())
        box.addView(sb)
    }

    private fun toggle(label: String, value: Boolean, set: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = label
        sw.setTextColor(Ui.TEXT)
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, v -> set(v) }
        box.addView(sw, margin())
    }

    private fun choice(label: String, opts: Array<String>, value: Int, set: (Int) -> Unit) {
        var cur = value.coerceIn(0, opts.size - 1)
        val btn = Ui.button(this, "$label: ${opts[cur]}") {}
        btn.setOnClickListener {
            cur = (cur + 1) % opts.size
            set(cur)
            btn.text = "$label: ${opts[cur]}"
        }
        box.addView(btn, margin())
    }
}
