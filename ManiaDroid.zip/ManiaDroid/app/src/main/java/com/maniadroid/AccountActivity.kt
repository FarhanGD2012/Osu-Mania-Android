package com.maniadroid

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Akun osu!: masuk lewat OAuth resmi, lihat profil mania, keluar. Dibuka lagi oleh browser lewat maniadroid://oauth. */
class AccountActivity : BaseActivity() {
    private lateinit var content: LinearLayout
    private lateinit var backdrop: MenuBackdrop
    private var busy = false

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        val root = FrameLayout(this)
        backdrop = MenuBackdrop(this)
        root.addView(backdrop, Ui.matchParams())
        val dim = View(this)
        dim.setBackgroundColor(0x99000000.toInt())
        root.addView(dim, Ui.matchParams())
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.gravity = Gravity.CENTER_HORIZONTAL
        content.setPadding(dp(24), dp(LazerBack.H_DP + 8), dp(24), dp(30))
        sv.addView(content, FrameLayout.LayoutParams(-1, -2))
        root.addView(sv, Ui.matchParams())
        root.addView(
            LazerBack(this) { finish() },
            FrameLayout.LayoutParams(dp(LazerBack.W_DP), dp(LazerBack.H_DP), Gravity.TOP or Gravity.START)
        )
        setContentView(root)
        render()
        handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        backdrop.refresh()
    }

    private fun handle(i: Intent?) {
        val d: Uri = i?.data ?: return
        if (d.scheme != "maniadroid") return
        i.data = null
        busy = true
        render()
        Thread {
            val err = OsuAccount.finishLogin(d)
            runOnUiThread {
                busy = false
                render()
                Toast.makeText(this, err ?: L.t("Berhasil masuk sebagai ${OsuAccount.name}", "Signed in as ${OsuAccount.name}"), Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun panel(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(20), dp(16), dp(20), dp(16))
        p.background = Ui.rounded(0xB30B0A12.toInt(), dp(18).toFloat())
        val lp = LinearLayout.LayoutParams(minOf(dp(560), resources.displayMetrics.widthPixels - dp(48)), -2)
        lp.topMargin = dp(12)
        content.addView(p, lp)
        return p
    }

    private fun field(box: LinearLayout, label: String, value: String, secret: Boolean, numeric: Boolean, onChange: (String) -> Unit) {
        box.addView(Ui.text(this, label, 12f, Ui.SUB), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(10) })
        val e = EditText(this)
        e.setText(value)
        e.setTextColor(Ui.TEXT)
        e.textSize = 14f
        e.setSingleLine(true)
        Ui.noExtractUi(e)
        e.inputType = when {
            numeric -> InputType.TYPE_CLASS_NUMBER
            secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else -> InputType.TYPE_CLASS_TEXT
        }
        e.background = Ui.rounded(0x33FFFFFF, dp(12).toFloat())
        e.setPadding(dp(14), dp(10), dp(14), dp(10))
        e.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) = onChange(s?.toString()?.trim() ?: "")
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        box.addView(e, LinearLayout.LayoutParams(-1, dp(46)).also { it.topMargin = dp(4) })
    }

    private fun render() {
        content.removeAllViews()
        val head = Ui.text(this, "Akun osu!", 28f, Color.WHITE, true)
        content.addView(head, LinearLayout.LayoutParams(minOf(dp(560), resources.displayMetrics.widthPixels - dp(48)), -2))
        if (busy) {
            val p = panel()
            p.addView(Ui.text(this, "Menghubungkan ke osu!…", 15f, Color.WHITE, true))
            return
        }
        if (OsuAccount.linked) renderProfile() else renderLogin()
    }

    private fun renderProfile() {
        val p = panel()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val av = ImageView(this)
        av.scaleType = ImageView.ScaleType.CENTER_CROP
        av.background = Ui.rounded(0xFF2B2A3A.toInt(), dp(14).toFloat())
        av.clipToOutline = true
        if (OsuAccount.avatar.isNotEmpty()) Img.load(OsuAccount.avatar, av)
        row.addView(av, LinearLayout.LayoutParams(dp(84), dp(84)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.text(this, OsuAccount.name, 24f, Color.WHITE, true))
        val sub = (if (OsuAccount.country.isNotEmpty()) OsuAccount.country + "  ·  " else "") + "osu!mania"
        col.addView(Ui.text(this, sub, 12.5f, Ui.ACCENT, true))
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = dp(16) })
        p.addView(row)

        val st = LinearLayout(this)
        st.orientation = LinearLayout.HORIZONTAL
        fun stat(label: String, value: String) {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.setPadding(dp(12), dp(8), dp(12), dp(8))
            c.background = Ui.rounded(0x33FFFFFF, dp(12).toFloat())
            c.addView(Ui.text(this, label, 10.5f, Ui.SUB))
            c.addView(Ui.text(this, value, 16f, Color.WHITE, true))
            st.addView(c, LinearLayout.LayoutParams(0, -2, 1f).also { it.rightMargin = dp(6) })
        }
        stat(L.t("Peringkat global", "Global rank"), if (OsuAccount.rank > 0) "#${OsuAccount.rank}" else "-")
        stat("pp", String.format(java.util.Locale.US, "%.0f", OsuAccount.pp))
        stat(L.t("Akurasi", "Accuracy"), String.format(java.util.Locale.US, "%.2f%%", OsuAccount.acc))
        stat(L.t("Dimainkan", "Play count"), OsuAccount.plays.toString())
        p.addView(st, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(14) })

        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        val refresh = Ui.button(this, "Segarkan profil", true, 14) {
            busy = true
            render()
            Thread {
                val err = OsuAccount.fetchProfile()
                runOnUiThread {
                    busy = false
                    render()
                    if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                }
            }.start()
        }
        val out = Ui.button(this, "Keluar akun", false, 14) {
            LDialog.confirm(this, "Keluar dari akun osu!?", "Token di perangkat ini dihapus. Client ID dan Secret tetap tersimpan.", "Keluar") {
                OsuAccount.logout()
                render()
            }
        }
        btns.addView(refresh, LinearLayout.LayoutParams(0, dp(46), 1f))
        btns.addView(out, LinearLayout.LayoutParams(0, dp(46), 1f).also { it.leftMargin = dp(8) })
        p.addView(btns, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(14) })
        p.addView(
            Ui.text(this, "Namamu dipakai otomatis di Versus (bisa diganti di Pengaturan > Versus).", 11.5f, Ui.SUB),
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(10) }
        )
    }

    private fun renderLogin() {
        val p = panel()
        p.addView(Ui.text(this, "Hubungkan akun osu! kamu", 17f, Color.WHITE, true))
        val steps = L.t(
            "1. Buka osu.ppy.sh/home/account/edit, gulir ke bagian OAuth, tekan \"New OAuth Application\".\n" +
                    "2. Nama bebas. Isi Callback URL persis:  maniadroid://oauth\n" +
                    "3. Salin Client ID dan Client Secret ke kolom di bawah, lalu tekan Masuk dengan osu!.\n" +
                    "Data hanya disimpan di HP ini dan hanya dipakai untuk bicara dengan osu!.",
            "1. Open osu.ppy.sh/home/account/edit, scroll to OAuth, tap \"New OAuth Application\".\n" +
                    "2. Any name. Set the Callback URL exactly:  maniadroid://oauth\n" +
                    "3. Copy the Client ID and Client Secret below, then tap Sign in with osu!.\n" +
                    "Your data stays on this phone and is only used to talk to osu!."
        )
        p.addView(Ui.text(this, steps, 12f, 0xFFB4B4C8.toInt()), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(6) })
        val open = Ui.button(this, "Buka halaman OAuth osu!", false, 14) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://osu.ppy.sh/home/account/edit#oauth")))
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak ada browser", Toast.LENGTH_SHORT).show()
            }
        }
        p.addView(open, LinearLayout.LayoutParams(-1, dp(44)).also { it.topMargin = dp(10) })
        field(p, "Client ID", if (Settings.osuClientId > 0) Settings.osuClientId.toString() else "", false, true) {
            Settings.osuClientId = it.toIntOrNull() ?: 0
        }
        field(p, "Client Secret", OsuAccount.clientSecret, true, false) { OsuAccount.clientSecret = it }
        val go = Ui.button(this, "Masuk dengan osu!", true, 14) {
            if (Settings.osuClientId <= 0 || OsuAccount.clientSecret.isEmpty()) {
                Toast.makeText(this, "Isi Client ID dan Client Secret dulu", Toast.LENGTH_LONG).show()
            } else {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(OsuAccount.authUrl())))
                } catch (e: Exception) {
                    Toast.makeText(this, "Tidak ada browser", Toast.LENGTH_SHORT).show()
                }
            }
        }
        p.addView(go, LinearLayout.LayoutParams(-1, dp(48)).also { it.topMargin = dp(14) })
    }
}
