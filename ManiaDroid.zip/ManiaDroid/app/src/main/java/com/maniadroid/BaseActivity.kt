package com.maniadroid

import android.app.Activity
import android.app.ActivityManager
import android.app.Dialog
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.view.WindowManager

/**
 * Dasar semua layar:
 *  - fullscreen imersif (bar status & tombol navigasi HP disembunyikan; geser dari tepi untuk memunculkan sementara),
 *  - layar dibuat ulang otomatis bila bahasa diganti di Pengaturan.
 */
open class BaseActivity : Activity() {
    companion object {
        private var taskIcon: android.graphics.Bitmap? = null
    }

    private var langAtCreate = 0

    /** GameActivity mematikan ini supaya permainan tidak ter-restart saat bahasa diganti dari menu jeda. */
    protected open val recreateOnLanguageChange: Boolean = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        langAtCreate = Settings.language
        hideBars()
        applyTaskIcon()
    }

    /** Ikon + warna kartu aplikasi di layar "terbaru / saran" (recents) disamakan dengan ikon Osu Mania. */
    @Suppress("DEPRECATION")
    private fun applyTaskIcon() {
        try {
            if (taskIcon == null) {
                val id = resources.getIdentifier("ic_launcher", "mipmap", packageName)
                if (id != 0) taskIcon = BitmapFactory.decodeResource(resources, id)
            }
            setTaskDescription(ActivityManager.TaskDescription("Osu Mania", taskIcon, 0xFF1B1033.toInt()))
        } catch (e: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        if (recreateOnLanguageChange && Settings.language != langAtCreate) {
            langAtCreate = Settings.language
            recreate()
        }
    }

    @Suppress("DEPRECATION")
    protected fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }
}

/** Tampilkan dialog tanpa memunculkan tombol navigasi HP (tetap imersif). */
@Suppress("DEPRECATION")
fun Dialog.showImmersive(a: Activity) {
    val w = window
    if (w == null) {
        show()
        return
    }
    w.setFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
    show()
    w.decorView.systemUiVisibility = a.window.decorView.systemUiVisibility
    w.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
}
