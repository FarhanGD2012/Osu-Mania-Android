package com.maniadroid

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

class SongSet(val dir: File, val maps: List<Beatmap>) {
    val title: String get() = maps.first().title
    val artist: String get() = maps.first().artist
    val creator: String get() = maps.first().creator
}

object Library {
    fun songsDir(c: Context): File {
        val d = File(c.filesDir, "songs")
        d.mkdirs()
        return d
    }

    /** Cari file secara case-insensitive (Android case-sensitive, chart dari Windows tidak). */
    fun findFile(dir: File, rel: String): File? {
        val clean = rel.replace('\\', '/')
        val direct = File(dir, clean)
        if (direct.isFile) return direct
        return dir.walkTopDown().firstOrNull {
            it.isFile && it.relativeTo(dir).path.replace('\\', '/').equals(clean, ignoreCase = true)
        }
    }

    fun scanDir(d: File): List<Beatmap> {
        val maps = ArrayList<Beatmap>()
        for (f in d.walkTopDown().maxDepth(2)) {
            if (f.isFile && f.extension.equals("osu", ignoreCase = true)) {
                val b = Beatmap.parse(f, false)
                if (b != null) maps.add(b)
            }
        }
        maps.sortWith(compareBy({ it.keys }, { it.noteCount }))
        return maps
    }

    fun scanSets(c: Context): List<SongSet> {
        val out = ArrayList<SongSet>()
        for (d in songsDir(c).listFiles().orEmpty()) {
            if (!d.isDirectory) continue
            val maps = scanDir(d)
            if (maps.isNotEmpty()) out.add(SongSet(d, maps))
        }
        out.sortBy { it.title.lowercase() }
        return out
    }

    /** Impor .osz. Return jumlah chart mania yang valid, atau -1 jika gagal. */
    fun importOsz(c: Context, name: String, open: () -> InputStream?): Int {
        val base = name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}._ -]"), "_")
            .trim().take(80).ifEmpty { "chart" }
        val dir = File(songsDir(c), base)
        if (dir.exists()) dir.deleteRecursively()
        dir.mkdirs()
        var ok = false
        for (cs in listOf(Charsets.UTF_8, Charsets.ISO_8859_1)) {
            try {
                val ins = open()
                if (ins == null) {
                    dir.deleteRecursively()
                    return -1
                }
                ZipInputStream(BufferedInputStream(ins), cs).use { z -> unzip(z, dir) }
                ok = true
                break
            } catch (e: IllegalArgumentException) {
                dir.deleteRecursively()
                dir.mkdirs()
            } catch (e: Exception) {
                dir.deleteRecursively()
                return -1
            }
        }
        if (!ok) {
            dir.deleteRecursively()
            return -1
        }
        val n = scanDir(dir).size
        if (n == 0) dir.deleteRecursively()
        return n
    }

    private fun unzip(z: ZipInputStream, dir: File) {
        val root = dir.canonicalPath + File.separator
        var e = z.nextEntry
        while (e != null) {
            if (!e.isDirectory) {
                val out = File(dir, e.name.replace('\\', '/'))
                if (out.canonicalPath.startsWith(root)) { // anti zip-slip
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { z.copyTo(it) }
                }
            }
            z.closeEntry()
            e = z.nextEntry
        }
    }
}
