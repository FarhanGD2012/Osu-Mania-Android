package com.maniadroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaPlayer
import android.os.SystemClock
import android.util.SparseIntArray
import android.view.Choreographer
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class Result(val counts: IntArray, val score: Int, val acc: Float, val maxCombo: Int, val failed: Boolean) {
    val rank: String
        get() = when {
            failed -> "F"
            acc >= 99.995f -> "SS"
            acc >= 95f -> "S"
            acc >= 90f -> "A"
            acc >= 80f -> "B"
            acc >= 70f -> "C"
            else -> "D"
        }
}

class GameView(
    ctx: Context,
    private val bm: Beatmap,
    private val backdrop: Backdrop,
    private val mp: MediaPlayer,
    private val cb: Callback
) : View(ctx), Choreographer.FrameCallback {

    interface Callback {
        fun onEnd(r: Result)
        fun onPausePressed()
    }

    companion object {
        private const val LEAD = 2500.0
        private val NAMES = arrayOf("MAX", "300", "200", "100", "50", "MISS")
        private val COLORS = intArrayOf(
            0xFF9FE8FF.toInt(), 0xFFFFE066.toInt(), 0xFF7DDC6A.toInt(),
            0xFF4DA3FF.toInt(), 0xFFB38CFF.toInt(), 0xFFFF5A5A.toInt()
        )
        private val W = intArrayOf(320, 300, 200, 100, 50, 0)
        private val A = intArrayOf(305, 300, 200, 100, 50, 0)
        private val HPD = floatArrayOf(0.012f, 0.010f, 0.004f, -0.015f, -0.040f, -0.090f)
    }

    private val notes = bm.notes
    private val keys = bm.keys
    private val byCol = Array(keys) { ArrayList<Note>() }
    private val colPtr = IntArray(keys)
    private val held = arrayOfNulls<Note>(keys)
    private val pressCount = IntArray(keys)
    private val ptrCol = SparseIntArray()
    private val win = FloatArray(6)
    private var totalJ = 0

    private val counts = IntArray(6)
    private var judged = 0
    private var sumW = 0L
    private var sumA = 0L
    private var combo = 0
    private var maxCombo = 0
    private var hp = 1f
    private var lastJ = -1
    private var lastJAt = 0L
    private var lastErr = 0.0

    private var speed = Settings.scrollSpeed
    private var up = Settings.upscroll
    private var dim = Settings.bgDim
    private var offset = Settings.offset
    private var padOffset = Settings.padOffset
    private val infoTitle = "${bm.artist} - ${bm.title}"
    private val infoSub = "[${bm.version}]  ·  mapper ${bm.creator}"
    private val infoStats = String.format(Locale.US, "%dK  ·  %s  ·  OD %.1f  ·  HP %.1f  ·  %d note", bm.keys, bm.bpmText, bm.od, bm.hp, bm.noteCount)
    private var noFail = Settings.noFail
    private var haptic = Settings.haptic
    private var sfx = Settings.sfxVol
    private var circle = Settings.noteShape == 0
    private var laneOp = Settings.laneOpacity

    private var started = false
    private var paused = false
    private var ended = false
    private var destroyed = false
    private var frozen = 0.0
    private var leadStart = 0L
    private var lastPos = 0
    private var lastNano = 0L
    private var lastSync = 0L
    private var endAt = -1.0
    private var drawStart = 0
    private var lastEnd = 1.0

    private var laneW = 0f
    private var fieldX = 0f
    private var hitY = 0f
    private var pxPerMs = 0f
    private var noteH = 0f
    private var noteD = 0f
    private var scrollMs = 600.0
    private val pauseRect = RectF()
    private val pauseHit = RectF()
    private val rect = RectF()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dens = resources.displayMetrics.density
    private val colBmp = arrayOfNulls<Bitmap>(keys)
    private var lastHaptic = 0L

    // teks HUD disimpan supaya tidak membuat objek String baru di setiap frame (mencegah GC / lag)
    private var scoreText = "0000000"
    private var accText = "100.00%"
    private var comboText = ""
    private var comboShown = -1

    init {
        val base = floatArrayOf(16f, 64f, 97f, 127f, 151f, 188f)
        win[0] = base[0]
        for (k in 1..5) win[k] = max(base[k] - 3f * bm.od, 20f)
        var lastE = 0
        for (n in notes) {
            byCol[n.col].add(n)
            totalJ += if (n.isHold) 2 else 1
            if (n.endTime > lastE) lastE = n.endTime
        }
        lastEnd = (lastE + 1000).toDouble()
    }

    // ---------- layout ----------
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        relayout(w, h)
    }

    /** Baca ulang pengaturan (dipanggil dari menu jeda) dan susun ulang tata letak. */
    fun applySettings() {
        speed = Settings.scrollSpeed
        up = Settings.upscroll
        dim = Settings.bgDim
        offset = Settings.offset
        padOffset = Settings.padOffset
        noFail = Settings.noFail
        haptic = Settings.haptic
        sfx = Settings.sfxVol
        circle = Settings.noteShape == 0
        laneOp = Settings.laneOpacity
        try {
            val v = Settings.musicVol / 100f
            mp.setVolume(v, v)
        } catch (e: Exception) {
        }
        if (width > 0 && height > 0) relayout(width, height)
        invalidate()
    }

    private fun relayout(w: Int, h: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        val maxLane = min(wf / keys, hf * 0.24f)
        laneW = min(maxLane * Settings.colWidth / 100f, wf / keys)
        fieldX = (wf - laneW * keys) / 2f
        hitY = if (up) hf * (100 - Settings.hitPos) / 100f else hf * Settings.hitPos / 100f
        noteD = min(laneW * 0.84f, hf * 0.17f)
        noteH = if (circle) noteD else min(max(laneW * 0.38f, 22f * dens), 56f * dens)
        scrollMs = 11485.0 / speed
        pxPerMs = ((if (up) hf - hitY else hitY) / scrollMs).toFloat()
        // tombol jeda di sisi kanan, tepat di bawah skor & akurasi
        val b = 44f * dens
        pauseRect.set(wf - 14f * dens - b, 84f * dens, wf - 14f * dens, 84f * dens + b)
        pauseHit.set(pauseRect)
        pauseHit.inset(-8f * dens, -8f * dens)
        buildNoteBitmaps()
    }

    // ---------- clock ----------
    fun begin() {
        leadStart = System.nanoTime()
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun destroy() {
        destroyed = true
        Choreographer.getInstance().removeFrameCallback(this)
    }

    /**
     * Waktu lagu. Murni hitungan dari posisi audio terakhir yang tersimpan (tanpa memanggil MediaPlayer),
     * jadi aman dipanggil berkali-kali saat banyak jari menyentuh layar.
     */
    private fun songTime(): Double {
        if (paused) return frozen
        val now = System.nanoTime()
        if (!started) return -LEAD + (now - leadStart) / 1e6
        return lastPos + (now - lastNano) / 1e6
    }

    /** Dipanggil SEKALI per frame: sinkronkan posisi audio asli. */
    private fun pollAudio() {
        if (!started || paused) return
        val pos = try {
            mp.currentPosition
        } catch (e: Exception) {
            return
        }
        if (pos != lastPos) {
            lastPos = pos
            lastNano = System.nanoTime()
        }
    }

    private fun startMusic() {
        started = true
        try {
            mp.start()
        } catch (e: Exception) {
        }
        lastPos = 0
        lastNano = System.nanoTime()
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (destroyed) return
        pollAudio()
        update()
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    // ---------- pause / resume ----------
    fun pauseGame() {
        if (paused || ended) return
        val t = songTime()
        for (c in 0 until keys) if (held[c] != null) release(c, t)
        frozen = t
        paused = true
        pressCount.fill(0)
        ptrCol.clear()
        if (started) {
            try {
                mp.pause()
            } catch (e: Exception) {
            }
        }
        backdrop.pause()
    }

    fun resumeGame() {
        if (!paused || ended) return
        if (!started) {
            leadStart = System.nanoTime() - ((frozen + LEAD) * 1e6).toLong()
            paused = false
            return
        }
        val target = max(0.0, frozen - 1500.0) // mundur 1,5 dtk supaya sempat siap
        frozen = target
        mp.setOnSeekCompleteListener { m ->
            m.setOnSeekCompleteListener(null)
            try {
                m.start()
            } catch (e: Exception) {
            }
            lastPos = target.toInt()
            lastNano = System.nanoTime()
            paused = false
        }
        mp.seekTo(target.toInt())
    }

    // ---------- game logic ----------
    private fun update() {
        if (paused || ended) return
        val t = songTime()
        if (!started && t >= 0) startMusic()
        val now = SystemClock.uptimeMillis()
        if (now - lastSync > 400) {
            lastSync = now
            backdrop.sync(t)
        }
        for (c in 0 until keys) {
            val q = byCol[c]
            var i = colPtr[c]
            while (i < q.size) {
                val n = q[i]
                if (n.finished) {
                    i++
                    continue
                }
                if (n.holding) {
                    if (t >= n.endTime) { // ditahan sampai habis
                        held[c] = null
                        n.holding = false
                        n.finished = true
                        register(0, 0.0)
                        i++
                        continue
                    }
                    break
                }
                if (t - n.time > win[5]) { // kepalanya terlewat
                    n.finished = true
                    n.missed = true
                    register(5, t - n.time)
                    if (n.isHold) register(5, 0.0)
                    i++
                    continue
                }
                break
            }
            colPtr[c] = i
        }
        if (ended) return
        if (judged >= totalJ) {
            if (endAt < 0) endAt = t + 800 else if (t >= endAt) finishRun(false)
        }
    }

    private fun register(j: Int, err: Double) {
        counts[j]++
        judged++
        sumW += W[j]
        sumA += A[j]
        if (j == 5) combo = 0 else {
            combo++
            if (combo > maxCombo) maxCombo = combo
        }
        hp = (hp + HPD[j]).coerceIn(0f, 1f)
        lastJ = j
        lastJAt = SystemClock.uptimeMillis()
        lastErr = err
        scoreText = String.format(Locale.US, "%07d", liveScore())
        accText = String.format(Locale.US, "%.2f%%", 100.0 * sumA / (305.0 * judged))
        if (hp <= 0f && !noFail) finishRun(true)
    }

    private fun finishRun(failed: Boolean) {
        if (ended) return
        ended = true
        try {
            mp.pause()
        } catch (e: Exception) {
        }
        backdrop.pause()
        cb.onEnd(result(failed))
    }

    private fun result(failed: Boolean): Result {
        val acc = if (judged == 0) 100f else (100.0 * sumA / (305.0 * judged)).toFloat()
        return Result(counts.copyOf(), liveScore(), acc, maxCombo, failed)
    }

    private fun liveScore(): Int =
        if (totalJ == 0) 0 else (1_000_000.0 * sumW / (320.0 * totalJ)).roundToInt()

    private fun hitTime(eventTime: Long, pad: Boolean = false): Double {
        val lag = (SystemClock.uptimeMillis() - eventTime).coerceIn(0L, 120L)
        return songTime() - lag - (if (pad) padOffset else offset)
    }

    // ---------- controller / keyboard ----------
    fun padPress(col: Int, et: Long) {
        if (paused || ended || col !in 0 until keys) return
        pressCount[col]++
        press(col, hitTime(et, true))
    }

    fun padRelease(col: Int, et: Long) {
        if (paused || ended || col !in 0 until keys) return
        pressCount[col] = max(0, pressCount[col] - 1)
        if (pressCount[col] == 0) release(col, hitTime(et, true))
    }

    private fun press(c: Int, tHit: Double) {
        if (haptic) {
            val nowMs = SystemClock.uptimeMillis()
            if (nowMs - lastHaptic >= 35) { // getaran dibatasi supaya tidak menumpuk saat banyak jari
                lastHaptic = nowMs
                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING)
            }
        }
        if (sfx > 0) Sfx.play(sfx / 100f)
        val q = byCol[c]
        var i = colPtr[c]
        while (i < q.size && q[i].finished) i++
        colPtr[c] = i
        if (i >= q.size) return
        val n = q[i]
        if (n.holding) return
        val diff = tHit - n.time
        if (diff < -win[5]) return // terlalu awal, abaikan
        val ad = abs(diff)
        var j = 5
        for (k in 0..4) {
            if (ad <= win[k]) {
                j = k
                break
            }
        }
        if (j == 5) { // tap di luar jendela 50 tapi masih dalam jendela miss
            n.finished = true
            n.missed = true
            register(5, diff)
            if (n.isHold) register(5, diff)
            return
        }
        if (n.isHold) {
            n.holding = true
            held[c] = n
        } else {
            n.finished = true
        }
        register(j, diff)
    }

    private fun release(c: Int, tHit: Double) {
        val n = held[c] ?: return
        held[c] = null
        n.holding = false
        n.finished = true
        val err = tHit - n.endTime
        val ad = abs(err)
        var j = 5
        for (k in 0..4) {
            if (ad <= win[k] * 1.5f) {
                j = k
                break
            }
        }
        if (j == 5) n.missed = true
        register(j, err)
    }

    // ---------- touch ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (paused || ended) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                // minta event sentuh tanpa dikelompokkan (batching) = respons lebih cepat
                if (e.actionMasked == MotionEvent.ACTION_DOWN) requestUnbufferedDispatch(e)
                val i = e.actionIndex
                touchDown(e.getPointerId(i), e.getX(i), e.getY(i), e.eventTime)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                touchUp(e.getPointerId(i), e.eventTime)
            }
            MotionEvent.ACTION_CANCEL -> {
                val t = hitTime(e.eventTime)
                for (k in 0 until ptrCol.size()) {
                    val col = ptrCol.valueAt(k)
                    pressCount[col] = max(0, pressCount[col] - 1)
                    if (pressCount[col] == 0) release(col, t)
                }
                ptrCol.clear()
            }
        }
        return true
    }

    private fun touchDown(id: Int, x: Float, y: Float, et: Long) {
        // jeda hanya jika tidak ada jari lain di lane (supaya tidak ter-pause saat menekan banyak jari)
        if (ptrCol.size() == 0 && pauseHit.contains(x, y)) {
            cb.onPausePressed()
            return
        }
        val col = ((x - fieldX) / laneW).toInt().coerceIn(0, keys - 1)
        val old = ptrCol.get(id, -1)
        if (old >= 0) { // pointer id yang sama tertekan lagi tanpa UP: bereskan dulu supaya tidak macet
            pressCount[old] = max(0, pressCount[old] - 1)
            if (pressCount[old] == 0) release(old, hitTime(et))
        }
        ptrCol.put(id, col)
        pressCount[col]++
        press(col, hitTime(et))
    }

    private fun touchUp(id: Int, et: Long) {
        val col = ptrCol.get(id, -1)
        if (col < 0) return
        ptrCol.delete(id)
        pressCount[col] = max(0, pressCount[col] - 1)
        if (pressCount[col] == 0) release(col, hitTime(et))
    }

    // ---------- drawing ----------
    private fun noteColor(c: Int): Int {
        if (keys % 2 == 1 && c == keys / 2) return 0xFFFFD84D.toInt()
        return if (min(c, keys - 1 - c) % 2 == 0) 0xFFF2F2F7.toInt() else 0xFF5BB8FF.toInt()
    }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)

    private fun darken(color: Int): Int {
        val r = (Color.red(color) * 0.70f).toInt()
        val g = (Color.green(color) * 0.70f).toInt()
        val b = (Color.blue(color) * 0.70f).toInt()
        return Color.rgb(r, g, b)
    }

    private fun yAt(time: Double, t: Double): Float {
        val sgn = if (up) -1.0 else 1.0
        return (hitY - sgn * (time - t) * pxPerMs).toFloat()
    }

    private fun lighten(color: Int, t: Float): Int {
        val r = (Color.red(color) + (255 - Color.red(color)) * t).toInt()
        val g = (Color.green(color) + (255 - Color.green(color)) * t).toInt()
        val b = (Color.blue(color) + (255 - Color.blue(color)) * t).toInt()
        return Color.rgb(r, g, b)
    }

    /** Siapkan gambar note (sekali saja tiap ukuran layar berubah), bukan digambar ulang tiap frame. */
    private fun buildNoteBitmaps() {
        for (i in colBmp.indices) colBmp[i] = null
        if (!circle || noteD < 8f) return
        val size = noteD.roundToInt() + 4
        val cache = HashMap<Int, Bitmap>()
        for (c in 0 until keys) {
            val base = noteColor(c)
            colBmp[c] = cache.getOrPut(base) { makeHitCircle(size, base) }
        }
    }

    /**
     * Tekstur hitcircle bergaya osu!: cakram berwarna dengan gradasi, cincin putih tebal di tepi,
     * garis bayangan tipis, dan kilap lembut di bagian atas.
     */
    private fun makeHitCircle(size: Int, base: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val pp = Paint(Paint.ANTI_ALIAS_FLAG)
        val cx = size / 2f
        val cy = size / 2f
        val ro = size / 2f - 1.5f          // radius luar cincin
        val ringW = ro * 0.11f              // tebal cincin putih
        val ri = ro - ringW                 // radius cakram

        // cakram berwarna: terang di tengah, gelap di tepi
        pp.style = Paint.Style.FILL
        pp.shader = RadialGradient(
            cx, cy - ri * 0.10f, ri * 1.05f,
            intArrayOf(lighten(base, 0.45f), base, darken(base)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, ri + 0.5f, pp)
        pp.shader = null

        // bayangan tipis di sisi dalam cincin
        pp.style = Paint.Style.STROKE
        pp.strokeWidth = ringW * 0.45f
        pp.color = Color.argb(70, 0, 0, 0)
        c.drawCircle(cx, cy, ri - ringW * 0.2f, pp)

        // kilap bagian atas cakram
        val clip = Path()
        clip.addCircle(cx, cy, ri, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        pp.style = Paint.Style.FILL
        pp.shader = LinearGradient(
            0f, cy - ri, 0f, cy, Color.argb(95, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )
        rect.set(cx - ri * 0.86f, cy - ri * 0.98f, cx + ri * 0.86f, cy)
        c.drawOval(rect, pp)
        pp.shader = null
        c.restore()

        // cincin putih luar
        pp.style = Paint.Style.STROKE
        pp.strokeWidth = ringW
        pp.color = Color.WHITE
        c.drawCircle(cx, cy, ro - ringW / 2f, pp)

        // garis gelap sangat tipis di tepi luar supaya cincin tegas di atas latar terang
        pp.strokeWidth = 1.2f
        pp.color = Color.argb(80, 0, 0, 0)
        c.drawCircle(cx, cy, ro + 0.4f, pp)
        return bmp
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = songTime()
        val fieldW = laneW * keys

        cv.drawColor(Color.argb(dim * 255 / 100, 0, 0, 0))

        p.style = Paint.Style.FILL
        if (laneOp > 0) {
            p.color = Color.argb(laneOp * 255 / 100, 0, 0, 0)
            cv.drawRect(fieldX, 0f, fieldX + fieldW, h, p)
        }
        p.color = Color.argb(60, 255, 255, 255)
        for (i in 0..keys) {
            val x = fieldX + i * laneW
            cv.drawRect(x - 1f, 0f, x + 1f, h, p)
        }
        for (c in 0 until keys) {
            if (pressCount[c] > 0) {
                p.color = Color.argb(45, 255, 255, 255)
                val x = fieldX + c * laneW
                if (up) cv.drawRect(x, hitY, x + laneW, hitY + laneW * 2.2f, p)
                else cv.drawRect(x, hitY - laneW * 2.2f, x + laneW, hitY, p)
            }
        }

        // garis hit (mode persegi) / reseptor bulat (mode bulat)
        val rr = noteH / 2f
        if (circle) {
            for (c in 0 until keys) {
                val cx = fieldX + c * laneW + laneW / 2f
                val down = pressCount[c] > 0
                if (down) {
                    p.style = Paint.Style.FILL
                    p.color = Color.argb(110, 255, 255, 255)
                    cv.drawCircle(cx, hitY, rr, p)
                }
                p.style = Paint.Style.STROKE
                p.strokeWidth = max(2f * dens, rr * 0.12f)
                p.color = Color.argb(if (down) 255 else 170, 255, 255, 255)
                cv.drawCircle(cx, hitY, rr - p.strokeWidth / 2f, p)
            }
            p.style = Paint.Style.FILL
        } else {
            p.color = Color.argb(230, 255, 255, 255)
            cv.drawRect(fieldX, hitY - 1.5f * dens, fieldX + fieldW, hitY + 1.5f * dens, p)
        }

        // notes
        while (drawStart < notes.size) {
            val dn = notes[drawStart]
            if (dn.endTime < t - 150 || (dn.finished && !(dn.isHold && dn.missed))) drawStart++ else break
        }
        val dist = (if (up) h - hitY else hitY) + noteH * 2
        val r = noteH * 0.25f
        var i = drawStart
        while (i < notes.size) {
            val n = notes[i]
            i++
            if ((n.time - t) * pxPerMs > dist) break
            if (n.finished && !(n.isHold && n.missed)) continue
            val x = fieldX + n.col * laneW
            val cx = x + laneW / 2f
            val pad = laneW * 0.06f
            val base = noteColor(n.col)
            val dimmed = n.missed
            val yHead = yAt(if (n.holding) max(n.time.toDouble(), t) else n.time.toDouble(), t)
            if (n.isHold) {
                val yTail = yAt(n.endTime.toDouble(), t)
                val bw = if (circle) noteH * 0.56f else laneW * 0.56f
                p.style = Paint.Style.FILL
                p.color = withAlpha(base, if (dimmed) 50 else if (n.holding) 200 else 130)
                rect.set(cx - bw / 2f, min(yHead, yTail), cx + bw / 2f, max(yHead, yTail))
                if (circle) cv.drawRoundRect(rect, bw / 2f, bw / 2f, p) else cv.drawRoundRect(rect, r, r, p)
            }
            if (circle) {
                val bmp = colBmp[n.col]
                if (bmp != null) {
                    bmpPaint.alpha = if (dimmed) 70 else 255
                    cv.drawBitmap(bmp, cx - bmp.width / 2f, yHead - bmp.height / 2f, bmpPaint)
                }
            } else {
                p.color = withAlpha(base, if (dimmed) 70 else 255)
                rect.set(x + pad, yHead - noteH / 2f, x + laneW - pad, yHead + noteH / 2f)
                cv.drawRoundRect(rect, r, r, p)
            }
        }
        p.style = Paint.Style.FILL

        // HUD: progres + HP
        p.color = Color.argb(170, 255, 255, 255)
        cv.drawRect(0f, 0f, w * (t / lastEnd).coerceIn(0.0, 1.0).toFloat(), 4f * dens, p)
        p.color = if (hp > 0.3f) Color.argb(210, 90, 220, 120) else Color.argb(230, 255, 80, 80)
        cv.drawRect(0f, 4f * dens, w * hp, 10f * dens, p)

        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.RIGHT
        p.color = Color.WHITE
        p.textSize = 26f * dens
        cv.drawText(scoreText, w - 16f * dens, 52f * dens, p)
        p.textSize = 14f * dens
        p.color = Color.argb(220, 255, 255, 255)
        cv.drawText(accText, w - 16f * dens, 74f * dens, p)

        p.textAlign = Paint.Align.CENTER
        if (combo > 1) {
            if (combo != comboShown) {
                comboShown = combo
                comboText = combo.toString()
            }
            p.textSize = 44f * dens
            p.color = Color.argb(200, 255, 255, 255)
            cv.drawText(comboText, w / 2f, h * 0.32f, p)
        }
        val age = SystemClock.uptimeMillis() - lastJAt
        if (lastJ >= 0 && age < 450) {
            val k = 1f - age / 450f
            p.textSize = 28f * dens * (1f + 0.15f * k)
            p.color = withAlpha(COLORS[lastJ], (255 * k).toInt())
            cv.drawText(NAMES[lastJ], w / 2f, h * 0.42f, p)
            if (lastJ in 1..4 && abs(lastErr) > win[0]) {
                p.textSize = 14f * dens
                cv.drawText(if (lastErr < 0) "EARLY" else "LATE", w / 2f, h * 0.42f + 22f * dens, p)
            }
        }

        // info chart saat awal lagu
        if (t < 5500) {
            val a = if (t < 3500) 255 else (255 * (1.0 - (t - 3500) / 2000.0)).toInt().coerceIn(0, 255)
            p.textAlign = Paint.Align.LEFT
            p.color = withAlpha(Color.WHITE, a)
            p.textSize = 20f * dens
            cv.drawText(infoTitle, 20f * dens, h - 76f * dens, p)
            p.color = withAlpha(0xFFD0D0E0.toInt(), a)
            p.textSize = 13f * dens
            cv.drawText(infoSub, 20f * dens, h - 52f * dens, p)
            cv.drawText(infoStats, 20f * dens, h - 32f * dens, p)
        }

        // tombol jeda (kanan): lingkaran gelap transparan dengan cincin tipis
        val pcx = pauseRect.centerX()
        val pcy = pauseRect.centerY()
        val pr = pauseRect.width() / 2f
        p.style = Paint.Style.FILL
        p.color = Color.argb(120, 12, 12, 20)
        cv.drawCircle(pcx, pcy, pr, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * dens
        p.color = Color.argb(110, 255, 255, 255)
        cv.drawCircle(pcx, pcy, pr - 0.75f * dens, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        rect.set(pcx - 7f * dens, pcy - 9f * dens, pcx - 2.5f * dens, pcy + 9f * dens)
        cv.drawRoundRect(rect, 1.5f * dens, 1.5f * dens, p)
        rect.set(pcx + 2.5f * dens, pcy - 9f * dens, pcx + 7f * dens, pcy + 9f * dens)
        cv.drawRoundRect(rect, 1.5f * dens, 1.5f * dens, p)
    }
}
