package com.maniadroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.BitmapShader
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaPlayer
import android.os.Build
import android.os.SystemClock
import android.util.SparseIntArray
import android.view.Choreographer
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class Result(val counts: IntArray, val score: Int, val acc: Float, val maxCombo: Int, val failed: Boolean) {
    var bot = false       // dimainkan oleh BOT
    var replay = false    // hasil memutar ulang rekaman
    val rank: String
        get() = when {
            failed -> "F"
            acc >= 99.995f -> "SS"
            acc >= 95f -> "S"
            acc >= 90f -> "A"
            acc >= 80f -> "B"
            acc >= 70f -> "C"
            else -> "D"
        }
}

class GameView(
    ctx: Context,
    private val bm: Beatmap,
    private val backdrop: Backdrop,
    private val mp: MediaPlayer,
    private val cb: Callback
) : View(ctx), Choreographer.FrameCallback {

    interface Callback {
        fun onEnd(r: Result)
        fun onPausePressed()
    }

    /** Dipakai mode Versus: kirim cuplikan skor ~5x/detik dan gambar papan skor lawan di atas layar main. */
    var onSnapshot: ((score: Int, acc: Float, combo: Int, hp: Float, prog: Float) -> Unit)? = null
    var overlayDraw: ((Canvas, Float, Float, Float) -> Unit)? = null
    private var lastSnap = 0L

    companion object {
        private const val LEAD = 2500.0
        private val NAMES_EN = arrayOf("MAX", "300", "200", "100", "50", "MISS")
        private val NAMES_ID = arrayOf("MAX", "300", "200", "100", "50", "MELESET")
        private val COLORS = intArrayOf(
            0xFF9FE8FF.toInt(), 0xFFFFE066.toInt(), 0xFF7DDC6A.toInt(),
            0xFF4DA3FF.toInt(), 0xFFB38CFF.toInt(), 0xFFFF5A5A.toInt()
        )
        private val W = intArrayOf(320, 300, 200, 100, 50, 0)
        private val A = intArrayOf(305, 300, 200, 100, 50, 0)
        private val HPD = floatArrayOf(0.012f, 0.010f, 0.004f, -0.015f, -0.040f, -0.090f)
    }

    private val notes = bm.notes
    private val keys = bm.keys
    private val byCol = Array(keys) { ArrayList<Note>() }
    private val colPtr = IntArray(keys)
    private val held = arrayOfNulls<Note>(keys)
    private val pressCount = IntArray(keys)
    private val keyCnt = IntArray(keys)
    private val keyTxt = Array(keys) { "0" }
    private val ptrCol = SparseIntArray()
    private val win = FloatArray(6)
    private var totalJ = 0

    private val counts = IntArray(6)
    private var judged = 0
    private var sumW = 0L
    private var sumA = 0L
    private var combo = 0
    private var maxCombo = 0
    private var hp = 1f
    private var lastJ = -1
    private var lastJAt = 0L
    private var lastErr = 0.0

    private var speed = Settings.scrollSpeed
    private var up = Settings.upscroll
    private var dim = Settings.bgDim
    private var offset = Settings.offset
    private var padOffset = Settings.padOffset
    private val infoTitle = "${bm.artist} - ${bm.title}"
    private val infoSub = "[${bm.version}]  ·  mapper ${bm.creator}"
    private val infoStats = String.format(Locale.US, "%dK  ·  %s  ·  OD %.1f  ·  HP %.1f  ·  %d %s", bm.keys, bm.bpmText, bm.od, bm.hp, bm.noteCount, L.t("note", "notes"))
    private var noFail = Settings.noFail
    private var haptic = Settings.haptic
    private var sfx = Settings.sfxVol * Settings.masterVol / 100
    private var circle = Settings.noteShape == 0
    private var argon = Settings.noteShape == 2
    private var keyCounter = Settings.keyCounter
    private var colLight = Settings.colLight
    private var laneOp = Settings.laneOpacity
    private var names = if (L.en) NAMES_EN else NAMES_ID
    private var txtEarly = L.t("TERLALU CEPAT", "EARLY")
    private var txtLate = L.t("TERLAMBAT", "LATE")

    private var started = false
    private var resuming = false        // sedang hitung mundur setelah menekan Lanjut (paused tetap true)
    private var resumeStart = 0L
    private var resumeMs = 0L
    private var resumeSeekDone = false
    private var resumeTarget = 0.0
    private var rewound = false         // sudah mundur (hitung mundur dibatalkan di tengah jalan): jangan mundur lagi
    private var progShown = -1
    private var progText = "00.00%"
    private var hpShown = -1
    private var hpText = "100.00%"
    private var paused = false
    private var ended = false
    private var destroyed = false
    private var frozen = 0.0
    private var leadStart = 0L
    private var basePos = 0.0          // posisi lagu (ms) pada saat baseNano; waktu lagu = basePos + selisih waktu
    private var baseNano = 0L
    private var lastReported = -1
    private var lastPollN = 0L
    private var lastSync = 0L
    private var endAt = -1.0
    private var drawStart = 0
    private var lastEnd = 1.0

    private var laneW = 0f
    private var fieldX = 0f
    private var hitY = 0f
    private var pxPerMs = 0f
    private var noteH = 0f
    private var noteD = 0f
    private var noteW = 0f
    private var scrollMs = 600.0
    private val pauseRect = RectF()
    private val pauseHit = RectF()
    private val rect = RectF()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dens = resources.displayMetrics.density
    private val colBmp = arrayOfNulls<Bitmap>(keys)
    private val bodyCol = IntArray(keys)
    private val bodyDark = IntArray(keys)
    private val trailCol = IntArray(keys)                    // warna isi trail (kustom atau bawaan)
    private val trailTex = arrayOfNulls<BitmapShader>(keys)  // gambar trail kustom (null = polos)
    private val trailMat = Matrix()
    private val glow = arrayOfNulls<Shader>(keys)
    private var lastHaptic = 0L

    // teks HUD disimpan supaya tidak membuat objek String baru di setiap frame (mencegah GC / lag)
    private var scoreText = "0000000"
    private var accText = "100.00%"
    private var comboText = ""
    private var comboShown = -1
    private var hpLabel = "HP 100.00%"
    private val sb = StringBuilder(16)

    // bar kesalahan timing + efek cincin saat note kena
    private val errMs = FloatArray(24)
    private val errAt = LongArray(24)
    private val errJ = IntArray(24)
    private var errHead = 0
    private val fxAt = LongArray(keys)
    private val fxJ = IntArray(keys)
    private var hudS = Settings.hudScale / 100f
    private var showCombo = Settings.showCombo
    private var showJudge = Settings.showJudge
    private var showAccHud = Settings.showAcc
    private var showHpHud = Settings.showHp
    private var hitErrorBar = Settings.hitError
    private var hitFx = Settings.hitEffect
    private var showFps = Settings.showFps
    private var pauseBtn = Settings.pauseButton
    private var fpsFrames = 0
    private var fpsT = 0L
    private var fpsText = ""

    // ---- BOT (map jalan sendiri) & replay ----
    var botMode = false
        private set
    var replayMode = false
        private set
    private var pbT: DoubleArray? = null
    private var pbC: IntArray? = null
    private var pbD: BooleanArray? = null
    private var pbN = 0
    private var pbIdx = 0
    private var usedPause = false
    private var recT = DoubleArray(2048)
    private var recC = IntArray(2048)
    private var recD = BooleanArray(2048)
    private var recN = 0
    private var recording = true
    private val tagText: String get() = if (botMode) "BOT" else if (replayMode) "REPLAY" else ""

    init {
        val base = floatArrayOf(16f, 64f, 97f, 127f, 151f, 188f)
        win[0] = base[0]
        for (k in 1..5) win[k] = max(base[k] - 3f * bm.od, 20f)
        var lastE = 0
        for (n in notes) {
            byCol[n.col].add(n)
            totalJ += if (n.isHold) 2 else 1
            if (n.endTime > lastE) lastE = n.endTime
        }
        lastEnd = (lastE + 1000).toDouble()
    }

    // ---------- layout ----------
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        relayout(w, h)
    }

    /** Baca ulang pengaturan (dipanggil dari menu jeda) dan susun ulang tata letak. */
    fun applySettings() {
        speed = Settings.scrollSpeed
        up = Settings.upscroll
        dim = Settings.bgDim
        offset = Settings.offset
        padOffset = Settings.padOffset
        noFail = Settings.noFail
        haptic = Settings.haptic && pbT == null
        sfx = Settings.sfxVol * Settings.masterVol / 100
        circle = Settings.noteShape == 0
        argon = Settings.noteShape == 2
        keyCounter = Settings.keyCounter
        colLight = Settings.colLight
        laneOp = Settings.laneOpacity
        hudS = Settings.hudScale / 100f
        showCombo = Settings.showCombo
        showJudge = Settings.showJudge
        showAccHud = Settings.showAcc
        showHpHud = Settings.showHp
        hitErrorBar = Settings.hitError
        hitFx = Settings.hitEffect
        showFps = Settings.showFps
        pauseBtn = Settings.pauseButton
        names = if (L.en) NAMES_EN else NAMES_ID
        txtEarly = L.t("TERLALU CEPAT", "EARLY")
        txtLate = L.t("TERLAMBAT", "LATE")
        try {
            val v = Settings.musicGain
            mp.setVolume(v, v)
        } catch (e: Exception) {
        }
        if (width > 0 && height > 0) relayout(width, height)
        invalidate()
    }

    private fun relayout(w: Int, h: Int) {
        val wf = w.toFloat()
        val hf = h.toFloat()
        val maxLane = min(wf / keys, hf * 0.24f)
        laneW = min(maxLane * Settings.colWidth / 100f, wf / keys)
        fieldX = (wf - laneW * keys) / 2f
        hitY = if (up) hf * (100 - Settings.hitPos) / 100f else hf * Settings.hitPos / 100f
        noteD = min(laneW * 0.84f, hf * 0.17f)
        noteH = if (argon) max(min(laneW * 0.7f, hf * 0.15f), 18f * dens) else if (circle) noteD else min(max(laneW * 0.38f, 22f * dens), 56f * dens)
        noteW = if (argon) laneW * 0.97f else if (circle) noteD else laneW * 0.88f
        scrollMs = 11485.0 / speed
        pxPerMs = ((if (up) hf - hitY else hitY) / scrollMs).toFloat()
        // tombol jeda di sisi kanan, tepat di bawah skor & akurasi
        val b = 44f * dens
        pauseRect.set(wf - 14f * dens - b, 78f * dens * hudS, wf - 14f * dens, 78f * dens * hudS + b)
        pauseHit.set(pauseRect)
        pauseHit.inset(-8f * dens, -8f * dens)
        buildNoteBitmaps()
        updateGestureExclusion(w, h)
    }

    /**
     * Android 10+: sentuhan yang mulai dari tepi layar dianggap gestur "kembali" dan ditelan sistem, sehingga bulatan
     * paling kiri / paling kanan (terutama mode 9K-10K atau kolom lebar) terasa tidak bisa ditekan. Di sini kita
     * minta sistem tidak memakai tepi layar di sekitar garis hit (batas sistem: 200 dp tinggi per sisi).
     */
    private fun updateGestureExclusion(w: Int, h: Int) {
        if (Build.VERSION.SDK_INT < 29) return
        try {
            if (!Settings.lockEdge) {
                systemGestureExclusionRects = emptyList()
                return
            }
            val bandH = (200f * dens).toInt().coerceAtMost(h)
            val top = (hitY - bandH / 2f).toInt().coerceIn(0, max(0, h - bandH))
            systemGestureExclusionRects = listOf(Rect(0, top, w, top + bandH))
        } catch (e: Throwable) {
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (changed && width > 0 && height > 0) updateGestureExclusion(width, height)
    }

    // ---------- BOT / replay ----------
    /** BOT: semua note ditekan tepat waktu (MAX) dan hold dilepas tepat di ujungnya. Skor tidak disimpan. */
    fun startBot() {
        val ev = ArrayList<Triple<Double, Int, Boolean>>(notes.size * 2)
        for (n in notes) {
            ev.add(Triple(n.time.toDouble(), n.col, true))
            ev.add(Triple((if (n.isHold) n.endTime else n.time + 45).toDouble(), n.col, false))
        }
        // pada waktu yang sama: lepas dulu, baru tekan (supaya tekan berikutnya di kolom yang sama tidak terhapus)
        ev.sortWith(compareBy({ it.first }, { if (it.third) 1 else 0 }))
        pbT = DoubleArray(ev.size) { ev[it].first }
        pbC = IntArray(ev.size) { ev[it].second }
        pbD = BooleanArray(ev.size) { ev[it].third }
        pbN = ev.size
        pbIdx = 0
        botMode = true
        recording = false
        haptic = false
    }

    /** Putar ulang rekaman sentuhan permainan sebelumnya; hasilnya sama persis dengan permainan aslinya. */
    fun startReplay(r: ReplayData) {
        pbT = r.t
        pbC = r.c
        pbD = r.d
        pbN = r.n
        pbIdx = 0
        replayMode = true
        recording = false
        haptic = false
    }

    /** Lebar badan hold (trail). */
    private fun trailW(): Float = if (argon) noteW else if (circle) noteH * 0.56f else laneW * 0.56f

    /** Baris key counter: tepat di luar garis hit; bar kesalahan timing digeser ke bawahnya supaya tidak tumpang tindih. */
    private fun keyY(): Float = if (up) hitY - noteH / 2f - 8f * dens else min(hitY + noteH / 2f + 16f * dens, height - 26f * dens)

    private fun rec(col: Int, down: Boolean, t: Double) {
        if (!recording) return
        if (recN == recT.size) {
            recT = recT.copyOf(recN * 2)
            recC = recC.copyOf(recN * 2)
            recD = recD.copyOf(recN * 2)
        }
        recT[recN] = t
        recC[recN] = col
        recD[recN] = down
        recN++
    }

    private fun userPress(col: Int, t: Double) {
        rec(col, true, t)
        press(col, t)
    }

    private fun userRelease(col: Int, t: Double) {
        rec(col, false, t)
        release(col, t)
    }

    /** Dipanggil tiap frame: jalankan peristiwa BOT / replay yang waktunya sudah tiba. */
    private fun feedPlayback(t: Double) {
        val pt = pbT ?: return
        val pc = pbC ?: return
        val pd = pbD ?: return
        while (pbIdx < pbN && pt[pbIdx] <= t) {
            val col = pc[pbIdx]
            if (col in 0 until keys) {
                if (pd[pbIdx]) {
                    pressCount[col]++
                    press(col, pt[pbIdx])
                } else {
                    pressCount[col] = max(0, pressCount[col] - 1)
                    if (pressCount[col] == 0) release(col, pt[pbIdx])
                }
            }
            pbIdx++
        }
    }

    // ---------- clock ----------
    fun begin() {
        leadStart = System.nanoTime()
        Choreographer.getInstance().postFrameCallback(this)
    }

    /** Versus: detik 0 lagu terjadi pada [zeroNano] (System.nanoTime) supaya semua pemain mulai bersamaan. */
    fun beginAt(zeroNano: Long) {
        val minZero = System.nanoTime() + 600_000_000L // terlambat memuat: mulai sedikit terlambat, bukan loncat
        val z = max(zeroNano, minZero)
        leadStart = z - (LEAD * 1e6).toLong()
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun destroy() {
        destroyed = true
        Choreographer.getInstance().removeFrameCallback(this)
    }

    /**
     * Waktu lagu. Murni hitungan dari posisi audio terakhir yang tersimpan (tanpa memanggil MediaPlayer),
     * jadi aman dipanggil berkali-kali saat banyak jari menyentuh layar.
     */
    private fun songTime(): Double {
        if (paused) return frozen
        val now = System.nanoTime()
        if (!started) return -LEAD + (now - leadStart) / 1e6
        return basePos + (now - baseNano) / 1e6
    }

    /** Dipanggil SEKALI per frame: sinkronkan posisi audio asli. */
    private fun pollAudio() {
        if (!started || paused) return
        val nowN = System.nanoTime()
        // currentPosition adalah panggilan ke layanan media (bisa tersendat saat banyak sentuhan): cukup ~25x per detik
        if (nowN - lastPollN < 40_000_000L) return
        lastPollN = nowN
        val pos = try {
            mp.currentPosition
        } catch (e: Exception) {
            return
        }
        if (pos == lastReported) return // nilai lama (jam audio belum maju)
        lastReported = pos
        val predicted = basePos + (nowN - baseNano) / 1e6
        val err = pos - predicted
        if (abs(err) > 60.0) { // melenceng jauh: samakan langsung
            basePos = pos.toDouble()
        } else { // melenceng kecil: geser pelan-pelan supaya scroll note halus (tidak "loncat")
            basePos = predicted + err * 0.2
        }
        baseNano = nowN
    }

    private fun startMusic() {
        started = true
        try {
            mp.start()
        } catch (e: Exception) {
        }
        basePos = 0.0
        baseNano = System.nanoTime()
        lastReported = -1
        lastPollN = baseNano
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (destroyed) return
        if (showFps) {
            fpsFrames++
            val nowF = SystemClock.uptimeMillis()
            if (fpsT == 0L) fpsT = nowF
            if (nowF - fpsT >= 500) {
                fpsText = (fpsFrames * 1000L / (nowF - fpsT)).toString() + " FPS"
                fpsFrames = 0
                fpsT = nowF
            }
        }
        pollAudio()
        tickResume()
        update()
        sendSnapshot()
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun sendSnapshot() {
        val cb2 = onSnapshot ?: return
        if (paused || ended) return
        val now = SystemClock.uptimeMillis()
        if (now - lastSnap < 200) return
        lastSnap = now
        val acc = if (judged == 0) 100f else (100.0 * sumA / (305.0 * judged)).toFloat()
        cb2(liveScore(), acc, combo, hp, (songTime() / lastEnd).coerceIn(0.0, 1.0).toFloat())
    }

    /** Hasil akhir yang sama dengan yang dikirim ke layar hasil (dipakai Versus saat pemain keluar di tengah lagu). */
    fun currentResult(failed: Boolean): Result = result(failed)

    /** Persen lagu & HP saat ini, untuk ditampilkan di menu jeda. */
    fun statusText(): String {
        val pv = ((songTime() / lastEnd).coerceIn(0.0, 1.0) * 10000.0).toInt()
        val hv = (hp.coerceIn(0f, 1f) * 10000f).toInt()
        return String.format(Locale.US, "%05.2f%%  ·  HP %05.2f%%", pv / 100.0, hv / 100.0)
    }

    // ---------- pause / resume ----------
    fun pauseGame() {
        if (ended) return
        if (paused) {
            if (resuming) { // jeda lagi saat hitung mundur: batalkan, tampilkan menu jeda lagi
                resuming = false
                rewound = true
                try {
                    mp.setOnSeekCompleteListener(null)
                    mp.pause()
                } catch (e: Exception) {
                }
            }
            return
        }
        val t = songTime()
        if (pbT == null) {
            usedPause = true
            for (c in 0 until keys) if (held[c] != null) release(c, t)
        }
        frozen = t
        paused = true
        pressCount.fill(0)
        ptrCol.clear()
        if (started) {
            try {
                mp.pause()
            } catch (e: Exception) {
            }
        }
        backdrop.pause()
    }

    fun resumeGame() {
        if (!paused || ended) return
        if (!started) {
            leadStart = System.nanoTime() - ((frozen + LEAD) * 1e6).toLong()
            paused = false
            return
        }
        if (resuming) return
        // Mundur beberapa detik (seperti Clone Hero). Note yang sudah kena tetap hilang; yang belum kena tetap bisa dimainkan.
        val back = if (rewound || pbT != null) 0.0 else Settings.resumeRewind * 1000.0
        rewound = false
        val target = max(0.0, frozen - back)
        frozen = target
        resumeTarget = target
        resumeMs = if (Settings.resumeCountdown) 3000L else 0L
        resumeStart = System.nanoTime()
        resumeSeekDone = false
        resuming = true
        try {
            backdrop.preview(target)
        } catch (e: Exception) {
        }
        try {
            mp.setOnSeekCompleteListener { m ->
                m.setOnSeekCompleteListener(null)
                resumeSeekDone = true
            }
            mp.seekTo(target.toInt())
        } catch (e: Exception) {
            resumeSeekDone = true
        }
    }

    /** Setelah hitung mundur selesai (dan seek audio beres), musik dan permainan jalan lagi dari posisi yang sudah mundur. */
    private fun tickResume() {
        if (!resuming) return
        val elapsed = (System.nanoTime() - resumeStart) / 1e6
        // cadangan: jika seek tak pernah melapor selesai, lanjut setelah 1,5 dtk ekstra
        if (!resumeSeekDone && elapsed > resumeMs + 1500) resumeSeekDone = true
        if (elapsed < resumeMs || !resumeSeekDone) return
        resuming = false
        try {
            mp.start()
        } catch (e: Exception) {
        }
        basePos = resumeTarget
        baseNano = System.nanoTime()
        lastReported = -1
        lastPollN = baseNano
        paused = false
        try {
            backdrop.sync(resumeTarget)
        } catch (e: Exception) {
        }
    }

    // ---------- game logic ----------
    private fun update() {
        if (paused || ended) return
        val t = songTime()
        if (!started && t >= 0) startMusic()
        val now = SystemClock.uptimeMillis()
        if (now - lastSync > 1000) { // sinkron video tiap ~1 dtk (panggilan ke layanan media tidak perlu lebih sering)
            lastSync = now
            backdrop.sync(t)
        }
        if (pbT != null) feedPlayback(t)
        for (c in 0 until keys) {
            val q = byCol[c]
            var i = colPtr[c]
            while (i < q.size) {
                val n = q[i]
                if (n.finished) {
                    i++
                    continue
                }
                if (n.holding) {
                    if (t >= n.endTime) { // ditahan sampai habis
                        held[c] = null
                        n.holding = false
                        n.finished = true
                        register(0, 0.0)
                        i++
                        continue
                    }
                    break
                }
                if (t - n.time > win[5]) { // kepalanya terlewat
                    n.finished = true
                    n.missed = true
                    register(5, t - n.time)
                    if (n.isHold) register(5, 0.0)
                    i++
                    continue
                }
                break
            }
            colPtr[c] = i
        }
        if (ended) return
        if (judged >= totalJ) {
            if (endAt < 0) endAt = t + 800 else if (t >= endAt) finishRun(false)
        }
    }

    private fun register(j: Int, err: Double) {
        counts[j]++
        judged++
        sumW += W[j]
        sumA += A[j]
        if (j == 5) combo = 0 else {
            combo++
            if (combo > maxCombo) maxCombo = combo
        }
        hp = (hp + HPD[j]).coerceIn(0f, 1f)
        lastJ = j
        lastJAt = SystemClock.uptimeMillis()
        lastErr = err
        scoreText = pad(liveScore(), 7)
        accText = pct2(100.0 * sumA / (305.0 * judged), 1)
        if (j < 5) { // catat kesalahan timing untuk bar di bawah layar
            errMs[errHead] = err.toFloat()
            errAt[errHead] = lastJAt
            errJ[errHead] = j
            errHead = (errHead + 1) % errMs.size
        }
        if (hp <= 0f && !noFail) finishRun(true)
    }

    /** Angka berisi nol di depan tanpa String.format (tidak membuat objek Formatter di jalur panas). */
    private fun pad(n: Int, width: Int): String {
        sb.setLength(0)
        val s = n.coerceAtLeast(0).toString()
        for (i in s.length until width) sb.append('0')
        sb.append(s)
        return sb.toString()
    }

    /** Persen dua desimal (mis. 07.35% / 100.00%) dengan lebar bagian bulat minimal [intW]. */
    private fun pct2(v: Double, intW: Int): String {
        val x = (v * 100.0 + 0.5).toInt().coerceAtLeast(0)
        sb.setLength(0)
        val ip = (x / 100).toString()
        for (i in ip.length until intW) sb.append('0')
        sb.append(ip).append('.')
        val f = x % 100
        if (f < 10) sb.append('0')
        sb.append(f).append('%')
        return sb.toString()
    }

    private fun finishRun(failed: Boolean) {
        if (ended) return
        ended = true
        try {
            mp.pause()
        } catch (e: Exception) {
        }
        backdrop.pause()
        if (recording && !usedPause && recN > 0) Replays.put(bm.file.path, ReplayData(recT.copyOf(recN), recC.copyOf(recN), recD.copyOf(recN), recN))
        cb.onEnd(result(failed))
    }

    private fun result(failed: Boolean): Result {
        val acc = if (judged == 0) 100f else (100.0 * sumA / (305.0 * judged)).toFloat()
        val r = Result(counts.copyOf(), liveScore(), acc, maxCombo, failed)
        r.bot = botMode
        r.replay = replayMode
        return r
    }

    private fun liveScore(): Int =
        if (totalJ == 0) 0 else (1_000_000.0 * sumW / (320.0 * totalJ)).roundToInt()

    private fun hitTime(eventTime: Long, pad: Boolean = false): Double {
        val lag = (SystemClock.uptimeMillis() - eventTime).coerceIn(0L, 120L)
        return songTime() - lag - (if (pad) padOffset else offset)
    }

    // ---------- controller / keyboard ----------
    fun padPress(col: Int, et: Long) {
        if (paused || ended || col !in 0 until keys) return
        pressCount[col]++
        userPress(col, hitTime(et, true))
    }

    fun padRelease(col: Int, et: Long) {
        if (paused || ended || col !in 0 until keys) return
        pressCount[col] = max(0, pressCount[col] - 1)
        if (pressCount[col] == 0) userRelease(col, hitTime(et, true))
    }

    private fun press(c: Int, tHit: Double) {
        keyCnt[c]++
        if (keyCounter) keyTxt[c] = keyCnt[c].toString()
        if (haptic) {
            val nowMs = SystemClock.uptimeMillis()
            if (nowMs - lastHaptic >= 35) { // getaran dibatasi supaya tidak menumpuk saat banyak jari
                lastHaptic = nowMs
                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING)
            }
        }
        if (sfx > 0) Sfx.play(sfx / 100f)
        val q = byCol[c]
        var i = colPtr[c]
        while (i < q.size && q[i].finished) i++
        colPtr[c] = i
        if (i >= q.size) return
        val n = q[i]
        if (n.holding) return
        val diff = tHit - n.time
        if (diff < -win[5]) return // terlalu awal, abaikan
        val ad = abs(diff)
        var j = 5
        for (k in 0..4) {
            if (ad <= win[k]) {
                j = k
                break
            }
        }
        if (j == 5) { // tap di luar jendela 50 tapi masih dalam jendela miss
            n.finished = true
            n.missed = true
            register(5, diff)
            if (n.isHold) register(5, diff)
            return
        }
        if (n.isHold) {
            n.holding = true
            held[c] = n
        } else {
            n.finished = true
        }
        fxAt[c] = SystemClock.uptimeMillis()
        fxJ[c] = j
        register(j, diff)
    }

    private fun release(c: Int, tHit: Double) {
        val n = held[c] ?: return
        held[c] = null
        n.holding = false
        n.finished = true
        val err = tHit - n.endTime
        val ad = abs(err)
        var j = 5
        for (k in 0..4) {
            if (ad <= win[k] * 1.5f) {
                j = k
                break
            }
        }
        if (j == 5) n.missed = true
        register(j, err)
    }

    // ---------- touch ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (paused || ended) return true
        if (pbT != null) { // BOT / replay: sentuhan hanya untuk tombol jeda
            if (e.actionMasked == MotionEvent.ACTION_DOWN && pauseBtn && pauseHit.contains(e.x, e.y)) cb.onPausePressed()
            return true
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                // minta event sentuh tanpa dikelompokkan (batching) = respons lebih cepat
                if (e.actionMasked == MotionEvent.ACTION_DOWN) requestUnbufferedDispatch(e)
                val i = e.actionIndex
                touchDown(e.getPointerId(i), e.getX(i), e.getY(i), e.eventTime)
            }
            MotionEvent.ACTION_MOVE -> {
                // geser jari ke kolom lain = kolom itu ikut tertekan (slide / glissando)
                for (i in 0 until e.pointerCount) touchMove(e.getPointerId(i), e.getX(i), e.eventTime)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val i = e.actionIndex
                touchUp(e.getPointerId(i), e.eventTime)
            }
            MotionEvent.ACTION_CANCEL -> {
                val t = hitTime(e.eventTime)
                for (k in 0 until ptrCol.size()) {
                    val col = ptrCol.valueAt(k)
                    pressCount[col] = max(0, pressCount[col] - 1)
                    if (pressCount[col] == 0) userRelease(col, t)
                }
                ptrCol.clear()
            }
        }
        return true
    }

    private fun touchDown(id: Int, x: Float, y: Float, et: Long) {
        // jeda hanya jika tidak ada jari lain di lane (supaya tidak ter-pause saat menekan banyak jari)
        if (pauseBtn && ptrCol.size() == 0 && pauseHit.contains(x, y)) {
            cb.onPausePressed()
            return
        }
        val col = ((x - fieldX) / laneW).toInt().coerceIn(0, keys - 1)
        val old = ptrCol.get(id, -1)
        if (old >= 0) { // pointer id yang sama tertekan lagi tanpa UP: bereskan dulu supaya tidak macet
            pressCount[old] = max(0, pressCount[old] - 1)
            if (pressCount[old] == 0) userRelease(old, hitTime(et))
        }
        ptrCol.put(id, col)
        pressCount[col]++
        userPress(col, hitTime(et))
    }

    /**
     * Jari yang sudah menempel lalu digeser ke kolom lain: kolom lama dilepas, kolom baru ditekan.
     * Jika geseran cepat melewati beberapa kolom, kolom yang dilewati ikut ditekan satu per satu (ala glissando).
     * Jari yang awalnya mendarat di luar lajur / tombol jeda tidak ikut (tidak ada di ptrCol).
     */
    private fun touchMove(id: Int, x: Float, et: Long) {
        val from = ptrCol.get(id, -1)
        if (from < 0) return
        val to = ((x - fieldX) / laneW).toInt().coerceIn(0, keys - 1)
        if (to == from) return
        val step = if (to > from) 1 else -1
        val t = hitTime(et)
        var cur = from
        while (cur != to) {
            val next = cur + step
            pressCount[cur] = max(0, pressCount[cur] - 1)
            if (pressCount[cur] == 0) userRelease(cur, t)
            ptrCol.put(id, next)
            pressCount[next]++
            userPress(next, t)
            cur = next
        }
    }

    private fun touchUp(id: Int, et: Long) {
        val col = ptrCol.get(id, -1)
        if (col < 0) return
        ptrCol.delete(id)
        pressCount[col] = max(0, pressCount[col] - 1)
        if (pressCount[col] == 0) userRelease(col, hitTime(et))
    }

    // ---------- drawing ----------
    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a shl 24)

    private fun yAt(time: Double, t: Double): Float {
        val sgn = if (up) -1.0 else 1.0
        return (hitY - sgn * (time - t) * pxPerMs).toFloat()
    }

    /** Siapkan gambar note tiap kolom (warna / gambar kustom dari Pengaturan > Note) sekali saja, bukan digambar ulang tiap frame. */
    private fun buildNoteBitmaps() {
        val w = noteW.roundToInt()
        val h = noteH.roundToInt()
        val style = if (argon) 2 else if (circle) 0 else 1
        // lampu kolom saat ditekan (skin Argon): gradasi warna kolom dari garis hit ke arah datangnya note
        val lineY = if (up) hitY - noteH / 2f else hitY + noteH / 2f
        val glowH = min(height * 0.5f, if (up) height - lineY else lineY).coerceAtLeast(1f)
        for (c in 0 until keys) {
            colBmp[c] = if (w >= 6 && h >= 6) NoteSkin.makeStyle(context, keys, c, w, h, style, up) else null
            bodyCol[c] = NoteSkin.bodyColor(context, keys, c)
            bodyDark[c] = NoteSkin.darkenTo(bodyCol[c], 0.6f)
            trailCol[c] = NoteSkin.trailFill(context, keys, c, argon)
            trailTex[c] = NoteSkin.trailShader(context, keys, c, trailW().roundToInt())
            glow[c] = if (argon) LinearGradient(
                0f, lineY, 0f, if (up) lineY + glowH else lineY - glowH,
                withAlpha(bodyCol[c], 120), withAlpha(bodyCol[c], 0), Shader.TileMode.CLAMP
            ) else null
        }
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = songTime()
        val fieldW = laneW * keys

        if (dim > 0) cv.drawColor(Color.argb(dim * 255 / 100, 0, 0, 0))

        p.style = Paint.Style.FILL
        if (laneOp > 0) {
            p.color = Color.argb(laneOp * 255 / 100, 0, 0, 0)
            cv.drawRect(fieldX, 0f, fieldX + fieldW, h, p)
        }
        // hanya dua garis luar (kiri & kanan); garis pemisah antar kolom dihilangkan
        p.color = Color.argb(60, 255, 255, 255)
        cv.drawRect(fieldX - 1f, 0f, fieldX + 1f, h, p)
        cv.drawRect(fieldX + fieldW - 1f, 0f, fieldX + fieldW + 1f, h, p)

        // garis hit (mode persegi) / reseptor bulat (mode bulat) / target hit + lampu kolom (skin Argon)
        val rr = noteH / 2f
        if (argon) {
            val crad = noteH * 3.4f / 42f
            val th = noteH * 0.82f
            val sgn = if (up) -1f else 1f
            val lineY = hitY + sgn * noteH / 2f
            val yc = lineY - sgn * th / 2f
            for (c in 0 until keys) {
                val cx = fieldX + c * laneW + laneW / 2f
                val down = pressCount[c] > 0
                if (down && colLight) {
                    val sh = glow[c]
                    if (sh != null) {
                        p.style = Paint.Style.FILL
                        p.color = Color.WHITE // paint harus opak saat memakai shader
                        p.shader = sh
                        if (up) rect.set(cx - noteW / 2f, lineY, cx + noteW / 2f, lineY + min(h * 0.5f, h - lineY))
                        else rect.set(cx - noteW / 2f, lineY - min(h * 0.5f, lineY), cx + noteW / 2f, lineY)
                        cv.drawRect(rect, p)
                        p.shader = null
                    }
                }
                p.style = Paint.Style.FILL
                p.color = Color.argb(if (down) 150 else 77, 255, 255, 255)
                rect.set(cx - noteW / 2f, yc - th / 2f, cx + noteW / 2f, yc + th / 2f)
                cv.drawRoundRect(rect, crad, crad, p)
            }
            p.style = Paint.Style.FILL
            p.color = Color.argb(235, 196, 196, 196)
            rect.set(fieldX, lineY - crad, fieldX + fieldW, lineY + crad)
            cv.drawRoundRect(rect, crad, crad, p)
        } else if (circle) {
            for (c in 0 until keys) {
                val cx = fieldX + c * laneW + laneW / 2f
                val down = pressCount[c] > 0
                if (down) {
                    p.style = Paint.Style.FILL
                    p.color = Color.argb(110, 255, 255, 255)
                    cv.drawCircle(cx, hitY, rr, p)
                }
                p.style = Paint.Style.STROKE
                p.strokeWidth = max(2f * dens, rr * 0.12f)
                p.color = Color.argb(if (down) 255 else 170, 255, 255, 255)
                cv.drawCircle(cx, hitY, rr - p.strokeWidth / 2f, p)
            }
            p.style = Paint.Style.FILL
        } else {
            p.color = Color.argb(230, 255, 255, 255)
            cv.drawRect(fieldX, hitY - 1.5f * dens, fieldX + fieldW, hitY + 1.5f * dens, p)
            // saat ditekan: putih hanya di dalam bentuk note kosong di garis hit, bukan satu kolom penuh
            val rrad = min(noteH * 0.28f, noteW * 0.2f)
            for (c in 0 until keys) {
                if (pressCount[c] > 0) {
                    val cx = fieldX + c * laneW + laneW / 2f
                    rect.set(cx - noteW / 2f, hitY - noteH / 2f, cx + noteW / 2f, hitY + noteH / 2f)
                    p.style = Paint.Style.FILL
                    p.color = Color.argb(110, 255, 255, 255)
                    cv.drawRoundRect(rect, rrad, rrad, p)
                }
            }
        }

        if (hitFx) {
            val nowFx = SystemClock.uptimeMillis()
            for (c in 0 until keys) {
                if (fxAt[c] == 0L) continue
                val age = nowFx - fxAt[c]
                if (age >= 280) continue
                val k = age / 280f
                p.style = Paint.Style.STROKE
                p.strokeWidth = 3f * dens * (1f - k) + 1f
                p.color = withAlpha(COLORS[fxJ[c]], (200 * (1f - k)).toInt())
                if (argon) {
                    val cxe = fieldX + c * laneW + laneW / 2f
                    val gx = noteW * 0.5f * (1f + 0.14f * k)
                    val gy = rr * (1f + 0.30f * k)
                    rect.set(cxe - gx, hitY - gy, cxe + gx, hitY + gy)
                    cv.drawRoundRect(rect, noteH * 0.1f, noteH * 0.1f, p)
                } else cv.drawCircle(fieldX + c * laneW + laneW / 2f, hitY, rr * (1f + 0.55f * k), p)
            }
            p.style = Paint.Style.FILL
        }

        if (keyCounter) { // hitungan tekan tiap kolom, kecil di sisi dalam garis hit
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.textSize = 13f * dens
            p.typeface = Typeface.DEFAULT_BOLD
            p.color = Color.argb(190, 255, 255, 255)
            val ky = keyY()
            for (c in 0 until keys) cv.drawText(keyTxt[c], fieldX + c * laneW + laneW / 2f, ky, p)
        }

        // notes
        while (drawStart < notes.size) {
            val dn = notes[drawStart]
            if (dn.endTime < t - 150 || (dn.finished && !(dn.isHold && dn.missed))) drawStart++ else break
        }
        val dist = (if (up) h - hitY else hitY) + noteH * 2
        val r = noteH * 0.25f
        var i = drawStart
        while (i < notes.size) {
            val n = notes[i]
            i++
            if ((n.time - t) * pxPerMs > dist) break
            if (n.finished && !(n.isHold && n.missed)) continue
            val x = fieldX + n.col * laneW
            val cx = x + laneW / 2f
            val base = bodyCol[n.col]
            val dimmed = n.missed
            val yHead = yAt(if (n.holding) max(n.time.toDouble(), t) else n.time.toDouble(), t)
            if (n.isHold) {
                val yTail = yAt(n.endTime.toDouble(), t)
                val bw = trailW()
                val tex = trailTex[n.col]
                p.style = Paint.Style.FILL
                if (tex != null) {
                    // gambar trail kustom: diulang ke bawah dan ikut bergerak bersama note (berpatokan pada ujung trail)
                    trailMat.setTranslate(cx - bw / 2f, yTail)
                    tex.setLocalMatrix(trailMat)
                    p.shader = tex
                    p.color = Color.argb(if (dimmed) 110 else if (n.holding) 255 else 225, 255, 255, 255)
                } else {
                    p.color = if (argon) withAlpha(trailCol[n.col], if (dimmed) 90 else 235) else withAlpha(trailCol[n.col], if (dimmed) 50 else if (n.holding) 200 else 130)
                }
                rect.set(cx - bw / 2f, min(yHead, yTail), cx + bw / 2f, max(yHead, yTail))
                if (circle) cv.drawRoundRect(rect, bw / 2f, bw / 2f, p) else cv.drawRoundRect(rect, r, r, p)
                p.shader = null
                if (n.holding && (argon || tex != null)) { // badan menyala saat ditahan (ArgonHoldNoteHittingLayer)
                    p.color = if (tex != null) withAlpha(Color.WHITE, 45) else withAlpha(base, 110)
                    cv.drawRoundRect(rect, r, r, p)
                }
            }
            val bmp = colBmp[n.col]
            if (bmp != null) {
                bmpPaint.alpha = if (dimmed) 70 else 255
                cv.drawBitmap(bmp, cx - bmp.width / 2f, yHead - bmp.height / 2f, bmpPaint)
            }
        }
        p.style = Paint.Style.FILL

        // persen progres lagu dan HP (dua angka desimal, mis. 07.35%) tanpa membuat String baru tiap frame
        val pv = ((t / lastEnd).coerceIn(0.0, 1.0) * 10000.0).toInt()
        if (pv != progShown) {
            progShown = pv
            progText = pct2(pv / 100.0, 2)
        }
        val hv = (hp.coerceIn(0f, 1f) * 10000f).toInt()
        if (hv != hpShown) {
            hpShown = hv
            hpText = pct2(hv / 100.0, 2)
            hpLabel = "HP $hpText"
        }
        val hs = hudS
        p.typeface = Typeface.DEFAULT_BOLD
        if (showHpHud) {
            val b1 = (12f + 20f * hs) * dens
            p.textAlign = Paint.Align.LEFT
            p.textSize = 20f * dens * hs
            p.color = Color.argb(235, 255, 255, 255)
            cv.drawText(progText, 14f * dens, b1, p)
            p.textSize = 15f * dens * hs
            p.color = if (hp > 0.3f) Color.argb(230, 130, 235, 150) else Color.argb(245, 255, 110, 110)
            cv.drawText(hpLabel, 14f * dens, b1 + 22f * dens * hs, p)
        }
        if (showAccHud) {
            val b2 = (10f + 28f * hs) * dens
            p.textAlign = Paint.Align.RIGHT
            p.color = Color.WHITE
            p.textSize = 28f * dens * hs
            cv.drawText(scoreText, w - 16f * dens, b2, p)
            p.textSize = 19f * dens * hs
            p.color = Color.argb(235, 255, 255, 255)
            cv.drawText(accText, w - 16f * dens, b2 + 26f * dens * hs, p)
        }

        p.textAlign = Paint.Align.CENTER
        if (showCombo && combo > 1) {
            if (combo != comboShown) {
                comboShown = combo
                comboText = combo.toString()
            }
            p.textSize = 44f * dens * hs
            p.color = Color.argb(200, 255, 255, 255)
            cv.drawText(comboText, w / 2f, h * 0.32f, p)
        }
        val age = SystemClock.uptimeMillis() - lastJAt
        if (showJudge && lastJ >= 0 && age < 450) {
            val k = 1f - age / 450f
            p.textSize = 28f * dens * hs * (1f + 0.15f * k)
            p.color = withAlpha(COLORS[lastJ], (255 * k).toInt())
            cv.drawText(names[lastJ], w / 2f, h * 0.42f, p)
            if (lastJ in 1..4 && abs(lastErr) > win[0]) {
                p.textSize = 14f * dens * hs
                cv.drawText(if (lastErr < 0) txtEarly else txtLate, w / 2f, h * 0.42f + 22f * dens * hs, p)
            }
        }

        // bar kesalahan timing (kiri = terlalu cepat, kanan = terlambat)
        if (hitErrorBar) {
            val cxb = w / 2f
            val by = if (up) h - 10f * dens else if (keyCounter) min(h - 6f * dens, keyY() + 15f * dens) else min(h - 9f * dens, hitY + noteH / 2f + 11f * dens)
            val half = min(w * 0.18f, 120f * dens)
            val range = max(win[4], 60f)
            val sc = half / range
            p.style = Paint.Style.FILL
            p.color = Color.argb(70, 255, 255, 255)
            cv.drawRect(cxb - half, by - 1f * dens, cxb + half, by + 1f * dens, p)
            p.color = Color.argb(170, 255, 255, 255)
            cv.drawRect(cxb - 1f * dens, by - 7f * dens, cxb + 1f * dens, by + 7f * dens, p)
            val nowE = SystemClock.uptimeMillis()
            for (k in errMs.indices) {
                if (errAt[k] == 0L) continue
                val ageE = nowE - errAt[k]
                if (ageE > 3000) continue
                val xE = cxb + errMs[k].coerceIn(-range, range) * sc
                p.color = withAlpha(COLORS[errJ[k]], (255 * (1f - ageE / 3000f)).toInt())
                cv.drawRect(xE - 1.5f * dens, by - 6f * dens, xE + 1.5f * dens, by + 6f * dens, p)
            }
        }

        // info chart saat awal lagu: di tengah atas (tidak menimpa bulatan), dikecilkan otomatis jika terlalu lebar
        if (t < 5500) {
            val a = if (t < 3500) 255 else (255 * (1.0 - (t - 3500) / 2000.0)).toInt().coerceIn(0, 255)
            p.textAlign = Paint.Align.CENTER
            val maxW = w * 0.8f
            var ts = 20f * dens
            p.textSize = ts
            val tw = p.measureText(infoTitle)
            if (tw > maxW) ts *= maxW / tw
            p.textSize = ts
            p.color = withAlpha(Color.WHITE, a)
            cv.drawText(infoTitle, w / 2f, h * 0.17f, p)
            p.color = withAlpha(0xFFD0D0E0.toInt(), a)
            p.textSize = 13f * dens
            cv.drawText(infoSub, w / 2f, h * 0.17f + 22f * dens, p)
            cv.drawText(infoStats, w / 2f, h * 0.17f + 42f * dens, p)
        }

        // hitung mundur 3-2-1 sesudah Lanjut
        if (resuming && resumeMs > 0L) {
            val el = ((System.nanoTime() - resumeStart) / 1e6).coerceAtLeast(0.0)
            val num = (3 - (el / 1000.0).toInt()).coerceIn(1, 3)
            val f = ((el % 1000.0) / 1000.0).toFloat().let { if (el >= resumeMs) 0f else it }
            p.style = Paint.Style.FILL
            p.color = Color.argb(70, 0, 0, 0)
            cv.drawRect(0f, 0f, w, h, p)
            val cxm = w / 2f
            val cym = h * 0.42f
            val rr = 54f * dens * (1f + 0.35f * f)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 3f * dens
            p.color = Color.argb((200 * (1f - f)).toInt().coerceIn(0, 255), 255, 255, 255)
            cv.drawCircle(cxm, cym, rr, p)
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = 78f * dens * (1.15f - 0.15f * f)
            p.color = Color.argb((255 * (1f - f * f)).toInt().coerceIn(0, 255), 255, 255, 255)
            cv.drawText(num.toString(), cxm, cym + 27f * dens, p)
        }

        overlayDraw?.invoke(cv, w, h, dens)
        if (pbT != null) {
            p.textAlign = Paint.Align.CENTER
            p.textSize = 13f * dens
            p.typeface = Typeface.DEFAULT_BOLD
            p.color = Color.argb(215, 255, 95, 162)
            cv.drawText(tagText, w / 2f, 24f * dens, p)
        }
        if (showFps && fpsText.isNotEmpty()) {
            p.textAlign = Paint.Align.RIGHT
            p.textSize = 11f * dens
            p.color = Color.argb(170, 255, 255, 255)
            cv.drawText(fpsText, w - 8f * dens, h - 8f * dens, p)
        }
        if (!pauseBtn) return

        // tombol jeda (kanan): lingkaran gelap transparan dengan cincin tipis
        val pcx = pauseRect.centerX()
        val pcy = pauseRect.centerY()
        val pr = pauseRect.width() / 2f
        p.style = Paint.Style.FILL
        p.color = Color.argb(120, 12, 12, 20)
        cv.drawCircle(pcx, pcy, pr, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * dens
        p.color = Color.argb(110, 255, 255, 255)
        cv.drawCircle(pcx, pcy, pr - 0.75f * dens, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        rect.set(pcx - 7f * dens, pcy - 9f * dens, pcx - 2.5f * dens, pcy + 9f * dens)
        cv.drawRoundRect(rect, 1.5f * dens, 1.5f * dens, p)
        rect.set(pcx + 2.5f * dens, pcy - 9f * dens, pcx + 7f * dens, pcy + 9f * dens)
        cv.drawRoundRect(rect, 1.5f * dens, 1.5f * dens, p)
    }
}
