package com.maniadroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.SystemClock
import android.view.Choreographer
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Metronom: klik tiap 500 ms mulai detik ke-3 (file WAV dibuat sendiri). */
object SyncAudio {
    const val FIRST = 3000
    const val GAP = 500
    const val COUNT = 40

    fun file(c: Context): File {
        val f = File(c.cacheDir, "sync_v1.wav")
        if (!f.exists()) write(f)
        return f
    }

    private fun write(f: File) {
        val sr = 44100
        val total = (FIRST + GAP * COUNT + 1500) * sr / 1000
        val bb = ByteBuffer.allocate(44 + total * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + total * 2); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16)
        bb.putShort(1); bb.putShort(1); bb.putInt(sr); bb.putInt(sr * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(total * 2)
        val data = ShortArray(total)
        for (k in 0 until COUNT) {
            val start = (FIRST + k * GAP) * sr / 1000
            for (i in 0 until 1100) {
                val s = sin(2 * PI * 1500 * i / sr) * exp(-i / 160.0) * 0.85
                val idx = start + i
                if (idx < total) data[idx] = (s * 32767).toInt().toShort()
            }
        }
        for (v in data) bb.putShort(v)
        f.writeBytes(bb.array())
    }
}

class SyncView(ctx: Context, private val mp: MediaPlayer, private val onDone: () -> Unit) :
    View(ctx), Choreographer.FrameCallback {
    private val times = IntArray(SyncAudio.COUNT) { SyncAudio.FIRST + it * SyncAudio.GAP }
    private val used = BooleanArray(times.size)
    private val touchErrs = ArrayList<Double>()
    private val padErrs = ArrayList<Double>()
    private var lastErr = 0.0
    private var lastKind = 0
    private var lastMsg = ""
    private var taps = 0
    private var done = false
    private var destroyed = false
    private var lastPos = 0
    private var lastNano = 0L
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dens = resources.displayMetrics.density

    fun begin() {
        try {
            mp.start()
        } catch (e: Exception) {
        }
        lastPos = 0
        lastNano = System.nanoTime()
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun destroy() {
        destroyed = true
        Choreographer.getInstance().removeFrameCallback(this)
    }

    private fun songTime(): Double {
        val now = System.nanoTime()
        val pos = try {
            mp.currentPosition
        } catch (e: Exception) {
            lastPos
        }
        if (pos != lastPos) {
            lastPos = pos
            lastNano = now
        }
        return lastPos + (now - lastNano) / 1e6
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (destroyed) return
        if (!done && songTime() > times[times.size - 1] + 1200) {
            done = true
            onDone()
        }
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun mean(list: List<Double>): Double {
        val tail = list.takeLast(12).sorted()
        val use = if (tail.size >= 6) tail.subList(1, tail.size - 1) else tail
        return use.average()
    }

    fun tap(eventTime: Long, pad: Boolean) {
        if (done) return
        val lag = (SystemClock.uptimeMillis() - eventTime).coerceIn(0L, 120L)
        val t = songTime() - lag
        var best = -1
        var bd = 1e9
        for (i in times.indices) {
            if (used[i]) continue
            val d = abs(t - times[i])
            if (d < bd) {
                bd = d
                best = i
            }
        }
        if (best < 0 || bd > 260) {
            lastMsg = "Ketukan di luar jangkauan"
            return
        }
        used[best] = true
        val err = t - times[best]
        taps++
        val list = if (pad) padErrs else touchErrs
        list.add(err)
        lastErr = err
        lastKind = if (pad) 2 else 1
        lastMsg = ""
        if (list.size >= 4) { // offset diperbarui otomatis
            val v = mean(list).roundToInt().coerceIn(-300, 300)
            if (pad) Settings.padOffset = v else Settings.offset = v
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) tap(e.eventTime, false)
        return true
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = songTime()
        cv.drawColor(0xFF0E0E18.toInt())
        val cx = w * 0.35f
        val hitY = h * 0.72f
        val scrollMs = 1300.0
        val px = hitY / scrollMs
        val r = min(h * 0.075f, 46f * dens)

        p.style = Paint.Style.FILL
        p.color = 0x14FFFFFF
        cv.drawRect(cx - r * 1.4f, 0f, cx + r * 1.4f, h, p)
        for (i in times.indices) {
            if (used[i]) continue
            val y = (hitY - (times[i] - t) * px).toFloat()
            if (y < -r || y > h + r) continue
            p.color = 0xFF5BB8FF.toInt()
            cv.drawCircle(cx, y, r, p)
            p.color = 0xFFA6D8FF.toInt()
            cv.drawCircle(cx, y, r * 0.74f, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f * dens
        p.color = Color.WHITE
        cv.drawCircle(cx, hitY, r, p)
        p.style = Paint.Style.FILL

        val tx = w * 0.62f
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.DEFAULT_BOLD
        p.color = Color.WHITE
        p.textSize = 22f * dens
        cv.drawText("Sinkron (kalibrasi)", tx, h * 0.14f, p)
        p.typeface = Typeface.DEFAULT
        p.textSize = 13f * dens
        p.color = 0xFFC9C9DA.toInt()
        cv.drawText("Ketuk (atau tekan tombol controller) tepat saat", tx, h * 0.21f, p)
        cv.drawText("lingkaran menyentuh cincin / saat bunyi klik.", tx, h * 0.25f, p)
        cv.drawText("Offset diperbarui otomatis tiap ketukan.", tx, h * 0.29f, p)

        if (lastKind != 0 && lastMsg.isEmpty()) {
            val ms = lastErr.roundToInt()
            val a = abs(lastErr)
            p.color = if (a <= 25) 0xFF7DDC6A.toInt() else if (a <= 60) 0xFFFFE066.toInt() else 0xFFFF6B6B.toInt()
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = 48f * dens
            cv.drawText(String.format(Locale.US, "%+d ms", ms), tx, h * 0.46f, p)
            p.textSize = 16f * dens
            cv.drawText(if (ms > 0) "LATE (terlambat)" else if (ms < 0) "EARLY (terlalu cepat)" else "TEPAT", tx, h * 0.52f, p)
        } else if (lastMsg.isNotEmpty()) {
            p.color = 0xFFFF6B6B.toInt()
            p.textSize = 16f * dens
            cv.drawText(lastMsg, tx, h * 0.46f, p)
        }
        p.typeface = Typeface.DEFAULT
        p.textSize = 14f * dens
        p.color = Color.WHITE
        cv.drawText("Offset sentuhan: ${Settings.offset} ms  (${touchErrs.size} ketukan)", tx, h * 0.64f, p)
        cv.drawText("Offset controller/keyboard: ${Settings.padOffset} ms  (${padErrs.size} ketukan)", tx, h * 0.69f, p)
        p.color = 0xFFC9C9DA.toInt()
        p.textSize = 12f * dens
        cv.drawText("Ketukan: $taps / ${times.size}", tx, h * 0.75f, p)
    }
}

class SyncActivity : Activity() {
    private var mp: MediaPlayer? = null
    private var view: SyncView? = null
    private val pad = PadState()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val player = MediaPlayer()
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            player.setDataSource(SyncAudio.file(this).path)
            player.prepare()
            player.setVolume(1f, 1f)
        } catch (e: Exception) {
            player.release()
            finish()
            return
        }
        mp = player
        val v = SyncView(this, player) { showDone() }
        view = v
        setContentView(v)
        v.begin()
    }

    private fun showDone() {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Sinkron selesai")
            .setMessage(
                "Offset sentuhan: ${Settings.offset} ms\nOffset controller/keyboard: ${Settings.padOffset} ms\n\n" +
                        "Sudah diterapkan otomatis. Nilai bisa diubah manual di Pengaturan."
            )
            .setCancelable(false)
            .setPositiveButton("Selesai") { _, _ -> finish() }
            .setNegativeButton("Ulangi") { _, _ ->
                finish()
                startActivity(Intent(this, SyncActivity::class.java))
            }
            .setNeutralButton("Reset ke 0") { _, _ ->
                Settings.offset = 0
                Settings.padOffset = 0
                finish()
            }
            .show()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val v = view ?: return super.dispatchKeyEvent(e)
        if (Input.isSystemKey(e.keyCode)) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.repeatCount == 0 && pad.keyDown(e.keyCode)) v.tap(e.eventTime, true)
        } else if (e.action == KeyEvent.ACTION_UP) {
            pad.keyUp(e.keyCode)
        }
        return true
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val v = view
        if (v != null && Input.isJoystickMove(ev)) {
            val st = Input.axisStates(ev)
            for (i in st.indices) {
                if (pad.axisSet(Input.AXIS_CODES[i], st[i]) > 0) v.tap(ev.eventTime, true)
            }
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun onDestroy() {
        super.onDestroy()
        view?.destroy()
        try {
            mp?.release()
        } catch (e: Exception) {
        }
    }
}
