package com.maniadroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Build
import android.view.Surface
import android.view.TextureView
import android.widget.FrameLayout
import android.widget.ImageView
import java.io.File
import kotlin.math.abs

/**
 * Latar belakang gameplay: gambar BG (lapisan bawah) + video (lapisan atas).
 * Jika chart punya video tapi tidak punya gambar BG, diambil satu frame dari video.
 * Jika video gagal diputar (format tidak didukung Android), gambar BG tetap tampil.
 */
class Backdrop(ctx: Context, private val bm: Beatmap, private val forEditor: Boolean = false) : FrameLayout(ctx), TextureView.SurfaceTextureListener {
    private val img = ImageView(ctx)
    private val tv = TextureView(ctx)
    private var vp: MediaPlayer? = null
    private var ready = false
    private var playing = false
    private var seeking = false
    private var wantPlay = false
    private var ended = false
    private var vw = 0
    private var vh = 0
    private val chartVideo: File? = bm.video?.let { Library.findFile(bm.dir, it) }
    private val videoFile: File? = if (Settings.showVideo) chartVideo else null

    /** Dipanggil (di main thread) saat video gagal diputar, untuk memberi tahu pemain. */
    var onNote: ((String) -> Unit)? = null

    /** Pesan awal jika chart mencantumkan video tapi file-nya tidak ada di paket. */
    val initialNote: String? =
        if (Settings.showVideo && bm.video != null && chartVideo == null)
            L.t("Chart ini mencantumkan video (${bm.video}) tapi file-nya tidak ada di paket chart. Unduh ulang dengan opsi video aktif.", "This chart lists a video (${bm.video}) but the file is missing from the chart package. Download it again with the video option on.")
        else null

    init {
        setBackgroundColor(Color.BLACK)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        addView(img, Ui.matchParams())
        loadImage()
        if (videoFile != null) {
            tv.surfaceTextureListener = this
            addView(tv, Ui.matchParams())
        }
    }

    /**
     * Aturan latar:
     *  - chart punya video -> gambar BG chart (atau 1 frame video) di bawah video
     *  - chart TANPA video -> hitam polos, kecuali: opsi "gambar BG chart" aktif / sedang di editor,
     *    atau pengguna memasang gambar background sendiri di Pengaturan.
     */
    private fun loadImage() {
        val chartBg = bm.bg?.let { Library.findFile(bm.dir, it) }
        // gambar sendiri hanya dipakai jika latar menu diset "Gambar sendiri"
        val custom = if (Settings.menuBg == 2) Library.customBg(context) else null
        val hasVideo = chartVideo != null
        val src: File? = when {
            hasVideo -> if (Settings.showBg || forEditor) chartBg else null
            forEditor || Settings.chartBgImage -> chartBg ?: custom
            else -> custom
        }
        val frameSrc = if (hasVideo && src == null && (Settings.showBg || forEditor)) chartVideo else null
        if (src == null && frameSrc == null) return
        Thread {
            var bmp: Bitmap? = null
            try {
                if (src != null) bmp = decode(src.path)
            } catch (e: Throwable) {
            }
            if (bmp == null && hasVideo && chartVideo != null && (Settings.showBg || forEditor)) bmp = frame(chartVideo)
            val b = bmp
            if (b != null) post { img.setImageBitmap(b) }
        }.start()
    }

    private fun decode(path: String): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / s > 1920 || o.outHeight / s > 1920) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return BitmapFactory.decodeFile(path, o2)
    }

    private fun frame(f: File): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.path)
            r.getFrameAtTime(2_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Throwable) {
            null
        } finally {
            try {
                r.release()
            } catch (e: Throwable) {
            }
        }
    }

    // ---- video ----
    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
        val f = videoFile ?: return
        releaseVideo()
        ready = false; playing = false; seeking = false; ended = false
        try {
            val p = MediaPlayer()
            vp = p
            p.setDataSource(f.path)
            p.setSurface(Surface(st))
            p.setVolume(0f, 0f)
            p.setOnVideoSizeChangedListener { _, w2, h2 ->
                if (w2 > 0 && h2 > 0) {
                    vw = w2; vh = h2
                    applyCrop()
                }
            }
            p.setOnPreparedListener { ready = true }
            p.setOnSeekCompleteListener { m ->
                seeking = false
                if (wantPlay && !playing && !ended) {
                    try {
                        m.start()
                        playing = true
                    } catch (e: Exception) {
                    }
                }
            }
            p.setOnCompletionListener {
                ended = true
                playing = false
            }
            p.setOnErrorListener { _, _, _ ->
                failVideo()
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            failVideo()
        }
    }

    private fun failVideo() {
        releaseVideo()
        tv.visibility = GONE // gambar BG di bawahnya tetap terlihat
        val ext = videoFile?.extension?.lowercase() ?: ""
        onNote?.invoke(L.t("Video .$ext tidak bisa diputar di Android (format/codec tidak didukung). Memakai gambar background.", "The .$ext video cannot be played on Android (unsupported format/codec). Using the background image instead."))
    }

    private fun applyCrop() {
        val viewW = tv.width.toFloat()
        val viewH = tv.height.toFloat()
        if (viewW <= 0f || viewH <= 0f || vw <= 0 || vh <= 0) return
        val va = vw.toFloat() / vh
        val wa = viewW / viewH
        var sx = 1f
        var sy = 1f
        if (va > wa) sx = va / wa else sy = wa / va
        val m = Matrix()
        m.setScale(sx, sy, viewW / 2f, viewH / 2f)
        tv.setTransform(m)
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) = applyCrop()
    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    /** Dipanggil game tiap ~400 ms dengan waktu lagu (ms). */
    fun sync(songMs: Double) {
        val p = vp ?: return
        if (!ready || seeking || ended) return
        val want = (songMs - bm.videoOffset).toInt()
        try {
            if (want < 0) {
                if (playing) {
                    p.pause()
                    playing = false
                }
                wantPlay = false
                return
            }
            wantPlay = true
            if (!playing || abs(p.currentPosition - want) > 300) seek(p, want)
        } catch (e: Exception) {
        }
    }

    private fun seek(p: MediaPlayer, ms: Int) {
        seeking = true
        if (Build.VERSION.SDK_INT >= 26) p.seekTo(ms.toLong(), MediaPlayer.SEEK_CLOSEST) else p.seekTo(ms)
    }

    /** Tampilkan frame video pada posisi tertentu saat editor digeser (tidak memutar). */
    fun preview(songMs: Double) {
        val p = vp ?: return
        if (!ready || seeking || playing) return
        val want = (songMs - bm.videoOffset).toInt()
        if (want < 0) return
        ended = false
        wantPlay = false
        try {
            seek(p, want)
        } catch (e: Exception) {
        }
    }

    fun pause() {
        wantPlay = false
        try {
            if (playing) vp?.pause()
        } catch (e: Exception) {
        }
        playing = false
    }

    private fun releaseVideo() {
        try {
            vp?.release()
        } catch (e: Exception) {
        }
        vp = null
    }

    fun release() = releaseVideo()
}
