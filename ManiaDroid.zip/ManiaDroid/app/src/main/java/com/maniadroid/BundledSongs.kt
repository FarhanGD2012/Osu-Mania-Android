package com.maniadroid

import android.content.Context

/**
 * Lagu bawaan ala osu!lazer: beberapa lagu + chart mania (Easy / Normal / Hard) ikut di dalam aplikasi
 * (folder assets/songs, berkas .osz). Dipasang otomatis sekali saja ke daftar lagu, jadi menu langsung berbunyi dan
 * ada yang bisa dimainkan walau belum mengunduh apa pun. Kalau dihapus pengguna, tidak dipasang lagi.
 * Semua lagu dibuat sendiri (bukan lagu berhak cipta).
 */
object BundledSongs {
    private const val VERSION = 1
    private const val KEY = "bundledSeed"

    @Synchronized
    fun seed(c: Context) {
        if (!Settings.ready) Settings.init(c)
        if (Settings.sp.getInt(KEY, 0) >= VERSION) return
        val am = c.applicationContext.assets
        val names = try {
            am.list("songs")
        } catch (e: Exception) {
            null
        } ?: return
        var any = false
        for (n in names.sorted()) {
            if (!n.endsWith(".osz", ignoreCase = true)) continue
            try {
                if (Library.importOsz(c.applicationContext, n) { am.open("songs/$n") } > 0) any = true
            } catch (e: Exception) {
            }
        }
        if (any || names.isEmpty()) Settings.sp.edit().putInt(KEY, VERSION).apply()
    }
}
