package com.maniadroid

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min

/** Logo bulat berwarna pink bergaya osu (gambar sendiri, bukan logo resmi). Berdenyut pelan. */
class LogoView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pulse = 1f
    private var anim: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 650
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            pulse = 1f + 0.035f * (it.animatedValue as Float)
            invalidate()
        }
        a.start()
        anim = a
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.88f * pulse
        p.style = Paint.Style.FILL
        p.color = 0x33FF66AA
        cv.drawCircle(cx, cy, r * 1.1f, p)
        p.color = Color.WHITE
        cv.drawCircle(cx, cy, r, p)
        p.color = 0xFFFF66AA.toInt()
        cv.drawCircle(cx, cy, r * 0.92f, p)
        p.color = 0x22FFFFFF
        cv.drawCircle(cx, cy - r * 0.18f, r * 0.62f, p)
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = r * 0.62f
        cv.drawText("osu", cx, cy + r * 0.08f, p)
        p.textSize = r * 0.27f
        cv.drawText("MANIA", cx, cy + r * 0.45f, p)
    }
}
