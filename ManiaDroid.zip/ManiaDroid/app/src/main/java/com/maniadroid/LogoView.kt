package com.maniadroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * Logo bulat berwarna pink bergaya osu (gambar sendiri, bukan logo resmi).
 * Berdenyut mengikuti lagu menu (hentakan bass), plus gelombang cincin saat ada hentakan kuat.
 * Kalau lagu belum selesai dianalisis / tidak ada musik, logo "bernapas" pelan.
 */
class LogoView(ctx: Context) : View(ctx), Choreographer.FrameCallback {
    companion object {
        /** Radius logo = BASE x sisi view (view persegi seukuran sisi terpendek layar; sisanya ruang gelombang). */
        const val BASE = 0.29f

        /** Gambar logo; dipakai juga oleh layar intro. glow: 0..1 */
        fun paintLogo(cv: Canvas, p: Paint, cx: Float, cy: Float, r: Float, glow: Float) {
            p.style = Paint.Style.FILL
            p.color = Color.argb((0x33 + 0x4A * glow).toInt().coerceIn(0, 255), 255, 0x66, 0xAA)
            cv.drawCircle(cx, cy, r * (1.10f + 0.04f * glow), p)
            p.color = Color.WHITE
            cv.drawCircle(cx, cy, r, p)
            p.color = 0xFFFF66AA.toInt()
            cv.drawCircle(cx, cy, r * 0.92f, p)
            p.color = 0x22FFFFFF
            cv.drawCircle(cx, cy - r * 0.18f, r * 0.62f, p)
            p.color = Color.WHITE
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = r * 0.62f
            cv.drawText("osu", cx, cy + r * 0.08f, p)
            p.textSize = r * 0.27f
            cv.drawText("MANIA", cx, cy + r * 0.45f, p)
        }
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var level = 0f
    private var prevTarget = 0f
    private var idlePhase = 0f
    private var lastFrame = 0L
    private var lastRipple = 0L
    private val ripple = FloatArray(3) { -1f } // progres 0..1, -1 = tidak aktif
    private var running = false

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        lastFrame = 0L
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDetachedFromWindow() {
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
        super.onDetachedFromWindow()
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        val dt = if (lastFrame == 0L) 0.016f else ((frameTimeNanos - lastFrame) / 1e9f).coerceIn(0.001f, 0.05f)
        lastFrame = frameTimeNanos

        val lv = MenuMusic.level()
        val reactive = lv >= 0f
        val target: Float
        if (reactive) {
            target = lv
        } else {
            idlePhase += dt * (2f * PI.toFloat() / 1.6f)
            target = 0.18f * (0.5f + 0.5f * sin(idlePhase))
        }
        // naik cepat (hentakan), turun lebih lambat (peluruhan halus)
        val k = if (target > level) 1f - exp(-dt * 40f) else 1f - exp(-dt * 7f)
        level += (target - level) * k

        // gelombang cincin saat hentakan kuat
        val nowMs = frameTimeNanos / 1_000_000L
        if (reactive && target > 0.72f && prevTarget <= 0.72f && nowMs - lastRipple > 220) {
            lastRipple = nowMs
            for (i in ripple.indices) {
                if (ripple[i] < 0f) {
                    ripple[i] = 0f
                    break
                }
            }
        }
        prevTarget = target
        for (i in ripple.indices) {
            if (ripple[i] >= 0f) {
                ripple[i] += dt / 0.85f
                if (ripple[i] >= 1f) ripple[i] = -1f
            }
        }
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun baseR(): Float = min(width, height) * BASE

    // hanya lingkaran logo yang bisa diketuk (view-nya lebih besar dari logo)
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            val dx = e.x - width / 2f
            val dy = e.y - height / 2f
            val r = baseR() * 1.08f
            if (dx * dx + dy * dy > r * r) return false
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = baseR()
        val maxR = min(width, height) / 2f

        // gelombang cincin
        p.style = Paint.Style.STROKE
        for (i in ripple.indices) {
            val a = ripple[i]
            if (a < 0f) continue
            val rr = base * 1.05f + (maxR - base * 1.05f) * a
            p.strokeWidth = base * 0.05f * (1f - a) + 1.5f
            p.color = Color.argb(((1f - a) * (1f - a) * 150).toInt(), 255, 0x88, 0xBB)
            cv.drawCircle(cx, cy, rr, p)
        }

        var s = 1f + 0.075f * level
        if (isPressed) s *= 0.97f
        paintLogo(cv, p, cx, cy, base * s, level)
    }
}
