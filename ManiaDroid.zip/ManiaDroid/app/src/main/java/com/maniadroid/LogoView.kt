package com.maniadroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * Logo bulat berwarna pink bergaya osu (gambar sendiri, bukan logo resmi).
 * Berdenyut mengikuti lagu menu (hentakan bass), plus gelombang cincin saat ada hentakan kuat.
 * Kalau lagu belum selesai dianalisis / tidak ada musik, logo "bernapas" pelan.
 */
class LogoView(ctx: Context) : View(ctx), Choreographer.FrameCallback {
    companion object {
        /** Radius logo = BASE x sisi view (view persegi seukuran sisi terpendek layar; sisanya ruang gelombang). */
        const val BASE = 0.315f

        private val dst = RectF()
        private val artPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        /** Gambar logo osu! (res/drawable-nodpi/osu_logo.png). Dimuat sekali; null = pakai gambar cadangan buatan kode. */
        @Volatile
        private var art: Bitmap? = null

        fun loadArt(c: Context) {
            if (art != null) return
            try {
                val o = BitmapFactory.Options()
                o.inScaled = false
                val id = c.resources.getIdentifier("osu_logo", "drawable", c.packageName)
                if (id != 0) art = BitmapFactory.decodeResource(c.resources, id, o)
            } catch (e: Throwable) {
            }
        }

        /** Gambar logo; dipakai juga oleh layar intro. glow: 0..1, flash: kilat putih saat diketuk (hanya di dalam lingkaran). */
        fun paintLogo(cv: Canvas, p: Paint, cx: Float, cy: Float, r: Float, glow: Float, flash: Float = 0f) {
            p.style = Paint.Style.FILL
            p.color = Color.argb((0x33 + 0x4A * glow).toInt().coerceIn(0, 255), 255, 0x66, 0xAA)
            cv.drawCircle(cx, cy, r * (1.10f + 0.04f * glow), p)
            val a = art
            if (a != null) {
                // gambar logo osu! asli: cincin putih di tepi + segitiga + tulisan "osu!"
                dst.set(cx - r, cy - r, cx + r, cy + r)
                cv.drawBitmap(a, null, dst, artPaint)
            } else {
                p.color = Color.WHITE
                cv.drawCircle(cx, cy, r, p)
                p.color = 0xFFFF66AA.toInt()
                cv.drawCircle(cx, cy, r * 0.92f, p)
                p.color = 0x22FFFFFF
                cv.drawCircle(cx, cy - r * 0.18f, r * 0.62f, p)
            }
            if (flash > 0.01f) {
                p.color = Color.argb((flash * 0.5f * 255f).toInt().coerceIn(0, 255), 255, 255, 255)
                cv.drawCircle(cx, cy, r * 0.90f, p)
            }
            if (a == null) {
                p.color = Color.WHITE
                p.textAlign = Paint.Align.CENTER
                p.typeface = Typeface.DEFAULT_BOLD
                p.textSize = r * 0.62f
                cv.drawText("OSU", cx, cy + r * 0.08f, p)
            }
        }
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var level = 0f
    private var prevTarget = 0f
    private var flash = 0f
    private var idlePhase = 0f
    private var lastFrame = 0L
    private var lastRipple = 0L
    private val ripple = FloatArray(3) { -1f } // progres 0..1, -1 = tidak aktif
    private var running = false

    init {
        loadArt(ctx)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        lastFrame = 0L
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDetachedFromWindow() {
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
        super.onDetachedFromWindow()
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        val dt = if (lastFrame == 0L) 0.016f else ((frameTimeNanos - lastFrame) / 1e9f).coerceIn(0.001f, 0.05f)
        lastFrame = frameTimeNanos

        val lv = MenuMusic.level()
        val reactive = lv >= 0f
        val target: Float
        if (reactive) {
            target = lv
        } else {
            idlePhase += dt * (2f * PI.toFloat() / 1.6f)
            target = 0.18f * (0.5f + 0.5f * sin(idlePhase))
        }
        // naik cepat (hentakan), turun lebih lambat (peluruhan halus)
        val k = if (target > level) 1f - exp(-dt * 40f) else 1f - exp(-dt * 7f)
        level += (target - level) * k
        // kilat putih saat logo ditekan: cepat muncul, pelan memudar
        val ft = if (isPressed) 1f else 0f
        flash += (ft - flash) * (if (ft > flash) 1f - exp(-dt * 30f) else 1f - exp(-dt * 9f))

        // gelombang cincin saat hentakan kuat
        val nowMs = frameTimeNanos / 1_000_000L
        if (reactive && target > 0.72f && prevTarget <= 0.72f && nowMs - lastRipple > 220) {
            lastRipple = nowMs
            for (i in ripple.indices) {
                if (ripple[i] < 0f) {
                    ripple[i] = 0f
                    break
                }
            }
        }
        prevTarget = target
        for (i in ripple.indices) {
            if (ripple[i] >= 0f) {
                ripple[i] += dt / 0.85f
                if (ripple[i] >= 1f) ripple[i] = -1f
            }
        }
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun baseR(): Float = min(width, height) * BASE

    /** Titik (koordinat lokal view) berada di dalam lingkaran logo? */
    fun containsLogoPoint(x: Float, y: Float): Boolean {
        val dx = x - width / 2f
        val dy = y - height / 2f
        val r = baseR() * 1.08f
        return dx * dx + dy * dy <= r * r
    }

    // hanya lingkaran logo yang bisa diketuk (view-nya lebih besar dari logo)
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN && !containsLogoPoint(e.x, e.y)) return false
        return super.onTouchEvent(e)
    }

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = baseR()
        val maxR = min(width, height) / 2f

        // gelombang cincin
        p.style = Paint.Style.STROKE
        for (i in ripple.indices) {
            val a = ripple[i]
            if (a < 0f) continue
            val rr = base * 1.05f + (maxR - base * 1.05f) * a
            p.strokeWidth = base * 0.05f * (1f - a) + 1.5f
            p.color = Color.argb(((1f - a) * (1f - a) * 150).toInt(), 255, 0x88, 0xBB)
            cv.drawCircle(cx, cy, rr, p)
        }

        var s = 1f + 0.09f * level
        if (isPressed) s *= 0.97f
        paintLogo(cv, p, cx, cy, base * s, level, flash)
    }
}
