package com.maniadroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var sets: List<SongSet> = emptyList()
    private lateinit var empty: TextView

    private fun dp(v: Int) = Ui.dp(this, v)

    private val adapter = object : BaseAdapter() {
        override fun getCount() = sets.size
        override fun getItem(position: Int): Any = sets[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = (convertView as? LinearLayout) ?: row()
            val s = sets[position]
            (v.getChildAt(0) as TextView).text = s.title
            val keys = s.maps.map { it.keys }.distinct().joinToString(", ") { "${it}K" }
            (v.getChildAt(1) as TextView).text = "${s.artist} · mapper ${s.creator} · $keys · ${s.maps.size} diff"
            return v
        }
    }

    private fun row(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(14), dp(10), dp(14), dp(10))
        l.background = Ui.rounded(Ui.CARD, dp(12).toFloat())
        val t = Ui.text(this, "", 16f, Ui.TEXT, true)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val s = Ui.text(this, "", 12f, Ui.SUB)
        s.maxLines = 1
        s.ellipsize = TextUtils.TruncateAt.END
        l.addView(t)
        l.addView(s)
        return l
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(dp(12), dp(12), dp(12), dp(8))

        root.addView(Ui.text(this, "ManiaDroid", 26f, Ui.TEXT, true))
        root.addView(Ui.text(this, "Game ritme 4K–10K offline · chart format .osz (mode mania)", 12f, Ui.SUB))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val lp = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) }
        bar.addView(Ui.button(this, "Impor .osz") { pick() }, lp())
        bar.addView(Ui.button(this, "Unduh") { startActivity(Intent(this, DownloadActivity::class.java)) }, lp())
        bar.addView(Ui.button(this, "Pengaturan") { startActivity(Intent(this, SettingsActivity::class.java)) }, lp())
        root.addView(bar)

        empty = Ui.text(
            this,
            "Belum ada chart.\n\nTekan “Impor .osz” untuk memilih file chart dari penyimpanan, atau “Unduh” untuk mencari & mengunduh chart.",
            14f, Ui.SUB
        )
        empty.setPadding(dp(8), dp(24), dp(8), 0)
        root.addView(empty)

        val list = ListView(this)
        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = dp(8)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> openSet(sets[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            confirmDelete(sets[pos])
            true
        }
        val llp = LinearLayout.LayoutParams(-1, 0, 1f)
        llp.topMargin = dp(10)
        root.addView(list, llp)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        Thread {
            val s = Library.scanSets(this)
            runOnUiThread {
                sets = s
                adapter.notifyDataSetChanged()
                empty.visibility = if (s.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    private fun openSet(s: SongSet) {
        val labels = s.maps.map { "${it.keys}K  [${it.version}]  ·  ${it.noteCount} note" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("${s.artist} - ${s.title}")
            .setItems(labels) { _, i ->
                startActivity(Intent(this, GameActivity::class.java).putExtra("osu", s.maps[i].file.path))
            }.show()
    }

    private fun confirmDelete(s: SongSet) {
        AlertDialog.Builder(this)
            .setTitle("Hapus chart?")
            .setMessage("${s.artist} - ${s.title}")
            .setPositiveButton("Hapus") { _, _ ->
                s.dir.deleteRecursively()
                reload()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---- impor .osz ----
    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 1 || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) uris.add(clip.getItemAt(k).uri)
        } else {
            val u = data.data
            if (u != null) uris.add(u)
        }
        Toast.makeText(this, "Mengimpor…", Toast.LENGTH_SHORT).show()
        Thread {
            var ok = 0
            var bad = 0
            for (u in uris) {
                val name = displayName(u) ?: "chart${System.currentTimeMillis()}.osz"
                if (!name.endsWith(".osz", ignoreCase = true)) {
                    bad++
                    continue
                }
                val n = try {
                    Library.importOsz(this, name) { contentResolver.openInputStream(u) }
                } catch (e: Exception) {
                    -1
                }
                if (n > 0) ok++ else bad++
            }
            runOnUiThread {
                Toast.makeText(
                    this,
                    "Impor selesai: $ok berhasil" + (if (bad > 0) ", $bad gagal (bukan .osz mania / rusak)" else ""),
                    Toast.LENGTH_LONG
                ).show()
                reload()
            }
        }.start()
    }

    private fun displayName(u: Uri): String? {
        return try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) c.getString(i) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
