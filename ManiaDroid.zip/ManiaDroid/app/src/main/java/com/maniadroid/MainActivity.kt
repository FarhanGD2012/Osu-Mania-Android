package com.maniadroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Spannable
import android.text.SpannableString
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class MainActivity : Activity() {
    private var sets: List<SongSet> = emptyList()
    private lateinit var empty: TextView
    private lateinit var stats: TextView

    private fun dp(v: Int) = Ui.dp(this, v)

    private class Card(
        val root: FrameLayout,
        val img: ImageView,
        val title: TextView,
        val sub: TextView,
        val chips: TextView
    )

    private val adapter = object : BaseAdapter() {
        override fun getCount() = sets.size
        override fun getItem(position: Int): Any = sets[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val cd = (convertView?.tag as? Card) ?: newCard()
            val s = sets[position]
            cd.title.text = s.title
            cd.sub.text = "${s.artist}  ·  mapper ${s.creator}"
            val keys = s.maps.map { it.keys }.distinct().joinToString(", ") { "${it}K" }
            cd.chips.text = "$keys   ·   ${s.maps.size} tingkat kesulitan"
            val hue = (abs(s.title.hashCode()) % 360).toFloat()
            cd.img.setBackgroundColor(Color.HSVToColor(floatArrayOf(hue, 0.45f, 0.32f)))
            Img.loadCover(s, cd.img)
            return cd.root
        }
    }

    private fun newCard(): Card {
        val root = FrameLayout(this)
        root.background = Ui.rounded(Ui.CARD, dp(18).toFloat())
        root.clipToOutline = true
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(img, FrameLayout.LayoutParams(-1, -1))
        val shade = View(this)
        shade.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xF2101018.toInt(), 0xB3101018.toInt(), 0x40101018.toInt())
        )
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_VERTICAL
        col.setPadding(dp(18), dp(8), dp(18), dp(8))
        val title = Ui.text(this, "", 18f, Ui.TEXT, true)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        val sub = Ui.text(this, "", 13f, 0xFFC9C9DA.toInt())
        sub.maxLines = 1
        sub.ellipsize = TextUtils.TruncateAt.END
        val chips = Ui.text(this, "", 12f, Ui.ACCENT, true)
        chips.setPadding(0, dp(4), 0, 0)
        col.addView(title)
        col.addView(sub)
        col.addView(chips)
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        root.layoutParams = AbsListView.LayoutParams(-1, dp(98))
        val cd = Card(root, img, title, sub, chips)
        root.tag = cd
        return cd
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        Ui.applyOrientation(this)

        val land = resources.displayMetrics.widthPixels > resources.displayMetrics.heightPixels

        val root = LinearLayout(this)
        root.orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        root.background = Ui.bgGradient()
        root.setPadding(dp(18), dp(16), dp(18), dp(12))

        // ---- panel kiri / header ----
        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL

        val logo = SpannableString("ManiaDroid")
        logo.setSpan(ForegroundColorSpan(Ui.ACCENT), 5, logo.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        val logoTv = Ui.text(this, "", 34f, Ui.TEXT, true)
        logoTv.text = logo
        head.addView(logoTv)
        head.addView(Ui.text(this, "Game ritme 4K–10K · offline · format chart .osz", 12f, Ui.SUB))

        stats = Ui.text(this, "", 13f, Ui.TEXT, true)
        stats.setPadding(dp(14), dp(10), dp(14), dp(10))
        stats.background = Ui.rounded(0x33FFFFFF, dp(14).toFloat())
        val sp = LinearLayout.LayoutParams(-2, -2)
        sp.topMargin = dp(14)
        head.addView(stats, sp)

        val bp = {
            val l = LinearLayout.LayoutParams(if (land) -1 else 0, -2, 1f)
            if (land) {
                l.height = -2
                l.weight = 0f
                l.topMargin = dp(12)
            } else {
                l.leftMargin = dp(4)
                l.rightMargin = dp(4)
            }
            l
        }
        val btns = LinearLayout(this)
        btns.orientation = if (land) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        btns.addView(Ui.button(this, "📂  Impor .osz") { pick() }, bp())
        btns.addView(Ui.button(this, "⬇  Unduh chart") { startActivity(Intent(this, DownloadActivity::class.java)) }, bp())
        btns.addView(Ui.button(this, "⚙  Pengaturan", false) { startActivity(Intent(this, SettingsActivity::class.java)) }, bp())
        val bl = LinearLayout.LayoutParams(-1, -2)
        bl.topMargin = dp(14)
        head.addView(btns, bl)

        if (land) {
            val hint = Ui.text(this, "Tekan lama sebuah kartu lagu untuk menghapusnya.", 11f, Ui.SUB)
            hint.setPadding(0, dp(14), 0, 0)
            head.addView(hint)
            val sv = ScrollView(this)
            sv.addView(head)
            root.addView(sv, LinearLayout.LayoutParams(0, -1, 0.38f))
        } else {
            root.addView(head, LinearLayout.LayoutParams(-1, -2))
        }

        // ---- daftar lagu ----
        val right = FrameLayout(this)
        empty = Ui.text(
            this,
            "Belum ada chart.\n\nTekan “Impor .osz” untuk memilih file chart dari penyimpanan, atau “Unduh chart” untuk mencari dan mengunduh.",
            14f, Ui.SUB
        )
        empty.gravity = Gravity.CENTER
        right.addView(empty, FrameLayout.LayoutParams(-1, -1))

        val list = ListView(this)
        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = dp(10)
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.clipToPadding = false
        list.setPadding(0, dp(2), 0, dp(10))
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> showDiffs(sets[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            confirmDelete(sets[pos])
            true
        }
        right.addView(list, FrameLayout.LayoutParams(-1, -1))

        val rp = if (land) LinearLayout.LayoutParams(0, -1, 0.62f) else LinearLayout.LayoutParams(-1, 0, 1f)
        if (land) rp.leftMargin = dp(18) else rp.topMargin = dp(10)
        root.addView(right, rp)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        Thread {
            val s = Library.scanSets(this)
            runOnUiThread {
                sets = s
                adapter.notifyDataSetChanged()
                empty.visibility = if (s.isEmpty()) View.VISIBLE else View.GONE
                val total = s.sumOf { it.maps.size }
                stats.text = "${s.size} lagu  ·  $total chart"
            }
        }.start()
    }

    // ---- pemilih tingkat kesulitan ----
    private fun diffColor(nps: Float): Int = when {
        nps < 3f -> 0xFF4CD08A.toInt()
        nps < 5f -> 0xFF4DA3FF.toInt()
        nps < 7f -> 0xFFFFC94D.toInt()
        nps < 9f -> 0xFFFF8A4D.toInt()
        else -> 0xFFFF4D6A.toInt()
    }

    private fun diffRow(m: Beatmap, onClick: () -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(10), dp(14), dp(10))
        row.background = Ui.ripple(Ui.rounded(Ui.CARD2, dp(14).toFloat()))
        val badge = Ui.text(this, "${m.keys}K", 14f, Color.WHITE, true)
        badge.gravity = Gravity.CENTER
        badge.background = Ui.rounded(diffColor(m.nps), dp(10).toFloat())
        row.addView(badge, LinearLayout.LayoutParams(dp(46), dp(40)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val v = Ui.text(this, m.version, 15f, Ui.TEXT, true)
        v.maxLines = 1
        v.ellipsize = TextUtils.TruncateAt.END
        col.addView(v)
        col.addView(Ui.text(this, String.format("%.1f nps  ·  %d note  ·  OD %.1f", m.nps, m.noteCount, m.od), 12f, Ui.SUB))
        val cp = LinearLayout.LayoutParams(0, -2, 1f)
        cp.leftMargin = dp(12)
        row.addView(col, cp)
        row.addView(Ui.text(this, "▶", 18f, Ui.ACCENT, true))
        row.setOnClickListener { onClick() }
        return row
    }

    private fun showDiffs(s: SongSet) {
        val dlg = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK).create()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(16), dp(16), dp(12))
        val t = Ui.text(this, s.title, 20f, Ui.TEXT, true)
        t.maxLines = 2
        t.ellipsize = TextUtils.TruncateAt.END
        box.addView(t)
        box.addView(Ui.text(this, "${s.artist}  ·  mapper ${s.creator}", 13f, Ui.SUB))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        for (m in s.maps) {
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.topMargin = dp(8)
            list.addView(diffRow(m) {
                dlg.dismiss()
                startActivity(Intent(this, GameActivity::class.java).putExtra("osu", m.file.path))
            }, lp)
        }
        val sv = ScrollView(this)
        sv.addView(list)
        val sp = LinearLayout.LayoutParams(-1, -2)
        sp.topMargin = dp(8)
        box.addView(sv, sp)
        dlg.setView(box)
        dlg.window?.setBackgroundDrawable(Ui.rounded(0xFF171724.toInt(), dp(22).toFloat()))
        dlg.show()
    }

    private fun confirmDelete(s: SongSet) {
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Hapus chart?")
            .setMessage("${s.artist} - ${s.title}")
            .setPositiveButton("Hapus") { _, _ ->
                s.dir.deleteRecursively()
                reload()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---- impor .osz ----
    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 1 || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) uris.add(clip.getItemAt(k).uri)
        } else {
            val u = data.data
            if (u != null) uris.add(u)
        }
        Toast.makeText(this, "Mengimpor…", Toast.LENGTH_SHORT).show()
        Thread {
            var ok = 0
            var bad = 0
            for (u in uris) {
                val name = displayName(u) ?: "chart${System.currentTimeMillis()}.osz"
                if (!name.endsWith(".osz", ignoreCase = true)) {
                    bad++
                    continue
                }
                val n = try {
                    Library.importOsz(this, name) { contentResolver.openInputStream(u) }
                } catch (e: Exception) {
                    -1
                }
                if (n > 0) ok++ else bad++
            }
            runOnUiThread {
                Toast.makeText(
                    this,
                    "Impor selesai: $ok berhasil" + (if (bad > 0) ", $bad gagal (bukan .osz mania / rusak)" else ""),
                    Toast.LENGTH_LONG
                ).show()
                reload()
            }
        }.start()
    }

    private fun displayName(u: Uri): String? {
        return try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) c.getString(i) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
