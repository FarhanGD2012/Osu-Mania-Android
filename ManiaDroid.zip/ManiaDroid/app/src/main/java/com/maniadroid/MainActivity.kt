package com.maniadroid

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.min

/** Menu utama ala osu!lazer: latar segitiga, logo besar di tengah; ketuk logo -> logo mengecil dan jalur tombol muncul. */
class MainActivity : BaseActivity() {
    companion object {
        const val OPEN_SCALE = 0.62f
    }

    private lateinit var backdrop: MenuBackdrop
    private lateinit var logo: LogoView
    private lateinit var strip: FrameLayout
    private lateinit var stripRow: LinearLayout
    private lateinit var spacer: View
    private lateinit var hint: TextView
    private lateinit var banner: LinearLayout
    private lateinit var bannerTitle: TextView
    private lateinit var bar: LinearLayout
    private lateinit var barTitle: TextView
    private lateinit var barLine: ProgressLine
    private lateinit var barPct: TextView
    private lateinit var playIcon: IconView
    private var open = false
    private var logoOpenX = 0f
    private lateinit var rootView: FrameLayout
    private var introView: IntroView? = null
    private var introMp: MediaPlayer? = null
    private var introActive = false
    private var impactDone = false
    private var introSpeed = 1f
    private var ticking = false

    private fun dp(v: Int) = Ui.dp(this, v)

    private val ticker = object : Runnable {
        override fun run() {
            if (!ticking) return
            val f = MenuMusic.progress()
            barLine.frac = f
            barPct.text = String.format(java.util.Locale.US, "%05.2f%%", f * 100.0)
            rootView.postDelayed(this, 120)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        backdrop = MenuBackdrop(this)
        root.addView(backdrop, Ui.matchParams())

        // ---- jalur tombol ala osu!lazer: pita gelap di tengah layar, tombol jajar genjang berwarna ----
        strip = FrameLayout(this)
        strip.visibility = View.GONE
        val band = View(this)
        band.setBackgroundColor(0x8C000000.toInt())
        strip.addView(band, Ui.matchParams())
        // garis tipis di tepi atas & bawah pita supaya lebih tegas
        val lineTop = View(this)
        lineTop.setBackgroundColor(0x24FFFFFF)
        strip.addView(lineTop, FrameLayout.LayoutParams(-1, dp(1), Gravity.TOP))
        val lineBot = View(this)
        lineBot.setBackgroundColor(0x14FFFFFF)
        strip.addView(lineBot, FrameLayout.LayoutParams(-1, dp(1), Gravity.BOTTOM))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(10), dp(8), dp(10), dp(8))
        fun btn(kind: Int, label: String, color: Int, click: () -> Unit) {
            row.addView(MenuButton(this, kind, label, color, click), LinearLayout.LayoutParams(0, -1, 1f))
        }
        btn(IconView.SETTINGS, "Setelan", 0xFF5B5E8F.toInt()) { startActivity(Intent(this, SettingsActivity::class.java)) }
        btn(IconView.SYNC, "Sinkron", 0xFF3F8E8A.toInt()) { startActivity(Intent(this, SyncActivity::class.java)) }
        btn(IconView.IMPORT, "Impor", 0xFF3F7FBF.toInt()) { pick() }
        spacer = View(this)
        row.addView(spacer, LinearLayout.LayoutParams(dp(120), -1))
        btn(IconView.PLAY, "Main", 0xFFFF66AB.toInt()) { startActivity(Intent(this, SongSelectActivity::class.java)) }
        btn(IconView.EDIT, "Editor", 0xFF8A5BE0.toInt()) { startActivity(Intent(this, SongSelectActivity::class.java).putExtra("edit", true)) }
        btn(IconView.DOWNLOAD, "Unduh", 0xFF2E9BD6.toInt()) { startActivity(Intent(this, DownloadActivity::class.java)) }
        btn(IconView.EXIT, "Keluar", 0xFFE0524D.toInt()) { finish() }
        strip.addView(row, Ui.matchParams())
        stripRow = row
        root.addView(strip, FrameLayout.LayoutParams(-1, dp(96), Gravity.CENTER_VERTICAL))

        // LogoView memenuhi layar (ada ruang untuk gelombang cincin); hanya lingkaran logo yang bisa diketuk
        logo = LogoView(this)
        root.addView(logo, Ui.matchParams())

        hint = Ui.text(this, "Ketuk logo untuk mulai", 13f, 0xFF9C9AB4.toInt())
        root.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).also { it.topMargin = dp(20) })

        // ---- bar lagu menu: kecil dan minimalis (kontrol tipis + judul + garis kemajuan) ----
        bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        val barBg = android.graphics.drawable.GradientDrawable()
        barBg.setColor(0x73000000)
        barBg.cornerRadius = dp(18).toFloat()
        barBg.setStroke(dp(1), 0x18FFFFFF)
        bar.background = barBg
        bar.setPadding(dp(6), dp(3), dp(14), dp(7))
        val barRow = LinearLayout(this)
        barRow.orientation = LinearLayout.HORIZONTAL
        barRow.gravity = Gravity.CENTER_VERTICAL
        fun ctl(kind: Int, onClick: () -> Unit): IconView {
            val ic = IconView(this, kind, 0xDDFFFFFF.toInt())
            ic.setPadding(dp(8), dp(8), dp(8), dp(8))
            ic.setOnClickListener { onClick() }
            barRow.addView(ic, LinearLayout.LayoutParams(dp(32), dp(32)))
            return ic
        }
        ctl(IconView.PREV) { MenuMusic.prev(); refreshBar() }
        playIcon = ctl(IconView.PAUSE) { MenuMusic.toggle(this); refreshBar() }
        ctl(IconView.NEXT) { MenuMusic.next(); refreshBar() }
        barTitle = Ui.text(this, "", 11.5f, 0xFFE6E6F0.toInt(), false)
        barTitle.maxLines = 1
        barTitle.ellipsize = TextUtils.TruncateAt.END
        barTitle.maxWidth = dp(190)
        val tp = LinearLayout.LayoutParams(-2, -2)
        tp.leftMargin = dp(4)
        barRow.addView(barTitle, tp)
        barPct = Ui.text(this, "00.00%", 10.5f, 0xFFFF8CC0.toInt(), true)
        val pp = LinearLayout.LayoutParams(-2, -2)
        pp.leftMargin = dp(10)
        barRow.addView(barPct, pp)
        bar.addView(barRow, LinearLayout.LayoutParams(-2, -2))
        barLine = ProgressLine(this)
        val lp2 = LinearLayout.LayoutParams(-1, dp(2))
        lp2.leftMargin = dp(8)
        lp2.topMargin = dp(1)
        bar.addView(barLine, lp2)
        bar.visibility = View.GONE
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = dp(10) })

        // ---- popup ganti lagu ----
        banner = LinearLayout(this)
        banner.orientation = LinearLayout.VERTICAL
        banner.gravity = Gravity.CENTER_HORIZONTAL
        banner.setPadding(dp(22), dp(8), dp(22), dp(9))
        val bnBg = android.graphics.drawable.GradientDrawable()
        bnBg.setColor(0xCC12111C.toInt())
        bnBg.cornerRadius = dp(16).toFloat()
        bnBg.setStroke(dp(1), 0x22FFFFFF)
        banner.background = bnBg
        banner.addView(Ui.text(this, "SEDANG DIPUTAR", 9.5f, Ui.ACCENT, true).also { it.letterSpacing = 0.18f })
        bannerTitle = Ui.text(this, "", 13f, Color.WHITE, true)
        bannerTitle.maxLines = 1
        bannerTitle.ellipsize = TextUtils.TruncateAt.END
        bannerTitle.maxWidth = dp(320)
        banner.addView(bannerTitle)
        banner.alpha = 0f
        root.addView(banner, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).also { it.topMargin = dp(14) })

        val foot = Ui.text(this, "Osu! Mania 1.7 \u00B7 proyek penggemar\nBukan produk resmi osu!", 9.5f, 0xFF77758C.toInt())
        foot.gravity = Gravity.END
        root.addView(foot, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).also {
            it.rightMargin = dp(14)
            it.bottomMargin = dp(8)
        })

        logo.setOnClickListener { toggle() }
        rootView = root
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> positionMenu() }
        setContentView(root)

        // intro ala osu!lazer hanya saat game baru dibuka (bukan saat layar diputar / kembali dari menu lain)
        if (b == null && Settings.introEnabled) startIntro()
    }

    /** Hitung lebar celah logo di jalur tombol dan posisi logo saat menu terbuka. */
    private fun positionMenu() {
        val w = rootView.width
        val h = rootView.height
        if (w <= 0 || h <= 0) return
        val r = min(w, h) * LogoView.BASE * OPEN_SCALE
        val space = (r * 2f * 1.2f).toInt()
        val side = dp(10)
        val bw = (w - 2 * side - space) / 7f
        logoOpenX = side + 3 * bw + space / 2f - w / 2f
        val sp = spacer.layoutParams as LinearLayout.LayoutParams
        if (sp.width != space) {
            sp.width = space
            spacer.layoutParams = sp
        }
        if (open) logo.translationX = logoOpenX
    }

    // ---- intro ----
    private fun startIntro() {
        introActive = true
        impactDone = false
        logo.visibility = View.INVISIBLE
        hint.alpha = 0f
        bar.alpha = 0f
        introSpeed = 1f
        val iv = IntroView(this, onImpact = { onIntroImpact() }, onDone = { onIntroDone() }, onSpeed = { sp -> setIntroSpeed(sp) })
        introView = iv
        rootView.addView(iv, Ui.matchParams())
        Thread {
            val m = IntroSound.prepare(this) // sintesis + prepare di thread latar
            runOnUiThread {
                if (isFinishing || introView !== iv) {
                    try {
                        m?.release()
                    } catch (e: Exception) {
                    }
                    return@runOnUiThread
                }
                introMp = m
                try {
                    m?.setOnCompletionListener { mm ->
                        try {
                            mm.release()
                        } catch (e: Exception) {
                        }
                        if (introMp === mm) introMp = null
                    }
                    m?.start()
                    if (introSpeed > 1f) setIntroSpeed(introSpeed)
                } catch (e: Exception) {
                }
                iv.begin() // visual dimulai bersamaan dengan suara
            }
        }.start()
    }

    /** Suara intro ikut dipercepat bersama visualnya (ketukan layar saat intro). */
    private fun setIntroSpeed(sp: Float) {
        introSpeed = sp
        val m = introMp ?: return
        try {
            if (m.isPlaying) m.playbackParams = m.playbackParams.setSpeed(sp)
        } catch (e: Exception) {
        }
    }

    private fun onIntroImpact() {
        impactDone = true
        MenuMusic.onChange = { t ->
            showBanner(t.title)
            refreshBar()
        }
        MenuMusic.start(this) // musik menu mulai tepat saat logo meletup
        refreshBar()
    }

    private fun onIntroDone() {
        introActive = false
        introView?.let { rootView.removeView(it) }
        introView = null
        logo.visibility = View.VISIBLE
        hint.animate().alpha(1f).setDuration(400).start()
        bar.animate().alpha(1f).setDuration(400).start()
    }

    private fun releaseIntroSound() {
        try {
            introMp?.release()
        } catch (e: Exception) {
        }
        introMp = null
    }

    private fun refreshBar() {
        val t = MenuMusic.current
        bar.visibility = if (MenuMusic.tracks.isEmpty() || !Settings.menuMusic) View.GONE else View.VISIBLE
        barTitle.text = t?.title ?: "…"
        playIcon.kind = if (MenuMusic.isPlaying) IconView.PAUSE else IconView.PLAY
        playIcon.invalidate()
    }

    private fun showBanner(text: String) {
        bannerTitle.text = text
        banner.animate().cancel()
        banner.animate().alpha(1f).setDuration(250).withEndAction {
            banner.postDelayed({ banner.animate().alpha(0f).setDuration(500).start() }, 3200)
        }.start()
    }

    private fun toggle() {
        if (introActive) return
        if (!open) openMenu() else startActivity(Intent(this, SongSelectActivity::class.java))
    }

    /** Tombol keluar dari balik logo satu per satu (yang paling dekat logo duluan). */
    private fun staggerButtons() {
        val dist = dp(54).toFloat()
        for (i in 0 until stripRow.childCount) {
            val c = stripRow.getChildAt(i)
            if (c !is MenuButton) continue
            val left = i < 3
            val order = if (left) 2 - i else i - 4
            c.animate().cancel()
            c.alpha = 0f
            c.translationX = if (left) dist else -dist
            c.animate().alpha(1f).translationX(0f).setStartDelay(30L + order * 38L).setDuration(280)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun openMenu() {
        open = true
        positionMenu()
        staggerButtons()
        hint.visibility = View.GONE
        strip.animate().cancel()
        strip.visibility = View.VISIBLE
        strip.alpha = 0f
        strip.scaleY = 0.25f
        strip.animate().alpha(1f).scaleY(1f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        logo.animate().translationX(logoOpenX).scaleX(OPEN_SCALE).scaleY(OPEN_SCALE).setDuration(300)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun closeMenu() {
        open = false
        hint.visibility = View.VISIBLE
        logo.animate().translationX(0f).scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
        strip.animate().cancel()
        strip.animate().alpha(0f).scaleY(0.25f).setDuration(200).withEndAction { strip.visibility = View.GONE }.start()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (introActive) {
            introView?.skip()
            return
        }
        if (open) closeMenu() else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        backdrop.refresh()
        // musik menu
        Thread {
            BundledSongs.seed(this) // lagu bawaan dipasang sekali (pertama kali / setelah pembaruan)
            MenuMusic.refresh(this)
            runOnUiThread {
                MenuMusic.onChange = { t ->
                    showBanner(t.title)
                    refreshBar()
                }
                if (!introActive || impactDone) MenuMusic.start(this)
                refreshBar()
            }
        }.start()
        ticking = true
        rootView.removeCallbacks(ticker)
        rootView.postDelayed(ticker, 120)
        // jaga-jaga: gambar ulang tombol menu setelah kembali dari layar lain
        strip.invalidate()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseIntroSound()
    }

    override fun onPause() {
        super.onPause()
        ticking = false
        MenuMusic.onChange = null
        MenuMusic.pause()
    }

    // ---- impor .osz ----
    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        @Suppress("DEPRECATION")
        startActivityForResult(i, 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 1 || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) uris.add(clip.getItemAt(k).uri)
        } else {
            val u = data.data
            if (u != null) uris.add(u)
        }
        Toast.makeText(this, "Mengimpor…", Toast.LENGTH_SHORT).show()
        Thread {
            var ok = 0
            var bad = 0
            for (u in uris) {
                val name = Library.displayName(this, u) ?: "chart${System.currentTimeMillis()}.osz"
                if (!name.endsWith(".osz", ignoreCase = true)) {
                    bad++
                    continue
                }
                val n = try {
                    Library.importOsz(this, name) { contentResolver.openInputStream(u) }
                } catch (e: Exception) {
                    -1
                }
                if (n > 0) ok++ else bad++
            }
            runOnUiThread {
                Toast.makeText(
                    this,
                    L.t(
                        "Impor selesai: $ok berhasil" + (if (bad > 0) ", $bad gagal (bukan .osz mania / rusak)" else ""),
                        "Import finished: $ok succeeded" + (if (bad > 0) ", $bad failed (not a mania .osz / corrupt)" else "")
                    ),
                    Toast.LENGTH_LONG
                ).show()
                // daftar musik menu ikut diperbarui
                Thread {
                    MenuMusic.refresh(this)
                    runOnUiThread { refreshBar() }
                }.start()
            }
        }.start()
    }
}
