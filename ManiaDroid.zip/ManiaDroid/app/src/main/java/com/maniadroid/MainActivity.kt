package com.maniadroid

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

/** Menu utama ala osu!lazer: latar hitam, logo besar di tengah, ketuk untuk membuka menu. */
class MainActivity : Activity() {
    private lateinit var logo: LogoView
    private lateinit var panel: LinearLayout
    private lateinit var bgImg: ImageView
    private lateinit var hint: TextView
    private lateinit var banner: TextView
    private lateinit var bar: LinearLayout
    private lateinit var barTitle: TextView
    private lateinit var playIcon: IconView
    private var open = false
    private lateinit var rootView: FrameLayout
    private var introView: IntroView? = null
    private var introMp: MediaPlayer? = null
    private var introActive = false
    private var impactDone = false

    private fun dp(v: Int) = Ui.dp(this, v)

    /** Ubin menu: ikon di atas, label di bawah. big = ubin utama "Main". */
    private fun tile(kind: Int, label: String, tint: Int, big: Boolean, onClick: () -> Unit): View {
        val t = LinearLayout(this)
        t.orientation = if (big) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(8), dp(8), dp(8))
        t.background = Ui.ripple(Ui.rounded(if (big) Ui.ACCENT else 0x2EFFFFFF, dp(20).toFloat()))
        val icon = IconView(this, kind, if (big) Color.WHITE else tint)
        t.addView(icon, LinearLayout.LayoutParams(dp(if (big) 34 else 32), dp(if (big) 34 else 32)))
        val txt = Ui.text(this, label, if (big) 19f else 12f, Color.WHITE, true)
        txt.gravity = Gravity.CENTER
        val lp = LinearLayout.LayoutParams(-2, -2)
        if (big) lp.leftMargin = dp(12) else lp.topMargin = dp(4)
        t.addView(txt, lp)
        t.setOnClickListener { onClick() }
        return t
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        val dm = resources.displayMetrics

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK) // latar awal: hitam polos
        bgImg = ImageView(this)
        bgImg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bgImg, Ui.matchParams())
        val dim = View(this)
        dim.setBackgroundColor(0x99000000.toInt())
        root.addView(dim, Ui.matchParams())

        // LogoView memenuhi layar (ada ruang untuk gelombang cincin); hanya lingkaran logo yang bisa diketuk
        logo = LogoView(this)
        root.addView(logo, Ui.matchParams())

        // ---- panel ubin menu (menyatu dengan latar, tanpa emoji) ----
        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.visibility = View.GONE
        val bigRow = LinearLayout(this)
        bigRow.addView(
            tile(IconView.PLAY, "Main", Color.WHITE, true) { startActivity(Intent(this, SongSelectActivity::class.java)) },
            LinearLayout.LayoutParams(0, dp(70), 1f)
        )
        panel.addView(bigRow, LinearLayout.LayoutParams(-1, -2))
        fun row(vararg v: View) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for ((i, x) in v.withIndex()) {
                val lp = LinearLayout.LayoutParams(0, dp(78), 1f)
                if (i > 0) lp.leftMargin = dp(8)
                r.addView(x, lp)
            }
            val rp = LinearLayout.LayoutParams(-1, -2)
            rp.topMargin = dp(8)
            panel.addView(r, rp)
        }
        row(
            tile(IconView.EDIT, "Editor", 0xFF8FE3A3.toInt(), false) { startActivity(Intent(this, SongSelectActivity::class.java).putExtra("edit", true)) },
            tile(IconView.SYNC, "Sinkron", 0xFFFFD84D.toInt(), false) { startActivity(Intent(this, SyncActivity::class.java)) },
            tile(IconView.IMPORT, "Impor", 0xFF9FC8FF.toInt(), false) { pick() }
        )
        row(
            tile(IconView.DOWNLOAD, "Unduh", 0xFF6FD6FF.toInt(), false) { startActivity(Intent(this, DownloadActivity::class.java)) },
            tile(IconView.SETTINGS, "Setelan", 0xFFD0D0E0.toInt(), false) { startActivity(Intent(this, SettingsActivity::class.java)) },
            tile(IconView.EXIT, "Keluar", 0xFFFF7A7A.toInt(), false) { finish() }
        )
        val pp = FrameLayout.LayoutParams(dp(330), -2, Gravity.CENTER_VERTICAL or Gravity.END)
        pp.rightMargin = dp(36)
        root.addView(panel, pp)

        hint = Ui.text(this, "Ketuk logo untuk mulai", 14f, Ui.SUB)
        root.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = dp(58) })

        // ---- bar "sedang diputar" + popup ganti lagu ----
        bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(6), dp(4), dp(16), dp(4))
        bar.background = Ui.rounded(0x55FFFFFF, dp(24).toFloat())
        fun ctl(kind: Int, onClick: () -> Unit): IconView {
            val ic = IconView(this, kind)
            ic.setPadding(dp(9), dp(9), dp(9), dp(9))
            ic.setOnClickListener { onClick() }
            bar.addView(ic, LinearLayout.LayoutParams(dp(42), dp(42)))
            return ic
        }
        ctl(IconView.PREV) { MenuMusic.prev(); refreshBar() }
        playIcon = ctl(IconView.PAUSE) { MenuMusic.toggle(this); refreshBar() }
        ctl(IconView.NEXT) { MenuMusic.next(); refreshBar() }
        barTitle = Ui.text(this, "", 12f, Color.WHITE, true)
        barTitle.maxLines = 1
        barTitle.ellipsize = TextUtils.TruncateAt.END
        barTitle.maxWidth = dp(260)
        val tp = LinearLayout.LayoutParams(-2, -2)
        tp.leftMargin = dp(6)
        bar.addView(barTitle, tp)
        bar.visibility = View.GONE
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = dp(10) })

        banner = Ui.text(this, "", 14f, Color.WHITE, true)
        banner.setPadding(dp(20), dp(10), dp(20), dp(10))
        banner.background = Ui.rounded(0xE61B1B2A.toInt(), dp(22).toFloat())
        banner.alpha = 0f
        root.addView(banner, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).also { it.topMargin = dp(18) })

        val foot = Ui.text(this, "Osu Mania 1.4 · proyek penggemar, bukan produk resmi osu!", 10f, Ui.SUB)
        root.addView(foot, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).also {
            it.leftMargin = dp(14)
            it.bottomMargin = dp(8)
        })

        logo.setOnClickListener { toggle() }
        rootView = root
        setContentView(root)

        // intro ala osu!lazer hanya saat game baru dibuka (bukan saat layar diputar / kembali dari menu lain)
        if (b == null && Settings.introEnabled) startIntro()
    }

    // ---- intro ----
    private fun startIntro() {
        introActive = true
        impactDone = false
        logo.visibility = View.INVISIBLE
        hint.alpha = 0f
        bar.alpha = 0f
        val iv = IntroView(this, onImpact = { onIntroImpact() }, onDone = { onIntroDone() })
        introView = iv
        rootView.addView(iv, Ui.matchParams())
        Thread {
            val m = IntroSound.prepare(this) // sintesis + prepare di thread latar
            runOnUiThread {
                if (isFinishing || introView !== iv) {
                    try {
                        m?.release()
                    } catch (e: Exception) {
                    }
                    return@runOnUiThread
                }
                introMp = m
                try {
                    m?.setOnCompletionListener { mm ->
                        try {
                            mm.release()
                        } catch (e: Exception) {
                        }
                        if (introMp === mm) introMp = null
                    }
                    m?.start()
                } catch (e: Exception) {
                }
                iv.begin() // visual dimulai bersamaan dengan suara
            }
        }.start()
    }

    private fun onIntroImpact() {
        impactDone = true
        MenuMusic.onChange = { t ->
            showBanner(t.title)
            refreshBar()
        }
        MenuMusic.start(this) // musik menu mulai tepat saat logo meletup
        refreshBar()
    }

    private fun onIntroDone() {
        introActive = false
        introView?.let { rootView.removeView(it) }
        introView = null
        logo.visibility = View.VISIBLE
        hint.animate().alpha(1f).setDuration(400).start()
        bar.animate().alpha(1f).setDuration(400).start()
    }

    private fun releaseIntroSound() {
        try {
            introMp?.release()
        } catch (e: Exception) {
        }
        introMp = null
    }

    private fun refreshBar() {
        val t = MenuMusic.current
        bar.visibility = if (MenuMusic.tracks.isEmpty() || !Settings.menuMusic) View.GONE else View.VISIBLE
        barTitle.text = t?.title ?: "…"
        playIcon.kind = if (MenuMusic.isPlaying) IconView.PAUSE else IconView.PLAY
        playIcon.invalidate()
    }

    private fun showBanner(text: String) {
        banner.text = "♪   $text"
        banner.animate().cancel()
        banner.animate().alpha(1f).setDuration(250).withEndAction {
            banner.postDelayed({ banner.animate().alpha(0f).setDuration(500).start() }, 3200)
        }.start()
    }

    private fun toggle() {
        if (introActive) return
        if (!open) {
            open = true
            hint.visibility = View.GONE
            logo.animate().translationX(-resources.displayMetrics.widthPixels * 0.2f).setDuration(300).start()
            panel.visibility = View.VISIBLE
            panel.alpha = 0f
            panel.translationX = dp(60).toFloat()
            panel.animate().alpha(1f).translationX(0f).setDuration(300).start()
        } else {
            startActivity(Intent(this, SongSelectActivity::class.java))
        }
    }

    private fun closeMenu() {
        open = false
        hint.visibility = View.VISIBLE
        logo.animate().translationX(0f).setDuration(250).start()
        panel.animate().alpha(0f).setDuration(200).withEndAction { panel.visibility = View.GONE }.start()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (introActive) {
            introView?.skip()
            return
        }
        if (open) closeMenu() else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        // gambar background pilihan pengguna (jika ada); kalau tidak, tetap hitam
        val custom = Library.customBg(this)
        if (custom != null) {
            Thread {
                val bmp = Img.decodeSampled(custom.path, 1280)
                runOnUiThread { bgImg.setImageBitmap(bmp) }
            }.start()
        } else {
            bgImg.setImageDrawable(null)
        }
        // musik menu
        Thread {
            MenuMusic.refresh(this)
            runOnUiThread {
                MenuMusic.onChange = { t ->
                    showBanner(t.title)
                    refreshBar()
                }
                if (!introActive || impactDone) MenuMusic.start(this)
                refreshBar()
            }
        }.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseIntroSound()
    }

    override fun onPause() {
        super.onPause()
        MenuMusic.onChange = null
        MenuMusic.pause()
    }

    // ---- impor .osz ----
    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        @Suppress("DEPRECATION")
        startActivityForResult(i, 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 1 || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) uris.add(clip.getItemAt(k).uri)
        } else {
            val u = data.data
            if (u != null) uris.add(u)
        }
        Toast.makeText(this, "Mengimpor…", Toast.LENGTH_SHORT).show()
        Thread {
            var ok = 0
            var bad = 0
            for (u in uris) {
                val name = Library.displayName(this, u) ?: "chart${System.currentTimeMillis()}.osz"
                if (!name.endsWith(".osz", ignoreCase = true)) {
                    bad++
                    continue
                }
                val n = try {
                    Library.importOsz(this, name) { contentResolver.openInputStream(u) }
                } catch (e: Exception) {
                    -1
                }
                if (n > 0) ok++ else bad++
            }
            runOnUiThread {
                Toast.makeText(
                    this,
                    "Impor selesai: $ok berhasil" + (if (bad > 0) ", $bad gagal (bukan .osz mania / rusak)" else ""),
                    Toast.LENGTH_LONG
                ).show()
                // daftar musik menu ikut diperbarui
                Thread {
                    MenuMusic.refresh(this)
                    runOnUiThread { refreshBar() }
                }.start()
            }
        }.start()
    }
}
