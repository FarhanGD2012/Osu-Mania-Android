package com.maniadroid

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

/** Menu utama ala osu!lazer: logo besar di tengah, ketuk untuk membuka menu. */
class MainActivity : Activity() {
    private lateinit var logo: LogoView
    private lateinit var panel: LinearLayout
    private lateinit var bgImg: ImageView
    private lateinit var hint: TextView
    private var open = false

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        val dm = resources.displayMetrics

        val root = FrameLayout(this)
        root.background = Ui.bgGradient()
        bgImg = ImageView(this)
        bgImg.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(bgImg, Ui.matchParams())
        val dim = View(this)
        dim.setBackgroundColor(0xB30B0B16.toInt())
        root.addView(dim, Ui.matchParams())

        val sz = (min(dm.widthPixels, dm.heightPixels) * 0.66f).toInt()
        logo = LogoView(this)
        root.addView(logo, FrameLayout.LayoutParams(sz, sz, Gravity.CENTER))

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.visibility = View.GONE
        fun row(vararg v: View): LinearLayout {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for ((i, x) in v.withIndex()) {
                val lp = LinearLayout.LayoutParams(0, -2, 1f)
                if (i > 0) lp.leftMargin = dp(8)
                r.addView(x, lp)
            }
            val rp = LinearLayout.LayoutParams(-1, -2)
            rp.topMargin = dp(8)
            panel.addView(r, rp)
            return r
        }
        row(Ui.button(this, "▶  Main") { startActivity(Intent(this, SongSelectActivity::class.java)) })
        row(
            Ui.button(this, "✎ Editor", false) { startActivity(Intent(this, SongSelectActivity::class.java).putExtra("edit", true)) },
            Ui.button(this, "⏱ Sinkron", false) { startActivity(Intent(this, SyncActivity::class.java)) }
        )
        row(
            Ui.button(this, "📂 Impor", false) { pick() },
            Ui.button(this, "⬇ Unduh", false) { startActivity(Intent(this, DownloadActivity::class.java)) }
        )
        row(
            Ui.button(this, "⚙ Setelan", false) { startActivity(Intent(this, SettingsActivity::class.java)) },
            Ui.button(this, "✕ Keluar", false) { finish() }
        )
        val pp = FrameLayout.LayoutParams(dp(320), -2, Gravity.CENTER_VERTICAL or Gravity.END)
        pp.rightMargin = dp(40)
        root.addView(panel, pp)

        hint = Ui.text(this, "Ketuk logo untuk mulai", 14f, Ui.SUB)
        root.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = dp(18) })
        val foot = Ui.text(this, "Osu Mania 1.2 · proyek penggemar, bukan produk resmi osu!", 10f, Ui.SUB)
        root.addView(foot, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).also {
            it.leftMargin = dp(14)
            it.bottomMargin = dp(8)
        })

        logo.setOnClickListener { toggle() }
        setContentView(root)
    }

    private fun toggle() {
        if (!open) {
            open = true
            hint.visibility = View.GONE
            logo.animate().translationX(-resources.displayMetrics.widthPixels * 0.2f).setDuration(300).start()
            panel.visibility = View.VISIBLE
            panel.alpha = 0f
            panel.translationX = dp(60).toFloat()
            panel.animate().alpha(1f).translationX(0f).setDuration(300).start()
        } else {
            startActivity(Intent(this, SongSelectActivity::class.java))
        }
    }

    private fun closeMenu() {
        open = false
        hint.visibility = View.VISIBLE
        logo.animate().translationX(0f).setDuration(250).start()
        panel.animate().alpha(0f).setDuration(200).withEndAction { panel.visibility = View.GONE }.start()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (open) closeMenu() else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        Thread {
            val sets = Library.scanSets(this)
            val withBg = sets.filter { it.maps.first().bg != null }
            if (withBg.isNotEmpty()) {
                val s = withBg.random()
                val m = s.maps.first()
                val f = Library.findFile(m.dir, m.bg!!)
                val bmp = if (f != null) Img.decodeSampled(f.path, 1280) else null
                if (bmp != null) runOnUiThread { bgImg.setImageBitmap(bmp) }
            }
        }.start()
    }

    // ---- impor .osz ----
    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 1 || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (k in 0 until clip.itemCount) uris.add(clip.getItemAt(k).uri)
        } else {
            val u = data.data
            if (u != null) uris.add(u)
        }
        Toast.makeText(this, "Mengimpor…", Toast.LENGTH_SHORT).show()
        Thread {
            var ok = 0
            var bad = 0
            for (u in uris) {
                val name = displayName(u) ?: "chart${System.currentTimeMillis()}.osz"
                if (!name.endsWith(".osz", ignoreCase = true)) {
                    bad++
                    continue
                }
                val n = try {
                    Library.importOsz(this, name) { contentResolver.openInputStream(u) }
                } catch (e: Exception) {
                    -1
                }
                if (n > 0) ok++ else bad++
            }
            runOnUiThread {
                Toast.makeText(
                    this,
                    "Impor selesai: $ok berhasil" + (if (bad > 0) ", $bad gagal (bukan .osz mania / rusak)" else ""),
                    Toast.LENGTH_LONG
                ).show()
            }
        }.start()
    }

    private fun displayName(u: Uri): String? {
        return try {
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) c.getString(i) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
