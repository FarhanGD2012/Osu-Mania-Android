package com.maniadroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

object Net {
    fun open(url: String, accept: String? = null, connectMs: Int = 15000, readMs: Int = 30000): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = connectMs
        c.readTimeout = readMs
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "ManiaDroid/1.1 (Android; offline osu!mania player)")
        if (accept != null) c.setRequestProperty("Accept", accept)
        return c
    }
}

object Img {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(3)

    fun decodeSampled(path: String, reqW: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= reqW) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return BitmapFactory.decodeFile(path, o2)
    }

    /** Gambar dari internet (thumbnail hasil pencarian). */
    fun load(url: String, iv: ImageView) {
        iv.tag = url
        val hit = cache.get(url)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        pool.execute {
            try {
                val c = Net.open(url)
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }
                if (bmp != null) {
                    cache.put(url, bmp)
                    iv.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
                }
            } catch (e: Exception) {
            }
        }
    }

    /** Cover lagu dari gambar background chart yang sudah terpasang (offline). */
    fun loadCover(s: SongSet, iv: ImageView) {
        val key = s.dir.path
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        pool.execute {
            try {
                val m = s.maps.first()
                val name = m.bg
                val f = if (name != null) Library.findFile(m.dir, name) else null
                val bmp = if (f != null) decodeSampled(f.path, 480) else null
                if (bmp != null) {
                    cache.put(key, bmp)
                    iv.post { if (iv.tag == key) iv.setImageBitmap(bmp) }
                }
            } catch (e: Throwable) {
            }
        }
    }
}

object Downloader {
    /** Satu tingkat kesulitan (diff) mania dalam sebuah set, dari data pencarian. */
    class Diff(
        val id: Int,
        val version: String,
        val keys: Int,
        val stars: Float,
        val notes: Int,
        val bpm: Float,
        val length: Int,
        val od: Float,
        val hp: Float
    )

    class Remote(
        val id: Int,
        val title: String,
        val artist: String,
        val creator: String,
        val status: String,
        val info: String,
        val stars: List<Float> = emptyList(),
        val keyCounts: List<Int> = emptyList(),
        val plays: Int = 0,
        val favs: Int = 0,
        val rankedAt: Long = 0L,
        val diffs: List<Diff> = emptyList()
    )

    // ---- filter hasil pencarian (dikerjakan di HP, karena mirror berbeda-beda parameternya) ----
    val DIFF_NAMES = arrayOf("Semua", "Easy", "Normal", "Hard", "Insane", "Expert")
    val KEY_VALUES = intArrayOf(0, 4, 5, 6, 7, 8)
    val KEY_NAMES = arrayOf("Semua", "4K", "5K", "6K", "7K", "8K+")
    val STATUS_NAMES = arrayOf("Semua", "Ranked", "Loved")

    /** Urutan hasil: dikirim ke mirror sebagai parameter sort DAN diurutkan lagi di HP (jaga-jaga mirror mengabaikannya). */
    val SORT_NAMES = arrayOf("Relevansi", "Paling banyak dimainkan", "Paling banyak di-like", "Terbaru", "Rating tertinggi")
    private val SORT_TOKENS = arrayOf("", "plays_desc", "favourites_desc", "ranked_desc", "rating_desc")

    /** Periode: hanya set yang di-ranked / diperbarui dalam rentang ini (dipadukan dengan urutan di atas). */
    val PERIOD_NAMES = arrayOf("Semua waktu", "Hari ini", "Minggu ini", "Bulan ini", "Tahun ini")
    private val PERIOD_SECONDS = longArrayOf(0L, 86400L, 7 * 86400L, 30 * 86400L, 365 * 86400L)

    class Filter(
        var artist: String = "",
        var diff: Int = 0,
        var keyIdx: Int = 0,
        var status: Int = 0,
        var sort: Int = 0,
        var period: Int = 0
    ) {
        val active: Boolean get() = artist.isNotBlank() || diff != 0 || keyIdx != 0 || status != 0 || period != 0
    }

    private fun inDiff(star: Float, d: Int): Boolean = when (d) {
        1 -> star < 2.0f
        2 -> star >= 2.0f && star < 2.7f
        3 -> star >= 2.7f && star < 4.0f
        4 -> star >= 4.0f && star < 5.3f
        5 -> star >= 5.3f
        else -> true
    }

    fun matches(r: Remote, f: Filter): Boolean {
        if (f.artist.isNotBlank() && !r.artist.lowercase().contains(f.artist.trim().lowercase())) return false
        val st = r.status.lowercase()
        if (f.status == 1 && st.isNotEmpty() && st != "ranked" && st != "approved") return false
        if (f.status == 2 && st.isNotEmpty() && st != "loved") return false
        if (f.period in 1 until PERIOD_SECONDS.size && r.rankedAt > 0L) {
            val cutoff = System.currentTimeMillis() - PERIOD_SECONDS[f.period] * 1000L
            if (r.rankedAt < cutoff) return false
        }
        val key = KEY_VALUES[f.keyIdx]
        if (f.diff == 0 && key == 0) return true
        if (r.stars.isEmpty()) return true
        for (i in r.stars.indices) {
            val k = r.keyCounts.getOrNull(i) ?: 0
            val keyOk = key == 0 || (if (key >= 8) k >= 8 else k == key)
            val star = r.stars[i]
            if (keyOk && (f.diff == 0 || star <= 0f || inDiff(star, f.diff))) return true
        }
        return false
    }

    /** Urutkan daftar di HP menurut pilihan (stabil: yang sama tetap pada urutan semula). */
    fun sortLocal(list: MutableList<Remote>, sort: Int) {
        when (sort) {
            1 -> list.sortByDescending { it.plays }
            2 -> list.sortByDescending { it.favs }
            3 -> list.sortByDescending { it.rankedAt }
            4 -> list.sortByDescending { it.stars.maxOrNull() ?: 0f }
        }
    }

    /** True jika periode dipilih: hasil diambil menurut tanggal terbaru lalu disaring dan diurutkan di HP. */
    fun periodSeconds(period: Int): Long = PERIOD_SECONDS.getOrElse(period) { 0L }

    class Mirror(
        val name: String,
        val searchUrl: ((String, Int, String) -> String)?,
        val downloadUrl: (Int, Boolean) -> String
    )

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
    private fun sortQ(sort: String): String = if (sort.isEmpty()) "" else "&sort=$sort"

    // Urutan bawaan (Okt 2026): Nerinyan sedang bermasalah, jadi ditaruh paling akhir.
    val mirrors: List<Mirror> = listOf(
        Mirror(
            "osu.direct",
            { q, p, so -> "https://osu.direct/api/v2/search?query=${enc(q)}&mode=3&amount=20&offset=${p * 20}" + sortQ(so) },
            { id, nv -> "https://osu.direct/api/d/$id" + (if (nv) "?noVideo=1" else "") }
        ),
        Mirror(
            "Catboy",
            { q, p, so -> "https://catboy.best/api/v2/search?q=${enc(q)}&query=${enc(q)}&mode=3&limit=20&offset=${p * 20}" + sortQ(so) },
            { id, nv -> "https://catboy.best/d/$id" + (if (nv) "n" else "") }
        ),
        Mirror(
            "Hinamizawa",
            null,
            { id, nv -> "https://mirror.hinamizawa.ai/api/v1/hinai/d/$id" + (if (nv) "?noVideo=1" else "") }
        ),
        Mirror(
            "Sayobot",
            null,
            { id, nv -> "https://txy1.sayobot.cn/beatmaps/download/" + (if (nv) "novideo" else "full") + "/$id" }
        ),
        Mirror(
            "Nerinyan",
            { q, p, so -> "https://api.nerinyan.moe/search?q=${enc(q)}&m=3&ps=20&p=$p" + sortQ(so) },
            { id, nv -> "https://api.nerinyan.moe/d/$id" + (if (nv) "?nv=1" else "") }
        )
    )

    val names: Array<String> = (listOf("Otomatis") + mirrors.map { it.name }).toTypedArray()

    private fun now() = System.currentTimeMillis()

    private fun recentlyFailed(m: Mirror): Boolean = now() - Settings.sp.getLong("dl_fail_${m.name}", 0L) < 10 * 60 * 1000L

    /**
     * Urutan mirror. Pilihan pengguna dulu; jika "Otomatis" dan [Settings.dlFastMirror] aktif, mirror yang terakhir
     * berhasil dicoba paling awal dan mirror yang baru gagal (10 menit terakhir) dipindah ke belakang.
     */
    private fun ordered(forDownload: Boolean = false): List<Mirror> {
        val sel = Settings.mirror - 1
        if (sel in mirrors.indices) {
            val out = ArrayList<Mirror>()
            out.add(mirrors[sel])
            for (i in mirrors.indices) if (i != sel) out.add(mirrors[i])
            return out
        }
        if (!Settings.dlFastMirror || !Settings.ready) return mirrors
        val key = if (forDownload) "dl_ok_d" else "dl_ok_s"
        val best = Settings.sp.getString(key, "") ?: ""
        val good = ArrayList<Mirror>()
        val bad = ArrayList<Mirror>()
        for (m in mirrors) if (recentlyFailed(m)) bad.add(m) else good.add(m)
        val first = good.firstOrNull { it.name == best }
        if (first != null) {
            good.remove(first)
            good.add(0, first)
        }
        return good + bad
    }

    private fun markOk(m: Mirror, forDownload: Boolean) {
        if (!Settings.ready) return
        Settings.sp.edit().putString(if (forDownload) "dl_ok_d" else "dl_ok_s", m.name).remove("dl_fail_${m.name}").apply()
    }

    private fun markFail(m: Mirror) {
        if (!Settings.ready) return
        Settings.sp.edit().putLong("dl_fail_${m.name}", now()).apply()
    }

    var lastSearchMirror = ""

    private fun parseDate(o: JSONObject, key: String): Long {
        val v = o.opt(key) ?: return 0L
        if (v is Number) {
            val n = v.toLong()
            return if (n > 100_000_000_000L) n else n * 1000L
        }
        val s = v.toString()
        if (s.length < 19) return 0L
        return try {
            val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
            f.timeZone = java.util.TimeZone.getTimeZone("UTC")
            f.parse(s.substring(0, 19))?.time ?: 0L
        } catch (e: Exception) {
            0L
        }
    }

    private fun parseSearch(body: String): List<Remote> {
        val t = body.trim()
        val arr: JSONArray = if (t.startsWith("[")) {
            JSONArray(t)
        } else {
            val o = JSONObject(t)
            o.optJSONArray("beatmapsets") ?: o.optJSONArray("data") ?: o.optJSONArray("results")
                ?: o.optJSONArray("sets") ?: JSONArray()
        }
        val out = ArrayList<Remote>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            var id = o.optInt("id")
            if (id == 0) id = o.optInt("beatmapset_id")
            if (id == 0) id = o.optInt("SetID")
            if (id == 0) continue
            val bms = o.optJSONArray("beatmaps") ?: o.optJSONArray("ChildrenBeatmaps")
            val ks = sortedSetOf<Int>()
            val starList = ArrayList<Float>()
            val keyList = ArrayList<Int>()
            val diffList = ArrayList<Diff>()
            var hasOther = false
            if (bms != null) {
                for (j in 0 until bms.length()) {
                    val b = bms.optJSONObject(j) ?: continue
                    val mode = b.optInt("mode_int", b.optInt("Mode", 3))
                    if (mode == 3) {
                        val cs = b.optDouble("cs", b.optDouble("CS", 0.0)).toInt()
                        if (cs > 0) ks.add(cs)
                        val sr = b.optDouble("difficulty_rating", b.optDouble("DifficultyRating", 0.0)).toFloat()
                        starList.add(sr)
                        keyList.add(cs)
                        var bid = b.optInt("id")
                        if (bid == 0) bid = b.optInt("BeatmapID")
                        diffList.add(
                            Diff(
                                bid,
                                b.optString("version", b.optString("DiffName")),
                                cs,
                                sr,
                                b.optInt("count_circles") + b.optInt("count_sliders"),
                                b.optDouble("bpm", b.optDouble("BPM", 0.0)).toFloat(),
                                b.optInt("total_length", b.optInt("hit_length", b.optInt("TotalLength"))),
                                b.optDouble("accuracy", b.optDouble("OD", 0.0)).toFloat(),
                                b.optDouble("drain", b.optDouble("HP", 0.0)).toFloat()
                            )
                        )
                    } else hasOther = true
                }
            }
            if (ks.isEmpty() && hasOther) continue // set tanpa chart mania
            val creator = o.optString("creator", o.optString("Creator"))
            val known = starList.filter { it > 0f }
            val starText = if (known.isEmpty()) "" else
                String.format(java.util.Locale.US, "SR %.1f–%.1f · ", known.min(), known.max())
            val keysText = (if (ks.isEmpty()) "" else ks.joinToString(", ") { "${it}K" } + " · ") + starText
            var rankedAt = parseDate(o, "ranked_date")
            if (rankedAt == 0L) rankedAt = parseDate(o, "last_updated")
            if (rankedAt == 0L) rankedAt = parseDate(o, "ApprovedDate")
            out.add(
                Remote(
                    id,
                    o.optString("title", o.optString("Title")),
                    o.optString("artist", o.optString("Artist")),
                    creator,
                    o.optString("status"),
                    keysText + "oleh " + creator,
                    starList,
                    keyList,
                    o.optInt("play_count", o.optInt("PlayCount")),
                    o.optInt("favourite_count", o.optInt("FavouriteCount")),
                    rankedAt,
                    diffList
                )
            )
        }
        return out
    }

    /** Cari chart mania. Mencoba mirror satu per satu sampai ada yang menjawab. [sort] = indeks di [SORT_NAMES]. */
    fun search(q: String, page: Int, sort: Int = 0): List<Remote> {
        val errs = ArrayList<String>()
        val token = SORT_TOKENS.getOrElse(sort) { "" }
        for (m in ordered(false)) {
            val su = m.searchUrl ?: continue
            val c = Net.open(su(q, page, token), "application/json", 9000, 20000)
            try {
                if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
                val r = parseSearch(c.inputStream.bufferedReader().use { it.readText() })
                if (r.isEmpty() && q.isEmpty() && page == 0) throw IOException("hasil kosong")
                lastSearchMirror = m.name
                markOk(m, false)
                return r
            } catch (e: Exception) {
                markFail(m)
                errs.add("${m.name}: ${e.message}")
            } finally {
                c.disconnect()
            }
        }
        throw IOException(errs.joinToString("; "))
    }

    // ---------- preview (cuplikan lagu + file .osu satu diff untuk menampilkan note) ----------
    fun previewAudioUrls(setId: Int): List<String> = listOf(
        "https://b.ppy.sh/preview/$setId.mp3",
        "https://catboy.best/preview/audio/$setId?set=1"
    )

    /** Ambil teks file .osu satu diff (untuk pratinjau note tanpa mengunduh seluruh set). Null jika semua sumber gagal. */
    fun fetchOsu(beatmapId: Int, cache: File): File? {
        val f = File(cache, "pv_$beatmapId.osu")
        if (f.isFile && f.length() > 200) return f
        val urls = listOf("https://osu.ppy.sh/osu/$beatmapId", "https://catboy.best/osu/$beatmapId")
        for (u in urls) {
            val c = try {
                Net.open(u, "*/*", 8000, 15000)
            } catch (e: Exception) {
                continue
            }
            try {
                if (c.responseCode != 200) continue
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                if (!txt.contains("[HitObjects]")) continue
                f.writeText(txt, Charsets.UTF_8)
                return f
            } catch (e: Exception) {
            } finally {
                c.disconnect()
            }
        }
        return null
    }

    private class NoMania : IOException("Set ini tidak berisi chart mania")

    private fun checkZip(f: File) {
        val b = ByteArray(4)
        val n = FileInputStream(f).use { it.read(b) }
        // harus file zip ("PK"); beberapa mirror membalas 200 berisi JSON error
        if (n < 4 || b[0] != 0x50.toByte() || b[1] != 0x4B.toByte()) throw IOException("balasan bukan file .osz")
    }

    private fun pctText(got: Long, total: Long): String =
        if (total > 0) String.format(java.util.Locale.US, "%05.2f%%", got * 100.0 / total)
        else String.format(java.util.Locale.US, "%.2f MB", got / 1048576.0)

    /** Unduh satu potongan dari byte from sampai to (inklusif) dengan Range; otomatis lanjut dari titik terputus (maks 4 percobaan). */
    private fun segment(url: String, tmp: File, from: Long, to: Long, onBytes: (Int) -> Unit) {
        var pos = from
        var attempt = 0
        while (pos <= to) {
            val c = Net.open(url, "*/*", 10000, 20000)
            c.setRequestProperty("Accept-Encoding", "identity")
            c.setRequestProperty("Range", "bytes=$pos-$to")
            try {
                val code = c.responseCode
                if (code != 206) throw IOException("HTTP $code (range)")
                RandomAccessFile(tmp, "rw").use { raf ->
                    raf.seek(pos)
                    c.inputStream.use { ins ->
                        val buf = ByteArray(65536)
                        while (pos <= to) {
                            val want = minOf(buf.size.toLong(), to - pos + 1).toInt()
                            val r = ins.read(buf, 0, want)
                            if (r < 0) break
                            raf.write(buf, 0, r)
                            pos += r
                            onBytes(r)
                        }
                    }
                }
                if (pos <= to) throw IOException("koneksi terputus")
            } catch (e: IOException) {
                if (++attempt > 4) throw e
                try {
                    Thread.sleep(300L * attempt)
                } catch (ie: InterruptedException) {
                    throw e
                }
            } finally {
                c.disconnect()
            }
        }
    }

    /**
     * Unduh dengan beberapa koneksi paralel (jika server mendukung Range dan file cukup besar). Kualitas file sama persis
     * (bukan kompresi lagi) — hanya diunduh per potongan lalu disambung. Jika Range tidak didukung: satu koneksi, dengan
     * lanjut otomatis dari titik terputus bila memungkinkan.
     */
    private fun fetchTo(url: String, tmp: File, connections: Int, progress: (String) -> Unit) {
        val conn = Net.open(url, "*/*", 10000, 20000)
        conn.setRequestProperty("Accept-Encoding", "identity")
        try {
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            val ranges = (conn.getHeaderField("Accept-Ranges") ?: "").contains("bytes", ignoreCase = true)
            val got = AtomicLong(0)
            val lastEmit = AtomicLong(0)
            val onBytes: (Int) -> Unit = { k ->
                val g = got.addAndGet(k.toLong())
                val nowMs = android.os.SystemClock.uptimeMillis()
                val le = lastEmit.get()
                // dibatasi ~10x per detik supaya layar tidak kewalahan
                if (nowMs - le >= 100 && lastEmit.compareAndSet(le, nowMs)) progress(pctText(g, total))
            }
            val n = connections.coerceIn(1, 8)
            if (total >= 2L * 1024 * 1024 && ranges && n > 1) {
                RandomAccessFile(tmp, "rw").use { it.setLength(total) }
                val seg = (total + n - 1) / n
                val errs = java.util.concurrent.CopyOnWriteArrayList<Throwable>()
                val threads = ArrayList<Thread>()
                for (i in 1 until n) {
                    val from = i * seg
                    val to = minOf(total - 1, (i + 1) * seg - 1)
                    if (from > to) continue
                    val t = Thread {
                        try {
                            segment(url, tmp, from, to, onBytes)
                        } catch (e: Throwable) {
                            errs.add(e)
                        }
                    }
                    t.start()
                    threads.add(t)
                }
                // potongan pertama dibaca dari koneksi yang sudah terbuka
                val end0 = minOf(total - 1, seg - 1)
                var pos = 0L
                try {
                    RandomAccessFile(tmp, "rw").use { raf ->
                        conn.inputStream.use { ins ->
                            val buf = ByteArray(65536)
                            while (pos <= end0) {
                                val r = ins.read(buf, 0, minOf(buf.size.toLong(), end0 - pos + 1).toInt())
                                if (r < 0) break
                                raf.write(buf, 0, r)
                                pos += r
                                onBytes(r)
                            }
                        }
                    }
                } catch (e: IOException) {
                    // dilanjutkan di bawah lewat Range
                }
                try {
                    if (pos <= end0) segment(url, tmp, pos, end0, onBytes)
                } catch (e: Throwable) {
                    errs.add(e)
                }
                for (t in threads) t.join()
                if (errs.isNotEmpty()) throw IOException(errs[0].message ?: "unduhan terputus")
                if (got.get() < total) throw IOException("unduhan tidak lengkap")
            } else {
                var pos = 0L
                try {
                    FileOutputStream(tmp).use { out ->
                        conn.inputStream.use { ins ->
                            val buf = ByteArray(65536)
                            while (true) {
                                val r = ins.read(buf)
                                if (r < 0) break
                                out.write(buf, 0, r)
                                pos += r
                                onBytes(r)
                            }
                        }
                    }
                } catch (e: IOException) {
                    // putus di tengah jalan: lanjutkan dari titik terakhir jika server mendukung Range
                    if (ranges && total > 0 && pos > 0 && pos < total) {
                        segment(url, tmp, pos, total - 1, onBytes)
                        pos = total
                    } else throw e
                }
                if (pos == 0L) throw IOException("balasan kosong")
                // server menutup koneksi lebih awal tanpa galat: file belum lengkap
                if (total > 0 && pos < total) {
                    if (ranges) {
                        segment(url, tmp, pos, total - 1, onBytes)
                        pos = total
                    } else throw IOException("unduhan tidak lengkap")
                }
            }
            if (total > 0) progress("100.00%")
            checkZip(tmp)
        } finally {
            conn.disconnect()
        }
    }

    /** Unduh + impor satu beatmapset, otomatis pindah mirror jika gagal. Return jumlah chart mania. */
    fun download(c: Context, id: Int, progress: (String) -> Unit): Int {
        val noVideo = !Settings.dlVideo
        val errs = ArrayList<String>()
        val tmp = File(c.cacheDir, "dl_$id.osz")
        try {
            for (m in ordered(true)) {
                try {
                    progress("${m.name}…")
                    val url = m.downloadUrl(id, noVideo)
                    try {
                        fetchTo(url, tmp, Settings.dlConnections, progress)
                    } catch (e: IOException) {
                        // beberapa mirror menolak banyak koneksi sekaligus: coba sekali lagi dengan satu koneksi di mirror yang sama
                        if (Settings.dlConnections > 1) {
                            progress("${m.name}…")
                            fetchTo(url, tmp, 1, progress)
                        } else throw e
                    }
                    progress("Mengimpor…")
                    val count = Library.importOsz(c, "dl_$id") { FileInputStream(tmp) }
                    if (count > 0) {
                        markOk(m, true)
                        return count
                    }
                    throw NoMania()
                } catch (e: NoMania) {
                    throw e
                } catch (e: Exception) {
                    markFail(m)
                    errs.add("${m.name}: ${e.message}")
                }
            }
        } finally {
            tmp.delete()
        }
        throw IOException("Semua mirror gagal (" + errs.joinToString("; ") + ")")
    }
}
