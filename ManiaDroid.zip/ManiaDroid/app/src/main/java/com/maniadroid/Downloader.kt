package com.maniadroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

object Net {
    fun open(url: String, accept: String? = null): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "ManiaDroid/1.1 (Android; offline osu!mania player)")
        if (accept != null) c.setRequestProperty("Accept", accept)
        return c
    }
}

object Img {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(3)

    fun decodeSampled(path: String, reqW: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= reqW) s *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = s
        return BitmapFactory.decodeFile(path, o2)
    }

    /** Gambar dari internet (thumbnail hasil pencarian). */
    fun load(url: String, iv: ImageView) {
        iv.tag = url
        val hit = cache.get(url)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        pool.execute {
            try {
                val c = Net.open(url)
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }
                if (bmp != null) {
                    cache.put(url, bmp)
                    iv.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
                }
            } catch (e: Exception) {
            }
        }
    }

    /** Cover lagu dari gambar background chart yang sudah terpasang (offline). */
    fun loadCover(s: SongSet, iv: ImageView) {
        val key = s.dir.path
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        pool.execute {
            try {
                val m = s.maps.first()
                val name = m.bg
                val f = if (name != null) Library.findFile(m.dir, name) else null
                val bmp = if (f != null) decodeSampled(f.path, 480) else null
                if (bmp != null) {
                    cache.put(key, bmp)
                    iv.post { if (iv.tag == key) iv.setImageBitmap(bmp) }
                }
            } catch (e: Throwable) {
            }
        }
    }
}

object Downloader {
    class Remote(
        val id: Int,
        val title: String,
        val artist: String,
        val creator: String,
        val status: String,
        val info: String,
        val stars: List<Float> = emptyList(),
        val keyCounts: List<Int> = emptyList()
    )

    // ---- filter hasil pencarian (dikerjakan di HP, karena mirror berbeda-beda parameternya) ----
    val DIFF_NAMES = arrayOf("Semua", "Easy", "Normal", "Hard", "Insane", "Expert")
    val KEY_VALUES = intArrayOf(0, 4, 5, 6, 7, 8)
    val KEY_NAMES = arrayOf("Semua", "4K", "5K", "6K", "7K", "8K+")
    val STATUS_NAMES = arrayOf("Semua", "Ranked", "Loved")

    class Filter(var artist: String = "", var diff: Int = 0, var keyIdx: Int = 0, var status: Int = 0) {
        val active: Boolean get() = artist.isNotBlank() || diff != 0 || keyIdx != 0 || status != 0
    }

    private fun inDiff(star: Float, d: Int): Boolean = when (d) {
        1 -> star < 2.0f
        2 -> star >= 2.0f && star < 2.7f
        3 -> star >= 2.7f && star < 4.0f
        4 -> star >= 4.0f && star < 5.3f
        5 -> star >= 5.3f
        else -> true
    }

    fun matches(r: Remote, f: Filter): Boolean {
        if (f.artist.isNotBlank() && !r.artist.lowercase().contains(f.artist.trim().lowercase())) return false
        val st = r.status.lowercase()
        if (f.status == 1 && st.isNotEmpty() && st != "ranked" && st != "approved") return false
        if (f.status == 2 && st.isNotEmpty() && st != "loved") return false
        val key = KEY_VALUES[f.keyIdx]
        if (f.diff == 0 && key == 0) return true
        if (r.stars.isEmpty()) return true
        for (i in r.stars.indices) {
            val k = r.keyCounts.getOrNull(i) ?: 0
            val keyOk = key == 0 || (if (key >= 8) k >= 8 else k == key)
            val star = r.stars[i]
            if (keyOk && (f.diff == 0 || star <= 0f || inDiff(star, f.diff))) return true
        }
        return false
    }

    class Mirror(
        val name: String,
        val searchUrl: ((String, Int) -> String)?,
        val downloadUrl: (Int, Boolean) -> String
    )

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    // Urutan bawaan (Okt 2026): Nerinyan sedang bermasalah, jadi ditaruh paling akhir.
    val mirrors: List<Mirror> = listOf(
        Mirror(
            "osu.direct",
            { q, p -> "https://osu.direct/api/v2/search?query=${enc(q)}&mode=3&amount=20&offset=${p * 20}" },
            { id, nv -> "https://osu.direct/api/d/$id" + (if (nv) "?noVideo=1" else "") }
        ),
        Mirror(
            "Catboy",
            { q, p -> "https://catboy.best/api/v2/search?q=${enc(q)}&query=${enc(q)}&mode=3&limit=20&offset=${p * 20}" },
            { id, nv -> "https://catboy.best/d/$id" + (if (nv) "n" else "") }
        ),
        Mirror(
            "Hinamizawa",
            null,
            { id, nv -> "https://mirror.hinamizawa.ai/api/v1/hinai/d/$id" + (if (nv) "?noVideo=1" else "") }
        ),
        Mirror(
            "Sayobot",
            null,
            { id, nv -> "https://txy1.sayobot.cn/beatmaps/download/" + (if (nv) "novideo" else "full") + "/$id" }
        ),
        Mirror(
            "Nerinyan",
            { q, p -> "https://api.nerinyan.moe/search?q=${enc(q)}&m=3&ps=20&p=$p" },
            { id, nv -> "https://api.nerinyan.moe/d/$id" + (if (nv) "?nv=1" else "") }
        )
    )

    val names: Array<String> = (listOf("Otomatis") + mirrors.map { it.name }).toTypedArray()

    /** Mirror pilihan pengguna dicoba lebih dulu, sisanya jadi cadangan. */
    private fun ordered(): List<Mirror> {
        val sel = Settings.mirror - 1
        if (sel < 0 || sel >= mirrors.size) return mirrors
        val out = ArrayList<Mirror>()
        out.add(mirrors[sel])
        for (i in mirrors.indices) if (i != sel) out.add(mirrors[i])
        return out
    }

    var lastSearchMirror = ""

    private fun parseSearch(body: String): List<Remote> {
        val t = body.trim()
        val arr: JSONArray = if (t.startsWith("[")) {
            JSONArray(t)
        } else {
            val o = JSONObject(t)
            o.optJSONArray("beatmapsets") ?: o.optJSONArray("data") ?: o.optJSONArray("results")
                ?: o.optJSONArray("sets") ?: JSONArray()
        }
        val out = ArrayList<Remote>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            var id = o.optInt("id")
            if (id == 0) id = o.optInt("beatmapset_id")
            if (id == 0) id = o.optInt("SetID")
            if (id == 0) continue
            val bms = o.optJSONArray("beatmaps") ?: o.optJSONArray("ChildrenBeatmaps")
            val ks = sortedSetOf<Int>()
            val starList = ArrayList<Float>()
            val keyList = ArrayList<Int>()
            var hasOther = false
            if (bms != null) {
                for (j in 0 until bms.length()) {
                    val b = bms.optJSONObject(j) ?: continue
                    val mode = b.optInt("mode_int", b.optInt("Mode", 3))
                    if (mode == 3) {
                        val cs = b.optDouble("cs", b.optDouble("CS", 0.0)).toInt()
                        if (cs > 0) ks.add(cs)
                        starList.add(b.optDouble("difficulty_rating", b.optDouble("DifficultyRating", 0.0)).toFloat())
                        keyList.add(cs)
                    } else hasOther = true
                }
            }
            if (ks.isEmpty() && hasOther) continue // set tanpa chart mania
            val creator = o.optString("creator", o.optString("Creator"))
            val known = starList.filter { it > 0f }
            val starText = if (known.isEmpty()) "" else
                String.format(java.util.Locale.US, "SR %.1f–%.1f · ", known.min(), known.max())
            val keysText = (if (ks.isEmpty()) "" else ks.joinToString(", ") { "${it}K" } + " · ") + starText
            out.add(
                Remote(
                    id,
                    o.optString("title", o.optString("Title")),
                    o.optString("artist", o.optString("Artist")),
                    creator,
                    o.optString("status"),
                    keysText + "oleh " + creator,
                    starList,
                    keyList
                )
            )
        }
        return out
    }

    /** Cari chart mania. Mencoba mirror satu per satu sampai ada yang menjawab. */
    fun search(q: String, page: Int): List<Remote> {
        val errs = ArrayList<String>()
        for (m in ordered()) {
            val su = m.searchUrl ?: continue
            val c = Net.open(su(q, page), "application/json")
            try {
                if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
                val r = parseSearch(c.inputStream.bufferedReader().use { it.readText() })
                if (r.isEmpty() && q.isEmpty() && page == 0) throw IOException("hasil kosong")
                lastSearchMirror = m.name
                return r
            } catch (e: Exception) {
                errs.add("${m.name}: ${e.message}")
            } finally {
                c.disconnect()
            }
        }
        throw IOException(errs.joinToString("; "))
    }

    private class NoMania : IOException("Set ini tidak berisi chart mania")

    private fun fetchTo(url: String, tmp: File, name: String, progress: (String) -> Unit) {
        val conn = Net.open(url, "*/*")
        try {
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            conn.inputStream.use { ins ->
                FileOutputStream(tmp).use { out ->
                    val buf = ByteArray(32768)
                    var got = 0L
                    var last = -1
                    var first = true
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        if (first) {
                            first = false
                            // harus file zip ("PK"); beberapa mirror membalas 200 berisi JSON error
                            if (n < 4 || buf[0] != 0x50.toByte() || buf[1] != 0x4B.toByte()) {
                                throw IOException("balasan bukan file .osz")
                            }
                        }
                        out.write(buf, 0, n)
                        got += n
                        val step = if (total > 0) (got * 100 / total).toInt() else (got / (1024 * 512)).toInt()
                        if (step != last) {
                            last = step
                            progress(if (total > 0) "$step%" else String.format("%.1f MB", got / 1048576.0))
                        }
                    }
                    if (first) throw IOException("balasan kosong")
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    /** Unduh + impor satu beatmapset, otomatis pindah mirror jika gagal. Return jumlah chart mania. */
    fun download(c: Context, id: Int, progress: (String) -> Unit): Int {
        val noVideo = !Settings.dlVideo
        val errs = ArrayList<String>()
        val tmp = File(c.cacheDir, "dl_$id.osz")
        try {
            for (m in ordered()) {
                try {
                    progress("${m.name}…")
                    fetchTo(m.downloadUrl(id, noVideo), tmp, m.name, progress)
                    progress("Mengimpor…")
                    val count = Library.importOsz(c, "dl_$id") { FileInputStream(tmp) }
                    if (count > 0) return count
                    throw NoMania()
                } catch (e: NoMania) {
                    throw e
                } catch (e: Exception) {
                    errs.add("${m.name}: ${e.message}")
                }
            }
        } finally {
            tmp.delete()
        }
        throw IOException("Semua mirror gagal (" + errs.joinToString("; ") + ")")
    }
}
