package com.maniadroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File
import java.util.Locale

class GameActivity : Activity(), GameView.Callback {
    private var mp: MediaPlayer? = null
    private var game: GameView? = null
    private var backdrop: Backdrop? = null
    private var dlg: AlertDialog? = null
    private var finished = false
    private var bestKey = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        Sfx.init(this)
        Ui.applyOrientation(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        val path = intent.getStringExtra("osu")
        if (path == null) {
            finish()
            return
        }
        val file = File(path)
        val bm = Beatmap.parse(file, true)
        if (bm == null || bm.notes.isEmpty()) {
            Toast.makeText(this, "Chart tidak valid / bukan mode mania", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val audio = Library.findFile(bm.dir, bm.audio)
        if (audio == null) {
            Toast.makeText(this, "File audio tidak ditemukan: ${bm.audio}", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val player = MediaPlayer()
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setDataSource(audio.path)
            player.prepare()
            val v = Settings.musicVol / 100f
            player.setVolume(v, v)
        } catch (e: Exception) {
            Toast.makeText(this, "Audio gagal dibuka: ${e.message}", Toast.LENGTH_LONG).show()
            player.release()
            finish()
            return
        }
        mp = player
        bestKey = file.parentFile!!.name + "/" + file.name

        val root = FrameLayout(this)
        val bd = Backdrop(this, bm)
        backdrop = bd
        bd.onNote = { msg -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        bd.initialNote?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        root.addView(bd, Ui.matchParams())
        val gv = GameView(this, bm, bd, player, this)
        game = gv
        root.addView(gv, Ui.matchParams())
        setContentView(root)
        gv.begin()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() {
        super.onPause()
        if (!finished && game != null) {
            game?.pauseGame()
            showPauseMenu()
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (finished || game == null) {
            super.onBackPressed()
            return
        }
        game?.pauseGame()
        showPauseMenu()
    }

    override fun onPausePressed() {
        game?.pauseGame()
        showPauseMenu()
    }

    private fun showPauseMenu() {
        if (finished || isFinishing || dlg?.isShowing == true) return
        dlg = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle("Jeda")
            .setCancelable(false)
            .setItems(arrayOf("Lanjut", "Ulangi", "Keluar")) { _, i ->
                when (i) {
                    0 -> game?.resumeGame()
                    1 -> retry()
                    else -> finish()
                }
            }.show()
    }

    private fun retry() {
        val i = Intent(intent)
        finish()
        startActivity(i)
        overridePendingTransition(0, 0)
    }

    override fun onEnd(r: Result) {
        finished = true
        if (!r.failed) Settings.saveBest(bestKey, r.score)
        val best = Settings.best(bestKey)
        val c = r.counts
        val msg = String.format(
            Locale.US,
            "Skor: %d   (terbaik: %d)\nAkurasi: %.2f%%\nMax combo: %d\n\nMAX %d   300 %d   200 %d\n100 %d   50 %d   Miss %d",
            r.score, best, r.acc, r.maxCombo, c[0], c[1], c[2], c[3], c[4], c[5]
        )
        dlg?.dismiss()
        dlg = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(if (r.failed) "GAGAL" else "Selesai · Rank ${r.rank}")
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("Ulangi") { _, _ -> retry() }
            .setNegativeButton("Kembali") { _, _ -> finish() }
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        dlg?.dismiss()
        game?.destroy()
        backdrop?.release()
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
    }
}
