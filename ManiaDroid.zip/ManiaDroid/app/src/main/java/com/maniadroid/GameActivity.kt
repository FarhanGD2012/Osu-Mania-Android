package com.maniadroid

import android.app.Activity
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import java.io.File

class GameActivity : BaseActivity(), GameView.Callback {
    private var mp: MediaPlayer? = null
    private var game: GameView? = null
    private var backdrop: Backdrop? = null
    private var resultUi: ResultOverlay? = null
    private var rootView: FrameLayout? = null
    private var pauseUi: PauseOverlay? = null
    private var songTitle = ""
    private var songSub = ""
    private var finished = false
    private var bestKey = ""
    private val pad = PadState()
    private var laneMap = HashMap<Int, ArrayList<Int>>()

    override val recreateOnLanguageChange: Boolean = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        Sfx.init(this)
        Ui.applyOrientation(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        val path = intent.getStringExtra("osu")
        if (path == null) {
            finish()
            return
        }
        val file = File(path)
        val bm = Beatmap.parse(file, true)
        if (bm == null || bm.notes.isEmpty()) {
            Toast.makeText(this, "Chart tidak valid / bukan mode mania", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        laneMap = Bindings.map(bm.keys)
        val audio = Library.findFile(bm.dir, bm.audio)
        if (audio == null) {
            Toast.makeText(this, L.t("File audio tidak ditemukan: ${bm.audio}", "Audio file not found: ${bm.audio}"), Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val player = MediaPlayer()
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setDataSource(audio.path)
            player.prepare()
            val v = Settings.musicVol / 100f
            player.setVolume(v, v)
        } catch (e: Exception) {
            Toast.makeText(this, L.t("Audio gagal dibuka: ${e.message}", "Failed to open audio: ${e.message}"), Toast.LENGTH_LONG).show()
            player.release()
            finish()
            return
        }
        mp = player
        bestKey = file.parentFile!!.name + "/" + file.name

        songTitle = "${bm.artist} - ${bm.title}"
        songSub = "[${bm.version}]  ·  mapper ${bm.creator}"
        val root = FrameLayout(this)
        rootView = root
        val bd = Backdrop(this, bm)
        backdrop = bd
        bd.onNote = { msg -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        bd.initialNote?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        root.addView(bd, Ui.matchParams())
        val gv = GameView(this, bm, bd, player, this)
        game = gv
        root.addView(gv, Ui.matchParams())
        setContentView(root)
        gv.begin()
    }

    // ---- controller & keyboard ----
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val g = game ?: return super.dispatchKeyEvent(e)
        val code = e.keyCode
        if (Input.isSystemKey(code)) return super.dispatchKeyEvent(e)
        val lanes = laneMap[code]
        val pauseKey = lanes == null && Input.isPauseKey(code)
        if (lanes == null && !pauseKey) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.repeatCount > 0) return true
            if (lanes != null) {
                if (pad.keyDown(code)) for (c in lanes) g.padPress(c, e.eventTime)
            } else {
                onPausePressed()
            }
        } else if (e.action == KeyEvent.ACTION_UP && lanes != null) {
            if (pad.keyUp(code)) for (c in lanes) g.padRelease(c, e.eventTime)
        }
        return true
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val g = game
        if (g != null && Input.isJoystickMove(ev)) {
            val st = Input.axisStates(ev)
            for (i in st.indices) {
                val code = Input.AXIS_CODES[i]
                val ch = pad.axisSet(code, st[i])
                if (ch == 0) continue
                val lanes = laneMap[code]
                if (lanes != null) {
                    for (c in lanes) if (ch > 0) g.padPress(c, ev.eventTime) else g.padRelease(c, ev.eventTime)
                }
            }
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun onPause() {
        super.onPause()
        if (!finished && game != null) {
            game?.pauseGame()
            showPauseMenu()
        }
    }

    override fun onResume() {
        super.onResume()
        // sehabis dari layar pengaturan lengkap: terapkan pengaturan baru
        game?.applySettings()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (finished || game == null) {
            super.onBackPressed()
            return
        }
        val ui = pauseUi
        if (ui != null) {
            if (!ui.back()) doResume() // Back di menu jeda = lanjut main
            return
        }
        game?.pauseGame()
        showPauseMenu()
    }

    override fun onPausePressed() {
        if (pauseUi != null) {
            doResume() // tombol Start controller: jeda <-> lanjut
            return
        }
        game?.pauseGame()
        showPauseMenu()
    }

    private fun showPauseMenu() {
        val root = rootView ?: return
        if (finished || isFinishing || pauseUi != null) return
        val ui = PauseOverlay(
            this, songTitle, songSub, game?.statusText() ?: "",
            onContinue = { doResume() },
            onRetry = { retry() },
            onQuit = { finish() },
            // "Setelan" langsung ke pengaturan lengkap (layar besar), bukan panel kecil
            onAllSettings = { startActivity(Intent(this, SettingsActivity::class.java)) }
        )
        pauseUi = ui
        root.addView(ui, Ui.matchParams())
    }

    private fun hidePauseMenu() {
        val ui = pauseUi ?: return
        pauseUi = null
        ui.animate().alpha(0f).setDuration(120).withEndAction { rootView?.removeView(ui) }.start()
    }

    private fun doResume() {
        hidePauseMenu()
        game?.applySettings()
        game?.resumeGame()
    }

    private fun retry() {
        val i = Intent(intent)
        finish()
        startActivity(i)
        overridePendingTransition(0, 0)
    }

    override fun onEnd(r: Result) {
        finished = true
        val prev = Settings.best(bestKey)
        if (!r.failed) Settings.saveBest(bestKey, r.score)
        val best = Settings.best(bestKey)
        val newBest = !r.failed && r.score > prev
        pauseUi?.let {
            pauseUi = null
            rootView?.removeView(it)
        }
        resultUi?.let { rootView?.removeView(it) }
        val ui = ResultOverlay(
            this, songTitle, songSub, r, best, newBest,
            onRetry = { retry() },
            onBack = { finish() }
        )
        resultUi = ui
        rootView?.addView(ui, Ui.matchParams())
    }

    override fun onDestroy() {
        super.onDestroy()
        game?.destroy()
        backdrop?.release()
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
    }
}
