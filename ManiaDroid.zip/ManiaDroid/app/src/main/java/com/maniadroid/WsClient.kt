package com.maniadroid

import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.EOFException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import javax.net.ssl.SSLSocketFactory

/**
 * Klien WebSocket (RFC 6455) minimal tanpa library tambahan: ws:// dan wss://, teks, ping/pong, fragmentasi.
 * Semua callback dipanggil dari thread pembaca (bukan thread utama).
 */
class WsClient(private val url: String, private val listener: Listener) {
    interface Listener {
        fun onOpen()
        fun onText(text: String)
        fun onClosed(reason: String)
    }

    @Volatile private var sock: Socket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile var open = false
        private set
    @Volatile private var closedCalled = false
    private val rnd = SecureRandom()
    private val sendLock = Any()

    // Android melarang menulis ke jaringan dari thread utama (NetworkOnMainThreadException): semua kiriman lewat satu thread penulis.
    private val writer = java.util.concurrent.Executors.newSingleThreadExecutor { r ->
        Thread(r, "ws-writer").also { it.isDaemon = true }
    }

    fun connect() {
        Thread({ run() }, "ws-reader").also { it.isDaemon = true }.start()
    }

    private fun parse(): Triple<Boolean, String, Pair<Int, String>> {
        val u = java.net.URI(url.trim())
        val secure = when (u.scheme?.lowercase()) {
            "wss", "https" -> true
            "ws", "http" -> false
            else -> throw IOException("Alamat harus diawali ws:// atau wss://")
        }
        val host = u.host ?: throw IOException("Alamat server tidak valid")
        val port = if (u.port > 0) u.port else if (secure) 443 else 80
        var path = u.rawPath ?: ""
        if (path.isEmpty()) path = "/"
        if (u.rawQuery != null) path += "?" + u.rawQuery
        return Triple(secure, host, Pair(port, path))
    }

    private fun run() {
        try {
            val (secure, host, pp) = parse()
            val (port, path) = pp
            val raw = Socket()
            raw.tcpNoDelay = true
            raw.connect(InetSocketAddress(host, port), 10000)
            val s: Socket = if (secure) {
                val ss = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(raw, host, port, true)
                ss.soTimeout = 10000
                (ss as javax.net.ssl.SSLSocket).startHandshake()
                ss
            } else raw
            s.soTimeout = 10000
            sock = s
            val ins = s.getInputStream()
            val os = s.getOutputStream()
            val keyBytes = ByteArray(16)
            rnd.nextBytes(keyBytes)
            val key = b64(keyBytes)
            val req = "GET $path HTTP/1.1\r\nHost: $host" + (if ((secure && port != 443) || (!secure && port != 80)) ":$port" else "") +
                    "\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: $key\r\nSec-WebSocket-Version: 13\r\n" +
                    "User-Agent: ManiaDroid-Versus\r\n\r\n"
            os.write(req.toByteArray(Charsets.ISO_8859_1))
            os.flush()
            // baca header balasan sampai baris kosong
            val head = StringBuilder()
            while (!head.endsWith("\r\n\r\n")) {
                val b = ins.read()
                if (b < 0) throw EOFException("server menutup koneksi")
                head.append(b.toChar())
                if (head.length > 8192) throw IOException("balasan server tidak valid")
            }
            val lines = head.toString().split("\r\n")
            if (!lines[0].contains(" 101")) throw IOException("Server menolak WebSocket: " + lines[0].take(60))
            val accept = lines.firstOrNull { it.startsWith("Sec-WebSocket-Accept:", ignoreCase = true) }?.substringAfter(':')?.trim()
            val md = MessageDigest.getInstance("SHA-1").digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").toByteArray())
            if (accept != null && accept != b64(md)) throw IOException("Jawaban server bukan WebSocket yang sah")
            s.soTimeout = 0
            out = os
            open = true
            listener.onOpen()
            readLoop(DataInputStream(ins))
            fireClosed("koneksi ditutup")
        } catch (e: Exception) {
            fireClosed(e.message ?: e.javaClass.simpleName)
        }
    }

    private fun readLoop(ins: DataInputStream) {
        val frag = ByteArrayOutputStream()
        var fragOp = 0
        while (true) {
            val b0 = ins.read()
            if (b0 < 0) return
            val b1 = ins.read()
            if (b1 < 0) return
            val fin = (b0 and 0x80) != 0
            val op = b0 and 0x0F
            val masked = (b1 and 0x80) != 0
            var len = (b1 and 0x7F).toLong()
            if (len == 126L) len = ((ins.read() shl 8) or ins.read()).toLong()
            else if (len == 127L) {
                len = 0
                for (i in 0 until 8) len = (len shl 8) or ins.read().toLong()
            }
            if (len > 4_000_000L) throw IOException("pesan terlalu besar")
            val mask = ByteArray(4)
            if (masked) ins.readFully(mask)
            val data = ByteArray(len.toInt())
            ins.readFully(data)
            if (masked) for (i in data.indices) data[i] = (data[i].toInt() xor mask[i and 3].toInt()).toByte()
            when (op) {
                0x8 -> { // close
                    try {
                        sendFrame(0x8, data.copyOf(minOf(2, data.size)))
                    } catch (e: Exception) {
                    }
                    return
                }
                0x9 -> sendFrame(0xA, data) // ping -> pong
                0xA -> {}
                0x1, 0x2, 0x0 -> {
                    if (op != 0x0) {
                        frag.reset()
                        fragOp = op
                    }
                    frag.write(data)
                    if (fin) {
                        if (fragOp == 0x1) listener.onText(String(frag.toByteArray(), Charsets.UTF_8))
                        frag.reset()
                    }
                }
            }
        }
    }

    private fun fireClosed(reason: String) {
        open = false
        try {
            writer.shutdown()
        } catch (e: Exception) {
        }
        try {
            sock?.close()
        } catch (e: Exception) {
        }
        synchronized(this) {
            if (closedCalled) return
            closedCalled = true
        }
        listener.onClosed(reason)
    }

    /** Kirim pesan teks (aman dipanggil dari thread mana pun). Return false jika koneksi belum / tidak terbuka. */
    fun send(text: String): Boolean {
        if (!open) return false
        val bytes = text.toByteArray(Charsets.UTF_8)
        return try {
            writer.execute {
                try {
                    sendFrame(0x1, bytes)
                } catch (e: Exception) {
                    fireClosed(e.message ?: "gagal mengirim")
                }
            }
            true
        } catch (e: java.util.concurrent.RejectedExecutionException) {
            false
        }
    }

    private fun sendFrame(op: Int, payload: ByteArray) {
        val os = out ?: throw IOException("belum terhubung")
        val bos = ByteArrayOutputStream(payload.size + 14)
        bos.write(0x80 or op)
        val n = payload.size
        when {
            n < 126 -> bos.write(0x80 or n)
            n < 65536 -> {
                bos.write(0x80 or 126)
                bos.write(n shr 8)
                bos.write(n and 0xFF)
            }
            else -> {
                bos.write(0x80 or 127)
                for (i in 7 downTo 0) bos.write(((n.toLong() shr (8 * i)) and 0xFF).toInt())
            }
        }
        val mask = ByteArray(4)
        rnd.nextBytes(mask)
        bos.write(mask)
        for (i in 0 until n) bos.write(payload[i].toInt() xor mask[i and 3].toInt())
        synchronized(sendLock) {
            os.write(bos.toByteArray())
            os.flush()
        }
    }

    fun close() {
        val wasOpen = open
        open = false // pesan berikutnya ditolak
        try {
            writer.execute {
                if (wasOpen) {
                    try {
                        sendFrame(0x8, ByteArray(0))
                    } catch (e: Exception) {
                    }
                }
                fireClosed("ditutup")
            }
            writer.shutdown()
        } catch (e: java.util.concurrent.RejectedExecutionException) {
            fireClosed("ditutup")
        }
    }

    private fun b64(b: ByteArray): String {
        val t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        val sb = StringBuilder()
        var i = 0
        while (i < b.size) {
            val b0 = b[i].toInt() and 0xFF
            val b1 = if (i + 1 < b.size) b[i + 1].toInt() and 0xFF else 0
            val b2 = if (i + 2 < b.size) b[i + 2].toInt() and 0xFF else 0
            sb.append(t[b0 shr 2])
            sb.append(t[((b0 and 3) shl 4) or (b1 shr 4)])
            sb.append(if (i + 1 < b.size) t[((b1 and 15) shl 2) or (b2 shr 6)] else '=')
            sb.append(if (i + 2 < b.size) t[b2 and 63] else '=')
            i += 3
        }
        return sb.toString()
    }
}
