package com.maniadroid

import android.net.Uri
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder

/**
 * Akun osu! lewat OAuth resmi (osu! API v2, Authorization Code). Kamu membuat "OAuth application" sendiri di
 * osu.ppy.sh/home/account/edit (callback: maniadroid://oauth), lalu memasukkan Client ID + Secret di layar Akun.
 * Token disimpan di perangkat saja. Dipakai untuk menampilkan profil mania dan nama di Versus.
 */
object OsuAccount {
    const val REDIRECT = "maniadroid://oauth"
    private const val BASE = "https://osu.ppy.sh"

    private fun gs(k: String): String = Settings.sp.getString(k, "") ?: ""
    private fun ps(k: String, v: String) {
        Settings.sp.edit().putString(k, v).apply()
    }

    var clientSecret: String
        get() = gs("acct_secret")
        set(v) = ps("acct_secret", v.trim())

    val name: String get() = gs("acct_name")
    val avatar: String get() = gs("acct_avatar")
    val country: String get() = gs("acct_country")
    val userId: Long get() = Settings.sp.getLong("acct_id", 0L)
    val rank: Long get() = Settings.sp.getLong("acct_rank", 0L)
    val pp: Float get() = Settings.sp.getFloat("acct_pp", 0f)
    val acc: Float get() = Settings.sp.getFloat("acct_acc", 0f)
    val plays: Long get() = Settings.sp.getLong("acct_plays", 0L)
    val level: Float get() = Settings.sp.getFloat("acct_level", 0f)
    val linked: Boolean get() = Settings.ready && name.isNotEmpty() && gs("acct_token").isNotEmpty()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Alamat otorisasi yang dibuka di browser. */
    fun authUrl(): String {
        val state = java.lang.Long.toHexString(java.util.Random().nextLong()) + java.lang.Long.toHexString(System.nanoTime())
        ps("acct_state", state)
        return "$BASE/oauth/authorize?client_id=${Settings.osuClientId}&redirect_uri=${enc(REDIRECT)}" +
                "&response_type=code&scope=${enc("identify public")}&state=$state"
    }

    private fun postJson(url: String, body: JSONObject): JSONObject {
        val c = Net.open(url, "application/json", 10000, 20000)
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try {
                    val j = JSONObject(txt)
                    j.optString("hint", j.optString("error_description", j.optString("error")))
                } catch (e: Exception) {
                    ""
                }
                throw IOException("HTTP $code" + (if (msg.isNotEmpty()) ": $msg" else ""))
            }
            return JSONObject(txt)
        } finally {
            c.disconnect()
        }
    }

    private fun saveTokens(j: JSONObject) {
        Settings.sp.edit()
            .putString("acct_token", j.optString("access_token"))
            .putString("acct_refresh", j.optString("refresh_token", gs("acct_refresh")))
            .putLong("acct_exp", System.currentTimeMillis() + j.optLong("expires_in", 3600L) * 1000L)
            .apply()
    }

    /** Dipanggil saat browser mengembalikan maniadroid://oauth?code=...  (jalankan di thread latar). Null = berhasil, selain itu pesan galat. */
    fun finishLogin(data: Uri): String? {
        val err = data.getQueryParameter("error")
        if (err != null) return L.t("Otorisasi dibatalkan atau ditolak ($err)", "Authorization cancelled or denied ($err)")
        val code = data.getQueryParameter("code") ?: return L.t("Tidak ada kode dari osu!", "No code returned by osu!")
        val st = data.getQueryParameter("state")
        if (st == null || st != gs("acct_state")) return L.t("Kode keamanan (state) tidak cocok, coba masuk lagi", "Security state mismatch, try signing in again")
        return try {
            val j = postJson(
                "$BASE/oauth/token",
                JSONObject().put("client_id", Settings.osuClientId).put("client_secret", clientSecret)
                    .put("code", code).put("grant_type", "authorization_code").put("redirect_uri", REDIRECT)
            )
            saveTokens(j)
            fetchProfile()
        } catch (e: Exception) {
            L.t("Gagal masuk: ${e.message}", "Sign-in failed: ${e.message}")
        }
    }

    private fun validToken(): String {
        if (System.currentTimeMillis() > Settings.sp.getLong("acct_exp", 0L) - 60_000L) {
            val rt = gs("acct_refresh")
            if (rt.isEmpty()) throw IOException("sesi habis, masuk lagi")
            val j = postJson(
                "$BASE/oauth/token",
                JSONObject().put("client_id", Settings.osuClientId).put("client_secret", clientSecret)
                    .put("grant_type", "refresh_token").put("refresh_token", rt)
            )
            saveTokens(j)
        }
        return gs("acct_token")
    }

    /** Ambil profil mania terbaru (thread latar). Null = berhasil. */
    fun fetchProfile(): String? {
        return try {
            val tok = validToken()
            val c = Net.open("$BASE/api/v2/me/mania", "application/json", 10000, 20000)
            try {
                c.setRequestProperty("Authorization", "Bearer $tok")
                if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
                val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val st = j.optJSONObject("statistics")
                val e = Settings.sp.edit()
                e.putLong("acct_id", j.optLong("id"))
                e.putString("acct_name", j.optString("username"))
                e.putString("acct_avatar", j.optString("avatar_url"))
                e.putString("acct_country", j.optString("country_code", j.optJSONObject("country")?.optString("code") ?: ""))
                if (st != null) {
                    e.putLong("acct_rank", st.optLong("global_rank", 0L))
                    e.putFloat("acct_pp", st.optDouble("pp", 0.0).toFloat())
                    e.putFloat("acct_acc", st.optDouble("hit_accuracy", 0.0).toFloat())
                    e.putLong("acct_plays", st.optLong("play_count", 0L))
                    e.putFloat("acct_level", (st.optJSONObject("level")?.optDouble("current", 0.0) ?: 0.0).toFloat())
                }
                e.apply()
                null
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            L.t("Gagal mengambil profil: ${e.message}", "Could not load profile: ${e.message}")
        }
    }

    fun logout() {
        val e = Settings.sp.edit()
        for (k in Settings.sp.all.keys) if (k.startsWith("acct_") && k != "acct_clientId" && k != "acct_secret") e.remove(k)
        e.apply()
    }
}
