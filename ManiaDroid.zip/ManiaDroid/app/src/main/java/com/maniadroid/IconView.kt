package com.maniadroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/** Ikon garis sederhana yang digambar sendiri (tanpa emoji / file gambar) supaya seragam di semua HP. */
class IconView(ctx: Context, var kind: Int, var tint: Int = 0xFFFFFFFF.toInt()) : View(ctx) {
    companion object {
        const val PLAY = 0
        const val EDIT = 1
        const val SYNC = 2
        const val IMPORT = 3
        const val DOWNLOAD = 4
        const val SETTINGS = 5
        const val EXIT = 6
        const val PREV = 7
        const val NEXT = 8
        const val PAUSE = 9
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val r = RectF()

    private fun line(cv: Canvas, ox: Float, oy: Float, s: Float, x1: Float, y1: Float, x2: Float, y2: Float) {
        cv.drawLine(ox + x1 * s, oy + y1 * s, ox + x2 * s, oy + y2 * s, p)
    }

    private fun tri(cv: Canvas, ox: Float, oy: Float, s: Float, x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
        path.reset()
        path.moveTo(ox + x1 * s, oy + y1 * s)
        path.lineTo(ox + x2 * s, oy + y2 * s)
        path.lineTo(ox + x3 * s, oy + y3 * s)
        path.close()
        cv.drawPath(path, p)
    }

    override fun onDraw(cv: Canvas) {
        val s = min(width, height).toFloat()
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        p.color = tint
        p.strokeWidth = s * 0.075f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        when (kind) {
            PLAY -> {
                p.style = Paint.Style.FILL
                tri(cv, ox, oy, s, 0.30f, 0.18f, 0.30f, 0.82f, 0.82f, 0.5f)
            }
            PAUSE -> {
                p.style = Paint.Style.FILL
                r.set(ox + 0.27f * s, oy + 0.20f * s, ox + 0.43f * s, oy + 0.80f * s)
                cv.drawRoundRect(r, s * 0.04f, s * 0.04f, p)
                r.set(ox + 0.57f * s, oy + 0.20f * s, ox + 0.73f * s, oy + 0.80f * s)
                cv.drawRoundRect(r, s * 0.04f, s * 0.04f, p)
            }
            PREV -> {
                p.style = Paint.Style.FILL
                r.set(ox + 0.20f * s, oy + 0.22f * s, ox + 0.29f * s, oy + 0.78f * s)
                cv.drawRoundRect(r, s * 0.03f, s * 0.03f, p)
                tri(cv, ox, oy, s, 0.80f, 0.20f, 0.80f, 0.80f, 0.34f, 0.5f)
            }
            NEXT -> {
                p.style = Paint.Style.FILL
                r.set(ox + 0.71f * s, oy + 0.22f * s, ox + 0.80f * s, oy + 0.78f * s)
                cv.drawRoundRect(r, s * 0.03f, s * 0.03f, p)
                tri(cv, ox, oy, s, 0.20f, 0.20f, 0.20f, 0.80f, 0.66f, 0.5f)
            }
            EDIT -> {
                p.style = Paint.Style.FILL
                cv.save()
                cv.rotate(45f, ox + 0.5f * s, oy + 0.5f * s)
                r.set(ox + 0.42f * s, oy + 0.16f * s, ox + 0.58f * s, oy + 0.62f * s)
                cv.drawRoundRect(r, s * 0.03f, s * 0.03f, p)
                tri(cv, ox, oy, s, 0.42f, 0.66f, 0.58f, 0.66f, 0.50f, 0.86f)
                cv.restore()
                p.style = Paint.Style.STROKE
                line(cv, ox, oy, s, 0.62f, 0.86f, 0.86f, 0.86f)
            }
            SYNC -> {
                p.style = Paint.Style.STROKE
                cv.drawCircle(ox + 0.5f * s, oy + 0.56f * s, 0.30f * s, p)
                line(cv, ox, oy, s, 0.5f, 0.56f, 0.5f, 0.38f)
                line(cv, ox, oy, s, 0.5f, 0.56f, 0.62f, 0.62f)
                line(cv, ox, oy, s, 0.42f, 0.13f, 0.58f, 0.13f)
                line(cv, ox, oy, s, 0.5f, 0.13f, 0.5f, 0.2f)
            }
            IMPORT -> {
                p.style = Paint.Style.STROKE
                r.set(ox + 0.14f * s, oy + 0.30f * s, ox + 0.86f * s, oy + 0.80f * s)
                cv.drawRoundRect(r, s * 0.07f, s * 0.07f, p)
                line(cv, ox, oy, s, 0.14f, 0.30f, 0.14f, 0.22f)
                line(cv, ox, oy, s, 0.14f, 0.22f, 0.40f, 0.22f)
                line(cv, ox, oy, s, 0.40f, 0.22f, 0.46f, 0.30f)
                line(cv, ox, oy, s, 0.5f, 0.40f, 0.5f, 0.66f)
                line(cv, ox, oy, s, 0.40f, 0.56f, 0.5f, 0.67f)
                line(cv, ox, oy, s, 0.60f, 0.56f, 0.5f, 0.67f)
            }
            DOWNLOAD -> {
                p.style = Paint.Style.STROKE
                line(cv, ox, oy, s, 0.5f, 0.14f, 0.5f, 0.60f)
                line(cv, ox, oy, s, 0.32f, 0.44f, 0.5f, 0.62f)
                line(cv, ox, oy, s, 0.68f, 0.44f, 0.5f, 0.62f)
                line(cv, ox, oy, s, 0.20f, 0.66f, 0.20f, 0.84f)
                line(cv, ox, oy, s, 0.20f, 0.84f, 0.80f, 0.84f)
                line(cv, ox, oy, s, 0.80f, 0.84f, 0.80f, 0.66f)
            }
            SETTINGS -> {
                p.style = Paint.Style.FILL
                for (i in 0 until 8) {
                    cv.save()
                    cv.rotate(i * 45f, ox + 0.5f * s, oy + 0.5f * s)
                    r.set(ox + 0.44f * s, oy + 0.10f * s, ox + 0.56f * s, oy + 0.26f * s)
                    cv.drawRoundRect(r, s * 0.03f, s * 0.03f, p)
                    cv.restore()
                }
                p.style = Paint.Style.STROKE
                p.strokeWidth = s * 0.10f
                cv.drawCircle(ox + 0.5f * s, oy + 0.5f * s, 0.27f * s, p)
                p.strokeWidth = s * 0.07f
                cv.drawCircle(ox + 0.5f * s, oy + 0.5f * s, 0.10f * s, p)
            }
            EXIT -> {
                p.style = Paint.Style.STROKE
                r.set(ox + 0.22f * s, oy + 0.24f * s, ox + 0.78f * s, oy + 0.80f * s)
                cv.drawArc(r, -60f, 300f, false, p)
                line(cv, ox, oy, s, 0.5f, 0.12f, 0.5f, 0.50f)
            }
        }
    }
}
