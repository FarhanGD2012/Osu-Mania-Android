package com.maniadroid

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView

object Ui {
    const val BG = 0xFF11111B.toInt()
    const val CARD = 0xFF1B1B2A.toInt()
    const val CARD2 = 0xFF242438.toInt()
    const val ACCENT = 0xFFFF5FA2.toInt()
    const val TEXT = 0xFFEDEDF5.toInt()
    const val SUB = 0xFF9A9AB0.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun applyOrientation(a: Activity) {
        a.requestedOrientation = when (Settings.orientation) {
            0 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
    }

    fun rounded(color: Int, radius: Float): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = radius
        return d
    }

    fun bgGradient(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(0xFF1B1033.toInt(), 0xFF0C0C17.toInt(), 0xFF0F1B33.toInt())
    )

    fun ripple(bg: Drawable): Drawable = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), bg, null)

    fun text(c: Context, s: String, sp: Float = 15f, color: Int = TEXT, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    /** Tombol bulat lonjong (pill). filled=false -> gaya outline gelap. */
    fun button(c: Context, s: String, filled: Boolean = true, onClick: () -> Unit): Button {
        val b = Button(c)
        b.text = s
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.gravity = Gravity.CENTER
        b.stateListAnimator = null
        b.minHeight = dp(c, 48)
        b.minimumHeight = dp(c, 48)
        b.setPadding(dp(c, 18), 0, dp(c, 18), 0)
        b.background = ripple(rounded(if (filled) ACCENT else CARD2, dp(c, 26).toFloat()))
        b.setOnClickListener { onClick() }
        return b
    }

    fun matchParams(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(-1, -1)
}
