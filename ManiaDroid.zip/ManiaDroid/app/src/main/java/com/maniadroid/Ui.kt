package com.maniadroid

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView

object Ui {
    const val BG = 0xFF11111B.toInt()
    const val CARD = 0xFF1B1B2A.toInt()
    const val CARD2 = 0xFF242438.toInt()
    const val ACCENT = 0xFFFF5FA2.toInt()
    const val TEXT = 0xFFEDEDF5.toInt()
    const val SUB = 0xFF9A9AB0.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    /**
     * Kotak teks tanpa mode "layar penuh" keyboard (di landscape keyboard biasanya mengambil alih seluruh layar,
     * sehingga tombol Enter tidak terasa menjalankan pencarian). Dipakai di semua kotak isian.
     */
    fun noExtractUi(e: EditText, action: Int = EditorInfo.IME_ACTION_DONE) {
        e.imeOptions = action or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
    }

    fun hideKeyboard(v: android.view.View) {
        (v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(v.windowToken, 0)
    }

    /** Kotak pencarian: Enter / tombol cari di keyboard menjalankan [onSubmit], menutup keyboard, dan melepas fokus. */
    fun searchField(e: EditText, onSubmit: () -> Unit) {
        e.setSingleLine(true)
        noExtractUi(e, EditorInfo.IME_ACTION_SEARCH)
        var last = 0L
        fun submit(): Boolean {
            val now = SystemClock.uptimeMillis()
            if (now - last < 250) return true // Enter bisa datang dobel (aksi editor + tombol)
            last = now
            onSubmit()
            hideKeyboard(e)
            e.clearFocus()
            return true
        }
        e.setOnEditorActionListener { _, actionId, ev ->
            val enter = ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN
            if (enter || actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_SEND || actionId == EditorInfo.IME_ACTION_NEXT
            ) submit() else false
        }
        e.setOnKeyListener { _, keyCode, ev ->
            if ((keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) && ev.action == KeyEvent.ACTION_UP) submit() else false
        }
    }

    fun applyOrientation(a: Activity) {
        a.requestedOrientation = when (Settings.orientation) {
            0 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        }
    }

    fun rounded(color: Int, radius: Float): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = radius
        return d
    }

    /** Warna dari rona tema (Pengaturan > Latar menu > Warna tema). */
    fun hue(s: Float, v: Float, shift: Float = 0f): Int {
        val h = ((Settings.themeHue + shift) % 360f + 360f) % 360f
        return Color.HSVToColor(floatArrayOf(h, s, v))
    }

    /** Latar gelap berwarna tema untuk layar-layar selain menu utama. */
    fun bgGradient(): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(hue(0.62f, 0.24f), hue(0.55f, 0.07f), hue(0.60f, 0.15f, 25f))
    )

    /**
     * Efek sentuh putih yang HANYA muncul di dalam bentuk tombolnya (ikut sudut membulat),
     * tidak meluber jadi kotak putih di luar bentuk.
     */
    fun ripple(bg: Drawable, color: Int = 0x30FFFFFF): Drawable {
        val r = (bg as? GradientDrawable)?.cornerRadius ?: 0f
        return RippleDrawable(ColorStateList.valueOf(color), bg, rounded(Color.WHITE, r))
    }

    fun text(c: Context, s: String, sp: Float = 15f, color: Int = TEXT, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = L.t(s)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    /** Tombol bulat lonjong (pill). filled=false -> gaya outline gelap. */
    fun button(c: Context, s: String, filled: Boolean = true, onClick: () -> Unit): Button =
        button(c, s, filled, 26, onClick)

    fun button(c: Context, s: String, filled: Boolean, radiusDp: Int, onClick: () -> Unit): Button {
        val b = Button(c)
        b.text = L.t(s)
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.gravity = Gravity.CENTER
        b.stateListAnimator = null
        b.minHeight = dp(c, 48)
        b.minimumHeight = dp(c, 48)
        b.setPadding(dp(c, 18), 0, dp(c, 18), 0)
        b.background = ripple(rounded(if (filled) ACCENT else CARD2, dp(c, radiusDp).toFloat()))
        b.setOnClickListener { onClick() }
        return b
    }

    fun matchParams(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(-1, -1)
}
