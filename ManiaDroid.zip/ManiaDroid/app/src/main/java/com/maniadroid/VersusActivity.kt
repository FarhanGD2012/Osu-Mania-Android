package com.maniadroid

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.wifi.WifiManager
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.io.File

/**
 * Multiplayer ala lobi osu!lazer: daftar room (jaringan lokal otomatis + internet), buat room dengan pengaturan lengkap
 * (tipe match, antrean chart, kondisi menang, mulai otomatis, batas pemain), lalu layar room.
 */
class VersusActivity : BaseActivity(), Versus.Listener {
    private lateinit var backdrop: MenuBackdrop
    private lateinit var page: FrameLayout
    private lateinit var title: LazerTitle
    private var localBm: Beatmap? = null
    private var resolvedKey = ""
    private var resolving = false
    private var dlText: String? = null
    private var launched = false
    private var listBox: LinearLayout? = null
    private var statusTv: TextView? = null
    private var cdView: TextView? = null
    private var retryJoin: ((String) -> Unit)? = null
    private var mcLock: WifiManager.MulticastLock? = null
    private var paused = true

    private fun dp(v: Int) = Ui.dp(this, v)

    private val ticker = object : Runnable {
        override fun run() {
            if (paused) return
            refreshDynamic()
            page.postDelayed(this, 1000)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        Versus.init(this)
        val root = FrameLayout(this)
        backdrop = MenuBackdrop(this)
        root.addView(backdrop, Ui.matchParams())
        val dim = View(this)
        dim.setBackgroundColor(0x99000000.toInt())
        root.addView(dim, Ui.matchParams())
        page = FrameLayout(this)
        root.addView(page, Ui.matchParams())
        root.addView(
            LazerBack(this) { back() },
            FrameLayout.LayoutParams(dp(LazerBack.W_DP), dp(LazerBack.H_DP), Gravity.TOP or Gravity.START)
        )
        title = LazerTitle(this, "Multiplayer", L.t("lobi", "lounge"))
        root.addView(title, LazerTitle.params(this))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        paused = false
        backdrop.refresh()
        launched = false
        Versus.listener = this
        Versus.inGame = false
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            mcLock = wm.createMulticastLock("maniadroid").also {
                it.setReferenceCounted(false)
                it.acquire()
            }
        } catch (e: Exception) {
        }
        if (!Versus.inRoom) startBrowse()
        render()
        page.removeCallbacks(ticker)
        page.postDelayed(ticker, 1000)
    }

    override fun onPause() {
        super.onPause()
        paused = true
        LobbyBrowser.stopAll()
        try {
            mcLock?.release()
        } catch (e: Exception) {
        }
        mcLock = null
    }

    override fun onDestroy() {
        super.onDestroy()
        if (Versus.listener === this) Versus.listener = null
    }

    /** Mulai memindai room di jaringan lokal (siaran otomatis) dan memasang pembaruan daftar. */
    private fun startBrowse() {
        LobbyBrowser.onChange = { if (!Versus.inRoom && !Versus.connecting) refreshList() }
        LobbyBrowser.startLan()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        back()
    }

    private fun back() {
        if (Versus.inRoom || Versus.connecting) {
            Versus.leave()
            startBrowse()
            render()
        } else finish()
    }

    // ---------- callback Versus ----------
    override fun onStatus(text: String) {
        statusTv?.text = text
        if (Versus.connecting) render()
    }

    override fun onRoom() = render()
    override fun onCountdown() = refreshDynamic()

    override fun onError(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        render()
    }

    override fun onClosed(reason: String) {
        Toast.makeText(this, reason, Toast.LENGTH_LONG).show()
        val r = retryJoin
        if (r != null && reason.contains("assword")) {
            LDialog.input(this, "Password room", "Password", "", secret = true) { pw -> r(pw) }
        }
        startBrowse()
        render()
    }

    // Catatan: JANGAN bernama onStart() — bentrok dengan siklus hidup Activity dan membuat aplikasi crash.
    override fun onRoundStart() {
        if (launched) return
        if (!Versus.imPlaying) {
            Toast.makeText(this, "Ronde dimulai, tapi kamu belum Siap, jadi tidak ikut. Tunggu ronde berikutnya.", Toast.LENGTH_LONG).show()
            return
        }
        val bm = localBm ?: Versus.chart?.let { Versus.findLocal(this, it) }
        if (bm == null) {
            Toast.makeText(this, "Chart belum ada di HP ini, tidak bisa ikut ronde ini", Toast.LENGTH_LONG).show()
            Versus.sendFinish(Result(IntArray(6), 0, 0f, 0, true))
            return
        }
        launched = true
        Versus.inGame = true
        startActivity(Intent(this, GameActivity::class.java).putExtra("osu", bm.file.path).putExtra("vs", true))
    }

    override fun onResults() {}

    // ---------- bahan tampilan ----------
    private fun card(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(16), dp(12), dp(16), dp(12))
        p.background = Ui.rounded(0xB30B0A12.toInt(), dp(16).toFloat())
        return p
    }

    private fun lp(w: Int, h: Int, top: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(w, h)
        l.topMargin = dp(top)
        return l
    }

    private fun label(s: String): TextView = Ui.text(this, s, 10.5f, Ui.SUB, true).also { it.letterSpacing = 0.15f }

    private fun chip(s: String, color: Int): TextView {
        val c = Ui.text(this, s, 11f, Color.WHITE, true)
        c.gravity = Gravity.CENTER
        c.setPadding(dp(9), dp(3), dp(9), dp(3))
        c.background = Ui.rounded(color, dp(9).toFloat())
        return c
    }

    private fun render() {
        if (!::page.isInitialized) return
        page.removeAllViews()
        listBox = null
        statusTv = null
        cdView = null
        title.setSection(
            when {
                Versus.connecting -> L.t("menghubungkan", "connecting")
                Versus.inRoom -> L.t("room", "match")
                else -> L.t("lobi", "lounge")
            }
        )
        when {
            Versus.connecting -> renderBusy()
            Versus.inRoom -> renderRoom()
            else -> renderLounge()
        }
    }

    private fun renderBusy() {
        val c = card()
        page.addView(c, FrameLayout.LayoutParams(minOf(dp(460), resources.displayMetrics.widthPixels - dp(40)), -2, Gravity.CENTER))
        val st = Ui.text(this, Versus.status.ifEmpty { L.t("Menghubungkan…", "Connecting…") }, 15f, Ui.ACCENT, true)
        statusTv = st
        c.addView(st, lp(-1, -2, 12))
        c.addView(Ui.button(this, "Batal", false, 14) { Versus.leave(); render() }, lp(-1, dp(46), 14))
    }

    // ============================================================ LOUNGE
    private fun renderLounge() {
        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        body.setPadding(dp(18), dp(LazerBack.H_DP + 6), dp(18), dp(14))
        page.addView(body, Ui.matchParams())

        // ---- kiri: aksi ----
        val left = card()
        left.addView(label(L.t("PEMAIN", "PLAYER")))
        val nameRow = LinearLayout(this)
        nameRow.orientation = LinearLayout.HORIZONTAL
        nameRow.gravity = Gravity.CENTER_VERTICAL
        val nm = Ui.text(this, L.t("Bermain sebagai ", "Playing as ") + Versus.displayName(), 12.5f, Ui.ACCENT, true)
        nm.maxLines = 1
        nm.ellipsize = TextUtils.TruncateAt.END
        nameRow.addView(nm, LinearLayout.LayoutParams(0, -2, 1f))
        nameRow.addView(Ui.text(this, "Ubah", 12f, Color.WHITE, true).also {
            it.setPadding(dp(10), dp(4), dp(10), dp(4))
            it.background = Ui.ripple(Ui.rounded(0x33FFFFFF, dp(10).toFloat()))
            it.setOnClickListener { renameDialog() }
        })
        left.addView(nameRow, lp(-1, -2, 2))
        left.addView(Ui.button(this, "Buat room", true, 14) { settingsDialog(true) }, lp(-1, dp(46), 12))
        left.addView(Ui.button(this, "Gabung host hotspot (otomatis)", false, 14) { joinGateway() }, lp(-1, dp(44), 8))
        left.addView(Ui.button(this, "Gabung lewat IP", false, 14) { joinIpDialog() }, lp(-1, dp(44), 6))
        left.addView(Ui.button(this, "Gabung dengan kode (internet)", false, 14) { joinCodeDialog() }, lp(-1, dp(44), 6))
        val ips = MpUtil.localIps()
        left.addView(
            Ui.text(
                this,
                L.t(
                    "Tanpa internet: satu HP buat room dan menyalakan hotspot, HP lain sambung ke hotspot itu lalu room muncul otomatis di daftar. Semua pemain harus memakai ManiaDroid.",
                    "No internet: one phone creates a room and turns on its hotspot, the others connect to that hotspot and the room shows up in the list. Everyone needs ManiaDroid."
                ), 11f, Ui.SUB
            ), lp(-1, -2, 10)
        )
        if (ips.isNotEmpty()) left.addView(Ui.text(this, L.t("IP HP ini: ", "This phone's IP: ") + ips.joinToString(", "), 11f, 0xFFB4B4C8.toInt()), lp(-1, -2, 4))
        val sv0 = ScrollView(this)
        sv0.isVerticalScrollBarEnabled = false
        sv0.addView(left)
        body.addView(sv0, LinearLayout.LayoutParams(0, -1, 0.4f))

        // ---- kanan: daftar room ----
        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(Ui.text(this, "Room yang tersedia", 15f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        val net = Ui.text(this, if (LobbyBrowser.netOn) "Internet: nyala" else "Cari di internet", 12f, Color.WHITE, true)
        net.setPadding(dp(12), dp(6), dp(12), dp(6))
        net.background = Ui.ripple(Ui.rounded(if (LobbyBrowser.netOn) 0xFF3FA66A.toInt() else 0x44FFFFFF, dp(12).toFloat()))
        net.setOnClickListener {
            if (LobbyBrowser.netOn) LobbyBrowser.stopNet() else LobbyBrowser.startNet()
            render()
        }
        head.addView(net)
        right.addView(head, lp(-1, -2))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        listBox = box
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(box)
        right.addView(sv, lp(-1, 0, 8).also { it.weight = 1f })
        body.addView(right, LinearLayout.LayoutParams(0, -1, 0.6f).also { it.leftMargin = dp(14) })
        refreshList()
    }

    private fun refreshList() {
        val box = listBox ?: return
        box.removeAllViews()
        val rooms = LobbyBrowser.snapshot()
        if (rooms.isEmpty()) {
            val msg = if (LobbyBrowser.netOn)
                L.t("Belum ada room. Buat room sendiri, atau tunggu teman membuatnya.", "No rooms yet. Create one, or wait for a friend to.")
            else L.t(
                "Belum ada room di jaringan ini. Pastikan HP-mu satu Wi-Fi / hotspot dengan host, atau tekan Cari di internet.",
                "No rooms on this network yet. Make sure you are on the same Wi-Fi / hotspot as the host, or tap Search internet."
            )
            box.addView(Ui.text(this, msg, 12.5f, Ui.SUB), lp(-1, -2, 8))
            return
        }
        for (r in rooms) box.addView(roomCard(r), lp(-1, -2).also { it.bottomMargin = dp(8) })
    }

    private fun roomCard(r: LobbyBrowser.Room): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(14), dp(10), dp(14), dp(10))
        row.background = Ui.ripple(Ui.rounded(0xB30B0A12.toInt(), dp(14).toFloat()))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(Ui.text(this, r.name, 15f, Color.WHITE, true).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(chip(if (r.key.startsWith("lan:")) "LAN" else "Internet", if (r.key.startsWith("lan:")) 0xFF3F7FBF.toInt() else 0xFF8A5BE0.toInt()), lp(-2, -2).also { it.leftMargin = dp(6) })
        if (r.pw) top.addView(chip(L.t("Password", "Password"), 0xFF8A4A5E.toInt()), lp(-2, -2).also { it.leftMargin = dp(6) })
        col.addView(top)
        val max = if (r.max > 0) "/${r.max}" else ""
        col.addView(
            Ui.text(
                this,
                "${r.host}  ·  ${r.players}$max ${L.t("pemain", "players")}  ·  ${Versus.matchNames[r.matchType.coerceIn(0, 1)]}  ·  ${Versus.winNames[r.winCond.coerceIn(0, 2)]}" +
                        if (r.st == "playing") "  ·  ${L.t("sedang main", "playing")}" else "",
                11.5f, 0xFFC9C9DA.toInt()
            ).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END }
        )
        if (r.chart.isNotEmpty()) col.addView(Ui.text(this, "${r.keys}K  ·  ${r.chart}", 11.5f, Ui.ACCENT, true).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Ui.button(this, "Gabung", true, 12) { joinRoom(r) }, LinearLayout.LayoutParams(dp(96), dp(40)).also { it.leftMargin = dp(10) })
        return row
    }

    private fun joinRoom(r: LobbyBrowser.Room) {
        val go = { pw: String ->
            if (r.key.startsWith("lan:")) joinLan(r.ip, r.port, pw) else joinNet(r.code, pw)
        }
        if (r.pw) LDialog.input(this, "Password room", "Password", "", secret = true) { go(it) } else go("")
    }

    private fun joinLan(ip: String, port: Int, pw: String) {
        retryJoin = { p -> joinLan(ip, port, p) }
        LobbyBrowser.stopAll()
        Versus.joinLan(this, ip, port, pw)
        render()
    }

    private fun joinNet(code: String, pw: String) {
        retryJoin = { p -> joinNet(code, p) }
        LobbyBrowser.stopAll()
        Versus.joinInternet(this, code, pw)
        render()
    }

    private fun joinIpDialog() {
        LDialog.input(this, "Alamat IP host", "contoh 192.168.43.1", "") { v ->
            val s = v.trim()
            if (s.isEmpty()) return@input
            val ip = s.substringBefore(':')
            val port = s.substringAfter(':', "").toIntOrNull() ?: MpConst.LAN_PORT
            joinLan(ip, port, "")
        }
    }

    private fun joinCodeDialog() {
        LDialog.input(this, "Kode room (internet)", "contoh A7K2QM", "") { v ->
            if (v.isNotBlank()) joinNet(v.trim().uppercase(), "")
        }
    }

    @Suppress("DEPRECATION")
    private fun joinGateway() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val g = wm.dhcpInfo?.gateway ?: 0
            if (g == 0) {
                Toast.makeText(this, "Tidak tersambung ke Wi-Fi / hotspot. Sambungkan ke hotspot milik host dulu.", Toast.LENGTH_LONG).show()
                return
            }
            val ip = "${g and 0xFF}.${(g shr 8) and 0xFF}.${(g shr 16) and 0xFF}.${(g shr 24) and 0xFF}"
            joinLan(ip, MpConst.LAN_PORT, "")
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa membaca alamat hotspot. Pakai Gabung lewat IP.", Toast.LENGTH_LONG).show()
        }
    }

    private fun renameDialog() {
        if (Accounts.current() != null) { // sudah punya akun: nama diatur di Profil
            startActivity(Intent(this, ProfileActivity::class.java))
            return
        }
        LDialog.input(this, "Nama pemain", "Nama tampilan", Versus.displayName()) { v ->
            if (v.isNotBlank()) Settings.vsName = v.take(24)
            render()
        }
    }

    // ============================================================ PENGATURAN ROOM (buat / ubah)
    private fun settingsDialog(create: Boolean) {
        val st = MpSettings()
        if (create) {
            st.name = Versus.displayName() + L.t(" - room", " - room")
        } else {
            st.name = Versus.roomName
            st.password = Versus.roomPassword
            st.matchType = Versus.matchType
            st.queueMode = Versus.queueMode
            st.winCond = Versus.winCond
            st.autoStart = Versus.autoStart
            st.maxPlayers = Versus.maxPlayers
            st.listed = Versus.listed
            st.internet = Versus.viaInternet
        }
        val autoVals = intArrayOf(0, 5, 10, 20, 30, 60)
        val maxVals = intArrayOf(0, 2, 4, 8, 16, 32)
        val (dlg, box) = LDialog.make(this, 460)
        LDialog.title(this, box, if (create) "Buat room" else "Pengaturan room")
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL

        fun field(title: String, value: String, hint: String, secret: Boolean = false): EditText {
            list.addView(label(title), lp(-1, -2, 10))
            val e = EditText(this)
            e.setText(value)
            e.hint = L.t(hint)
            e.setHintTextColor(Ui.SUB)
            e.setTextColor(Ui.TEXT)
            e.textSize = 14f
            e.setSingleLine(true)
            Ui.noExtractUi(e)
            e.inputType = android.text.InputType.TYPE_CLASS_TEXT or (if (secret) android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else 0)
            e.background = Ui.rounded(0x33FFFFFF, dp(12).toFloat())
            e.setPadding(dp(14), dp(9), dp(14), dp(9))
            list.addView(e, lp(-1, -2, 4))
            return e
        }

        fun drop(title: String, opts: List<String>, cur: Int, set: (Int) -> Unit) {
            list.addView(label(title), lp(-1, -2, 10))
            var c = cur.coerceIn(0, opts.size - 1)
            val dd = LazerDropdown(this, opts[c])
            dd.setOnClickListener {
                LDialog.pick(this, title, opts, c) { i ->
                    c = i
                    dd.text = opts[i]
                    set(i)
                }
            }
            list.addView(dd, lp(-1, -2, 4))
        }

        val nameE = field("NAMA ROOM", st.name, "Nama room")
        val pwE = field("PASSWORD (KOSONG = TANPA PASSWORD)", st.password, "Tanpa password")
        drop("TIPE MATCH", Versus.matchNames, st.matchType) { st.matchType = it }
        drop("ANTREAN CHART", Versus.queueNames, st.queueMode) { st.queueMode = it }
        drop("KONDISI MENANG", Versus.winNames, st.winCond) { st.winCond = it }
        drop(
            "MULAI OTOMATIS", autoVals.map { if (it == 0) L.t("Mati", "Off") else L.t("$it detik", "$it seconds") },
            autoVals.indexOf(st.autoStart).let { if (it < 0) 0 else it }
        ) { st.autoStart = autoVals[it] }
        drop(
            "BATAS PEMAIN", maxVals.map { if (it == 0) L.t("Tanpa batas", "Unlimited") else "$it" },
            maxVals.indexOf(st.maxPlayers).let { if (it < 0) 0 else it }
        ) { st.maxPlayers = maxVals[it] }
        if (create) {
            drop(
                "JARINGAN",
                listOf(L.t("Wi-Fi / hotspot saja (tanpa internet)", "Wi-Fi / hotspot only (no internet)"), L.t("Wi-Fi / hotspot + internet", "Wi-Fi / hotspot + internet")),
                if (st.internet) 1 else 0
            ) { st.internet = it == 1 }
        }
        drop("TAMPIL DI DAFTAR ROOM INTERNET", listOf(L.t("Ya (publik)", "Yes (public)"), L.t("Tidak (hanya lewat kode)", "No (code only)")), if (st.listed) 0 else 1) { st.listed = it == 0 }

        val maxH = (resources.displayMetrics.heightPixels - dp(170)).coerceAtLeast(dp(160))
        val sv = CappedScroll(this, maxH)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        box.addView(sv, lp(-1, -2, 4))
        LDialog.buttons(
            this, box,
            LDialog.textButton(this, "Batal", false) { dlg.dismiss() },
            LDialog.textButton(this, if (create) "Buat" else "Simpan", true) {
                st.name = nameE.text.toString().trim().ifBlank { st.name }
                st.password = pwE.text.toString().trim()
                dlg.dismiss()
                if (create) {
                    LobbyBrowser.stopAll()
                    Versus.host(this, st)
                    render()
                } else {
                    Versus.updateSettings(
                        JSONObject().put("name", st.name).put("pw", st.password).put("mt", st.matchType).put("qm", st.queueMode)
                            .put("wc", st.winCond).put("as", st.autoStart).put("mx", st.maxPlayers).put("ls", st.listed)
                    )
                }
            }
        )
        dlg.showImmersive(this)
    }

    // ============================================================ ROOM
    private fun resolveChart() {
        val ci = Versus.chart
        val key = ci?.ck ?: ""
        if (key == resolvedKey) return
        resolvedKey = key
        localBm = null
        dlText = null
        if (ci == null || resolving) return
        resolving = true
        Thread {
            val bm = Versus.findLocal(this, ci)
            runOnUiThread {
                resolving = false
                if (resolvedKey == key) {
                    localBm = bm
                    if (bm != null && Settings.vsAutoReady && !Versus.isHost && Versus.me?.ready != true && Versus.state == "lobby") Versus.setReady(true)
                    // lewat Wi-Fi / hotspot chart diambil otomatis dari HP pemiliknya (cepat, tanpa internet)
                    if (bm == null && !Versus.viaInternet && (ci.ownerIp.isNotEmpty() || Versus.hostIp != null) && !Versus.isHost) fetch(ci)
                } else resolvedKey = ""
                render()
            }
        }.start()
    }

    private fun fetch(ci: Versus.ChartInfo) {
        if (dlText != null) return
        dlText = "0%"
        render()
        Thread {
            try {
                Versus.fetchChart(this, ci) { t ->
                    runOnUiThread {
                        dlText = t
                        statusTv?.text = t
                        render()
                    }
                }
                runOnUiThread {
                    dlText = null
                    resolvedKey = ""
                    render()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dlText = null
                    Toast.makeText(this, L.t("Gagal mengambil chart: ${e.message}", "Failed to get chart: ${e.message}"), Toast.LENGTH_LONG).show()
                    render()
                }
            }
        }.start()
    }

    private fun renderRoom() {
        resolveChart()
        val ci = Versus.chart
        val me = Versus.me
        val host = Versus.isHost
        val canPick = host || Versus.queueMode != 0
        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        body.setPadding(dp(18), dp(LazerBack.H_DP + 6), dp(18), dp(14))
        page.addView(body, Ui.matchParams())

        // ---- kiri: info room + chart + antrean ----
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        val info = card()
        val t1 = Ui.text(this, Versus.roomName.ifBlank { "Room" }, 19f, Color.WHITE, true)
        t1.maxLines = 1
        t1.ellipsize = TextUtils.TruncateAt.END
        info.addView(t1)
        info.addView(
            Ui.text(
                this,
                "${Versus.matchNames[Versus.matchType.coerceIn(0, 1)]}  ·  ${Versus.queueNames[Versus.queueMode.coerceIn(0, 2)]}  ·  ${Versus.winNames[Versus.winCond.coerceIn(0, 2)]}",
                11.5f, 0xFFC9C9DA.toInt()
            )
        )
        val codeRow = LinearLayout(this)
        codeRow.orientation = LinearLayout.HORIZONTAL
        codeRow.gravity = Gravity.CENTER_VERTICAL
        if (Versus.viaInternet || !host) {
            if (Versus.viaInternet) {
                val ct = Ui.text(this, Versus.code, 22f, Color.WHITE, true)
                ct.letterSpacing = 0.2f
                codeRow.addView(ct)
                codeRow.addView(Ui.text(this, L.t("  kode internet · ketuk untuk salin", "  internet code · tap to copy"), 10.5f, Ui.ACCENT, true))
                codeRow.setOnClickListener {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("room", Versus.code))
                    Toast.makeText(this, "Kode room disalin", Toast.LENGTH_SHORT).show()
                }
            }
        }
        if (codeRow.childCount > 0) info.addView(codeRow, lp(-1, -2, 4))
        if (host) {
            val ips = MpUtil.localIps()
            if (ips.isNotEmpty()) info.addView(Ui.text(this, L.t("IP LAN: ", "LAN IP: ") + ips.joinToString(", "), 11f, 0xFFB4B4C8.toInt()), lp(-1, -2, 2))
            info.addView(
                Ui.text(this, L.t("Tanpa internet: nyalakan hotspot, suruh teman sambung ke hotspotmu lalu Gabung.", "No internet: turn on your hotspot and have friends connect to it, then Join."), 10.5f, Ui.SUB),
                lp(-1, -2, 2)
            )
        }
        left.addView(info, lp(-1, -2))

        val chartCard = card()
        chartCard.addView(label("CHART"))
        if (ci == null) {
            chartCard.addView(
                Ui.text(this, if (canPick) "Belum ada chart. Pilih satu dari chart di HP-mu." else "Menunggu host memilih chart…", 13f, Color.WHITE),
                lp(-1, -2, 4)
            )
        } else {
            if (ci.setId > 0) {
                val cover = ImageView(this)
                cover.scaleType = ImageView.ScaleType.CENTER_CROP
                cover.background = Ui.rounded(0xFF2B2A3A.toInt(), dp(12).toFloat())
                cover.clipToOutline = true
                Img.load("https://assets.ppy.sh/beatmaps/${ci.setId}/covers/card.jpg", cover)
                chartCard.addView(cover, lp(-1, dp(56), 6))
            }
            chartCard.addView(Ui.text(this, ci.title, 16f, Color.WHITE, true).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END })
            chartCard.addView(Ui.text(this, "${ci.artist}  ·  mapper ${ci.creator}", 11.5f, 0xFFC9C9DA.toInt()).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END })
            chartCard.addView(Ui.text(this, "${ci.keys}K  ·  ${ci.version}  ·  ${ci.notes} note  ·  ${L.t("dipilih ", "picked by ")}${ci.ownerName}", 11.5f, Ui.ACCENT, true).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END })
            val have = localBm != null
            val msg = when {
                resolving -> L.t("Memeriksa chart di HP…", "Checking chart on this phone…")
                dlText != null -> L.t("Mengambil: $dlText", "Getting chart: $dlText")
                have -> L.t("Chart sudah ada di HP-mu", "You have this chart")
                else -> L.t("Chart ini belum ada di HP-mu", "You don't have this chart yet")
            }
            val st = Ui.text(this, msg, 11.5f, if (have) 0xFF7DDC6A.toInt() else 0xFFFFC94D.toInt(), true)
            statusTv = st
            chartCard.addView(st, lp(-1, -2, 4))
        }
        left.addView(chartCard, lp(-1, -2, 8))

        if (Versus.queue.size > 1) {
            val qc = card()
            qc.addView(label(L.t("ANTREAN BERIKUTNYA (${Versus.queue.size - 1})", "UP NEXT (${Versus.queue.size - 1})")))
            for (i in 1 until Versus.queue.size) {
                val q = Versus.queue[i]
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                val tv = Ui.text(this, "${q.artist} - ${q.title} [${q.version}]  ·  ${q.ownerName}", 11.5f, Color.WHITE)
                tv.maxLines = 1
                tv.ellipsize = TextUtils.TruncateAt.END
                r.addView(tv, LinearLayout.LayoutParams(0, -2, 1f))
                if (host || q.ownerId == Versus.myId) {
                    val x = Ui.text(this, "✕", 14f, 0xFFFF9AA8.toInt(), true)
                    x.setPadding(dp(10), dp(4), dp(4), dp(4))
                    x.setOnClickListener { Versus.removeQueue(i) }
                    r.addView(x)
                }
                qc.addView(r, lp(-1, -2, 4))
            }
            left.addView(qc, lp(-1, -2, 8))
        }
        if (canPick) {
            val label = if (Versus.queueMode == 0) (if (ci == null) "Pilih chart" else "Ganti chart") else "Tambah chart ke antrean"
            left.addView(
                Ui.button(this, label, false, 14) {
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent(this, SongSelectActivity::class.java).putExtra("pick", true), 31)
                }, lp(-1, dp(44), 8)
            )
        }
        if (host) left.addView(Ui.button(this, "Pengaturan room", false, 14) { settingsDialog(false) }, lp(-1, dp(44), 6))
        val lsv = ScrollView(this)
        lsv.isVerticalScrollBarEnabled = false
        lsv.addView(left)
        body.addView(lsv, LinearLayout.LayoutParams(0, -1, 0.46f))

        // ---- kanan: pemain + tombol ----
        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        val hrow = LinearLayout(this)
        hrow.orientation = LinearLayout.HORIZONTAL
        hrow.gravity = Gravity.CENTER_VERTICAL
        val cap = if (Versus.maxPlayers > 0) "/${Versus.maxPlayers}" else ""
        hrow.addView(Ui.text(this, L.t("Pemain (${Versus.players.size}$cap)", "Players (${Versus.players.size}$cap)"), 13f, Ui.SUB, true), LinearLayout.LayoutParams(0, -2, 1f))
        if (Versus.matchType == 1 && me != null && Versus.state == "lobby") {
            val other = 1 - me.team.coerceIn(0, 1)
            val sw = Ui.text(this, L.t("Pindah ke tim ${Versus.teamNames[other]}", "Switch to ${Versus.teamNames[other]}"), 11.5f, Color.WHITE, true)
            sw.setPadding(dp(12), dp(5), dp(12), dp(5))
            sw.background = Ui.ripple(Ui.rounded(Versus.TEAM_COLORS[other], dp(12).toFloat()))
            sw.setOnClickListener { Versus.setTeam(other) }
            hrow.addView(sw)
        }
        right.addView(hrow, lp(-1, -2, 0))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        for (p in Versus.players) list.addView(playerRow(p, host), lp(-1, -2).also { it.bottomMargin = dp(5) })
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        right.addView(sv, lp(-1, 0, 6).also { it.weight = 1f })

        val cd = Ui.text(this, "", 12.5f, Ui.ACCENT, true)
        cd.gravity = Gravity.CENTER
        cdView = cd
        right.addView(cd, lp(-1, -2, 4))

        val have = localBm != null
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        val playing = Versus.state == "playing"
        if (ci != null && !have && !resolving && !host) {
            val dl = Ui.button(this, if (dlText != null) "Mengambil…" else "Ambil chart", true, 14) { fetch(ci) }
            dl.isEnabled = dlText == null
            btns.addView(dl, LinearLayout.LayoutParams(0, dp(48), 1.5f))
        } else {
            if (host) {
                val go = Ui.button(this, "Mulai", true, 14) {
                    if (ci == null || !have) Toast.makeText(this, "Pilih chart dulu", Toast.LENGTH_SHORT).show() else Versus.start()
                }
                go.isEnabled = !playing
                btns.addView(go, LinearLayout.LayoutParams(0, dp(48), 1.4f))
            }
            if (!host || Versus.autoStart > 0) {
                val ready = me?.ready == true
                val rb = Ui.button(this, if (ready) "Batal siap" else "Siap", !ready && !host, 14) { Versus.setReady(!ready) }
                rb.isEnabled = ci != null && have && !playing
                btns.addView(rb, LinearLayout.LayoutParams(0, dp(48), 1f).also { if (host) it.leftMargin = dp(8) })
            }
        }
        btns.addView(Ui.button(this, "Keluar room", false, 14) {
            Versus.leave()
            startBrowse()
            render()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).also { it.leftMargin = dp(8) })
        right.addView(btns, lp(-1, -2, 6))
        body.addView(right, LinearLayout.LayoutParams(0, -1, 0.54f).also { it.leftMargin = dp(14) })
        refreshDynamic()
    }

    private fun playerRow(p: Versus.Player, host: Boolean): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(7), dp(10), dp(7))
        row.background = Ui.rounded(if (p.id == Versus.myId) 0x40FF5FA2 else 0x55000000, dp(14).toFloat())
        val team = p.team.coerceIn(0, 1)
        val av = Ui.text(this, p.name.take(1).uppercase(), 15f, Color.WHITE, true)
        av.gravity = Gravity.CENTER
        av.background = Ui.rounded(if (Versus.matchType == 1) Versus.TEAM_COLORS[team] else 0xFF3A3856.toInt(), dp(16).toFloat())
        row.addView(av, LinearLayout.LayoutParams(dp(32), dp(32)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.text(this, p.name, 14f, Color.WHITE, true).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END })
        val sub = StringBuilder()
        if (p.id == Versus.hostId) sub.append("HOST")
        if (Versus.matchType == 1) {
            if (sub.isNotEmpty()) sub.append("  ·  ")
            sub.append(Versus.teamNames[team])
        }
        if (Versus.state == "playing" && p.state != "lobby") {
            if (sub.isNotEmpty()) sub.append("  ·  ")
            sub.append(if (p.finished) L.t("selesai", "finished") else L.t("bermain", "playing")).append("  ").append(p.score)
        }
        if (sub.isNotEmpty()) col.addView(Ui.text(this, sub.toString(), 10.5f, Ui.ACCENT, true))
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = dp(10) })
        val ready = p.id == Versus.hostId || p.ready
        row.addView(
            chip(if (p.id == Versus.hostId) "Host" else if (p.ready) L.t("Siap", "Ready") else L.t("Belum siap", "Not ready"), if (ready) 0xFF3FA66A.toInt() else 0xFF4A4962.toInt())
        )
        if (host && p.id != Versus.myId) {
            val x = Ui.text(this, "✕", 14f, 0xFFFF9AA8.toInt(), true)
            x.setPadding(dp(12), dp(4), dp(4), dp(4))
            x.setOnClickListener {
                LDialog.confirm(this, "Keluarkan ${p.name}?", "Pemain ini dikeluarkan dari room.", "Keluarkan") { Versus.kick(p.id) }
            }
            row.addView(x)
        }
        return row
    }

    /** Bagian yang berubah tiap detik (hitung mundur mulai otomatis) tanpa membangun ulang layar. */
    private fun refreshDynamic() {
        if (Versus.inRoom) {
            val tv = cdView ?: return
            val left = Versus.countdownAt - System.currentTimeMillis()
            tv.text = if (Versus.countdownAt > 0 && left > 0) L.t("Mulai otomatis dalam ${(left + 999) / 1000} detik", "Starting automatically in ${(left + 999) / 1000}s")
            else if (Versus.state == "playing") L.t("Pertandingan sedang berjalan…", "Match in progress…") else ""
        } else if (listBox != null) refreshList()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 31 || res != RESULT_OK) return
        val path = data?.getStringExtra("osu") ?: return
        val bm = Beatmap.parse(File(path), false) ?: return
        localBm = bm
        resolvedKey = Versus.chartKey(bm)
        Versus.addChart(this, bm)
    }
}
