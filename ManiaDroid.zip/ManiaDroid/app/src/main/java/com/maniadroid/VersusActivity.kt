package com.maniadroid

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/** Versus online: lobi room (buat / gabung dengan kode), pilih chart, siap, mulai bersama. */
class VersusActivity : BaseActivity(), Versus.Listener {
    private lateinit var backdrop: MenuBackdrop
    private lateinit var page: FrameLayout
    private var status = ""
    private var localBm: Beatmap? = null
    private var resolvedKey = ""
    private var resolving = false
    private var dlText: String? = null
    private var launched = false
    private lateinit var codeIn: EditText

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        val root = FrameLayout(this)
        backdrop = MenuBackdrop(this)
        root.addView(backdrop, Ui.matchParams())
        val dim = View(this)
        dim.setBackgroundColor(0x99000000.toInt())
        root.addView(dim, Ui.matchParams())
        page = FrameLayout(this)
        root.addView(page, Ui.matchParams())
        root.addView(
            LazerBack(this) { exit() },
            FrameLayout.LayoutParams(dp(LazerBack.W_DP), dp(LazerBack.H_DP), Gravity.TOP or Gravity.START)
        )
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        backdrop.refresh()
        launched = false
        Versus.listener = this
        Versus.inGame = false
        if (!Versus.connected && !Versus.connecting && Settings.vsServer.isNotBlank()) Versus.connect()
        render()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (Versus.listener === this) Versus.listener = null
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        exit()
    }

    private fun exit() {
        if (Versus.inRoom) Versus.leaveRoom()
        Versus.disconnect()
        finish()
    }

    // ---------- callback Versus ----------
    override fun onStatus(text: String) {
        status = text
        render()
    }

    override fun onRoom() = render()
    override fun onScores() {}
    override fun onError(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        render()
    }

    override fun onStart() {
        if (launched) return
        val bm = localBm ?: Versus.chart?.let { Versus.findLocal(this, it) }
        if (bm == null) {
            Toast.makeText(this, "Chart belum ada di HP ini, tidak bisa ikut ronde ini", Toast.LENGTH_LONG).show()
            return
        }
        launched = true
        Versus.inGame = true
        startActivity(Intent(this, GameActivity::class.java).putExtra("osu", bm.file.path).putExtra("vs", true))
    }

    override fun onResults() {}

    // ---------- tampilan ----------
    private fun card(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(18), dp(14), dp(18), dp(14))
        p.background = Ui.rounded(0xB30B0A12.toInt(), dp(18).toFloat())
        return p
    }

    private fun render() {
        if (!::page.isInitialized) return
        page.removeAllViews()
        when {
            Settings.vsServer.isBlank() -> renderNoServer()
            !Versus.connected -> renderConnecting()
            !Versus.inRoom -> renderEntry()
            else -> renderLobby()
        }
    }

    private fun centered(width: Int = 520): LinearLayout {
        val c = card()
        val lp = FrameLayout.LayoutParams(minOf(dp(width), resources.displayMetrics.widthPixels - dp(40)), -2, Gravity.CENTER)
        page.addView(c, lp)
        return c
    }

    private fun renderNoServer() {
        val c = centered()
        c.addView(Ui.text(this, "Versus Online", 24f, Color.WHITE, true))
        c.addView(
            Ui.text(
                this,
                "Versus butuh server (kamu atau temanmu yang menjalankan). Folder versus-server di proyek ini berisi server siap pakai beserta cara memasangnya gratis. Setelah server jalan, isi alamatnya di Pengaturan > Versus (contoh: wss://nama-server.onrender.com).",
                12.5f, 0xFFB4B4C8.toInt()
            ),
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(8) }
        )
        c.addView(Ui.button(this, "Buka Pengaturan", true, 14) { startActivity(Intent(this, SettingsActivity::class.java)) },
            LinearLayout.LayoutParams(-1, dp(46)).also { it.topMargin = dp(14) })
    }

    private fun renderConnecting() {
        val c = centered()
        c.addView(Ui.text(this, "Versus Online", 24f, Color.WHITE, true))
        c.addView(Ui.text(this, Settings.vsServer, 11.5f, Ui.SUB), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(4) })
        val st = if (Versus.connecting) L.t("Menghubungkan…", "Connecting…") else status.ifEmpty { L.t("Belum terhubung", "Not connected") }
        c.addView(Ui.text(this, st, 15f, if (Versus.connecting) Ui.ACCENT else Color.WHITE, true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(12) })
        if (!Versus.connecting) {
            c.addView(Ui.button(this, "Coba lagi", true, 14) { Versus.connect() }, LinearLayout.LayoutParams(-1, dp(46)).also { it.topMargin = dp(14) })
            c.addView(Ui.button(this, "Ubah alamat server", false, 14) { startActivity(Intent(this, SettingsActivity::class.java)) },
                LinearLayout.LayoutParams(-1, dp(46)).also { it.topMargin = dp(8) })
            c.addView(
                Ui.text(this, "Server gratis (mis. Render) bisa butuh ~30 detik untuk bangun saat pertama dipakai; tekan Coba lagi.", 11.5f, Ui.SUB),
                LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(10) }
            )
        }
    }

    private fun renderEntry() {
        val c = centered()
        c.addView(Ui.text(this, "Versus Online", 24f, Color.WHITE, true))
        c.addView(
            Ui.text(this, L.t("Masuk sebagai ", "Signed in as ") + Versus.displayName(), 12.5f, Ui.ACCENT, true),
            LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(2) }
        )
        c.addView(Ui.button(this, "Buat room", true, 14) { Versus.createRoom() }, LinearLayout.LayoutParams(-1, dp(48)).also { it.topMargin = dp(14) })
        c.addView(Ui.text(this, "atau gabung dengan kode room", 12f, Ui.SUB), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(14) })
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        codeIn = EditText(this)
        codeIn.hint = "KODE"
        codeIn.setHintTextColor(Ui.SUB)
        codeIn.setTextColor(Color.WHITE)
        codeIn.textSize = 20f
        codeIn.letterSpacing = 0.3f
        codeIn.gravity = Gravity.CENTER
        codeIn.setSingleLine(true)
        codeIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        Ui.searchField(codeIn) { join() }
        codeIn.background = Ui.rounded(0x33FFFFFF, dp(14).toFloat())
        row.addView(codeIn, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(Ui.button(this, "Gabung", true, 14) { join() }, LinearLayout.LayoutParams(dp(110), dp(48)).also { it.leftMargin = dp(8) })
        c.addView(row, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(6) })
    }

    private fun join() {
        val code = codeIn.text.toString().trim()
        if (code.length < 3) {
            Toast.makeText(this, "Masukkan kode room dulu", Toast.LENGTH_SHORT).show()
            return
        }
        Versus.joinRoom(code)
    }

    // ---------- lobi ----------
    private fun resolveChart() {
        val ci = Versus.chart
        val key = if (ci == null) "" else "${ci.setId}|${ci.version}|${ci.keys}"
        if (key == resolvedKey) return
        resolvedKey = key
        localBm = null
        if (ci == null || resolving) return
        resolving = true
        Thread {
            val bm = Versus.findLocal(this, ci)
            runOnUiThread {
                resolving = false
                if (resolvedKey == key) localBm = bm
                else resolvedKey = "" // chart berganti selagi mencari: cari lagi
                render()
            }
        }.start()
    }

    private fun renderLobby() {
        resolveChart()
        val ci = Versus.chart
        val me = Versus.me
        val host = Versus.isHost
        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        body.setPadding(dp(18), dp(LazerBack.H_DP + 8), dp(18), dp(14))
        page.addView(body, Ui.matchParams())

        // ---- kiri: kode + chart ----
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        val codeCard = card()
        codeCard.addView(Ui.text(this, "KODE ROOM", 10.5f, Ui.SUB, true).also { it.letterSpacing = 0.15f })
        val codeTv = Ui.text(this, Versus.code, 38f, Color.WHITE, true)
        codeTv.letterSpacing = 0.25f
        codeCard.addView(codeTv)
        codeCard.addView(Ui.text(this, "Ketuk untuk menyalin dan kirim ke temanmu", 11f, Ui.ACCENT))
        codeCard.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("room", Versus.code))
            Toast.makeText(this, "Kode room disalin", Toast.LENGTH_SHORT).show()
        }
        left.addView(codeCard, LinearLayout.LayoutParams(-1, -2))

        val chartCard = card()
        chartCard.addView(Ui.text(this, "CHART", 10.5f, Ui.SUB, true).also { it.letterSpacing = 0.15f })
        if (ci == null) {
            chartCard.addView(
                Ui.text(this, if (host) "Belum ada chart. Pilih satu dari chart yang sudah ada di HP-mu." else "Menunggu host memilih chart…", 13f, Color.WHITE),
                LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(4) }
            )
        } else {
            val cover = ImageView(this)
            cover.scaleType = ImageView.ScaleType.CENTER_CROP
            cover.background = Ui.rounded(0xFF2B2A3A.toInt(), dp(12).toFloat())
            cover.clipToOutline = true
            Img.load("https://assets.ppy.sh/beatmaps/${ci.setId}/covers/card.jpg", cover)
            chartCard.addView(cover, LinearLayout.LayoutParams(-1, dp(64)).also { it.topMargin = dp(6) })
            chartCard.addView(Ui.text(this, ci.title, 16f, Color.WHITE, true).also { it.maxLines = 1; it.ellipsize = android.text.TextUtils.TruncateAt.END })
            chartCard.addView(Ui.text(this, "${ci.artist}  ·  mapper ${ci.creator}", 11.5f, 0xFFC9C9DA.toInt()).also { it.maxLines = 1; it.ellipsize = android.text.TextUtils.TruncateAt.END })
            chartCard.addView(Ui.text(this, "${ci.keys}K  ·  ${ci.version}  ·  ${ci.notes} note", 11.5f, Ui.ACCENT, true).also { it.maxLines = 1; it.ellipsize = android.text.TextUtils.TruncateAt.END })
            val have = localBm != null
            val msg = when {
                resolving -> L.t("Memeriksa chart di HP…", "Checking chart on this phone…")
                dlText != null -> L.t("Mengunduh: $dlText", "Downloading: $dlText")
                have -> L.t("Chart sudah ada di HP-mu", "You have this chart")
                else -> L.t("Chart ini belum ada di HP-mu", "You don't have this chart yet")
            }
            chartCard.addView(Ui.text(this, msg, 11.5f, if (have) 0xFF7DDC6A.toInt() else 0xFFFFC94D.toInt(), true), LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(4) })
        }
        left.addView(chartCard, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(10) })
        if (host) {
            left.addView(
                Ui.button(this, if (ci == null) "Pilih chart" else "Ganti chart", false, 14) {
                    @Suppress("DEPRECATION")
                    startActivityForResult(Intent(this, SongSelectActivity::class.java).putExtra("pick", true), 31)
                },
                LinearLayout.LayoutParams(-1, dp(46)).also { it.topMargin = dp(10) }
            )
        }
        body.addView(left, LinearLayout.LayoutParams(0, -1, 0.46f))

        // ---- kanan: pemain + tombol ----
        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        for (p in Versus.players) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(8), dp(12), dp(8))
            row.background = Ui.rounded(if (p.id == Versus.myId) 0x40FF5FA2 else 0x55000000, dp(14).toFloat())
            val av = ImageView(this)
            av.scaleType = ImageView.ScaleType.CENTER_CROP
            av.background = Ui.rounded(0xFF3A3856.toInt(), dp(12).toFloat())
            av.clipToOutline = true
            if (p.avatar.startsWith("http")) Img.load(p.avatar, av)
            row.addView(av, LinearLayout.LayoutParams(dp(36), dp(36)))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(Ui.text(this, p.name, 14.5f, Color.WHITE, true).also { it.maxLines = 1; it.ellipsize = android.text.TextUtils.TruncateAt.END })
            if (p.id == Versus.hostId) col.addView(Ui.text(this, "HOST", 9.5f, Ui.ACCENT, true).also { it.letterSpacing = 0.15f })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = dp(10) })
            val ready = p.id == Versus.hostId || p.ready
            val chip = Ui.text(this, if (p.id == Versus.hostId) "Host" else if (p.ready) "Siap" else "Belum siap", 11.5f, Color.WHITE, true)
            chip.gravity = Gravity.CENTER
            chip.setPadding(dp(10), dp(4), dp(10), dp(4))
            chip.background = Ui.rounded(if (ready) 0xFF3FA66A.toInt() else 0xFF4A4962.toInt(), dp(10).toFloat())
            row.addView(chip)
            list.addView(row, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = dp(6) })
        }
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(list)
        right.addView(Ui.text(this, L.t("Pemain (${Versus.players.size})", "Players (${Versus.players.size})"), 12f, Ui.SUB, true), LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = dp(6) })
        right.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val have = localBm != null
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        if (host) {
            val go = Ui.button(this, "Mulai", true, 14) {
                if (!have) Toast.makeText(this, "Pilih chart dulu", Toast.LENGTH_SHORT).show() else Versus.start()
            }
            btns.addView(go, LinearLayout.LayoutParams(0, dp(48), 1.5f))
        } else if (ci != null && !have && !resolving) {
            val dl = Ui.button(this, if (dlText != null) "Mengunduh…" else "Unduh chart", true, 14) { downloadChart(ci) }
            dl.isEnabled = dlText == null
            btns.addView(dl, LinearLayout.LayoutParams(0, dp(48), 1.5f))
        } else {
            val ready = me?.ready == true
            val rb = Ui.button(this, if (ready) "Batal siap" else "Siap", !ready, 14) { Versus.setReady(!ready) }
            rb.isEnabled = ci != null && have
            btns.addView(rb, LinearLayout.LayoutParams(0, dp(48), 1.5f))
        }
        btns.addView(Ui.button(this, "Keluar room", false, 14) {
            Versus.leaveRoom()
            render()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).also { it.leftMargin = dp(8) })
        right.addView(btns, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(8) })
        body.addView(right, LinearLayout.LayoutParams(0, -1, 0.54f).also { it.leftMargin = dp(14) })
    }

    private fun downloadChart(ci: Versus.ChartInfo) {
        if (dlText != null) return
        dlText = "0%"
        render()
        Thread {
            try {
                Downloader.download(this, ci.setId) { t ->
                    runOnUiThread {
                        dlText = t
                        render()
                    }
                }
                runOnUiThread {
                    dlText = null
                    resolvedKey = ""
                    render()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dlText = null
                    Toast.makeText(this, L.t("Gagal unduh: ${e.message}", "Download failed: ${e.message}"), Toast.LENGTH_LONG).show()
                    render()
                }
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 31 || res != RESULT_OK) return
        val path = data?.getStringExtra("osu") ?: return
        val bm = Beatmap.parse(File(path), false) ?: return
        val id = Versus.setIdOf(bm)
        if (id <= 0) {
            Toast.makeText(this, "Chart ini tidak punya ID osu! (bukan hasil unduhan), lawan tidak bisa mengunduhnya. Pilih chart dari menu Unduh.", Toast.LENGTH_LONG).show()
            return
        }
        localBm = bm
        resolvedKey = "${id}|${bm.version}|${bm.keys}"
        Versus.setChart(id, bm)
    }
}
