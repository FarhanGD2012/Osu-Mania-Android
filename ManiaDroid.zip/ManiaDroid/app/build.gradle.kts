plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.maniadroid"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.maniadroid"
        minSdk = 24
        targetSdk = 34
        versionCode = 12
        versionName = "2.0.1"
    }

    // Keystore tetap: build di GitHub (runner selalu baru) tetap bertanda tangan sama,
    // jadi APK baru bisa menimpa APK lama tanpa uninstall.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
