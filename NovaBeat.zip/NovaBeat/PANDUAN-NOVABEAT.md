# PANDUAN NOVA BEAT — server gratis, avatar 7 hari, room multiplayer, keystore rilis

Semua langkah di bawah memakai layanan **gratis tanpa kartu kredit/debit**: GitHub, Turso, Render, cron-job.org, dan alat bawaan (keytool).
Hal yang **sengaja dihindari** karena butuh kartu: Fly.io (default lama di `Cloud.kt`, sudah diganti), Google Play (biaya pendaftaran), Cloudflare R2, AWS/GCP/Azure.

> Batas gratis berubah dari waktu ke waktu. Angka di bawah dicek saat panduan ini dibuat (28 Nov 2026); cek ulang di halaman harga masing-masing sebelum berharap banyak.

---
## 0. Yang berubah di proyek ini
| Area | Perubahan |
|---|---|
| Akun | Tetap username + sandi (Argon2id), tanpa email. Penguncian login kini tersimpan di database (tahan restart). |
| Foto profil | Maks **1x / 7 hari**, dicatat di database (kolom `avatar_changed_at`). Hapus foto selalu boleh. Respons 429 berbahasa Indonesia dengan sisa waktu + tanggal. |
| Android | Alamat server lewat build (`NOVABEAT_SERVER_URL`) + dialog "Alamat server" (validasi, simpan & tes). Token sesi dienkripsi dengan Android Keystore. Pesan galat jaringan berbahasa Indonesia. Foto baru hanya dipakai di HP bila server menerima. |
| Multiplayer | Jalur ketiga **"Server Nova Beat"** (selain Wi-Fi/hotspot dan MQTT): buat/gabung room, siap, pilih lagu, skor langsung, peringkat. Timing note tetap lokal. |
| Keamanan | Pembatas laju memori diberi batas ukuran & IP aman dari pemalsuan header; `keepAliveTimeout`; SIGTERM rapi; dukungan keystore rilis. |

---
## 1. Siapkan server gratis (sekali saja)
### 1.1 Database Turso (tanpa kartu)
1. Buka https://turso.tech → **Sign up** (GitHub/email).
2. Buat database baru (pilih lokasi terdekat, mis. Singapore). Nama bebas, mis. `novabeat`.
3. Di dashboard database: salin **URL** (`libsql://novabeat-namamu.turso.io`).
4. Buat **token** (Create Token, akses read & write) lalu salin. Simpan keduanya di tempat aman.
Jatah gratis (saat dicek): ±5 GB penyimpanan, ±500 juta baris dibaca, ±10 juta baris ditulis per bulan. Melebihi jatah → permintaan **ditolak** (tidak ditagih) kecuali kamu sendiri mengaktifkan pembayaran lebih. Server ini hemat jatah: sesi/skor saja yang menulis, papan global di-cache 15 detik, room multiplayer **tidak** menulis ke database.

### 1.2 Hosting Render (tanpa kartu)
1. Taruh folder proyek di repo GitHub-mu (sudah ada: repo build APK-mu).
2. https://render.com → Sign up dengan GitHub → **New → Web Service** → pilih repo.
3. Isi: **Root Directory** `NovaBeat/server` (sesuaikan dengan lokasi folder `server` di repo), **Runtime** Node, **Build Command** `npm install`, **Start Command** `npm start`, **Instance Type: Free**.
4. **Environment** (Add variable):
   - `TURSO_DATABASE_URL` = URL dari 1.1
   - `TURSO_AUTH_TOKEN` = token dari 1.1
   - `TRUST_PROXY` = `1`
   - `NODE_VERSION` = `22.13.0`
5. **Create Web Service**. Tunggu "Live". Alamatmu: `https://nama-layananmu.onrender.com`.
6. Tes di browser: `https://nama-layananmu.onrender.com/api/health` → `{"ok":true,...}`.

Sifat paket gratis Render: layanan **tidur** setelah ±15 menit tanpa lalu lintas dan butuh ±1 menit untuk bangun; disk-nya sementara (karena itu data ada di Turso — akun & skor aman). Room multiplayer yang sedang berjalan menghitung sebagai lalu lintas, jadi server tidak tidur saat ada yang main.
Opsional agar tidak tidur: buat cron gratis di https://cron-job.org yang membuka `/api/health` tiap 10 menit. Satu layanan 24 jam ≈ 744 jam, masih di bawah jatah jam gratis bulanan, tetapi cek kebijakan Render terbaru; tanpa ini pun aplikasi sudah menunggu server bangun (tombol "Tes koneksi" dan pesan "bisa sampai 1 menit").

### 1.3 Periksa IP untuk pembatas laju (penting)
Buka `https://alamatmu/api/whoami` dari HP (data seluler, bukan Wi-Fi rumah) dan bandingkan `ip` dengan IP publik HP-mu (cari "what is my ip"). Lalu uji pemalsuan:
`curl -H "X-Forwarded-For: 1.2.3.4" https://alamatmu/api/whoami`
- Bila `ip` tetap IP aslimu → pengaturan sudah benar.
- Bila `ip` menjadi `1.2.3.4` → header bisa dipalsukan: tambah variabel `TRUST_PROXY_HOPS` = `2` (atau sesuaikan sampai `ip` benar), atau `IP_HEADER` bila hosting menyediakan header IP khusus.
- Bila `ip` selalu sama untuk semua orang (IP proxy) → naikkan/turunkan `TRUST_PROXY_HOPS` sampai benar. Dokumentasi Render soal urutan X-Forwarded-For tidak jelas, jadi pengecekan ini yang menentukan.

---
## 2. Arahkan aplikasi ke servermu
**Cara 1 (disarankan, tanpa ubah kode):** di repo GitHub → Settings → Secrets and variables → Actions → tab **Variables** → New repository variable: `NOVABEAT_SERVER_URL` = `https://nama-layananmu.onrender.com`. Build GitHub Actions berikutnya memakainya sebagai alamat bawaan.
**Cara 2 (lokal):** `gradle assembleDebug -Pnovabeat.serverUrl=https://nama-layananmu.onrender.com`.
**Cara 3 (pemain):** Profil → **Alamat server** → ketik alamat (boleh tanpa `https://`) → **Simpan & tes**. Pindah server otomatis keluar dari akun (token server lama tidak berlaku di server baru). Ada juga tombol **Tes koneksi server**.
`http://` hanya diterima untuk jaringan lokal (localhost, 192.168.x.x, 10.x.x.x), supaya sandi dan token tidak lewat internet tanpa enkripsi.

Pesan galat yang kini tampil jelas: server tidak ditemukan, waktu habis (server sedang bangun), HTTPS gagal (cek tanggal/jam HP), 404/429/502-504/5xx, sesi habis, dst.

---
## 3. Batas ganti foto profil (1x / 7 hari)
Aturan di server (`POST /api/me/avatar`):
- Unggah foto: boleh bila belum pernah, atau sudah ≥ 7×86.400.000 ms sejak unggah terakhir (`avatar_changed_at` di tabel `users`, jadi tahan restart/tidur).
- Pembaruan **atomik** (`UPDATE … WHERE avatar_changed_at <= sekarang-7hari`): dua permintaan bersamaan tidak bisa sama-sama lolos.
- Belum 7 hari → **429** `{"error":"avatar_dibatasi","message":"Foto profil hanya bisa diganti 1 kali setiap 7 hari. Kamu bisa menggantinya lagi dalam sekitar 3 hari 5 jam, yaitu pada Jumat, 4 Desember 2026 pukul 14.30 WIB. Menghapus foto tetap boleh kapan saja.","retry_at":…,"retry_after_seconds":…}` + header `Retry-After`.
- `{"remove":true}` selalu diizinkan dan **tidak** me-reset hitungan (supaya "hapus lalu unggah" tidak menembus batas).
- Akun lama: hitungan dimulai dari waktu unggah foto terakhirnya (migrasi otomatis saat server start).
Di aplikasi: tombol "Ganti foto profil" lebih dulu menampilkan sisa waktu (dalam zona waktu HP) tanpa membuka galeri; foto baru dikirim dulu, dan baru dipakai di HP setelah server menerima (sebelumnya foto lokal berubah walau server menolak).

---
## 4. Multiplayer lewat server
### Cara pakai
- **Buat room:** Multiplayer → Buat room → JARINGAN = **Server Nova Beat** → Buat. Perlu masuk akun. Kode room berawalan **S** (mis. `S7K2QM`).
- **Gabung:** pilih dari daftar (tekan "Cari di internet": daftar server ikut tampil) atau **Gabung dengan kode** (kode berawalan S otomatis ke server).
- Pilih lagu (mode Host saja / Semua pemain / Bergiliran), siap, host menekan Mulai: semua HP mulai bersamaan (aba-aba 5 detik + sinkron jam ping/pong), skor teman tampil langsung, peringkat muncul di akhir.
- Bila host keluar, host pindah otomatis ke pemain tertua (di jalur HP-host, room bubar). Room kosong dihapus.
- Voice chat **tidak** tersedia di room server (hanya Wi-Fi/hotspot dan MQTT).

### Mengapa ketukan tidak lag
Server **tidak** menghitung apa pun soal permainan. Note, timing, hit-window, skor dihitung lokal di HP (GameView). Server hanya: (1) mengirim satu waktu mulai bersama, (2) menyiarkan angka skor/progres ±4x per detik untuk papan skor di layar, (3) menyusun peringkat. Ping tinggi hanya membuat papan skor teman telat sedikit, bukan ketukanmu.

### Ringan & gratis
Room hanya di memori (tanpa tulis database). Pembatas: 16 pemain/room, 60 room, 300 koneksi, 40 pesan/detik/pemain, pesan maks 16 KB, satu akun satu room aktif, 12 room dibuat/jam/akun. Siaran skor tumbuh ±kuadrat jumlah pemain, itu sebabnya batas 16 (ubah dengan `ROOM_MAX_PLAYERS`). Jika server restart/tidur, room hilang dan pemain mendapat pesan "Room ditutup".
Lagu: pemain tanpa file chart mengunduhnya dari mirror berdasarkan ID set (sama seperti room internet), bukan lewat server.

### Protokol (untuk pengembang)
Pesan JSON sama dengan jalur lain: klien→server `ready, team, chart, unq, settings, kick, start, score, finish, ping, leave`; server→klien `welcome, room, cd, start, scores, results, error, kicked, closed, left, pong`. Pesan pertama klien wajib `{"t":"create","token":…,"settings":{…}}` atau `{"t":"join","token":…,"code":"S…","pw":"…"}`.

---
## 5. Evaluasi pembatas laju
| Hal | Temuan | Tindakan |
|---|---|---|
| `hits = new Map()` di memori | Cepat dan gratis, tetapi hilang saat restart/tidur dan tidak dibagi bila ada >1 instans; kuncinya tumbuh tanpa batas | Tetap dipakai untuk lalu lintas umum; kini dibatasi 50.000 kunci (buang yang kedaluwarsa lalu yang tertua) |
| Penguncian per nama (`loginu:`) | Orang iseng bisa mengunci akun korban dari IP mana pun | Diganti 3 hitungan di **database**: nama+IP (8/15 mnt), nama saja (60/jam), IP saja (40/15 mnt). Hanya menulis saat login **gagal**, jadi hemat jatah tulis |
| Alamat IP | Mengambil entri pertama `X-Forwarded-For` bisa dipalsukan | Ambil dari kanan sesuai `TRUST_PROXY_HOPS`, atau `IP_HEADER`; cek via `/api/whoami` |
| Banyak pemain satu IP (CGNAT seluler) | Batas ketat per IP bisa menghukum orang tak bersalah | Batas IP dibuat longgar; batas ketat per akun |
| Lain-lain | — | `keepAliveTimeout` 65 dtk (hindari 502 acak), SIGTERM menutup room dengan rapi |
Bila suatu saat memakai >1 instans, pindahkan pembatas panas ke penyimpanan bersama (mis. tabel Turso dengan jendela waktu) — belum perlu di paket gratis (1 instans).

---
## 6. Pemeliharaan database
- Rutin: `npm run maintain` (dengan variabel Turso diisi di komputer) → hapus sesi kedaluwarsa & hitungan gagal lama, tampilkan jumlah baris, jumlah/ukuran foto, perkiraan ukuran DB. Server juga membersihkan sesi/hitungan gagal otomatis tiap start dan tiap menit.
- **VACUUM:** `npm run maintain -- --vacuum` mencoba memadatkan file. Dukungan VACUUM di Turso Cloud tidak terjamin (skrip akan melaporkan jika ditolak dan tidak mengubah apa pun). Menghapus baris tidak membuat DB membengkak (halaman kosong dipakai ulang), jadi VACUUM hanya berguna setelah menghapus data besar sekaligus.
- **Cadangan gratis:** pasang Turso CLI (https://docs.turso.tech/cli/installation) lalu `turso db shell NAMA-DB .dump > cadangan.sql`. Memulihkan/memindahkan: `turso db create db-baru --from-dump cadangan.sql` (cek `turso db create --help` bila opsi berubah). Ini juga cara "memadatkan" bila VACUUM ditolak.
- **Foto profil:** disimpan sebagai BLOB di tabel `users`, ≤80 KB (praktisnya ±10 KB karena 160×160). 5 GB ≈ ratusan ribu foto, jadi aman untuk waktu lama. **Pisahkan foto bila** `maintenance.js` memperingatkan (>1,5 GB) atau pembacaan baris mendekati jatah:
  1. Buat tabel `avatars(user_id INTEGER PRIMARY KEY, jpeg BLOB NOT NULL, updated_at INTEGER NOT NULL)`.
  2. Salin: `INSERT INTO avatars SELECT id, avatar, avatar_at FROM users WHERE avatar IS NOT NULL;`
  3. Ubah `claimAvatar`, `clearAvatar`, dan route `GET /api/users/:id/avatar` agar memakai tabel itu (kolom `avatar_at` & `avatar_changed_at` tetap di `users`), lalu `UPDATE users SET avatar = NULL`.
  4. Bila masih kurang: database Turso kedua khusus foto (jatah gratis per akun mencakup banyak database) atau layanan gambar gratis tanpa kartu. Hindari yang meminta kartu.
  Keuntungan: tabel `users` yang sering dibaca (login, pencarian) tetap kecil.

---
## 7. Keystore rilis Android (produksi)
Penting: APK dengan tanda tangan berbeda **tidak bisa menimpa** APK lama. Pemain yang memasang build debug harus **uninstall dulu** saat pertama kali pindah ke build rilis (data lokal hilang; akun server aman). Putuskan ini sekali, sebelum game menyebar luas. **Jangan pernah kehilangan keystore**: tanpa itu kamu tidak bisa merilis pembaruan yang bisa menimpa versi lama.

1. Buat keystore (di komputer dengan Java; `keytool` ikut JDK, gratis):
   ```
   keytool -genkeypair -v -keystore novabeat-release.jks -alias novabeat -keyalg RSA -keysize 4096 -validity 10000
   ```
   Isi kata sandi keystore & kunci (pakai sandi panjang), nama/organisasi bebas.
2. **Cadangkan** `novabeat-release.jks` + kedua sandi di ≥2 tempat aman (pengelola sandi, flashdisk). **Jangan commit ke Git** (tambahkan `*.jks` ke `.gitignore`).
3. Build lokal: 
   ```
   NOVABEAT_KEYSTORE_FILE=/jalur/novabeat-release.jks NOVABEAT_KEYSTORE_PASSWORD=… NOVABEAT_KEY_ALIAS=novabeat NOVABEAT_KEY_PASSWORD=… gradle assembleRelease
   ```
4. Build di GitHub Actions: ubah keystore ke base64 (`base64 -w0 novabeat-release.jks`), lalu di repo → Settings → Secrets and variables → Actions → **Secrets**: `NOVABEAT_KEYSTORE_B64` (hasil base64), `NOVABEAT_KEYSTORE_PASSWORD`, `NOVABEAT_KEY_ALIAS`, `NOVABEAT_KEY_PASSWORD`. Workflow `build.yml` otomatis membuat artifact **NovaBeat-release-apk** bila rahasia terisi; bila tidak, hanya APK debug seperti biasa.
5. Verifikasi tanda tangan: `apksigner verify --print-certs app-release.apk` (dari Android SDK build-tools).
6. Unggah APK ke GameJolt/GameBanana/GitHub Releases (gratis). Google Play dihindari karena biaya pendaftaran.

---
## 8. Hasil pengujian di lingkungan penyusunan (jujur soal batasnya)
- Uji server `npm test` (akun, sesi, skor, PP sekali per map, teman, leaderboard, avatar 7 hari termasuk balapan & Retry-After, penguncian login) → **lulus**. Uji room `node test-rooms.js` (buat/gabung/password/penuh/siap/pilih lagu/skor di-clamp/hasil/host pindah/banjir pesan/jalur WS salah) → **lulus**.
- Pengujian memakai pengganti lokal untuk `argon2` (scrypt) dan `@libsql/client` (SQLite bawaan Node) karena tidak ada internet di sana. **Argon2 asli dan Turso asli belum teruji di sini** — jalankan `npm install && npm test` di komputermu / lihat log Render saat deploy pertama.
- **Kode Kotlin belum dikompilasi** (tidak ada Gradle/Kotlin di lingkungan itu); hanya diperiksa dengan membaca & pemeriksaan kurung. Build lewat GitHub Actions; bila ada galat kompilasi, kirim lognya.
- Klien Android room-server memakai OkHttp 4.12 (gratis, sumber terbuka) — satu-satunya dependensi baru.
