'use strict';
/**
 * Nova Beat server: akun (Argon2id), profil, teman, dan leaderboard.
 * Node >= 22.13 (memakai node:sqlite bawaan) + paket `argon2`. Tanpa framework lain.
 *
 * Aturan PP (ala level rated Geometry Dash): satu map hanya memberi PP SEKALI per akun, yaitu saat pertama kali
 * ditamatkan. Penanda ada di tabel map_completions dengan UNIQUE(user_id, map_id). Tamat ulang hanya memperbarui
 * skor / akurasi terbaik di tabel scores, tidak menambah PP.
 */
const http = require('node:http');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const argon2 = require('argon2');

const ARGON_OPTS = { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 }; // rekomendasi OWASP
const SESSION_DAYS = 180;
const MAX_BODY = 200 * 1024;
const MAX_AVATAR = 80 * 1024;
const MAX_PP_PER_MAP = 2000; // batas kewajaran; klien yang menghitung PP, server hanya membatasi

const USERNAME_RE = /^[A-Za-z0-9_.-]{3,20}$/;
const MAPID_RE = /^[A-Za-z0-9:_.\-]{1,64}$/;

function openDb(file) {
  const db = new DatabaseSync(file);
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      bio           TEXT NOT NULL DEFAULT '',
      avatar        BLOB,
      avatar_at     INTEGER NOT NULL DEFAULT 0,
      created_at    INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      created_at INTEGER NOT NULL,
      last_used  INTEGER NOT NULL
    );
    -- Penanda "map sudah pernah ditamatkan / PP sudah diklaim".
    CREATE TABLE IF NOT EXISTS map_completions (
      user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      map_id       TEXT NOT NULL,
      pp_awarded   REAL NOT NULL,
      completed_at INTEGER NOT NULL,
      UNIQUE (user_id, map_id)
    );
    -- Skor terbaik tiap pemain per map (satu baris per pemain per map).
    CREATE TABLE IF NOT EXISTS scores (
      user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      map_id      TEXT NOT NULL,
      map_title   TEXT NOT NULL DEFAULT '',
      score       INTEGER NOT NULL,
      accuracy    REAL NOT NULL,
      max_combo   INTEGER NOT NULL DEFAULT 0,
      achieved_at INTEGER NOT NULL,
      plays       INTEGER NOT NULL DEFAULT 1,
      UNIQUE (user_id, map_id)
    );
    CREATE INDEX IF NOT EXISTS idx_scores_map ON scores (map_id, score DESC);
    CREATE INDEX IF NOT EXISTS idx_comp_user ON map_completions (user_id);
    CREATE TABLE IF NOT EXISTS friendships (
      requester_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      addressee_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      status       TEXT NOT NULL CHECK (status IN ('pending', 'accepted')),
      created_at   INTEGER NOT NULL,
      UNIQUE (requester_id, addressee_id)
    );
    CREATE INDEX IF NOT EXISTS idx_friend_addr ON friendships (addressee_id);
  `);
  return db;
}

class HttpError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

function cleanText(s, max) {
  return String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, max);
}

function sha256(s) {
  return crypto.createHash('sha256').update(s).digest('hex');
}

function createApp(opts = {}) {
  const dataDir = opts.dataDir || process.env.DATA_DIR || path.join(__dirname, 'data');
  if (opts.dbFile !== ':memory:') fs.mkdirSync(dataDir, { recursive: true });
  const db = openDb(opts.dbFile || path.join(dataDir, 'novabeat.db'));
  const trustProxy = opts.trustProxy ?? process.env.TRUST_PROXY === '1';

  const q = {
    userByName: db.prepare('SELECT * FROM users WHERE username = ?'),
    userById: db.prepare('SELECT * FROM users WHERE id = ?'),
    insertUser: db.prepare('INSERT INTO users (username, password_hash, created_at) VALUES (?, ?, ?)'),
    updatePw: db.prepare('UPDATE users SET password_hash = ? WHERE id = ?'),
    updateBio: db.prepare('UPDATE users SET bio = ? WHERE id = ?'),
    setAvatar: db.prepare('UPDATE users SET avatar = ?, avatar_at = ? WHERE id = ?'),
    insertSession: db.prepare('INSERT INTO sessions (token_hash, user_id, created_at, last_used) VALUES (?, ?, ?, ?)'),
    sessionUser: db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.last_used > ?'),
    touchSession: db.prepare('UPDATE sessions SET last_used = ? WHERE token_hash = ?'),
    delSession: db.prepare('DELETE FROM sessions WHERE token_hash = ?'),
    delUserSessions: db.prepare('DELETE FROM sessions WHERE user_id = ?'),
    purgeSessions: db.prepare('DELETE FROM sessions WHERE last_used < ?'),
    insertCompletion: db.prepare('INSERT OR IGNORE INTO map_completions (user_id, map_id, pp_awarded, completed_at) VALUES (?, ?, ?, ?)'),
    getCompletion: db.prepare('SELECT pp_awarded, completed_at FROM map_completions WHERE user_id = ? AND map_id = ?'),
    getScore: db.prepare('SELECT * FROM scores WHERE user_id = ? AND map_id = ?'),
    insertScore: db.prepare('INSERT INTO scores (user_id, map_id, map_title, score, accuracy, max_combo, achieved_at) VALUES (?, ?, ?, ?, ?, ?, ?)'),
    updateScoreBest: db.prepare('UPDATE scores SET map_title = ?, score = ?, accuracy = ?, max_combo = ?, achieved_at = ?, plays = plays + 1 WHERE user_id = ? AND map_id = ?'),
    bumpPlays: db.prepare('UPDATE scores SET plays = plays + 1 WHERE user_id = ? AND map_id = ?'),
    totalPp: db.prepare('SELECT COALESCE(SUM(pp_awarded), 0) AS t, COUNT(*) AS n FROM map_completions WHERE user_id = ?'),
    globalRankOf: db.prepare('SELECT COUNT(*) + 1 AS r FROM (SELECT user_id FROM map_completions GROUP BY user_id HAVING SUM(pp_awarded) > ?)'),
    mapRankOf: db.prepare('SELECT COUNT(*) + 1 AS r FROM scores WHERE map_id = ? AND (score > ? OR (score = ? AND achieved_at < ?))'),
    userStats: db.prepare('SELECT COUNT(*) AS maps, COALESCE(SUM(plays), 0) AS plays, COALESCE(AVG(accuracy), 0) AS avg_acc, COALESCE(MAX(score), 0) AS best FROM scores WHERE user_id = ?'),
    recent: db.prepare(`SELECT s.map_id, s.map_title, s.score, s.accuracy, s.achieved_at, COALESCE(c.pp_awarded, 0) AS pp
      FROM scores s LEFT JOIN map_completions c ON c.user_id = s.user_id AND c.map_id = s.map_id
      WHERE s.user_id = ? ORDER BY s.achieved_at DESC LIMIT 5`),
    search: db.prepare(`SELECT u.id, u.username, u.avatar_at,
        COALESCE((SELECT SUM(pp_awarded) FROM map_completions WHERE user_id = u.id), 0) AS total_pp
      FROM users u WHERE u.username LIKE ? ESCAPE '\\' AND u.id != ? ORDER BY (u.username LIKE ? ESCAPE '\\') DESC, u.username COLLATE NOCASE LIMIT 30`),
    friendRow: db.prepare('SELECT * FROM friendships WHERE requester_id = ? AND addressee_id = ?'),
    insertFriend: db.prepare("INSERT INTO friendships (requester_id, addressee_id, status, created_at) VALUES (?, ?, 'pending', ?)"),
    acceptFriend: db.prepare("UPDATE friendships SET status = 'accepted' WHERE requester_id = ? AND addressee_id = ?"),
    delFriend: db.prepare('DELETE FROM friendships WHERE requester_id = ? AND addressee_id = ?'),
    friendsAccepted: db.prepare(`SELECT u.id, u.username, u.avatar_at,
        COALESCE((SELECT SUM(pp_awarded) FROM map_completions WHERE user_id = u.id), 0) AS total_pp
      FROM friendships f JOIN users u ON u.id = CASE WHEN f.requester_id = ? THEN f.addressee_id ELSE f.requester_id END
      WHERE f.status = 'accepted' AND (f.requester_id = ? OR f.addressee_id = ?) ORDER BY u.username COLLATE NOCASE`),
    friendsIncoming: db.prepare(`SELECT u.id, u.username, u.avatar_at FROM friendships f JOIN users u ON u.id = f.requester_id
      WHERE f.addressee_id = ? AND f.status = 'pending' ORDER BY f.created_at DESC`),
    friendsOutgoing: db.prepare(`SELECT u.id, u.username, u.avatar_at FROM friendships f JOIN users u ON u.id = f.addressee_id
      WHERE f.requester_id = ? AND f.status = 'pending' ORDER BY f.created_at DESC`),
    friendCount: db.prepare("SELECT COUNT(*) AS n FROM friendships WHERE status = 'accepted' AND (requester_id = ? OR addressee_id = ?)"),
    globalBoard: db.prepare(`SELECT u.id AS user_id, u.username, u.avatar_at,
        SUM(c.pp_awarded) AS total_pp, COUNT(c.map_id) AS maps,
        (SELECT COALESCE(AVG(accuracy), 0) FROM scores s WHERE s.user_id = u.id) AS accuracy,
        (SELECT MAX(achieved_at) FROM scores s WHERE s.user_id = u.id) AS last_at
      FROM map_completions c JOIN users u ON u.id = c.user_id
      GROUP BY u.id ORDER BY total_pp DESC, u.id ASC LIMIT ? OFFSET ?`),
    globalMe: db.prepare(`SELECT COALESCE(SUM(c.pp_awarded), 0) AS total_pp, COUNT(c.map_id) AS maps,
        (SELECT COALESCE(AVG(accuracy), 0) FROM scores WHERE user_id = ?) AS accuracy,
        (SELECT MAX(achieved_at) FROM scores WHERE user_id = ?) AS last_at
      FROM map_completions c WHERE c.user_id = ?`),
    mapBoardScore: db.prepare(`SELECT s.user_id, u.username, u.avatar_at, s.score, s.accuracy, s.max_combo, s.achieved_at, COALESCE(c.pp_awarded, 0) AS pp
      FROM scores s JOIN users u ON u.id = s.user_id
      LEFT JOIN map_completions c ON c.user_id = s.user_id AND c.map_id = s.map_id
      WHERE s.map_id = ? ORDER BY s.score DESC, s.achieved_at ASC LIMIT ?`),
    mapBoardPp: db.prepare(`SELECT s.user_id, u.username, u.avatar_at, s.score, s.accuracy, s.max_combo, s.achieved_at, COALESCE(c.pp_awarded, 0) AS pp
      FROM scores s JOIN users u ON u.id = s.user_id
      LEFT JOIN map_completions c ON c.user_id = s.user_id AND c.map_id = s.map_id
      WHERE s.map_id = ? ORDER BY pp DESC, s.score DESC, s.achieved_at ASC LIMIT ?`),
    mapTitle: db.prepare('SELECT map_title FROM scores WHERE map_id = ? ORDER BY achieved_at DESC LIMIT 1'),
    mapMine: db.prepare('SELECT s.score, s.accuracy, s.max_combo, s.achieved_at, COALESCE(c.pp_awarded, 0) AS pp FROM scores s LEFT JOIN map_completions c ON c.user_id = s.user_id AND c.map_id = s.map_id WHERE s.user_id = ? AND s.map_id = ?'),
    mapCount: db.prepare('SELECT COUNT(*) AS n FROM scores WHERE map_id = ?'),
  };

  q.purgeSessions.run(Date.now() - SESSION_DAYS * 86400000);

  // ---- pembatas laju sederhana (di memori) ----
  const hits = new Map();
  function rateLimit(key, max, windowMs) {
    const now = Date.now();
    let h = hits.get(key);
    if (!h || h.reset < now) {
      h = { n: 0, reset: now + windowMs };
      hits.set(key, h);
    }
    h.n++;
    if (h.n > max) throw new HttpError(429, 'terlalu_cepat', 'Terlalu banyak percobaan. Coba lagi sebentar lagi.');
  }
  setInterval(() => {
    const now = Date.now();
    for (const [k, h] of hits) if (h.reset < now) hits.delete(k);
  }, 60000).unref();

  function clientIp(req) {
    if (trustProxy) {
      const f = req.headers['fly-client-ip'] || (req.headers['x-forwarded-for'] || '').split(',')[0].trim();
      if (f) return f;
    }
    return req.socket.remoteAddress || '?';
  }

  // ---- akun ----
  let dummyHash = null; // dipakai agar waktu respons sama untuk nama yang tidak ada
  async function getDummy() {
    if (!dummyHash) dummyHash = await argon2.hash(crypto.randomBytes(16).toString('hex'), ARGON_OPTS);
    return dummyHash;
  }

  function newSession(userId) {
    const token = crypto.randomBytes(32).toString('base64url');
    const now = Date.now();
    q.insertSession.run(sha256(token), userId, now, now);
    return token;
  }

  function authUser(req, required = true) {
    const h = req.headers['authorization'] || '';
    const m = /^Bearer\s+([A-Za-z0-9_-]{20,100})$/.exec(h);
    if (m) {
      const th = sha256(m[1]);
      const now = Date.now();
      const u = q.sessionUser.get(th, now - SESSION_DAYS * 86400000);
      if (u) {
        q.touchSession.run(now, th);
        return { user: u, tokenHash: th };
      }
    }
    if (required) throw new HttpError(401, 'belum_masuk', 'Sesi habis. Silakan masuk lagi.');
    return null;
  }

  function checkPassword(pw) {
    if (typeof pw !== 'string' || pw.length < 6) throw new HttpError(400, 'sandi_pendek', 'Kata sandi minimal 6 karakter');
    if (pw.length > 128) throw new HttpError(400, 'sandi_panjang', 'Kata sandi maksimal 128 karakter');
  }

  function checkUsername(n) {
    if (typeof n !== 'string' || !USERNAME_RE.test(n)) {
      throw new HttpError(400, 'nama_tidak_valid', 'Nama 3–20 karakter: huruf, angka, titik, strip, atau garis bawah');
    }
  }

  function publicUser(u) {
    return { id: u.id, username: u.username, avatar_at: u.avatar_at || 0 };
  }

  function totalsOf(userId) {
    const t = q.totalPp.get(userId);
    return { total_pp: round2(t.t), maps_cleared: t.n };
  }

  const round2 = (x) => Math.round(Number(x) * 100) / 100;

  function selfJson(u) {
    return { id: u.id, username: u.username, bio: u.bio, created_at: u.created_at, avatar_at: u.avatar_at || 0, ...totalsOf(u.id) };
  }

  // ---- handler endpoint ----
  const routes = [];
  const route = (method, re, fn) => routes.push({ method, re, fn });

  route('GET', /^\/api\/health$/, async () => ({ ok: true, time: Date.now() }));

  route('POST', /^\/api\/register$/, async (ctx) => {
    rateLimit('reg:' + ctx.ip, 8, 3600000);
    const { username, password } = ctx.body;
    checkUsername(username);
    checkPassword(password);
    if (q.userByName.get(username)) throw new HttpError(409, 'nama_dipakai', 'Nama itu sudah dipakai orang lain');
    const hash = await argon2.hash(password, ARGON_OPTS); // Argon2id + salt acak otomatis
    let id;
    try {
      id = q.insertUser.run(username, hash, Date.now()).lastInsertRowid;
    } catch (e) {
      throw new HttpError(409, 'nama_dipakai', 'Nama itu sudah dipakai orang lain');
    }
    const user = q.userById.get(id);
    return { token: newSession(user.id), user: selfJson(user) };
  });

  route('POST', /^\/api\/login$/, async (ctx) => {
    rateLimit('login:' + ctx.ip, 30, 600000);
    const { username, password } = ctx.body;
    if (typeof username !== 'string' || typeof password !== 'string' || password.length > 128) {
      throw new HttpError(400, 'data_salah', 'Nama dan kata sandi wajib diisi');
    }
    rateLimit('loginu:' + username.toLowerCase(), 10, 600000);
    const user = q.userByName.get(username.trim());
    // Selalu jalankan verify (pada hash palsu bila nama tidak ada) supaya waktu respons tidak membocorkan nama yang ada.
    const ok = await argon2.verify(user ? user.password_hash : await getDummy(), password).catch(() => false);
    if (!user || !ok) throw new HttpError(401, 'login_gagal', 'Nama atau kata sandi salah');
    if (argon2.needsRehash(user.password_hash, ARGON_OPTS)) q.updatePw.run(await argon2.hash(password, ARGON_OPTS), user.id);
    return { token: newSession(user.id), user: selfJson(user) };
  });

  route('POST', /^\/api\/logout$/, async (ctx) => {
    const a = authUser(ctx.req);
    q.delSession.run(a.tokenHash);
    return { ok: true };
  });

  route('GET', /^\/api\/me$/, async (ctx) => ({ user: selfJson(authUser(ctx.req).user) }));

  route('POST', /^\/api\/me\/profile$/, async (ctx) => {
    const { user } = authUser(ctx.req);
    q.updateBio.run(cleanText(ctx.body.bio, 120), user.id);
    return { user: selfJson(q.userById.get(user.id)) };
  });

  route('POST', /^\/api\/me\/password$/, async (ctx) => {
    const { user } = authUser(ctx.req);
    rateLimit('pw:' + user.id, 10, 600000);
    const { old_password, new_password } = ctx.body;
    if (typeof old_password !== 'string' || !(await argon2.verify(user.password_hash, old_password).catch(() => false))) {
      throw new HttpError(403, 'sandi_lama_salah', 'Kata sandi lama salah');
    }
    checkPassword(new_password);
    q.updatePw.run(await argon2.hash(new_password, ARGON_OPTS), user.id);
    q.delUserSessions.run(user.id); // semua perangkat harus masuk ulang
    return { token: newSession(user.id), ok: true };
  });

  route('POST', /^\/api\/me\/delete$/, async (ctx) => {
    const { user } = authUser(ctx.req);
    rateLimit('del:' + user.id, 5, 600000);
    const pw = ctx.body.password;
    if (typeof pw !== 'string' || !(await argon2.verify(user.password_hash, pw).catch(() => false))) {
      throw new HttpError(403, 'sandi_salah', 'Kata sandi salah');
    }
    db.prepare('DELETE FROM users WHERE id = ?').run(user.id); // sesi, skor, penanda tamat, dan pertemanan ikut terhapus (CASCADE)
    return { ok: true };
  });

  route('POST', /^\/api\/me\/avatar$/, async (ctx) => {
    const { user } = authUser(ctx.req);
    if (ctx.body.remove) {
      q.setAvatar.run(null, 0, user.id);
      return { ok: true, avatar_at: 0 };
    }
    const b64 = ctx.body.jpeg_base64;
    if (typeof b64 !== 'string') throw new HttpError(400, 'data_salah', 'Gambar tidak ada');
    const buf = Buffer.from(b64, 'base64');
    if (buf.length < 100 || buf.length > MAX_AVATAR) throw new HttpError(413, 'gambar_besar', 'Foto terlalu besar (maksimal 80 KB)');
    if (!(buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff)) throw new HttpError(400, 'bukan_jpeg', 'Foto harus JPEG');
    const at = Date.now();
    q.setAvatar.run(buf, at, user.id);
    return { ok: true, avatar_at: at };
  });

  route('GET', /^\/api\/users\/(\d+)\/avatar$/, async (ctx, m) => {
    const u = q.userById.get(Number(m[1]));
    if (!u || !u.avatar) throw new HttpError(404, 'tidak_ada', 'Tidak ada foto');
    return { raw: Buffer.from(u.avatar), type: 'image/jpeg', cache: 'public, max-age=86400' };
  });

  route('GET', /^\/api\/users\/search$/, async (ctx) => {
    const me = authUser(ctx.req).user;
    const term = cleanText(ctx.url.searchParams.get('q'), 30);
    if (term.length < 1) return { users: [] };
    const esc = term.replace(/[\\%_]/g, (c) => '\\' + c);
    const rows = q.search.all('%' + esc + '%', me.id, esc + '%');
    return {
      users: rows.map((r) => ({ ...publicUser(r), total_pp: round2(r.total_pp), relation: relationOf(me.id, r.id) })),
    };
  });

  function relationOf(meId, otherId) {
    if (meId === otherId) return 'self';
    const out = q.friendRow.get(meId, otherId);
    const inc = q.friendRow.get(otherId, meId);
    if ((out && out.status === 'accepted') || (inc && inc.status === 'accepted')) return 'friend';
    if (inc) return 'incoming'; // dia mengirim permintaan ke saya
    if (out) return 'outgoing';
    return 'none';
  }

  route('GET', /^\/api\/users\/(\d+)$/, async (ctx, m) => {
    const me = authUser(ctx.req, false);
    const u = q.userById.get(Number(m[1]));
    if (!u) throw new HttpError(404, 'tidak_ada', 'Pemain tidak ditemukan');
    const tot = totalsOf(u.id);
    const st = q.userStats.get(u.id);
    return {
      user: {
        id: u.id,
        username: u.username,
        bio: u.bio,
        created_at: u.created_at,
        avatar_at: u.avatar_at || 0,
        total_pp: tot.total_pp,
        maps_cleared: tot.maps_cleared,
        global_rank: tot.maps_cleared > 0 ? q.globalRankOf.get(tot.total_pp).r : 0,
        plays: st.plays,
        avg_accuracy: round2(st.avg_acc),
        best_score: st.best,
        friends: q.friendCount.get(u.id, u.id).n,
        relation: me ? relationOf(me.user.id, u.id) : 'none',
        recent: q.recent.all(u.id).map((r) => ({ ...r, accuracy: round2(r.accuracy), pp: round2(r.pp) })),
      },
    };
  });

  // ---- teman ----
  route('GET', /^\/api\/friends$/, async (ctx) => {
    const me = authUser(ctx.req).user;
    const f = (r) => ({ ...publicUser(r), total_pp: round2(r.total_pp || 0) });
    return {
      friends: q.friendsAccepted.all(me.id, me.id, me.id).map(f),
      incoming: q.friendsIncoming.all(me.id).map(f),
      outgoing: q.friendsOutgoing.all(me.id).map(f),
    };
  });

  function targetUser(body, me) {
    const id = Number(body.user_id);
    if (!Number.isInteger(id) || id <= 0) throw new HttpError(400, 'data_salah', 'Pemain tidak valid');
    if (id === me.id) throw new HttpError(400, 'diri_sendiri', 'Tidak bisa berteman dengan diri sendiri');
    const u = q.userById.get(id);
    if (!u) throw new HttpError(404, 'tidak_ada', 'Pemain tidak ditemukan');
    return u;
  }

  route('POST', /^\/api\/friends\/request$/, async (ctx) => {
    const me = authUser(ctx.req).user;
    rateLimit('freq:' + me.id, 40, 3600000);
    const t = targetUser(ctx.body, me);
    const rel = relationOf(me.id, t.id);
    if (rel === 'friend') return { relation: 'friend' };
    if (rel === 'outgoing') return { relation: 'outgoing' };
    if (rel === 'incoming') {
      q.acceptFriend.run(t.id, me.id); // dia sudah meminta lebih dulu: langsung jadi teman
      return { relation: 'friend' };
    }
    q.insertFriend.run(me.id, t.id, Date.now());
    return { relation: 'outgoing' };
  });

  route('POST', /^\/api\/friends\/accept$/, async (ctx) => {
    const me = authUser(ctx.req).user;
    const t = targetUser(ctx.body, me);
    const row = q.friendRow.get(t.id, me.id);
    if (!row || row.status !== 'pending') throw new HttpError(404, 'tidak_ada', 'Tidak ada permintaan dari pemain itu');
    q.acceptFriend.run(t.id, me.id);
    return { relation: 'friend' };
  });

  // tolak permintaan masuk, batalkan permintaan keluar, atau hapus teman
  route('POST', /^\/api\/friends\/remove$/, async (ctx) => {
    const me = authUser(ctx.req).user;
    const t = targetUser(ctx.body, me);
    q.delFriend.run(me.id, t.id);
    q.delFriend.run(t.id, me.id);
    return { relation: 'none' };
  });

  // ---- skor & PP ----
  route('POST', /^\/api\/scores$/, async (ctx) => {
    const me = authUser(ctx.req).user;
    rateLimit('score:' + me.id, 120, 3600000);
    const b = ctx.body;
    const mapId = String(b.map_id || '');
    if (!MAPID_RE.test(mapId)) throw new HttpError(400, 'map_tidak_valid', 'ID map tidak valid');
    const score = Math.round(Number(b.score));
    const acc = Number(b.accuracy);
    const combo = Math.round(Number(b.max_combo || 0));
    let pp = Number(b.pp);
    if (!Number.isFinite(score) || score < 0 || score > 1000000) throw new HttpError(400, 'skor_tidak_valid', 'Skor tidak valid');
    if (!Number.isFinite(acc) || acc < 0 || acc > 100) throw new HttpError(400, 'akurasi_tidak_valid', 'Akurasi tidak valid');
    if (!Number.isFinite(pp) || pp < 0) pp = 0;
    pp = round2(Math.min(pp, MAX_PP_PER_MAP));
    const title = cleanText(b.map_title, 120);
    const now = Date.now();

    db.exec('BEGIN IMMEDIATE');
    let out;
    try {
      // Tanda "sudah ditamatkan": INSERT OR IGNORE pada UNIQUE(user_id, map_id). changes = 1 hanya pada tamat pertama.
      const first = q.insertCompletion.run(me.id, mapId, pp, now).changes === 1;
      const prev = q.getScore.get(me.id, mapId);
      let newBest = false;
      if (!prev) {
        q.insertScore.run(me.id, mapId, title, score, acc, Math.max(0, combo), now);
        newBest = true;
      } else if (score > prev.score) {
        q.updateScoreBest.run(title || prev.map_title, score, acc, Math.max(0, combo), now, me.id, mapId);
        newBest = true;
      } else {
        q.bumpPlays.run(me.id, mapId);
      }
      db.exec('COMMIT');
      const comp = q.getCompletion.get(me.id, mapId);
      const mine = q.getScore.get(me.id, mapId);
      out = {
        ok: true,
        first_clear: first,
        pp_awarded: first ? comp.pp_awarded : 0,
        pp_claimed: comp.pp_awarded,
        already_claimed: !first,
        new_best: newBest,
        best_score: mine.score,
        best_accuracy: round2(mine.accuracy),
        map_rank: q.mapRankOf.get(mapId, mine.score, mine.score, mine.achieved_at).r,
        ...totalsOf(me.id),
      };
      out.global_rank = q.globalRankOf.get(out.total_pp).r;
    } catch (e) {
      try {
        db.exec('ROLLBACK');
      } catch (x) {
        /* sudah selesai */
      }
      throw e;
    }
    return out;
  });

  const rowOut = (r, i) => ({
    rank: i + 1,
    user_id: r.user_id,
    username: r.username,
    avatar_at: r.avatar_at || 0,
    score: r.score,
    accuracy: round2(r.accuracy),
    max_combo: r.max_combo,
    pp: round2(r.pp),
    achieved_at: r.achieved_at,
  });

  route('GET', /^\/api\/leaderboard\/map\/([A-Za-z0-9:_.\-]{1,64})$/, async (ctx, m) => {
    const me = authUser(ctx.req, false);
    const mapId = m[1];
    const limit = Math.min(100, Math.max(1, Number(ctx.url.searchParams.get('limit')) || 50));
    const sort = ctx.url.searchParams.get('sort') === 'pp' ? 'pp' : 'score';
    const rows = (sort === 'pp' ? q.mapBoardPp : q.mapBoardScore).all(mapId, limit);
    const out = { map_id: mapId, sort, title: (q.mapTitle.get(mapId) || {}).map_title || '', total: q.mapCount.get(mapId).n, entries: rows.map(rowOut) };
    if (me) {
      const mine = q.mapMine.get(me.user.id, mapId);
      if (mine) {
        out.me = {
          rank: q.mapRankOf.get(mapId, mine.score, mine.score, mine.achieved_at).r,
          user_id: me.user.id,
          username: me.user.username,
          score: mine.score,
          accuracy: round2(mine.accuracy),
          max_combo: mine.max_combo,
          pp: round2(mine.pp),
          achieved_at: mine.achieved_at,
        };
      }
    }
    return out;
  });

  route('GET', /^\/api\/leaderboard\/global$/, async (ctx) => {
    const me = authUser(ctx.req, false);
    const limit = Math.min(100, Math.max(1, Number(ctx.url.searchParams.get('limit')) || 50));
    const offset = Math.max(0, Number(ctx.url.searchParams.get('offset')) || 0);
    const rows = q.globalBoard.all(limit, offset);
    const out = {
      offset,
      entries: rows.map((r, i) => ({
        rank: offset + i + 1,
        user_id: r.user_id,
        username: r.username,
        avatar_at: r.avatar_at || 0,
        pp: round2(r.total_pp),
        maps: r.maps,
        accuracy: round2(r.accuracy),
        achieved_at: r.last_at,
      })),
    };
    if (me) {
      const g = q.globalMe.get(me.user.id, me.user.id, me.user.id);
      if (g.maps > 0) {
        out.me = {
          rank: q.globalRankOf.get(round2(g.total_pp)).r,
          user_id: me.user.id,
          username: me.user.username,
          pp: round2(g.total_pp),
          maps: g.maps,
          accuracy: round2(g.accuracy),
          achieved_at: g.last_at,
        };
      }
    }
    return out;
  });

  // ---- server HTTP ----
  function readBody(req) {
    return new Promise((resolve, reject) => {
      if (req.method === 'GET' || req.method === 'HEAD') return resolve({});
      const chunks = [];
      let n = 0;
      req.on('data', (c) => {
        n += c.length;
        if (n > MAX_BODY) {
          reject(new HttpError(413, 'terlalu_besar', 'Data terlalu besar'));
          req.destroy();
        } else chunks.push(c);
      });
      req.on('end', () => {
        if (n === 0) return resolve({});
        try {
          const v = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          resolve(v && typeof v === 'object' ? v : {});
        } catch (e) {
          reject(new HttpError(400, 'json_rusak', 'Format data salah'));
        }
      });
      req.on('error', reject);
    });
  }

  const server = http.createServer(async (req, res) => {
    const send = (status, obj, extra) => {
      const body = Buffer.from(JSON.stringify(obj));
      res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': body.length, 'Cache-Control': 'no-store', ...extra });
      res.end(body);
    };
    try {
      const url = new URL(req.url, 'http://x');
      const ip = clientIp(req);
      rateLimit('ip:' + ip, 600, 60000); // batas kasar semua permintaan per IP
      let handler = null;
      let m = null;
      for (const r of routes) {
        if (r.method !== req.method) continue;
        m = r.re.exec(url.pathname);
        if (m) {
          handler = r;
          break;
        }
      }
      if (!handler) throw new HttpError(404, 'tidak_ada', 'Alamat tidak ditemukan');
      const body = await readBody(req);
      const out = await handler.fn({ req, url, body, ip }, m);
      if (out && out.raw) {
        res.writeHead(200, { 'Content-Type': out.type, 'Content-Length': out.raw.length, 'Cache-Control': out.cache || 'no-store' });
        res.end(out.raw);
      } else send(200, out);
    } catch (e) {
      if (e instanceof HttpError) send(e.status, { error: e.code, message: e.message });
      else {
        console.error('galat:', e);
        send(500, { error: 'server', message: 'Galat di server' });
      }
    }
  });
  server.requestTimeout = 15000;

  return { server, db };
}

module.exports = { createApp };

if (require.main === module) {
  const { server } = createApp();
  const port = Number(process.env.PORT) || 8080;
  server.listen(port, '0.0.0.0', () => console.log('Nova Beat server aktif di port ' + port));
}
