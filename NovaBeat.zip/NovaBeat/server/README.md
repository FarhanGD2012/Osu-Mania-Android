# Nova Beat server

Server akun, teman, dan leaderboard. Node >= 22.13 (SQLite bawaan `node:sqlite`) + paket `argon2`.

## Jalankan di komputer
```
cd server
npm install
npm test        # uji alur akun, PP sekali-klaim, leaderboard, teman
npm start       # port 8080, data di ./data/novabeat.db
```
Di app: Profil > Alamat server > `http://IP-KOMPUTER:8080` (HP dan komputer satu Wi-Fi).

## Deploy (agar bisa dari mana saja)
Server butuh **penyimpanan tetap** (file SQLite). Hosting tanpa disk (mis. paket gratis yang di-reset) akan menghapus akun saat restart.
Contoh Fly.io (ada `fly.toml` + `Dockerfile`):
```
fly launch --no-deploy --copy-config
fly volumes create novabeat_data --size 1
fly secrets set TRUST_PROXY=1
fly deploy
```
Lalu isi alamat `https://NAMA-APP.fly.dev` di app (atau ubah `Cloud.DEFAULT_URL` sebelum build). Selalu pakai **HTTPS** di internet.

## Keamanan
- Kata sandi: Argon2id (memory 19 MiB, time 2, parallelism 1) + salt acak; verifikasi dengan `argon2.verify`; hash lama otomatis di-upgrade bila parameter berubah.
- Token sesi acak 256-bit; yang tersimpan di database hanya SHA-256-nya. Ganti kata sandi mencabut semua sesi.
- Pembatas laju untuk daftar / masuk / skor; waktu respons login sama untuk nama yang ada maupun tidak.
- **Batasan jujur:** PP dihitung di app dan server hanya membatasi nilainya (maks. 2000 per map) serta memastikan sekali-klaim. App yang dimodifikasi bisa mengirim skor palsu; anti-curang penuh butuh server memverifikasi replay.

## Endpoint
`POST /api/register|login|logout`, `GET /api/me`, `POST /api/me/profile|password|avatar|delete`,
`GET /api/users/search?q=`, `GET /api/users/:id`, `GET /api/users/:id/avatar`,
`GET /api/friends`, `POST /api/friends/request|accept|remove`,
`POST /api/scores`, `GET /api/leaderboard/global`, `GET /api/leaderboard/map/:mapId`.
