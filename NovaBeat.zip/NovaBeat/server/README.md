# Nova Beat server

Server akun, teman, dan leaderboard. Node >= 22.13 + paket `argon2` + `@libsql/client`.
Database: **Turso** (gratis, SQLite-compatible, data tidak hilang walau server tidur / di-restart).

## Variabel lingkungan
| Nama | Isi |
|---|---|
| `TURSO_DATABASE_URL` | `libsql://nama-db-akun.turso.io` |
| `TURSO_AUTH_TOKEN` | token dari Turso |
| `TRUST_PROXY` | `1` bila di belakang proxy (Render) supaya batas laju memakai IP pemain |
| `PORT` | diisi otomatis oleh hosting |

Tanpa `TURSO_*`, server memakai file lokal `./data/novabeat.db` (hanya untuk uji coba).

## Uji (butuh komputer)
```
cd server && npm install && npm test && npm start
```

## Keamanan
- Kata sandi: Argon2id (memory 19 MiB, time 2, parallelism 1) + salt acak; verifikasi dengan `argon2.verify`.
- Token sesi acak 256-bit; yang tersimpan hanya SHA-256-nya. Ganti kata sandi mencabut semua sesi.
- Pembatas laju untuk daftar / masuk / skor; waktu respons login sama untuk nama yang ada maupun tidak.
- **Batasan jujur:** PP dihitung di app; server hanya membatasi nilainya (maks. 2000 per map) dan memastikan sekali-klaim.

## Endpoint
`POST /api/register|login|logout`, `GET /api/me`, `POST /api/me/profile|password|avatar|delete`,
`GET /api/users/search?q=`, `GET /api/users/:id`, `GET /api/users/:id/avatar`,
`GET /api/friends`, `POST /api/friends/request|accept|remove`,
`POST /api/scores`, `GET /api/leaderboard/global`, `GET /api/leaderboard/map/:mapId`, `GET /api/health`.
