'use strict';
// Uji cepat: node test.js   (butuh paket argon2 terpasang: npm install)
const assert = require('node:assert/strict');
const { createApp } = require('./server');

(async () => {
  const { server, db } = createApp({ dbFile: ':memory:' });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + server.address().port;
  const call = async (method, path, body, token) => {
    const res = await fetch(base + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
      body: body ? JSON.stringify(body) : undefined,
    });
    const ct = res.headers.get('content-type') || '';
    return { status: res.status, json: ct.includes('json') ? await res.json() : null, buf: ct.includes('json') ? null : Buffer.from(await res.arrayBuffer()) };
  };

  // --- daftar & masuk ---
  let r = await call('POST', '/api/register', { username: 'Alice', password: 'rahasia123' });
  assert.equal(r.status, 200);
  const tA = r.json.token;
  const idA = r.json.user.id;
  const stored = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(idA).password_hash;
  assert.ok(!stored.includes('rahasia123'), 'sandi tidak boleh tersimpan polos');
  assert.ok(stored.startsWith('$argon2id$'), 'harus hash Argon2id: ' + stored);
  r = await call('POST', '/api/register', { username: 'alice', password: 'lainnya123' });
  assert.equal(r.status, 409, 'nama tidak boleh kembar (tanpa beda huruf besar/kecil)');
  r = await call('POST', '/api/register', { username: 'x', password: 'rahasia123' });
  assert.equal(r.status, 400);
  r = await call('POST', '/api/register', { username: 'Bobby', password: '123' });
  assert.equal(r.status, 400);
  r = await call('POST', '/api/login', { username: 'Alice', password: 'salah-salah' });
  assert.equal(r.status, 401);
  r = await call('POST', '/api/login', { username: 'ALICE', password: 'rahasia123' });
  assert.equal(r.status, 200);
  r = await call('POST', '/api/login', { username: 'tidak-ada', password: 'rahasia123' });
  assert.equal(r.status, 401);
  r = await call('GET', '/api/me');
  assert.equal(r.status, 401);
  r = await call('GET', '/api/me', null, tA);
  assert.equal(r.json.user.username, 'Alice');

  r = await call('POST', '/api/register', { username: 'Bobby', password: 'sandibobby' });
  const tB = r.json.token;
  const idB = r.json.user.id;

  // --- PP hanya sekali per map per akun ---
  r = await call('POST', '/api/scores', { map_id: 'osu:111', map_title: 'Lagu A', score: 800000, accuracy: 95.5, max_combo: 300, pp: 120.5 }, tA);
  assert.equal(r.status, 200);
  assert.equal(r.json.first_clear, true);
  assert.equal(r.json.pp_awarded, 120.5);
  assert.equal(r.json.total_pp, 120.5);
  r = await call('POST', '/api/scores', { map_id: 'osu:111', map_title: 'Lagu A', score: 950000, accuracy: 99, max_combo: 400, pp: 300 }, tA);
  assert.equal(r.json.first_clear, false);
  assert.equal(r.json.already_claimed, true);
  assert.equal(r.json.pp_awarded, 0);
  assert.equal(r.json.total_pp, 120.5, 'tamat ulang tidak boleh menambah PP');
  assert.equal(r.json.new_best, true);
  assert.equal(r.json.best_score, 950000);
  r = await call('POST', '/api/scores', { map_id: 'osu:111', map_title: 'Lagu A', score: 100000, accuracy: 50, max_combo: 10, pp: 999 }, tA);
  assert.equal(r.json.new_best, false);
  assert.equal(r.json.best_score, 950000, 'skor lebih rendah tidak menimpa rekor');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM map_completions WHERE user_id = ?').get(idA).n, 1);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM scores WHERE user_id = ? AND map_id = ?').get(idA, 'osu:111').n, 1);

  await call('POST', '/api/scores', { map_id: 'osu:222', map_title: 'Lagu B', score: 700000, accuracy: 90, max_combo: 200, pp: 80 }, tA);
  await call('POST', '/api/scores', { map_id: 'osu:111', map_title: 'Lagu A', score: 990000, accuracy: 99.5, max_combo: 420, pp: 150 }, tB);
  r = await call('POST', '/api/scores', { map_id: 'osu:111', score: 2000000, accuracy: 99, pp: 1 }, tB);
  assert.equal(r.status, 400);
  r = await call('POST', '/api/scores', { map_id: 'osu:333', map_title: 'Cheat', score: 1000, accuracy: 50, max_combo: 1, pp: 99999999 }, tB);
  assert.equal(r.json.pp_awarded, 2000, 'PP dibatasi server');

  // --- leaderboard ---
  r = await call('GET', '/api/leaderboard/map/osu:111', null, tA);
  assert.equal(r.json.entries.length, 2, 'satu baris per pemain per map');
  assert.equal(r.json.entries[0].username, 'Bobby');
  assert.equal(r.json.entries[1].username, 'Alice');
  assert.equal(r.json.entries[1].pp, 120.5);
  assert.equal(r.json.me.rank, 2);
  r = await call('GET', '/api/leaderboard/map/osu:111?sort=pp');
  assert.equal(r.json.entries[0].username, 'Bobby');
  r = await call('GET', '/api/leaderboard/global', null, tA);
  assert.equal(r.json.entries[0].username, 'Bobby');
  assert.equal(r.json.entries[0].pp, 2150);
  assert.equal(r.json.entries[1].username, 'Alice');
  assert.equal(r.json.entries[1].pp, 200.5);
  assert.equal(r.json.me.rank, 2);
  assert.ok(r.json.entries[1].achieved_at > 0);

  // --- cari pemain, teman, profil ---
  r = await call('GET', '/api/users/search?q=bob', null, tA);
  assert.equal(r.json.users.length, 1);
  assert.equal(r.json.users[0].relation, 'none');
  r = await call('GET', '/api/users/search?q=%25', null, tA);
  assert.equal(r.json.users.length, 0, 'karakter % tidak boleh jadi wildcard');
  r = await call('POST', '/api/friends/request', { user_id: idB }, tA);
  assert.equal(r.json.relation, 'outgoing');
  r = await call('GET', '/api/friends', null, tB);
  assert.equal(r.json.incoming.length, 1);
  assert.equal(r.json.incoming[0].username, 'Alice');
  r = await call('GET', '/api/users/' + idA, null, tB);
  assert.equal(r.json.user.relation, 'incoming');
  r = await call('POST', '/api/friends/accept', { user_id: idA }, tB);
  assert.equal(r.json.relation, 'friend');
  r = await call('GET', '/api/friends', null, tA);
  assert.equal(r.json.friends.length, 1);
  r = await call('GET', '/api/users/' + idB, null, tA);
  assert.equal(r.json.user.relation, 'friend');
  assert.equal(r.json.user.global_rank, 1);
  assert.equal(r.json.user.maps_cleared, 2);
  assert.ok(r.json.user.recent.length >= 1);
  r = await call('POST', '/api/friends/request', { user_id: idA }, tA);
  assert.equal(r.status, 400);
  r = await call('POST', '/api/friends/remove', { user_id: idB }, tA);
  assert.equal(r.json.relation, 'none');

  // --- profil, avatar, sandi ---
  r = await call('POST', '/api/me/profile', { bio: 'halo dunia' }, tA);
  assert.equal(r.json.user.bio, 'halo dunia');
  const fakeJpeg = Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(500, 7)]);
  r = await call('POST', '/api/me/avatar', { jpeg_base64: fakeJpeg.toString('base64') }, tA);
  assert.equal(r.status, 200);
  r = await call('GET', '/api/users/' + idA + '/avatar');
  assert.equal(r.status, 200);
  assert.equal(r.buf.length, fakeJpeg.length);
  r = await call('POST', '/api/me/avatar', { jpeg_base64: Buffer.alloc(500, 1).toString('base64') }, tA);
  assert.equal(r.status, 400);
  r = await call('POST', '/api/me/password', { old_password: 'salah', new_password: 'baruuuuu1' }, tA);
  assert.equal(r.status, 403);
  r = await call('POST', '/api/me/password', { old_password: 'rahasia123', new_password: 'baruuuuu1' }, tA);
  assert.equal(r.status, 200);
  r = await call('GET', '/api/me', null, tA);
  assert.equal(r.status, 401, 'sesi lama dicabut setelah ganti sandi');
  r = await call('POST', '/api/login', { username: 'Alice', password: 'baruuuuu1' });
  assert.equal(r.status, 200);

  // --- hapus akun ---
  r = await call('POST', '/api/me/delete', { password: 'salah' }, tB);
  assert.equal(r.status, 403);
  r = await call('POST', '/api/me/delete', { password: 'sandibobby' }, tB);
  assert.equal(r.status, 200);
  r = await call('GET', '/api/leaderboard/map/osu:111');
  assert.equal(r.json.entries.length, 1, 'skor akun terhapus ikut hilang');
  assert.equal(db.prepare('SELECT COUNT(*) n FROM map_completions WHERE user_id = ?').get(idB).n, 0);

  console.log('SEMUA UJI LULUS');
  server.close();
  process.exit(0);
})().catch((e) => {
  console.error('UJI GAGAL:', e);
  process.exit(1);
});
