package com.maniadroid

import java.security.MessageDigest

/**
 * PP ala "level rated" Geometry Dash: nilainya ditentukan oleh tingkat kesulitan map (bukan oleh seberapa bagus
 * permainanmu), dan diberikan SEKALI per akun per map, yaitu saat pertama kali ditamatkan (diatur oleh server lewat
 * tabel map_completions). Tamat ulang hanya memperbarui skor / akurasi terbaik.
 */
object Pp {
    /** ID map yang sama di semua HP: ID osu! bila ada, kalau tidak sidik jari isi chart. */
    fun mapKey(bm: Beatmap): String {
        if (bm.mapId > 0) return "osu:${bm.mapId}"
        val raw = "${bm.title}|${bm.artist}|${bm.creator}|${bm.version}|${bm.keys}|${bm.noteCount}"
        val h = MessageDigest.getInstance("SHA-1").digest(raw.toByteArray(Charsets.UTF_8))
        return "c:" + h.joinToString("") { String.format("%02x", it) }.take(24)
    }

    /**
     * Perkiraan bintang kesulitan dari kepadatan note: jendela 1 detik (geser tiap 0,5 detik); kepala note = 1, ekor hold = 0,5.
     * Puncak (rata-rata 15% jendela terpadat) dan rata-rata keseluruhan dicampur, lalu dikonversi ke "bintang".
     */
    fun stars(bm: Beatmap): Double {
        if (bm.notes.isEmpty()) return 0.0
        val last = bm.notes.maxOf { maxOf(it.time, it.endTime) } + 1
        val steps = last / 500 + 1
        val density = DoubleArray(steps + 2)
        for (n in bm.notes) {
            density[(n.time / 500).coerceIn(0, steps)] += 1.0
            if (n.isHold) density[(n.endTime / 500).coerceIn(0, steps)] += 0.5
        }
        val win = ArrayList<Double>()
        for (i in 0 until steps) win.add((density[i] + density[i + 1]) / 1.0) // 2 blok x 0,5 detik = jendela 1 detik
        val nonEmpty = win.filter { it > 0.0 }
        if (nonEmpty.isEmpty()) return 0.0
        val sorted = nonEmpty.sortedDescending()
        val topN = maxOf(1, (sorted.size * 0.15).toInt())
        val peak = sorted.take(topN).average()
        val overall = nonEmpty.average()
        val base = 0.55 * peak + 0.45 * overall
        val keyF = 1.0 + 0.015 * (bm.keys - 4).coerceIn(-3, 6)
        val odF = 1.0 + (bm.od - 8.0) * 0.02
        return (0.6 * Math.pow(base, 0.85) * keyF * odF).coerceIn(0.3, 12.0)
    }

    /** PP map ini bila ditamatkan pertama kali (tidak bergantung pada akurasi, seperti bintang level rated). */
    fun forMap(bm: Beatmap): Double {
        val st = stars(bm)
        val sec = (if (bm.lastTime > 0) bm.lastTime else 0) / 1000.0
        val lengthF = (0.6 + 0.4 * sec / 90.0).coerceIn(0.6, 1.0)
        return Math.round(12.0 * Math.pow(st, 1.8) * lengthF * 100.0) / 100.0
    }
}
