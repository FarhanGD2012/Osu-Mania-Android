package com.maniadroid

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.Inflater

/**
 * Baca isi satu file di dalam .osz YANG MASIH DI SERVER, tanpa mengunduh seluruh set: ambil direktori zip dari ujung
 * file (HTTP Range), lalu hanya bagian lagunya. Dipakai preview supaya lagu PENUH bisa diputar dan di-seek dalam beberapa
 * detik (set utuh dengan video / gambar bisa puluhan MB). Server yang tidak mendukung Range -> gagal rapi (IOException),
 * pemanggil kembali ke cuplikan.
 */
object RemoteZip {
    class Entry(val name: String, val method: Int, val csize: Long, val usize: Long, val offset: Long, val flags: Int)

    class Source(val url: String, val size: Long)

    private fun u16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun u32(b: ByteArray, o: Int): Long =
        (u16(b, o).toLong()) or (u16(b, o + 2).toLong() shl 16)

    /** Pastikan server mendukung Range dan ketahui ukuran file. */
    fun probe(url: String): Source {
        val c = Net.open(url, "*/*", 10000, 20000)
        c.setRequestProperty("Accept-Encoding", "identity")
        c.setRequestProperty("Range", "bytes=0-0")
        try {
            if (c.responseCode != 206) throw IOException("server tidak mendukung Range (HTTP ${c.responseCode})")
            val cr = c.getHeaderField("Content-Range") ?: throw IOException("tanpa Content-Range")
            val total = cr.substringAfter('/').trim().toLongOrNull() ?: throw IOException("ukuran tidak diketahui")
            if (total < 100) throw IOException("file terlalu kecil")
            return Source(url, total)
        } finally {
            c.disconnect()
        }
    }

    private fun readRange(url: String, from: Long, to: Long): ByteArray {
        val c = Net.open(url, "*/*", 10000, 25000)
        c.setRequestProperty("Accept-Encoding", "identity")
        c.setRequestProperty("Range", "bytes=$from-$to")
        try {
            if (c.responseCode != 206) throw IOException("HTTP ${c.responseCode} (range)")
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    /** Daftar isi zip (direktori pusat). Zip64 tidak didukung. */
    fun entries(src: Source): List<Entry> {
        val tailLen = minOf(src.size, 131072L)
        val tailStart = src.size - tailLen
        val tail = readRange(src.url, tailStart, src.size - 1)
        var eocd = -1
        for (i in tail.size - 22 downTo 0) {
            if (tail[i] == 0x50.toByte() && tail[i + 1] == 0x4B.toByte() && tail[i + 2] == 0x05.toByte() && tail[i + 3] == 0x06.toByte()) {
                eocd = i
                break
            }
        }
        if (eocd < 0) throw IOException("direktori zip tidak ditemukan")
        val count = u16(tail, eocd + 10)
        val cdSize = u32(tail, eocd + 12)
        val cdOff = u32(tail, eocd + 16)
        if (cdOff == 0xFFFFFFFFL || count == 0xFFFF) throw IOException("zip64 tidak didukung")
        val cd: ByteArray = if (cdOff >= tailStart) {
            tail.copyOfRange((cdOff - tailStart).toInt(), (cdOff - tailStart + cdSize).toInt().coerceAtMost(tail.size))
        } else readRange(src.url, cdOff, cdOff + cdSize - 1)
        val out = ArrayList<Entry>()
        var p = 0
        while (p + 46 <= cd.size && u32(cd, p) == 0x02014b50L) {
            val flags = u16(cd, p + 8)
            val method = u16(cd, p + 10)
            val csize = u32(cd, p + 20)
            val usize = u32(cd, p + 24)
            val nl = u16(cd, p + 28)
            val el = u16(cd, p + 30)
            val cl = u16(cd, p + 32)
            val off = u32(cd, p + 42)
            if (p + 46 + nl > cd.size) break
            val name = String(cd, p + 46, nl, Charsets.UTF_8)
            out.add(Entry(name, method, csize, usize, off, flags))
            p += 46 + nl + el + cl
        }
        if (out.isEmpty()) throw IOException("zip kosong")
        return out
    }

    /** Pilih file lagu: sesuai nama di .osu (AudioFilename) bila ada, jika tidak file audio terbesar. */
    fun pickAudio(list: List<Entry>, audioName: String?): Entry? {
        if (!audioName.isNullOrBlank()) {
            val want = audioName.trim().replace('\\', '/').lowercase()
            list.firstOrNull { it.name.lowercase().replace('\\', '/') == want }?.let { return it }
        }
        return list.filter {
            val n = it.name.lowercase()
            n.endsWith(".mp3") || n.endsWith(".ogg") || n.endsWith(".wav")
        }.maxByOrNull { it.usize }
    }

    private class Counting(val ins: InputStream, val onBytes: (Int) -> Unit) : InputStream() {
        override fun read(): Int {
            val r = ins.read()
            if (r >= 0) onBytes(1)
            return r
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = ins.read(b, off, len)
            if (r > 0) onBytes(r)
            return r
        }

        override fun close() = ins.close()
    }

    /** Unduh satu entri ke [dest] (sudah dibuka / diinflate). [progress] 0..1 berdasarkan byte terkompresi. */
    fun extract(src: Source, e: Entry, dest: File, progress: (Float) -> Unit) {
        if (e.flags and 1 != 0) throw IOException("entri terenkripsi")
        if (e.method != 0 && e.method != 8) throw IOException("metode kompresi ${e.method} tidak didukung")
        val head = readRange(src.url, e.offset, e.offset + 29)
        if (head.size < 30 || u32(head, 0) != 0x04034b50L) throw IOException("header lokal rusak")
        val start = e.offset + 30 + u16(head, 26) + u16(head, 28)
        val end = start + e.csize - 1
        val c = Net.open(src.url, "*/*", 10000, 30000)
        c.setRequestProperty("Accept-Encoding", "identity")
        c.setRequestProperty("Range", "bytes=$start-$end")
        val tmp = File(dest.path + ".part")
        try {
            if (c.responseCode != 206) throw IOException("HTTP ${c.responseCode} (range)")
            var got = 0L
            val total = maxOf(1L, e.csize)
            var lastEmit = 0L
            val counted = Counting(c.inputStream) { n ->
                got += n
                val now = android.os.SystemClock.uptimeMillis()
                if (now - lastEmit > 120) {
                    lastEmit = now
                    progress((got.toFloat() / total).coerceIn(0f, 1f))
                }
            }
            FileOutputStream(tmp).use { out ->
                val buf = ByteArray(32768)
                if (e.method == 0) {
                    while (true) {
                        val r = counted.read(buf)
                        if (r < 0) break
                        out.write(buf, 0, r)
                    }
                } else {
                    val inf = Inflater(true)
                    try {
                        val inb = ByteArray(32768)
                        while (!inf.finished()) {
                            if (inf.needsInput()) {
                                val r = counted.read(inb)
                                if (r < 0) break
                                inf.setInput(inb, 0, r)
                            }
                            val n = inf.inflate(buf)
                            if (n > 0) out.write(buf, 0, n)
                            else if (inf.needsDictionary()) throw IOException("kamus zip")
                            else if (!inf.needsInput() && !inf.finished()) throw IOException("data zip rusak")
                        }
                    } finally {
                        inf.end()
                    }
                }
            }
            if (e.usize > 0 && tmp.length() != e.usize) throw IOException("ukuran lagu tidak cocok")
            if (!tmp.renameTo(dest)) throw IOException("gagal menyimpan lagu")
            progress(1f)
        } finally {
            c.disconnect()
            if (tmp.exists()) tmp.delete()
        }
    }
}
