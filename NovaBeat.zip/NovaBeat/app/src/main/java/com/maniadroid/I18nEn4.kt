package com.maniadroid

/** Terjemahan tambahan (v2.1: profil lokal, favorit, info chart, mini-player). Belum dipakai L.t() kecuali ditambahkan di rantai pencarian. */
val EN_MAP4: Map<String, String> = mapOf(
    "Profil" to "Profile", "Masuk" to "Sign in", "Buat akun baru" to "Create new account",
    "Impor akun dari file (HP lain)" to "Import account from file (other phone)",
    "Ganti foto profil" to "Change profile photo", "Hapus foto profil" to "Remove profile photo",
    "Ubah nama" to "Change name", "Ubah bio" to "Edit bio", "Ubah kata sandi" to "Change password",
    "Ekspor akun ke file" to "Export account to file", "Keluar (ganti akun)" to "Sign out (switch account)",
    "Hapus akun ini" to "Delete this account", "Favorit" to "Favourites", "Unduh" to "Download",
    "Belum ada favorit" to "No favourites yet",
    "Ketuk ikon hati di kartu chart untuk menambahkannya." to "Tap the heart on a chart card to add it."
)
