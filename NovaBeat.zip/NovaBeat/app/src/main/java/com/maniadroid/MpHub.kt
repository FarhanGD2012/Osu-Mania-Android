package com.maniadroid

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/** Pengaturan room (meniru pengaturan room multiplayer osu!lazer; kondisi menang seperti osu! stable). */
class MpSettings {
    var name = "Room"
    var password = ""
    var matchType = 0      // 0 Head-to-head, 1 Team versus
    var queueMode = 0      // 0 Host saja, 1 Semua pemain, 2 Semua pemain (bergiliran)
    var winCond = 0        // 0 Skor, 1 Akurasi, 2 Combo
    var autoStart = 0      // detik; 0 = mati
    var maxPlayers = 0     // 0 = tanpa batas
    var internet = false   // juga lewat internet (broker publik)
    var listed = true      // tampil di daftar lobi internet
    var server = false     // room dihosting di server Nova Beat (perlu akun; tanpa voice chat)
    var voice = true       // voice chat room (mikrofon tiap pemain tetap mati sampai dinyalakan sendiri)
}

/** Satu chart di antrean room. [ck] = kunci isi chart (dipakai transfer lewat LAN). */
class MpChart(
    val ck: String, val setId: Int, val title: String, val artist: String, val creator: String,
    val version: String, val keys: Int, val notes: Int, val owner: String, val ownerName: String, val ownerIp: String = ""
) {
    fun toJson(): JSONObject = JSONObject().put("ck", ck).put("sid", setId).put("ti", title).put("ar", artist)
        .put("cr", creator).put("v", version).put("k", keys).put("n", notes).put("o", owner).put("on", ownerName).put("oi", ownerIp)

    companion object {
        fun fromJson(o: JSONObject) = MpChart(
            o.optString("ck"), o.optInt("sid"), o.optString("ti"), o.optString("ar"), o.optString("cr"),
            o.optString("v"), o.optInt("k", 4), o.optInt("n"), o.optString("o"), o.optString("on"), o.optString("oi")
        )
    }
}

/**
 * Otak sebuah room. Berjalan di HP host dan menjadi "server" bagi semua pemain (LAN maupun internet), jadi tidak butuh
 * server terpisah dan tidak butuh akun. Semua perubahan status terjadi di SATU thread ([exec]); masukan dari thread lain
 * hanya menjadwalkan pekerjaan ke sana.
 */
class MpHub(
    val code: String,
    val st: MpSettings,
    private val hostName: String,
    private val localDeliver: (String) -> Unit,
    private val mqtt: MqttLite?,
    private val lanPort: () -> Int,
    private val voicePort: () -> Int = { 0 }
) {
    private class P(val id: String, var name: String) {
        var conn: LanConn? = null
        var viaMqtt = false
        var local = false
        var team = 0
        var muted = false // di-mute host (voice chat)
        var ready = false
        var state = "lobby" // lobby | playing | finished
        var score = 0
        var acc = 100f
        var combo = 0
        var hp = 1f
        var prog = 0f
        var result: JSONObject? = null
        var lastSeen = System.currentTimeMillis()
    }

    companion object {
        const val START_DELAY_MS = 5000L
        const val LOCAL_ID = "host"
    }

    private val exec: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "mp-hub").also { it.isDaemon = true }
    }
    private val players = LinkedHashMap<String, P>()
    private val queue = ArrayList<MpChart>()
    private var hostId = LOCAL_ID
    private var state = "lobby"
    private var round = 0
    private var dirty = false
    private var closed = false
    private var seq = 1
    private var cdAt = 0L
    private var cdToken = 0
    private var lastInfoPub = 0L
    private val participants = HashSet<String>()
    private val finishedResults = LinkedHashMap<String, JSONObject>()
    private var tickN = 0
    private var roomDirty = false
    private var lastRoomAt = 0L

    // ---- voice chat: daftar anggota & status mute yang boleh dibaca thread jaringan suara ----
    private val voiceGate = java.util.concurrent.ConcurrentHashMap<String, Boolean>()
    @Volatile private var voiceOnFlag = true

    fun voiceMember(id: String): Boolean = voiceGate.containsKey(id)
    fun voiceAllowed(id: String): Boolean = voiceOnFlag && voiceGate[id] == true

    private fun syncVoice() {
        voiceOnFlag = st.voice
        voiceGate.keys.retainAll(players.keys)
        for (p in players.values) voiceGate[p.id] = !p.muted
    }

    /** Ringkasan room untuk siaran LAN (diisi hub, dibaca thread siaran). */
    @Volatile var beacon: String? = null
        private set

    init {
        val h = P(LOCAL_ID, hostName)
        h.local = true
        h.ready = false
        players[LOCAL_ID] = h
        exec.scheduleWithFixedDelay({ safe { tick() } }, 250, 250, TimeUnit.MILLISECONDS)
        exec.scheduleWithFixedDelay({ safe { sweep() } }, 3, 3, TimeUnit.SECONDS)
        exec.schedule({ safe { refreshInfo(true); broadcastRoom() } }, 0, TimeUnit.MILLISECONDS)
    }

    private inline fun safe(f: () -> Unit) {
        try {
            f()
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------ masukan dari berbagai jalur
    fun fromLocal(o: JSONObject) {
        run { safe { handle(players[LOCAL_ID], o) } }
    }

    private fun run(r: () -> Unit) {
        try {
            exec.execute { r() }
        } catch (e: java.util.concurrent.RejectedExecutionException) {
        }
    }

    fun fromLan(c: LanConn, line: String) {
        run {
            safe {
                val o = JSONObject(line)
                var p = players.values.firstOrNull { it.conn === c }
                if (p == null) {
                    if (o.optString("t") != "hello") return@safe
                    p = admit(o, c, null)
                    if (p == null) return@safe
                }
                handle(p, o)
            }
        }
    }

    fun onLanDrop(c: LanConn) {
        run { safe { players.values.firstOrNull { it.conn === c }?.let { drop(it, "putus") } } }
    }

    fun fromMqtt(payload: ByteArray) {
        run {
            safe {
                val o = JSONObject(String(payload, Charsets.UTF_8))
                val id = o.optString("id")
                if (id.isEmpty() || id == LOCAL_ID) return@safe
                var p = players[id]
                if (p == null) {
                    if (o.optString("t") != "hello") return@safe
                    p = admit(o, null, id)
                    if (p == null) return@safe
                }
                handle(p, o)
            }
        }
    }

    // ------------------------------------------------ pengiriman
    private fun sendTo(p: P, o: JSONObject) {
        when {
            p.local -> localDeliver(o.toString())
            p.conn != null -> p.conn?.send(o.toString())
            p.viaMqtt -> try {
                mqtt?.publish(MpConst.downTopic(code), JSONObject(o.toString()).put("to", p.id).toString())
            } catch (e: Exception) {
            }
        }
    }

    private fun broadcast(o: JSONObject) {
        val s = o.toString()
        var anyMqtt = false
        for (p in players.values) {
            when {
                p.local -> localDeliver(s)
                p.conn != null -> p.conn?.send(s)
                p.viaMqtt -> anyMqtt = true
            }
        }
        if (anyMqtt) try {
            mqtt?.publish(MpConst.downTopic(code), s)
        } catch (e: Exception) {
        }
    }

    private fun err(p: P, msg: String, fatal: Boolean = false) {
        sendTo(p, JSONObject().put("t", "error").put("msg", msg).put("fatal", fatal))
    }

    // ------------------------------------------------ pemain masuk / keluar
    private fun admit(o: JSONObject, c: LanConn?, mqttId: String?): P? {
        val name = clean(o.optString("name"), 24).ifBlank { "Pemain" }
        val tmp = P(mqttId ?: "p${seq++}", name)
        tmp.conn = c
        tmp.viaMqtt = mqttId != null
        if (st.maxPlayers > 0 && players.size >= st.maxPlayers) {
            err(tmp, "Room penuh", true)
            c?.closeSoft()
            return null
        }
        if (st.password.isNotEmpty() && o.optString("pw") != st.password) {
            err(tmp, "Password room salah", true)
            c?.closeSoft()
            return null
        }
        tmp.team = if (players.values.count { it.team == 0 } <= players.values.count { it.team == 1 }) 0 else 1
        players[tmp.id] = tmp
        sendTo(tmp, JSONObject().put("t", "welcome").put("id", tmp.id).put("code", code).put("now", System.currentTimeMillis()).put("vp", voicePort()))
        dirty = true
        refreshInfo(false)
        broadcastRoom()
        return tmp
    }

    private fun drop(p: P, why: String) {
        if (players.remove(p.id) == null) return
        p.conn?.closeSoft()
        if (state == "playing" && participants.contains(p.id) && p.state == "playing") {
            p.state = "finished"
            p.result = JSONObject().put("id", p.id).put("name", p.name).put("team", p.team).put("score", p.score)
                .put("acc", p.acc.toDouble()).put("maxCombo", p.combo).put("failed", true).put("left", true)
            finishedResults[p.id] = p.result!!
        }
        participants.remove(p.id)
        refreshInfo(false)
        broadcastRoom()
        checkAllFinished()
        evalAutoStart()
    }

    fun kickLocal(id: String) {
        run {
            safe {
                val p = players[id] ?: return@safe
                if (p.local) return@safe
                sendTo(p, JSONObject().put("t", "kicked"))
                drop(p, "kick")
            }
        }
    }

    // ------------------------------------------------ pesan dari pemain
    private fun clean(s: String, n: Int): String =
        s.filter { it.code >= 32 && it.code != 127 }.trim().take(n)

    private fun handle(p: P?, m: JSONObject) {
        if (p == null || closed) return
        p.lastSeen = System.currentTimeMillis()
        val isHost = p.id == hostId
        when (m.optString("t")) {
            "hello" -> {
                // nama bisa diganti dari klien yang sudah terdaftar
                val n = clean(m.optString("name"), 24)
                if (n.isNotEmpty() && n != p.name) {
                    p.name = n
                    dirty = true
                    broadcastRoom()
                }
            }
            "ping" -> sendTo(p, JSONObject().put("t", "pong").put("c", m.optLong("c")).put("s", System.currentTimeMillis()))
            "leave" -> {
                if (!p.local) {
                    sendTo(p, JSONObject().put("t", "left"))
                    drop(p, "keluar")
                }
            }
            "ready" -> {
                if (state != "lobby") return
                p.ready = m.optBoolean("ready")
                broadcastRoom()
                evalAutoStart()
            }
            "team" -> {
                if (state != "lobby" || st.matchType != 1) return
                p.team = if (m.optInt("team") == 1) 1 else 0
                broadcastRoom()
            }
            "chart" -> addChart(p, m)
            "unq" -> {
                if (state != "lobby") return
                val i = m.optInt("i", -1)
                if (i !in queue.indices) return
                if (!isHost && queue[i].owner != p.id) return
                queue.removeAt(i)
                chartsChanged()
            }
            "settings" -> if (isHost && state == "lobby") applySettings(m)
            "kick" -> {
                if (!isHost) return
                val v = players[m.optString("id")] ?: return
                if (v.local) return
                sendTo(v, JSONObject().put("t", "kicked"))
                drop(v, "kick")
            }
            "mute" -> { // host membisukan / membunyikan pemain lain untuk SEMUA orang
                if (!isHost) return
                val v = players[m.optString("id")] ?: return
                if (v.local) return
                v.muted = m.optBoolean("muted")
                broadcastRoom(true)
            }
            "start" -> if (isHost) startRound()
            "score" -> {
                if (state != "playing" || p.state != "playing") return
                p.score = m.optInt("score", p.score).coerceIn(0, 2_000_000)
                p.acc = m.optDouble("acc", p.acc.toDouble()).toFloat().coerceIn(0f, 100f)
                p.combo = m.optInt("combo", p.combo).coerceIn(0, 1_000_000)
                p.hp = m.optDouble("hp", p.hp.toDouble()).toFloat().coerceIn(0f, 1f)
                p.prog = m.optDouble("prog", p.prog.toDouble()).toFloat().coerceIn(0f, 1f)
                dirty = true
            }
            "finish" -> {
                if (state != "playing" || p.state != "playing") return
                p.state = "finished"
                p.score = m.optInt("score", p.score).coerceIn(0, 2_000_000)
                p.acc = m.optDouble("acc", p.acc.toDouble()).toFloat().coerceIn(0f, 100f)
                val r = JSONObject().put("id", p.id).put("name", p.name).put("team", p.team).put("score", p.score)
                    .put("acc", p.acc.toDouble()).put("maxCombo", m.optInt("maxCombo").coerceIn(0, 1_000_000))
                    .put("failed", m.optBoolean("failed")).put("left", false)
                    .put("counts", m.optJSONArray("counts") ?: JSONArray())
                p.result = r
                finishedResults[p.id] = r
                dirty = true
                checkAllFinished()
            }
        }
    }

    private fun addChart(p: P, m: JSONObject) {
        if (state != "lobby") return
        val item = MpChart(
            clean(m.optString("ck"), 40), m.optInt("sid").coerceAtLeast(0), clean(m.optString("ti"), 120),
            clean(m.optString("ar"), 120), clean(m.optString("cr"), 60), clean(m.optString("v"), 120),
            m.optInt("k", 4).coerceIn(1, 10), m.optInt("n").coerceAtLeast(0), p.id, p.name, p.conn?.remote ?: ""
        )
        if (item.ck.isEmpty()) return
        if (st.queueMode == 0) {
            if (p.id != hostId) {
                err(p, "Hanya host yang boleh memilih chart")
                return
            }
            queue.clear()
            queue.add(item)
        } else {
            if (queue.any { it.ck == item.ck }) return
            queue.add(item)
            if (st.queueMode == 2) roundRobinSort()
        }
        chartsChanged()
    }

    /** Bergiliran: chart ke-1 tiap pemain dulu, lalu ke-2 tiap pemain, dst (urutan tambah dipertahankan). */
    private fun roundRobinSort() {
        if (queue.size < 2) return
        val first = queue[0]
        val rest = queue.subList(1, queue.size).toList()
        val count = HashMap<String, Int>()
        count[first.owner] = 1
        val keyed = rest.mapIndexed { idx, c ->
            val n = count.getOrDefault(c.owner, 0)
            count[c.owner] = n + 1
            Triple(n, idx, c)
        }.sortedWith(compareBy({ it.first }, { it.second }))
        queue.clear()
        queue.add(first)
        for (t in keyed) queue.add(t.third)
    }

    private fun chartsChanged() {
        for (p in players.values) p.ready = false
        cancelCountdown()
        refreshInfo(false)
        broadcastRoom()
    }

    private fun applySettings(m: JSONObject) {
        if (m.has("name")) st.name = clean(m.optString("name"), 40).ifBlank { st.name }
        if (m.has("pw")) st.password = clean(m.optString("pw"), 24)
        if (m.has("mt")) st.matchType = m.optInt("mt").coerceIn(0, 1)
        if (m.has("qm")) {
            val q = m.optInt("qm").coerceIn(0, 2)
            if (q != st.queueMode) {
                st.queueMode = q
                if (q == 0 && queue.size > 1) while (queue.size > 1) queue.removeAt(queue.size - 1)
                if (q == 2) roundRobinSort()
            }
        }
        if (m.has("wc")) st.winCond = m.optInt("wc").coerceIn(0, 2)
        if (m.has("as")) st.autoStart = m.optInt("as").coerceIn(0, 120)
        if (m.has("mx")) st.maxPlayers = m.optInt("mx").coerceIn(0, 10000)
        if (m.has("ls")) st.listed = m.optBoolean("ls")
        if (m.has("vc")) st.voice = m.optBoolean("vc")
        if (st.matchType == 1) {
            // tim dibagi rata saat Team versus dinyalakan
            var i = 0
            for (p in players.values) p.team = i++ % 2
        }
        refreshInfo(true)
        broadcastRoom()
        evalAutoStart()
    }

    // ------------------------------------------------ ronde
    private fun startRound() {
        if (state != "lobby" || queue.isEmpty()) {
            players[hostId]?.let { err(it, "Pilih chart dulu") }
            return
        }
        cancelCountdown()
        participants.clear()
        for (p in players.values) if (p.ready || p.id == hostId) participants.add(p.id)
        state = "playing"
        round++
        finishedResults.clear()
        for (p in players.values) {
            p.result = null
            p.score = 0; p.acc = 100f; p.combo = 0; p.hp = 1f; p.prog = 0f
            p.state = if (participants.contains(p.id)) "playing" else "lobby"
        }
        val at = System.currentTimeMillis() + START_DELAY_MS
        broadcast(JSONObject().put("t", "start").put("at", at).put("now", System.currentTimeMillis()).put("round", round)
            .put("parts", JSONArray(participants.toList())))
        refreshInfo(true)
        broadcastRoom(true)
    }

    private fun checkAllFinished() {
        if (state != "playing") return
        for (id in participants) {
            val p = players[id] ?: continue
            if (p.state != "finished") return
        }
        val list = ArrayList<JSONObject>(finishedResults.values)
        val metric = { o: JSONObject ->
            when (st.winCond) {
                1 -> o.optDouble("acc")
                2 -> o.optInt("maxCombo").toDouble()
                else -> o.optInt("score").toDouble()
            }
        }
        list.sortWith(Comparator { a, b ->
            val fa = a.optBoolean("failed")
            val fb = b.optBoolean("failed")
            if (fa != fb) (if (fa) 1 else -1)
            else {
                val c = metric(b).compareTo(metric(a))
                if (c != 0) c else b.optInt("score").compareTo(a.optInt("score"))
            }
        })
        val res = JSONObject().put("t", "results").put("round", round).put("wc", st.winCond).put("mt", st.matchType)
            .put("ranking", JSONArray(list))
        if (st.matchType == 1) {
            val tot = DoubleArray(2)
            val cnt = IntArray(2)
            for (r in list) {
                val t = r.optInt("team").coerceIn(0, 1)
                cnt[t]++
                tot[t] += metric(r)
            }
            if (st.winCond == 1) for (t in 0..1) if (cnt[t] > 0) tot[t] = tot[t] / cnt[t].toDouble()
            res.put("teams", JSONArray(listOf(tot[0], tot[1])))
        }
        state = "lobby"
        participants.clear()
        for (p in players.values) {
            p.ready = false
            p.state = "lobby"
        }
        if (st.queueMode != 0 && queue.isNotEmpty()) queue.removeAt(0)
        broadcast(res)
        refreshInfo(true)
        broadcastRoom(true)
    }

    // ------------------------------------------------ mulai otomatis
    private fun cancelCountdown() {
        if (cdAt != 0L) {
            cdAt = 0L
            cdToken++
            broadcast(JSONObject().put("t", "cd").put("at", 0))
        }
    }

    private fun evalAutoStart() {
        if (st.autoStart <= 0 || state != "lobby" || queue.isEmpty() || players.values.none { it.ready }) {
            if (cdAt != 0L && (st.autoStart <= 0 || state != "lobby" || queue.isEmpty() || players.values.none { it.ready })) cancelCountdown()
            return
        }
        if (cdAt != 0L) return
        cdAt = System.currentTimeMillis() + st.autoStart * 1000L
        val tok = ++cdToken
        broadcast(JSONObject().put("t", "cd").put("at", cdAt).put("now", System.currentTimeMillis()))
        exec.schedule({
            safe {
                if (cdToken == tok && cdAt != 0L && state == "lobby") {
                    cdAt = 0L
                    startRound()
                }
            }
        }, st.autoStart * 1000L, TimeUnit.MILLISECONDS)
    }

    // ------------------------------------------------ siaran status
    private fun roomJson(): JSONObject {
        val arr = JSONArray()
        for (p in players.values) {
            arr.put(
                JSONObject().put("id", p.id).put("n", p.name).put("tm", p.team).put("mu", p.muted).put("rd", p.ready).put("s", p.state)
                    .put("sc", p.score).put("ac", p.acc.toDouble()).put("cb", p.combo).put("hp", p.hp.toDouble()).put("pr", p.prog.toDouble())
            )
        }
        val q = JSONArray()
        for (c in queue) q.put(c.toJson())
        return JSONObject().put("t", "room").put("code", code).put("name", st.name).put("host", hostId).put("st", state)
            .put("mt", st.matchType).put("qm", st.queueMode).put("wc", st.winCond).put("as", st.autoStart).put("mx", st.maxPlayers)
            .put("pw", st.password.isNotEmpty()).put("ls", st.listed).put("vc", st.voice).put("net", st.internet).put("round", round)
            .put("players", arr).put("queue", q)
    }

    /**
     * Siaran status room digabung: perubahan pertama dikirim langsung, perubahan beruntun (mis. banyak pemain masuk
     * sekaligus) dikirim satu kali per ~200 ms. Tanpa ini, room besar membanjiri jaringan (tiap perubahan x tiap pemain).
     */
    private fun broadcastRoom(force: Boolean = false) {
        if (closed) return
        syncVoice()
        val now = System.currentTimeMillis()
        if (force || now - lastRoomAt >= 200) {
            roomDirty = false
            lastRoomAt = now
            broadcast(roomJson())
        } else roomDirty = true
    }

    private fun infoJson(): String {
        val c = queue.firstOrNull()
        return JSONObject().put("a", "mdv1").put("code", code).put("name", st.name).put("host", hostName)
            .put("pl", players.size).put("mx", st.maxPlayers).put("mt", st.matchType).put("qm", st.queueMode).put("wc", st.winCond)
            .put("pw", st.password.isNotEmpty()).put("st", state).put("port", lanPort()).put("net", st.internet)
            .put("ch", if (c == null) "" else "${c.artist} - ${c.title} [${c.version}]").put("k", c?.keys ?: 0)
            .put("ts", System.currentTimeMillis()).toString()
    }

    /** Perbarui ringkasan untuk siaran LAN dan daftar lobi internet (dibatasi supaya broker tidak dibanjiri). */
    private fun refreshInfo(force: Boolean) {
        val s = infoJson()
        beacon = s
        val m = mqtt ?: return
        if (!st.internet || !st.listed) return
        val now = System.currentTimeMillis()
        if (!force && now - lastInfoPub < 3000) return
        lastInfoPub = now
        try {
            m.publish(MpConst.lobbyTopic(code), s, true)
        } catch (e: Exception) {
        }
    }

    private fun tick() {
        if (closed) return
        if (roomDirty) broadcastRoom(true)
        if (dirty && state == "playing") {
            dirty = false
            val a = JSONArray()
            for (p in players.values) {
                if (!participants.contains(p.id)) continue
                a.put(JSONArray().put(p.id).put(p.score).put(Math.round(p.acc * 100f) / 100.0).put(p.combo)
                    .put(Math.round(p.hp * 100f) / 100.0).put(Math.round(p.prog * 1000f) / 1000.0).put(if (p.state == "finished") 1 else 0))
            }
            broadcast(JSONObject().put("t", "scores").put("p", a))
        }
        if (++tickN % 60 == 0) refreshInfo(true) // ~15 dtk: daftar lobi internet tetap segar
    }

    private fun sweep() {
        if (closed) return
        val now = System.currentTimeMillis()
        for (p in players.values.toList()) {
            if (p.local) continue
            if (now - p.lastSeen > 30000) drop(p, "timeout")
        }
    }

    // ------------------------------------------------ tutup room
    fun close() {
        run {
            safe {
                if (closed) return@safe
                broadcast(JSONObject().put("t", "closed"))
                closed = true
                if (st.internet) try {
                    mqtt?.publish(MpConst.lobbyTopic(code), ByteArray(0), true)
                } catch (e: Exception) {
                }
                for (p in players.values) p.conn?.closeSoft()
                try {
                    mqtt?.close()
                } catch (e: Exception) {
                }
            }
            exec.shutdown()
        }
    }
}
