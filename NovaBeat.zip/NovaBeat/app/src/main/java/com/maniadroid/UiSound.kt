package com.maniadroid

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Suara tombol menu: klik biasa, kembali, dan konfirmasi (ketuk logo).
 * Dibuat sendiri lewat sintesis (tanpa file audio), disimpan di cache, dimainkan lewat SoundPool
 * dari thread terpisah supaya tidak menahan thread utama.
 */
object UiSound {
    const val CLICK = 0
    const val BACK = 1
    const val CONFIRM = 2
    private const val VER = "v1"

    @Volatile
    private var pool: SoundPool? = null
    private val ids = IntArray(3)
    private val thread = HandlerThread("uisfx").also { it.start() }
    private val handler = Handler(thread.looper)
    private var lastPlay = 0L

    @Synchronized
    fun init(c: Context) {
        if (pool != null) return
        val dir = c.applicationContext.cacheDir
        val p = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        pool = p
        handler.post {
            for (k in 0..2) {
                try {
                    val f = File(dir, "ui_${VER}_$k.wav")
                    if (!f.isFile || f.length() < 100) write(f, k)
                    ids[k] = p.load(f.path, 1)
                } catch (e: Exception) {
                }
            }
        }
    }

    fun play(kind: Int = CLICK) {
        if (!Settings.ready || !Settings.uiSound) return
        val v = Settings.uiGain
        if (v <= 0f) return
        val now = SystemClock.uptimeMillis()
        if (now - lastPlay < 40) return
        lastPlay = now
        val k = kind.coerceIn(0, 2)
        handler.post {
            try {
                val id = ids[k]
                if (id != 0) pool?.play(id, v, v, 1, 0, 1f)
            } catch (e: Exception) {
            }
        }
    }

    private fun write(f: File, kind: Int) {
        val sr = 44100
        val ms = when (kind) {
            CONFIRM -> 230
            BACK -> 120
            else -> 95
        }
        val n = sr * ms / 1000
        val s = FloatArray(n)
        val rnd = java.util.Random(7L + kind)
        var ph1 = 0.0
        var ph2 = 0.0
        var ph3 = 0.0
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            var v: Double
            when (kind) {
                CLICK -> {
                    // "tik" lembut: nada pendek yang turun cepat + dentum rendah + sedikit desis di awal
                    ph1 += 2 * PI * (1000.0 + 700.0 * exp(-t / 0.012)) / sr
                    ph2 += 2 * PI * 2900.0 / sr
                    ph3 += 2 * PI * 170.0 / sr
                    v = sin(ph1) * exp(-t / 0.020) * 0.62 +
                        sin(ph2) * exp(-t / 0.008) * 0.12 +
                        sin(ph3) * exp(-t / 0.028) * 0.32 +
                        (rnd.nextDouble() * 2 - 1) * exp(-t / 0.0015) * 0.16
                }
                BACK -> {
                    // lebih rendah dan turun: terdengar seperti "menutup"
                    ph1 += 2 * PI * (700.0 + 380.0 * exp(-t / 0.016)) / sr
                    ph3 += 2 * PI * 130.0 / sr
                    v = sin(ph1) * exp(-t / 0.028) * 0.60 +
                        sin(ph3) * exp(-t / 0.034) * 0.34 +
                        (rnd.nextDouble() * 2 - 1) * exp(-t / 0.0015) * 0.12
                }
                else -> {
                    // konfirmasi: dua nada naik (G5 -> D6) + dentum
                    ph1 += 2 * PI * 784.0 / sr
                    ph2 += 2 * PI * 1175.0 / sr
                    ph3 += 2 * PI * 150.0 / sr
                    val t2 = if (t > 0.035) t - 0.035 else 0.0
                    val a2 = if (t > 0.035) 1.0 else 0.0
                    v = sin(ph1) * exp(-t / 0.075) * 0.50 +
                        sin(ph2) * exp(-t2 / 0.085) * 0.45 * a2 +
                        sin(ph3) * exp(-t / 0.040) * 0.30
                }
            }
            val atk = if (t < 0.0008) t / 0.0008 else 1.0
            val tail = if (i > n - sr / 200) (n - i) / (sr / 200.0) else 1.0
            s[i] = (v * atk * tail).toFloat()
        }
        var peak = 0.0001f
        for (x in s) if (kotlin.math.abs(x) > peak) peak = kotlin.math.abs(x)
        val g = 0.85f / peak
        val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + n * 2); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16)
        bb.putShort(1); bb.putShort(1); bb.putInt(sr); bb.putInt(sr * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(n * 2)
        for (x in s) bb.putShort((x * g * 32767f).toInt().coerceIn(-32768, 32767).toShort())
        f.writeBytes(bb.array())
    }
}
