package com.maniadroid

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Mini-player musik menu (sebelumnya hanya ada di menu utama): sebelumnya / jeda-putar / berikutnya, judul lagu,
 * dan garis kemajuan. Dipasang otomatis di pojok kanan atas semua layar menu oleh [BaseActivity].
 * Mengikuti [MenuMusic] sendiri (membaca status tiap ~0,2 dtk), jadi tidak perlu dihubungkan ke layar mana pun.
 */
class MusicBar(ctx: Context) : LinearLayout(ctx) {
    companion object {
        /** Lebar perkiraan (dp) untuk layar yang perlu menyisakan ruang di sebelahnya. */
        const val W_DP = 196
        const val H_DP = 38
    }

    private val play: IconView
    private val title: TextView
    private val line: ProgressLine
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            refresh()
            postDelayed(this, 200)
        }
    }

    private fun dp(v: Int) = Ui.dp(context, v)

    init {
        orientation = VERTICAL
        val bg = GradientDrawable()
        bg.setColor(0x99000000.toInt())
        bg.cornerRadius = dp(16).toFloat()
        bg.setStroke(dp(1), 0x22FFFFFF)
        background = bg
        setPadding(dp(4), dp(2), dp(10), dp(5))

        val row = LinearLayout(ctx)
        row.orientation = HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        fun ctl(kind: Int, onClick: () -> Unit): IconView {
            val ic = IconView(ctx, kind, 0xDDFFFFFF.toInt())
            ic.setPadding(dp(7), dp(7), dp(7), dp(7))
            ic.setOnClickListener {
                onClick()
                refresh()
            }
            row.addView(ic, LayoutParams(dp(26), dp(26)))
            return ic
        }
        ctl(IconView.PREV) { MenuMusic.prev() }
        play = ctl(IconView.PAUSE) { MenuMusic.toggle(ctx) }
        ctl(IconView.NEXT) { MenuMusic.next() }
        title = Ui.text(ctx, "", 10.5f, 0xFFE6E6F0.toInt(), false)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        title.maxWidth = dp(82)
        row.addView(title, LayoutParams(-2, -2).also { it.leftMargin = dp(3) })
        addView(row, LayoutParams(-2, -2))
        line = ProgressLine(ctx)
        addView(line, LayoutParams(-1, dp(2)).also {
            it.leftMargin = dp(6)
            it.topMargin = dp(1)
        })
        visibility = View.GONE
    }

    fun refresh() {
        val show = MenuMusic.tracks.isNotEmpty() && Settings.menuMusic
        visibility = if (show) View.VISIBLE else View.GONE
        if (!show) return
        title.text = MenuMusic.current?.title ?: "…"
        val k = if (MenuMusic.isPlaying) IconView.PAUSE else IconView.PLAY
        if (play.kind != k) {
            play.kind = k
            play.invalidate()
        }
        line.frac = MenuMusic.progress()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        removeCallbacks(tick)
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
