package com.maniadroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.Choreographer
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import kotlin.math.exp
import kotlin.math.max

/**
 * Latar bawaan ala osu!lazer: gradasi gelap berwarna tema dengan segitiga transparan yang melayang
 * pelan ke atas. Kalau ada musik menu yang sedang diputar, segitiga bergerak lebih cepat mengikuti hentakan.
 */
class TriangleView(ctx: Context) : View(ctx), Choreographer.FrameCallback {
    private val n = 36
    private val rnd = java.util.Random(11)
    private val tx = FloatArray(n) { rnd.nextFloat() }
    private val ty = FloatArray(n) { rnd.nextFloat() * 1.4f - 0.2f }
    private val ts = FloatArray(n) { 0.08f + rnd.nextFloat() * 0.24f }      // ukuran (x tinggi layar)
    private val tv = FloatArray(n) { 0.010f + rnd.nextFloat() * 0.034f }    // kecepatan (tinggi layar / detik)
    private val ta = FloatArray(n) { 0.035f + rnd.nextFloat() * 0.085f }    // keburaman
    private val tl = BooleanArray(n) { rnd.nextBoolean() }                  // terang / gelap

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var bg: Shader? = null
    private var glow: Shader? = null
    private var lastW = 0
    private var lastH = 0
    private var lastHue = -1
    private var lastNano = 0L
    private var boost = 0f
    private var running = false
    private var attached = false
    private var winVisible = true

    /** false = segitiga diam (hemat baterai). */
    var moving = true
        set(v) {
            field = v
            syncLoop()
        }

    private fun rebuild() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        lastW = width
        lastH = height
        lastHue = Settings.themeHue
        bg = LinearGradient(
            0f, 0f, w * 0.35f, h,
            intArrayOf(Ui.hue(0.70f, 0.32f), Ui.hue(0.66f, 0.18f, 8f), Ui.hue(0.60f, 0.08f, 16f)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        val gc = Ui.hue(0.55f, 0.55f)
        glow = RadialGradient(
            w * 0.5f, h * 0.5f, max(w, h) * 0.65f,
            intArrayOf(Color.argb(0x55, Color.red(gc), Color.green(gc), Color.blue(gc)), Color.TRANSPARENT),
            floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        attached = true
        syncLoop()
    }

    override fun onDetachedFromWindow() {
        attached = false
        syncLoop()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        winVisible = visibility == VISIBLE
        syncLoop()
    }

    private fun syncLoop() {
        val want = attached && winVisible && moving
        if (want && !running) {
            running = true
            lastNano = 0L
            Choreographer.getInstance().postFrameCallback(this)
        } else if (!want && running) {
            running = false
            Choreographer.getInstance().removeFrameCallback(this)
        }
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        val dt = if (lastNano == 0L) 0.016f else ((frameTimeNanos - lastNano) / 1e9f).coerceIn(0.001f, 0.05f)
        lastNano = frameTimeNanos
        val lv = MenuMusic.level()
        val target = if (lv > 0f) lv else 0f
        val k = if (target > boost) 1f - exp(-dt * 25f) else 1f - exp(-dt * 5f)
        boost += (target - boost) * k
        val mult = 1f + boost * 2.4f
        for (i in 0 until n) {
            ty[i] -= tv[i] * mult * dt
            if (ty[i] < -ts[i]) {
                ty[i] = 1f + ts[i] * 0.2f
                tx[i] = rnd.nextFloat()
            }
        }
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDraw(cv: Canvas) {
        if (width != lastW || height != lastH || Settings.themeHue != lastHue) rebuild()
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.shader = bg
        p.color = Color.BLACK
        cv.drawRect(0f, 0f, w, h, p)
        p.shader = glow
        cv.drawRect(0f, 0f, w, h, p)
        p.shader = null
        val light = Ui.hue(0.30f, 1f)
        val lr = Color.red(light)
        val lg = Color.green(light)
        val lb = Color.blue(light)
        for (i in 0 until n) {
            val s = ts[i] * h
            val cx = tx[i] * w
            val top = ty[i] * h
            path.reset()
            path.moveTo(cx, top)
            path.lineTo(cx - s * 0.58f, top + s)
            path.lineTo(cx + s * 0.58f, top + s)
            path.close()
            val a = ta[i] * (1f + boost * 0.9f)
            p.color = if (tl[i]) Color.argb((a * 255f).toInt().coerceIn(0, 255), lr, lg, lb)
            else Color.argb((a * 1.5f * 255f).toInt().coerceIn(0, 255), 0, 0, 0)
            cv.drawPath(path, p)
        }
    }
}

/**
 * Latar menu yang bisa diganti (Pengaturan > Latar menu):
 *  0 = bawaan osu!lazer (segitiga), 1 = hitam polos, 2 = gambar sendiri.
 */
class MenuBackdrop(ctx: Context) : FrameLayout(ctx) {
    private val tri = TriangleView(ctx)
    private val img = ImageView(ctx)
    private val dim = View(ctx)
    private var token = 0

    init {
        setBackgroundColor(Color.BLACK)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        dim.setBackgroundColor(0x99000000.toInt())
        addView(tri, Ui.matchParams())
        addView(img, Ui.matchParams())
        addView(dim, Ui.matchParams())
        refresh()
    }

    /** Gambar ulang segitiga (mis. setelah warna tema berubah). */
    fun redraw() {
        tri.invalidate()
    }

    /** Terapkan ulang pilihan latar dari Pengaturan (dipanggil saat layar kembali tampil / pengaturan berubah). */
    fun refresh() {
        val mode = Settings.menuBg
        val custom = if (mode == 2) Library.customBg(context) else null
        val useTri = mode == 0 || (mode == 2 && custom == null)
        tri.visibility = if (useTri) VISIBLE else GONE
        tri.moving = Settings.bgTriangles
        tri.invalidate()
        val my = ++token
        if (custom != null) {
            dim.visibility = VISIBLE
            Thread {
                val bmp = Img.decodeSampled(custom.path, 1280)
                post { if (my == token) img.setImageBitmap(bmp) }
            }.start()
        } else {
            dim.visibility = GONE
            img.setImageDrawable(null)
        }
    }
}
