package com.maniadroid

import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * Analisis lagu (tanpa izin apa pun): lagu didekode di thread latar, lalu dihitung "denyut" nada bass
 * tiap 20 ms. Hasilnya dipakai logo osu untuk berdenyut mengikuti lagu yang sedang diputar.
 * Hasil analisis disimpan di cache, jadi lagu yang sama tidak dianalisis dua kali.
 */
object BeatEnv {
    const val HOP_MS = 20f
    private const val CACHE_VER = "v1"

    class Env(val data: ByteArray) {
        /** Kekuatan denyut 0..1 pada waktu lagu [ms]. */
        fun at(ms: Double): Float {
            if (data.size < 2 || ms < 0) return 0f
            val f = ms / HOP_MS
            val i = f.toInt()
            if (i >= data.size - 1) return 0f
            val a = (data[i].toInt() and 0xFF) / 255f
            val b = (data[i + 1].toInt() and 0xFF) / 255f
            return a + (b - a) * (f - i).toFloat()
        }
    }

    fun load(cacheDir: File, path: String): Env? {
        val f = File(path)
        val key = Integer.toHexString("$path|${f.length()}|${f.lastModified()}".hashCode())
        val cf = File(cacheDir, "env_${CACHE_VER}_$key.bin")
        if (cf.isFile && cf.length() > 0) {
            try {
                return Env(cf.readBytes())
            } catch (e: Exception) {
            }
        }
        val env = analyze(path) ?: return null
        try {
            cf.writeBytes(env.data)
        } catch (e: Exception) {
        }
        return env
    }

    /** Penampung nilai energi per hop yang bisa membesar sendiri. */
    private class Floats {
        var a = FloatArray(16384)
        var n = 0
        fun add(v: Float) {
            if (n == a.size) a = a.copyOf(n * 2)
            a[n++] = v
        }
    }

    private fun analyze(path: String): Env? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(path)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    track = i
                    fmt = f
                    break
                }
            }
            if (track < 0 || fmt == null) return null
            ex.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return null
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()

            var sr = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var isFloat = false
            var alpha = 1.0 - exp(-2.0 * PI * 150.0 / sr) // low-pass ~150 Hz (bass / kick)
            var hop = (sr * HOP_MS / 1000f).toInt().coerceAtLeast(1)
            var lp = 0.0
            var sum = 0.0
            var cnt = 0
            val out = Floats()

            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            val deadline = System.nanoTime() + 90_000_000_000L
            val maxHops = (15 * 60 * 1000 / HOP_MS).toInt() // paling banyak 15 menit
            while (!outDone) {
                if (System.nanoTime() > deadline || out.n > maxHops) break
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = c.getOutputBuffer(oi)
                        if (ob != null) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.order(ByteOrder.nativeOrder())
                            val chn = ch.coerceAtLeast(1)
                            if (isFloat) {
                                val fb = ob.asFloatBuffer()
                                val frames = fb.remaining() / chn
                                for (f in 0 until frames) {
                                    var m = 0f
                                    for (k in 0 until chn) m += fb.get()
                                    val x = m / chn
                                    lp += alpha * (x - lp)
                                    sum += lp * lp
                                    if (++cnt >= hop) {
                                        out.add(sqrt(sum / cnt).toFloat())
                                        sum = 0.0
                                        cnt = 0
                                    }
                                }
                            } else {
                                val sb = ob.asShortBuffer()
                                val frames = sb.remaining() / chn
                                for (f in 0 until frames) {
                                    var m = 0
                                    for (k in 0 until chn) m += sb.get().toInt()
                                    val x = m / (32768f * chn)
                                    lp += alpha * (x - lp)
                                    sum += lp * lp
                                    if (++cnt >= hop) {
                                        out.add(sqrt(sum / cnt).toFloat())
                                        sum = 0.0
                                        cnt = 0
                                    }
                                }
                            }
                        }
                    }
                    c.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = c.outputFormat
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sr = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    isFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    alpha = 1.0 - exp(-2.0 * PI * 150.0 / sr)
                    hop = (sr * HOP_MS / 1000f).toInt().coerceAtLeast(1)
                }
            }
            if (out.n < 50) return null
            return Env(normalize(out.a, out.n))
        } catch (e: Throwable) {
            return null
        } finally {
            try {
                codec?.stop()
            } catch (e: Throwable) {
            }
            try {
                codec?.release()
            } catch (e: Throwable) {
            }
            try {
                ex.release()
            } catch (e: Throwable) {
            }
        }
    }

    /**
     * Bagi dengan energi tertinggi di sekitarnya (±1,5 dtk) lalu pertajam puncaknya,
     * jadi denyut mengikuti hentakan (kick/bass), bukan sekadar keras-pelannya lagu.
     */
    private fun normalize(r: FloatArray, n: Int): ByteArray {
        val block = 75 // 75 hop = 1,5 dtk
        val nb = (n + block - 1) / block
        val bm = FloatArray(nb)
        for (i in 0 until n) {
            val b = i / block
            if (r[i] > bm[b]) bm[b] = r[i]
        }
        // 1) energi bass relatif terhadap sekitarnya (0..1)
        val v = FloatArray(n)
        for (i in 0 until n) {
            val b = i / block
            var m = bm[b]
            if (b > 0 && bm[b - 1] > m) m = bm[b - 1]
            if (b < nb - 1 && bm[b + 1] > m) m = bm[b + 1]
            v[i] = if (m < 1e-4f) 0f else (r[i] / m).coerceIn(0f, 1f)
        }
        // 2) gabungkan: puncak energi + "onset" (lonjakan mendadak = hentakan kick)
        val res = ByteArray(n)
        var run = 0f
        val w = 8 // rata-rata 8 hop (160 ms) sebelumnya
        val ring = FloatArray(w)
        for (i in 0 until n) {
            val prevAvg = run / w
            val peak = ((v[i] - 0.45f) / 0.55f).coerceIn(0f, 1f)
            val onset = ((v[i] - prevAvg) * 3f).coerceIn(0f, 1f)
            val t = (0.45f * peak * peak + 0.55f * onset).coerceIn(0f, 1f)
            res[i] = (t * 255f).toInt().toByte()
            run += v[i] - ring[i % w]
            ring[i % w] = v[i]
        }
        return res
    }
}
