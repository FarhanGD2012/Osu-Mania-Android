package com.maniadroid

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Enkripsi kecil untuk rahasia di HP (token sesi). Kuncinya AES-256 yang dibuat di Android Keystore dan TIDAK bisa diekspor:
 * isi SharedPreferences yang tersalin (backup, root, adb) hanya berisi teks terenkripsi yang tidak berguna tanpa kunci itu.
 * Bila Keystore perangkat rusak / tidak ada, [encrypt] mengembalikan null dan pemanggil memakai cadangan.
 */
object SecureStore {
    private const val ALIAS = "novabeat_session_key"
    private const val GCM_BITS = 128

    private fun key(): SecretKey? = try {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        (ks.getKey(ALIAS, null) as? SecretKey) ?: run {
            val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            kg.init(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            kg.generateKey()
        }
    } catch (e: Exception) {
        null
    }

    /** Hasil: base64(IV 12 byte + ciphertext + tag). Null bila enkripsi tidak mungkin. */
    fun encrypt(plain: String): String? {
        return try {
            val k = key()
            if (k == null) {
                null
            } else {
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.ENCRYPT_MODE, k)
                val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
                Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Null bila gagal (mis. kunci hilang setelah pemulihan perangkat): pengguna cukup masuk lagi. */
    fun decrypt(enc: String): String? {
        return try {
            val k = key()
            val raw = Base64.decode(enc, Base64.NO_WRAP)
            if (k == null || raw.size < 13) {
                null
            } else {
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(GCM_BITS, raw, 0, 12))
                String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
            }
        } catch (e: Exception) {
            null
        }
    }
}
