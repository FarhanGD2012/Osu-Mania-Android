package com.maniadroid

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** Hasil satu panggilan ke server. [status] 0 = tidak bisa terhubung. */
class CloudRes(val ok: Boolean, val status: Int, val json: JSONObject, val message: String)

/**
 * Klien server akun Nova Beat (lihat folder `server/`): daftar / masuk (kata sandi di-hash Argon2 di server),
 * profil, teman, leaderboard, dan pengiriman skor + PP. Semua fungsi yang memanggil jaringan MEMBLOKIR:
 * panggil lewat [async] (thread latar), jangan dari thread utama.
 */
object Cloud {
    /**
     * Alamat server bawaan. Diisi saat build dari `app/build.gradle.kts` (properti Gradle `novabeat.serverUrl`, atau variabel
     * repo GitHub NOVABEAT_SERVER_URL): tidak perlu mengubah kode. Pemain juga bisa menggantinya di Profil > Alamat server.
     */
    const val DEFAULT_URL: String = BuildConfig.SERVER_URL

    /** false = fitur server disembunyikan dan tidak ada lalu lintas jaringan ke server (kode tetap ada; lihat build.gradle.kts). */
    const val enabled: Boolean = BuildConfig.ENABLE_SERVER

    /** Bawaan lama (Fly.io wajib kartu kredit, tidak dipakai lagi): pengguna yang tidak pernah mengubahnya dipindah ke bawaan baru. */
    private const val LEGACY_URL = "https://novabeat-server.fly.dev"

    private lateinit var sp: SharedPreferences
    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newFixedThreadPool(3) { r -> Thread(r, "cloud-io").also { it.isDaemon = true } }
    private val bmpCache = android.util.LruCache<String, Bitmap>(60)
    @Volatile private var lastRefresh = 0L

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            app = c.applicationContext
            sp = app.getSharedPreferences("novabeat_cloud", Context.MODE_PRIVATE)
            if ((sp.getString("url", "") ?: "").trim().trimEnd('/') == LEGACY_URL) sp.edit().remove("url").apply()
        }
    }

    /** Alamat server yang dipakai sekarang (tanpa garis miring di akhir). Ubah lewat [changeServer]. */
    val baseUrl: String
        get() = (sp.getString("url", DEFAULT_URL) ?: DEFAULT_URL).trim().trimEnd('/')

    // ---------- alamat server ----------
    class UrlCheck(val url: String?, val error: String?)

    private fun isLocalHost(h: String): Boolean =
        h == "localhost" || h == "10.0.2.2" || h.startsWith("127.") || h.startsWith("192.168.") || h.startsWith("10.") ||
            Regex("^172\\.(1[6-9]|2[0-9]|3[01])\\..*").matches(h)

    /**
     * Rapikan & periksa alamat yang diketik pemain. "novabeat.onrender.com" otomatis jadi https://novabeat.onrender.com;
     * path / query dibuang; http:// hanya boleh untuk jaringan lokal (kata sandi & token tidak boleh lewat http di internet).
     */
    fun checkServerUrl(raw: String): UrlCheck {
        var s = raw.trim()
        if (s.isEmpty()) return UrlCheck(null, "Alamat server kosong")
        if (!s.contains("://")) s = "https://$s"
        val uri = try {
            java.net.URI(s)
        } catch (e: Exception) {
            return UrlCheck(null, "Alamat server tidak valid")
        }
        val scheme = (uri.scheme ?: "").lowercase(Locale.ROOT)
        val host = uri.host ?: return UrlCheck(null, "Alamat server tidak valid")
        if (scheme != "http" && scheme != "https") return UrlCheck(null, "Alamat harus diawali http:// atau https://")
        if (scheme == "http" && !isLocalHost(host)) {
            return UrlCheck(null, "Alamat http:// hanya boleh untuk jaringan lokal. Pakai https:// supaya kata sandi dan token terenkripsi.")
        }
        val port = if (uri.port > 0) ":${uri.port}" else ""
        return UrlCheck("$scheme://$host$port", null)
    }

    /**
     * Simpan alamat server baru. Return pesan galat (Indonesia) atau null bila berhasil. Berpindah server = keluar dari akun:
     * token dan ID pemain milik server lama tidak berlaku di server baru, dan antrean skor tertunda dikosongkan.
     */
    fun changeServer(raw: String): String? {
        val c = checkServerUrl(raw)
        val u = c.url ?: return c.error
        if (u != baseUrl) {
            if (loggedIn) {
                token = ""
                Accounts.logout()
            }
            sp.edit().putString("url", u).putString("pending", "[]").putFloat("pp", 0f).putInt("maps", 0)
                .putLong("uid", 0L).putLong("avatar_at", 0L).putLong("avatar_next", 0L).apply()
        }
        return null
    }

    fun resetServer(): String? = changeServer(DEFAULT_URL)

    val isDefaultServer: Boolean get() = baseUrl == DEFAULT_URL.trim().trimEnd('/')

    /** Tes koneksi ke server (memblokir; server gratis yang tidur butuh ~1 menit, percobaan ulang ada di [request]). */
    fun ping(): CloudRes {
        val t0 = System.currentTimeMillis()
        val r = request("GET", "/api/health", null, false)
        if (!r.ok) return r
        if (!r.json.optBoolean("ok")) return CloudRes(false, r.status, r.json, "Alamat ini menjawab, tetapi bukan server Nova Beat. Periksa alamatnya.")
        return CloudRes(true, r.status, r.json, "Server terhubung (${System.currentTimeMillis() - t0} ms)")
    }

    /** Token sesi untuk koneksi room server (kosong bila belum masuk). */
    fun sessionToken(): String = if (::sp.isInitialized) token else ""

    /** Alamat WebSocket room: http(s) -> ws(s) + /ws/rooms. */
    fun wsUrl(): String = baseUrl.replaceFirst("http", "ws") + "/ws/rooms"

    /** Daftar room publik di server (tanpa login). */
    fun listRooms(): CloudRes = request("GET", "/api/rooms", null, false)

    // ---------- token sesi: terenkripsi dengan kunci Android Keystore ----------
    @Volatile private var tokenMem: String? = null

    private var token: String
        get() {
            tokenMem?.let { return it }
            val v = readToken()
            tokenMem = v
            return v
        }
        set(v) {
            tokenMem = v
            writeToken(v)
        }

    private fun readToken(): String {
        val enc = sp.getString("token_enc", "") ?: ""
        if (enc.isNotEmpty()) return SecureStore.decrypt(enc) ?: "" // kunci hilang (mis. pulihkan HP): minta masuk lagi
        val old = sp.getString("token", "") ?: ""
        if (old.isNotEmpty()) { // versi lama menyimpan token sebagai teks biasa: pindahkan ke penyimpanan terenkripsi
            val e = SecureStore.encrypt(old)
            if (e != null) sp.edit().putString("token_enc", e).remove("token").apply()
        }
        return old
    }

    private fun writeToken(v: String) {
        if (v.isEmpty()) {
            sp.edit().remove("token_enc").remove("token").apply()
            return
        }
        val e = SecureStore.encrypt(v)
        if (e != null) sp.edit().putString("token_enc", e).remove("token").apply()
        else sp.edit().putString("token", v).apply() // Keystore perangkat tidak berfungsi: cadangan terakhir
    }

    val loggedIn: Boolean get() = ::sp.isInitialized && token.isNotEmpty()
    val userId: Long get() = sp.getLong("uid", 0L)
    val totalPp: Float get() = sp.getFloat("pp", 0f)

    /** Jalankan [work] di thread latar lalu panggil [done] di thread utama. */
    fun <T : Any> async(work: () -> T, done: (T) -> Unit) {
        io.execute {
            val r: T? = try {
                work()
            } catch (e: Throwable) {
                null
            }
            main.post { if (r != null) done(r) }
        }
    }

    // ============================================================ HTTP
    /**
     * Server gratis (Render) tidur saat sepi dan butuh sekitar 1 menit untuk bangun: batas waktu dibuat longgar dan
     * jawaban 502/503/504 (server belum siap) dicoba ulang beberapa kali.
     */
    fun request(method: String, path: String, body: JSONObject? = null, auth: Boolean = true, bearer: String? = null): CloudRes {
        var r = requestOnce(method, path, body, auth, bearer)
        var tries = 0
        while ((r.status == 502 || r.status == 503 || r.status == 504) && tries < 4) {
            tries++
            try {
                Thread.sleep(5000)
            } catch (e: InterruptedException) {
                break
            }
            r = requestOnce(method, path, body, auth, bearer)
        }
        return r
    }

    private fun requestOnce(method: String, path: String, body: JSONObject?, auth: Boolean, bearer: String?): CloudRes {
        var c: HttpURLConnection? = null
        try {
            c = URL(baseUrl + path).openConnection() as HttpURLConnection
            c.requestMethod = method
            c.connectTimeout = 20000
            c.readTimeout = 75000
            c.setRequestProperty("Accept", "application/json")
            val tk = bearer ?: token
            if (auth && tk.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer $tk")
            if (body != null) {
                val b = body.toString().toByteArray(Charsets.UTF_8)
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.setFixedLengthStreamingMode(b.size)
                c.outputStream.use { it.write(b) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            val js = try {
                JSONObject(txt)
            } catch (e: Exception) {
                JSONObject()
            }
            if (code == 401 && auth && js.optString("error") == "belum_masuk") expire()
            val ok = code in 200..299
            return CloudRes(ok, code, js, if (ok) js.optString("message", "") else friendly(code, js))
        } catch (e: java.net.UnknownHostException) {
            return CloudRes(false, 0, JSONObject(), "Alamat server tidak ditemukan ($baseUrl). Periksa internet atau alamat server di Profil.")
        } catch (e: java.net.SocketTimeoutException) {
            return CloudRes(false, 0, JSONObject(), "Server tidak menjawab (waktu habis). Server gratis butuh ±1 menit untuk bangun; coba lagi sebentar lagi.")
        } catch (e: javax.net.ssl.SSLException) {
            return CloudRes(false, 0, JSONObject(), "Sambungan aman (HTTPS) ke server gagal. Periksa tanggal & jam HP dan alamat server.")
        } catch (e: Exception) {
            return CloudRes(false, 0, JSONObject(), "Tidak bisa terhubung ke server ($baseUrl). Periksa internet atau alamat server.")
        } finally {
            try {
                c?.disconnect()
            } catch (e: Exception) {
            }
        }
    }

    /** Pesan galat berbahasa Indonesia. Pesan dari server (sudah Indonesia) dipakai bila ada; selain itu dibuat dari kode status. */
    private fun friendly(code: Int, js: JSONObject): String {
        val m = js.optString("message")
        if (m.isNotEmpty()) return m
        return when (code) {
            401 -> "Sesi habis. Silakan masuk lagi."
            404 -> "Alamat server tidak ditemukan (404). Periksa alamat server di Profil, atau server belum diperbarui."
            413 -> "Data terlalu besar untuk dikirim."
            429 -> "Terlalu banyak percobaan. Coba lagi sebentar lagi."
            502, 503, 504 -> "Server sedang bangun atau sibuk. Tunggu sekitar 1 menit lalu coba lagi."
            in 500..599 -> "Galat di server ($code). Coba lagi nanti."
            else -> "Galat server ($code)"
        }
    }

    private fun download(path: String): ByteArray? {
        var c: HttpURLConnection? = null
        return try {
            c = URL(baseUrl + path).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 15000
            if (c.responseCode == 200) c.inputStream.use { it.readBytes() } else null
        } catch (e: Exception) {
            null
        } finally {
            try {
                c?.disconnect()
            } catch (e: Exception) {
            }
        }
    }

    /** Sesi di server sudah tidak berlaku: keluar secara lokal (profil lokal bayangan ikut keluar). */
    private fun expire() {
        token = ""
        Accounts.logout()
    }

    // ============================================================ AKUN
    /** Daftar ([register] = true) atau masuk. Kata sandi dikirim lewat HTTPS dan di-hash Argon2id di server. */
    fun authenticate(register: Boolean, name: String, pw: String): CloudRes {
        val r = request("POST", if (register) "/api/register" else "/api/login", JSONObject().put("username", name.trim()).put("password", pw), false)
        if (r.ok) {
            token = r.json.optString("token")
            r.json.optJSONObject("user")?.let { applyUser(it) }
            lastRefresh = System.currentTimeMillis()
        }
        return r
    }

    /** Terapkan data akun dari server ke profil lokal bayangan (id "c<id>") supaya fitur lama (favorit, chip, foto) ikut bekerja. */
    fun applyUser(u: JSONObject) {
        val id = u.optLong("id")
        Accounts.useCloud(id, u.optString("username"), u.optString("bio"), u.optLong("created_at"))
        sp.edit().putLong("uid", id).putFloat("pp", u.optDouble("total_pp", 0.0).toFloat()).putInt("maps", u.optInt("maps_cleared"))
            .putLong("avatar_next", u.optLong("avatar_next_change_at")).apply()
        syncAvatar(id, u.optLong("avatar_at"))
    }

    private fun syncAvatar(id: Long, at: Long) {
        val acc = Accounts.current() ?: return
        val f = Accounts.avatarFile(acc)
        if (at <= 0L) {
            if (f.isFile) {
                f.delete()
                AvatarView.invalidateCache()
            }
            sp.edit().putLong("avatar_at", 0L).apply()
            return
        }
        if (f.isFile && sp.getLong("avatar_at", 0L) == at) return
        val b = download("/api/users/$id/avatar") ?: return
        try {
            f.writeBytes(b)
            sp.edit().putLong("avatar_at", at).apply()
            AvatarView.invalidateCache()
        } catch (e: Exception) {
        }
    }

    fun refreshMe(): CloudRes? {
        if (!loggedIn) return null
        val r = request("GET", "/api/me")
        if (r.ok) {
            r.json.optJSONObject("user")?.let { applyUser(it) }
            lastRefresh = System.currentTimeMillis()
        }
        return r
    }

    /** Panggil dari onResume layar utama: segarkan PP / foto (maks. sekali per menit) dan kirim skor yang tertunda. */
    fun onAppActive() {
        if (!enabled) return
        wake()
        if (!loggedIn) return
        val now = System.currentTimeMillis()
        if (now - lastRefresh < 60000L) return
        lastRefresh = now
        io.execute {
            refreshMe()
            flushPending()
        }
    }

    @Volatile private var lastWake = 0L

    /** Bangunkan server yang tidur (hosting gratis) selagi pemain masih di menu, supaya masuk / daftar tidak menunggu lama. */
    fun wake() {
        if (!::sp.isInitialized) return
        val now = System.currentTimeMillis()
        if (now - lastWake < 5 * 60 * 1000L) return
        lastWake = now
        io.execute { requestOnce("GET", "/api/health", null, false, null) }
    }

    fun logout() {
        val t = token
        if (t.isNotEmpty()) io.execute { request("POST", "/api/logout", JSONObject(), true, t) } // server mencabut sesi di latar
        token = ""
        Accounts.logout()
        sp.edit().putFloat("pp", 0f).putInt("maps", 0).apply()
    }

    fun setBio(bio: String): CloudRes {
        val r = request("POST", "/api/me/profile", JSONObject().put("bio", bio))
        if (r.ok) r.json.optJSONObject("user")?.let { applyUser(it) }
        return r
    }

    fun changePassword(old: String, new: String): CloudRes {
        val r = request("POST", "/api/me/password", JSONObject().put("old_password", old).put("new_password", new))
        if (r.ok) token = r.json.optString("token", token)
        return r
    }

    fun deleteAccount(pw: String): CloudRes {
        val r = request("POST", "/api/me/delete", JSONObject().put("password", pw))
        if (r.ok) {
            token = ""
            Accounts.current()?.let { Accounts.delete(it) }
        }
        return r
    }

    // ---------- batas ganti foto: 1 kali per 7 hari (diputuskan server, dicatat di database) ----------
    /** Sisa waktu (ms) sampai foto boleh diganti lagi menurut catatan terakhir dari server; 0 = boleh sekarang. */
    fun avatarWaitMs(): Long = (sp.getLong("avatar_next", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    private fun durText(ms: Long): String {
        val min = Math.max(1L, (ms + 59_999L) / 60_000L)
        val d = min / 1440
        val h = (min % 1440) / 60
        val m = min % 60
        val parts = ArrayList<String>()
        if (d > 0) parts.add(L.t("$d hari", "$d day" + (if (d > 1) "s" else "")))
        if (h > 0) parts.add(L.t("$h jam", "$h hour" + (if (h > 1) "s" else "")))
        if (m > 0 && d == 0L) parts.add(L.t("$m menit", "$m min"))
        return if (parts.isEmpty()) L.t("kurang dari semenit", "less than a minute") else parts.joinToString(" ")
    }

    /** Pesan "belum boleh ganti foto" dengan sisa waktu dan tanggal di zona waktu HP. [untilMs] default: catatan terakhir dari server. */
    fun avatarWaitMessage(untilMs: Long = sp.getLong("avatar_next", 0L)): String {
        val wait = untilMs - System.currentTimeMillis()
        val fmt = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT, if (L.en) Locale.ENGLISH else Locale("id", "ID"))
        val on = fmt.format(Date(untilMs))
        return L.t(
            "Foto profil hanya bisa diganti 1 kali setiap 7 hari. Kamu bisa menggantinya lagi dalam sekitar ${durText(wait)}, yaitu pada $on. Menghapus foto tetap boleh kapan saja.",
            "Your profile photo can only be changed once every 7 days. You can change it again in about ${durText(wait)}, on $on. Removing the photo is always allowed."
        )
    }

    /** Unggah foto (file JPEG lokal, diperkecil ke 160 px supaya < 80 KB). Pesan 429 diganti versi berzona waktu HP. */
    fun uploadAvatar(file: File): CloudRes {
        val bmp = BitmapFactory.decodeFile(file.path) ?: return CloudRes(false, 0, JSONObject(), "Gambar tidak bisa dibaca")
        val sm = Bitmap.createScaledBitmap(bmp, 160, 160, true)
        val bo = ByteArrayOutputStream()
        sm.compress(Bitmap.CompressFormat.JPEG, 82, bo)
        val r = request("POST", "/api/me/avatar", JSONObject().put("jpeg_base64", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)))
        if (r.ok) {
            sp.edit().putLong("avatar_at", r.json.optLong("avatar_at")).putLong("avatar_next", r.json.optLong("avatar_next_change_at")).apply()
        } else if (r.status == 429 && r.json.optString("error") == "avatar_dibatasi") {
            val until = r.json.optLong("retry_at")
            if (until > 0L) {
                sp.edit().putLong("avatar_next", until).apply()
                return CloudRes(false, 429, r.json, avatarWaitMessage(until))
            }
        }
        return r
    }

    /** Hapus foto di server (selalu boleh; tidak mengubah batas 7 hari). */
    fun removeAvatar(): CloudRes {
        val r = request("POST", "/api/me/avatar", JSONObject().put("remove", true))
        if (r.ok) sp.edit().putLong("avatar_at", 0L).putLong("avatar_next", r.json.optLong("avatar_next_change_at")).apply()
        return r
    }

    /** Foto pemain lain (cache memori + disk). [cb] dipanggil di thread utama; null = tidak punya foto. */
    fun avatar(id: Long, at: Long, cb: (Bitmap?) -> Unit) {
        if (at <= 0L) {
            cb(null)
            return
        }
        val key = "$id:$at"
        bmpCache.get(key)?.let {
            cb(it)
            return
        }
        io.execute {
            val f = File(app.cacheDir, "av_${id}_$at.jpg")
            var bmp: Bitmap? = if (f.isFile) BitmapFactory.decodeFile(f.path) else null
            if (bmp == null) {
                val b = download("/api/users/$id/avatar")
                if (b != null) {
                    try {
                        f.writeBytes(b)
                    } catch (e: Exception) {
                    }
                    bmp = BitmapFactory.decodeByteArray(b, 0, b.size)
                }
            }
            if (bmp != null) bmpCache.put(key, bmp)
            main.post { cb(bmp) }
        }
    }

    // ============================================================ SOSIAL & PERINGKAT
    fun search(q: String): CloudRes = request("GET", "/api/users/search?q=" + java.net.URLEncoder.encode(q, "UTF-8"))
    fun user(id: Long): CloudRes = request("GET", "/api/users/$id")
    fun friends(): CloudRes = request("GET", "/api/friends")
    fun friendRequest(id: Long): CloudRes = request("POST", "/api/friends/request", JSONObject().put("user_id", id))
    fun friendAccept(id: Long): CloudRes = request("POST", "/api/friends/accept", JSONObject().put("user_id", id))
    fun friendRemove(id: Long): CloudRes = request("POST", "/api/friends/remove", JSONObject().put("user_id", id))
    fun globalBoard(): CloudRes = request("GET", "/api/leaderboard/global?limit=100")
    fun mapBoard(mapKey: String, sort: String): CloudRes =
        request("GET", "/api/leaderboard/map/" + java.net.URLEncoder.encode(mapKey, "UTF-8") + "?limit=100&sort=" + sort)

    // ============================================================ SKOR + PP
    class ScoreSub(val mapKey: String, val title: String, val score: Int, val acc: Float, val combo: Int, val pp: Double, val stars: Double = 0.0)

    /**
     * Kirim skor tamat. Server memberi PP hanya pada tamat PERTAMA map itu untuk akun ini. Bila tidak ada internet,
     * skor disimpan di antrean dan dikirim ulang nanti. [cb] (thread utama): null = belum masuk / masuk antrean.
     */
    fun submitScore(s: ScoreSub, cb: (CloudRes?) -> Unit) {
        if (!loggedIn) {
            cb(null)
            return
        }
        io.execute {
            val r = sendScore(s)
            if (r.status == 0 || r.status >= 500) enqueue(s)
            else if (r.ok) sp.edit().putFloat("pp", r.json.optDouble("total_pp", totalPp.toDouble()).toFloat()).putInt("maps", r.json.optInt("maps_cleared")).apply()
            main.post { cb(if (r.ok) r else null) }
        }
    }

    private fun sendScore(s: ScoreSub): CloudRes = request(
        "POST", "/api/scores",
        JSONObject().put("map_id", s.mapKey).put("map_title", s.title).put("score", s.score).put("accuracy", s.acc.toDouble())
            .put("max_combo", s.combo).put("pp", s.pp).put("stars", s.stars)
    )

    @Synchronized
    private fun enqueue(s: ScoreSub) {
        val arr = try {
            JSONArray(sp.getString("pending", "[]") ?: "[]")
        } catch (e: Exception) {
            JSONArray()
        }
        // satu entri per (akun, map): simpan skor tertinggi
        val out = JSONArray()
        var merged = false
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optLong("uid") == userId && o.optString("map") == s.mapKey) {
                merged = true
                if (s.score > o.optInt("score")) {
                    o.put("score", s.score).put("acc", s.acc.toDouble()).put("combo", s.combo)
                }
            }
            out.put(o)
        }
        if (!merged) out.put(JSONObject().put("uid", userId).put("map", s.mapKey).put("title", s.title).put("score", s.score).put("acc", s.acc.toDouble()).put("combo", s.combo).put("pp", s.pp).put("stars", s.stars))
        val trimmed = JSONArray()
        val from = maxOf(0, out.length() - 60)
        for (i in from until out.length()) trimmed.put(out.get(i))
        sp.edit().putString("pending", trimmed.toString()).apply()
    }

    @Synchronized
    fun flushPending() {
        if (!loggedIn) return
        val arr = try {
            JSONArray(sp.getString("pending", "[]") ?: "[]")
        } catch (e: Exception) {
            return
        }
        if (arr.length() == 0) return
        val keep = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optLong("uid") != userId) {
                keep.put(o)
                continue
            }
            val r = sendScore(ScoreSub(o.optString("map"), o.optString("title"), o.optInt("score"), o.optDouble("acc").toFloat(), o.optInt("combo"), o.optDouble("pp"), o.optDouble("stars", 0.0)))
            if (!r.ok && (r.status == 0 || r.status >= 500 || r.status == 429)) keep.put(o) // coba lagi nanti
            else if (r.ok) sp.edit().putFloat("pp", r.json.optDouble("total_pp", totalPp.toDouble()).toFloat()).apply()
        }
        sp.edit().putString("pending", keep.toString()).apply()
    }
}
