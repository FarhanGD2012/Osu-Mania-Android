package com.maniadroid

import android.os.Handler
import android.os.Looper
import org.json.JSONObject

/**
 * Daftar room yang bisa dimasuki: dari siaran Wi-Fi / hotspot (otomatis, tanpa internet) dan dari daftar lobi internet
 * (broker MQTT publik, hanya bila pengguna menyalakannya). Callback [onChange] berjalan di thread utama.
 */
object LobbyBrowser {
    class Room(
        val key: String, val code: String, val name: String, val host: String, val players: Int, val max: Int,
        val matchType: Int, val queueMode: Int, val winCond: Int, val pw: Boolean, val st: String, val chart: String,
        val keys: Int, val internet: Boolean, val ip: String, val port: Int, val seen: Long, val ts: Long
    )

    private val main = Handler(Looper.getMainLooper())
    private val rooms = LinkedHashMap<String, Room>()
    var onChange: (() -> Unit)? = null
    private var scanner: LanScanner? = null
    private val nets = ArrayList<MqttLite>()
    @Volatile var netOn = false
        private set
    @Volatile var netConnected = 0
        private set

    private fun parse(ip: String, json: String, net: Boolean, codeFromTopic: String?): Room? {
        return try {
            val o = JSONObject(json)
            if (o.optString("a") != "mdv1") return null
            val code = o.optString("code")
            if (code.isEmpty()) return null
            Room(
                (if (net) "net:" else "lan:$ip:") + code, code, o.optString("name"), o.optString("host"), o.optInt("pl"), o.optInt("mx"),
                o.optInt("mt"), o.optInt("qm"), o.optInt("wc"), o.optBoolean("pw"), o.optString("st", "lobby"), o.optString("ch"),
                o.optInt("k"), net || o.optBoolean("net"), ip, o.optInt("port", MpConst.LAN_PORT), System.currentTimeMillis(), o.optLong("ts")
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun changed() {
        main.post { onChange?.invoke() }
    }

    fun snapshot(): List<Room> {
        val now = System.currentTimeMillis()
        synchronized(rooms) {
            val it = rooms.entries.iterator()
            while (it.hasNext()) {
                val r = it.next().value
                val lan = r.key.startsWith("lan:")
                if (lan && now - r.seen > 6000) it.remove()
                else if (!lan && (now - r.ts > 120_000 || r.ts - now > 60_000)) it.remove()
            }
            return rooms.values.toList()
        }
    }

    fun startLan() {
        if (scanner != null) return
        scanner = LanScanner { ip, json ->
            val r = parse(ip, json, false, null) ?: return@LanScanner
            if (r.code == Versus.code) return@LanScanner
            synchronized(rooms) { rooms[r.key] = r }
            changed()
        }.also { it.start() }
    }

    fun stopLan() {
        scanner?.stop()
        scanner = null
    }

    fun startNet() {
        if (netOn) return
        netOn = true
        netConnected = 0
        for ((i, b) in MpConst.BROKERS.withIndex()) {
            Thread {
                val m = MqttLite("mdl-" + java.lang.Long.toHexString(java.util.Random().nextLong()).take(10))
                try {
                    m.listener = object : MqttLite.Listener {
                        override fun onMessage(topic: String, payload: ByteArray) {
                            val code = topic.substringAfterLast('/')
                            if (payload.isEmpty()) {
                                synchronized(rooms) { rooms.remove("net:$code") }
                                changed()
                                return
                            }
                            val r = parse("", String(payload, Charsets.UTF_8), true, code) ?: return
                            synchronized(nets) { if (!netOn) return }
                            if (r.code == Versus.code) return
                            synchronized(rooms) { rooms[r.key] = r }
                            changed()
                        }

                        override fun onClosed(reason: String) {
                            netConnected = (netConnected - 1).coerceAtLeast(0)
                            changed()
                        }
                    }
                    m.connect(b.first, b.second, null)
                    m.subscribe(MpConst.LOBBY_FILTER)
                    var keep: Boolean
                    synchronized(nets) {
                        keep = netOn
                        if (keep) nets.add(m)
                    }
                    if (keep) {
                        netConnected++
                        changed()
                    } else m.close()
                } catch (e: Exception) {
                    try {
                        m.close()
                    } catch (x: Exception) {
                    }
                    changed()
                }
            }.also { it.isDaemon = true; it.name = "lobby-net$i" }.start()
        }
    }

    fun stopNet() {
        synchronized(nets) {
            netOn = false
            for (m in nets) try {
                m.close()
            } catch (e: Exception) {
            }
            nets.clear()
        }
        synchronized(rooms) { rooms.keys.removeAll { it.startsWith("net:") } }
        netConnected = 0
    }

    fun stopAll() {
        stopLan()
        stopNet()
        onChange = null
    }
}
