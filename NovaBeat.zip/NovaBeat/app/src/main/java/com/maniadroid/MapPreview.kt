package com.maniadroid

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * Pratinjau note: menggambar note jatuh dari satu chart (file .osu yang diambil sekilas dari mirror, tanpa mengunduh
 * seluruh set) selaras dengan cuplikan lagu. Memakai warna / gambar note yang sama dengan permainan.
 */
class NotePreviewView(ctx: Context) : View(ctx) {
    private var bm: Beatmap? = null
    private var startMs = 0.0
    private var clock: (() -> Double)? = null
    private var bmps = arrayOfNulls<Bitmap>(0)
    private var bodies = IntArray(0)
    private var bw = 0
    private var idx = 0
    private var lastT = 0.0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val d = resources.displayMetrics.density
    var message: String = ""
        set(v) {
            field = v
            invalidate()
        }

    fun setChart(b: Beatmap?, start: Double, clk: () -> Double) {
        bm = b
        startMs = start
        clock = clk
        idx = 0
        lastT = 0.0
        bw = 0
        invalidate()
    }

    private fun build(w: Int, h: Int, keys: Int): Float {
        val lane = min(w / keys.toFloat(), h * 0.2f)
        val nd = (lane * 0.84f).toInt().coerceAtLeast(8)
        if (bw != nd || bmps.size != keys) {
            bw = nd
            bmps = arrayOfNulls(keys)
            bodies = IntArray(keys)
            for (c in 0 until keys) {
                bmps[c] = try {
                    NoteSkin.make(context, keys, c, nd, nd, true)
                } catch (e: Throwable) {
                    null
                }
                bodies[c] = NoteSkin.bodyColor(context, keys, c)
            }
        }
        return lane
    }

    override fun onDraw(cv: Canvas) {
        val w = width
        val h = height
        p.style = Paint.Style.FILL
        p.color = 0xFF000000.toInt()
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        val b = bm
        val ck = clock
        if (b == null || ck == null || b.notes.isEmpty()) {
            p.color = 0xFF9A9AB0.toInt()
            p.textAlign = Paint.Align.CENTER
            p.textSize = 13f * d
            cv.drawText(message, w / 2f, h / 2f, p)
            postInvalidateOnAnimation()
            return
        }
        val keys = b.keys
        val lane = build(w, h, keys)
        val fieldW = lane * keys
        val fx = (w - fieldW) / 2f
        val hitY = h * 0.84f
        val t = startMs + ck()
        if (t < lastT - 80) idx = 0
        lastT = t
        val ns = b.notes
        while (idx < ns.size && ns[idx].endTime < t - 120) idx++
        val scrollMs = 850.0
        val pxMs = hitY / scrollMs
        // garis luar
        p.color = 0x3CFFFFFF
        cv.drawRect(fx - 1f, 0f, fx + 1f, h.toFloat(), p)
        cv.drawRect(fx + fieldW - 1f, 0f, fx + fieldW + 1f, h.toFloat(), p)
        // bulatan kosong
        val rr = bw / 2f
        p.style = Paint.Style.STROKE
        p.strokeWidth = max(2f * d, rr * 0.12f)
        p.color = 0xAAFFFFFF.toInt()
        for (c in 0 until keys) cv.drawCircle(fx + c * lane + lane / 2f, hitY, rr - p.strokeWidth / 2f, p)
        p.style = Paint.Style.FILL
        var i = idx
        while (i < ns.size) {
            val n = ns[i]
            i++
            if ((n.time - t) * pxMs > hitY + bw) break
            val cx = fx + n.col * lane + lane / 2f
            val yHead = (hitY - (n.time - t) * pxMs).toFloat()
            if (n.isHold) {
                val yTail = (hitY - (n.endTime - t) * pxMs).toFloat()
                val bwid = bw * 0.56f
                p.color = (bodies[n.col] and 0x00FFFFFF) or (130 shl 24)
                rect.set(cx - bwid / 2f, min(yHead, yTail), cx + bwid / 2f, max(yHead, yTail))
                cv.drawRoundRect(rect, bwid / 2f, bwid / 2f, p)
            }
            val bmp = bmps.getOrNull(n.col)
            if (bmp != null) cv.drawBitmap(bmp, cx - bmp.width / 2f, yHead - bmp.height / 2f, null)
        }
        postInvalidateOnAnimation()
    }
}

/**
 * Bar posisi ala YouTube: jalur abu-abu, bagian yang sudah dimuat lebih terang, bagian yang sudah diputar MERAH, dan
 * bulatan di ujungnya. Seret / ketuk untuk loncat ke bagian mana pun. Tidak bisa disentuh saat [enabled] = false.
 */
class SeekLine(ctx: Context) : View(ctx) {
    var frac = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var buffered = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var scrubbing = false
        private set
    var onScrub: ((Float, Boolean) -> Unit)? = null // (posisi 0..1, selesai?)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    init {
        isEnabled = false
    }

    override fun onDraw(cv: Canvas) {
        val h = height.toFloat()
        val pad = 8f * d
        val w = width - pad * 2
        val th = 3.5f * d
        val cy = h / 2f
        p.style = Paint.Style.FILL
        p.color = 0x40FFFFFF
        cv.drawRoundRect(pad, cy - th / 2, pad + w, cy + th / 2, th, th, p)
        if (buffered > 0f && buffered < 1f) {
            p.color = 0x70FFFFFF
            cv.drawRoundRect(pad, cy - th / 2, pad + w * buffered, cy + th / 2, th, th, p)
        }
        p.color = if (isEnabled) 0xFFFF2B2B.toInt() else 0x66FF2B2B
        cv.drawRoundRect(pad, cy - th / 2, pad + w * frac, cy + th / 2, th, th, p)
        if (isEnabled) cv.drawCircle(pad + w * frac, cy, (if (scrubbing) 7f else 5.5f) * d, p)
    }

    private fun fracAt(x: Float): Float {
        val pad = 8f * d
        return ((x - pad) / (width - pad * 2)).coerceIn(0f, 1f)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!isEnabled) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                scrubbing = true
                frac = fracAt(e.x)
                onScrub?.invoke(frac, false)
            }
            MotionEvent.ACTION_MOVE -> if (scrubbing) {
                frac = fracAt(e.x)
                onScrub?.invoke(frac, false)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (scrubbing) {
                scrubbing = false
                frac = fracAt(e.x)
                onScrub?.invoke(frac, true)
                invalidate()
            }
        }
        return true
    }
}

/**
 * Layar info + preview satu beatmapset di daftar Unduh (muncul saat kartu diketuk atau tombol Preview ditekan):
 *  - info lengkap: sampul, judul, artis, mapper, status, genre / bahasa / tag, tanggal, dimainkan / suka, dan tiap diff
 *    (SR, jumlah note dipecah tap / hold, NPS, BPM, durasi, OD, HP),
 *  - preview note jatuh dari diff yang dipilih, dengan LAGU PENUH + bar merah ala YouTube untuk loncat ke bagian mana pun
 *    (lagu penuh diambil sebagian saja dari server, tidak mengunduh seluruh set; bila gagal: cuplikan lalu mode tanpa suara
 *    yang tetap bisa digeser untuk melihat seluruh chart),
 *  - tombol favorit (hati), Unduh, Tutup.
 */
class MapPreview(
    private val a: Activity,
    private val r: Downloader.Remote,
    private val installed: Boolean,
    private val onFavChanged: () -> Unit = {},
    private val onDownload: () -> Unit
) {
    private lateinit var dlg: Dialog
    private var closed = false
    private var mp: MediaPlayer? = null
    private var mpReady = false
    private var audioFailed = false
    private var timerStart = 0L

    // mode waktu: 0 = cuplikan 10 dtk, 1 = lagu penuh, 2 = tanpa suara (garis waktu chart saja)
    private var mode = 0
    private var fullDurMs = 0
    private var silentPos = 0.0
    private var silentT0 = 0L
    private var playing = true
    private var snippetStart = 0.0
    private var chartLenMs = 0.0
    private var fullFailed = false
    private var fullTried = false

    private var sel = -1
    private var loadToken = 0
    private var curBm: Beatmap? = null
    private var detail: Downloader.Detail? = null
    private var diffs: List<Downloader.Diff> = r.diffs.sortedWith(compareBy({ it.keys }, { it.stars }))

    private lateinit var view: NotePreviewView
    private lateinit var status: TextView
    private lateinit var rows: LinearLayout
    private lateinit var infoLine: TextView
    private lateinit var statLine: TextView
    private lateinit var playBtn: IconView
    private lateinit var heart: IconView
    private lateinit var seek: SeekLine
    private lateinit var tCur: TextView
    private lateinit var tTot: TextView
    private val ui = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = Ui.dp(a, v)

    private fun starColor(s: Float): Int = when {
        s < 2f -> 0xFF4CD08A.toInt()
        s < 2.7f -> 0xFF4DA3FF.toInt()
        s < 4f -> 0xFFFFC94D.toInt()
        s < 5.3f -> 0xFFFF8A4D.toInt()
        s < 6.5f -> 0xFFFF4D6A.toInt()
        else -> 0xFF714DFF.toInt()
    }

    private fun mmss(ms: Double): String {
        val s = (ms / 1000.0).toInt().coerceAtLeast(0)
        return String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60)
    }

    // ---------- tampilan ----------
    fun show() {
        MenuMusic.hold = true // musik menu berhenti selama preview
        MenuMusic.pause()
        purgeOldAudio()
        val d = Dialog(a)
        dlg = d
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val root = FrameLayout(a)
        root.setBackgroundColor(0xFF0B0A12.toInt())
        val cover = ImageView(a)
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(cover, FrameLayout.LayoutParams(-1, -1))
        Img.load("https://assets.ppy.sh/beatmaps/${r.id}/covers/cover.jpg", cover)
        val dim = View(a)
        dim.setBackgroundColor(0xD00B0A12.toInt())
        root.addView(dim, FrameLayout.LayoutParams(-1, -1))

        val body = LinearLayout(a)
        body.orientation = LinearLayout.HORIZONTAL
        body.setPadding(dp(18), dp(14), dp(18), dp(12))
        root.addView(body, FrameLayout.LayoutParams(-1, -1))

        // ---- kiri: info (bisa digulir) + tombol ----
        val left = LinearLayout(a)
        left.orientation = LinearLayout.VERTICAL
        val col = LinearLayout(a)
        col.orientation = LinearLayout.VERTICAL
        val title = Ui.text(a, if (r.title.isEmpty()) "Beatmapset #${r.id}" else r.title, 20f, Color.WHITE, true)
        title.maxLines = 2
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(title)
        if (r.artist.isNotEmpty()) col.addView(Ui.text(a, r.artist, 13.5f, 0xFFE0E0EE.toInt()))
        if (r.creator.isNotEmpty()) col.addView(Ui.text(a, "mapper ${r.creator}", 12f, Ui.SUB))
        statLine = Ui.text(a, "", 11.5f, Ui.ACCENT, true)
        col.addView(statLine, LinearLayout.LayoutParams(-2, -2).also { it.topMargin = dp(4) })
        infoLine = Ui.text(a, "", 11f, 0xFFB8B8CC.toInt())
        col.addView(infoLine, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(3) })
        rows = LinearLayout(a)
        rows.orientation = LinearLayout.VERTICAL
        col.addView(rows, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(10) })
        val sv = ScrollView(a)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(col)
        left.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        val btns = LinearLayout(a)
        btns.orientation = LinearLayout.HORIZONTAL
        btns.gravity = Gravity.CENTER_VERTICAL
        heart = IconView(a, if (Accounts.isFav(r.id)) IconView.HEART_FILLED else IconView.HEART, heartTint())
        heart.setPadding(dp(11), dp(11), dp(11), dp(11))
        heart.background = Ui.ripple(Ui.lazerFill(0xFF2B2A3A.toInt(), dp(14).toFloat(), true, a))
        heart.setOnClickListener {
            Accounts.toggleFav(r)
            refreshHeart()
            onFavChanged()
        }
        btns.addView(heart, LinearLayout.LayoutParams(dp(44), dp(44)))
        val dl = Ui.button(a, if (installed) "Terpasang" else "Unduh", !installed, 14) {
            if (!installed) {
                close()
                onDownload()
            }
        }
        dl.isEnabled = !installed
        val cl = Ui.button(a, "Tutup", false, 14) { close() }
        btns.addView(dl, LinearLayout.LayoutParams(0, dp(44), 1.4f).also { it.leftMargin = dp(8) })
        btns.addView(cl, LinearLayout.LayoutParams(0, dp(44), 1f).also { it.leftMargin = dp(8) })
        left.addView(btns, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(8) })
        body.addView(left, LinearLayout.LayoutParams(0, -1, 0.47f))

        // ---- kanan: preview note + kontrol putar + bar merah ----
        val right = LinearLayout(a)
        right.orientation = LinearLayout.VERTICAL
        view = NotePreviewView(a)
        view.background = Ui.rounded(Color.BLACK, dp(16).toFloat())
        view.clipToOutline = true
        view.message = L.t("Pilih diff untuk melihat note", "Pick a difficulty to see the notes")
        right.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))

        val ctl = LinearLayout(a)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER_VERTICAL
        playBtn = IconView(a, IconView.PAUSE, Color.WHITE)
        playBtn.setPadding(dp(7), dp(7), dp(7), dp(7))
        playBtn.setOnClickListener { togglePlay() }
        ctl.addView(playBtn, LinearLayout.LayoutParams(dp(34), dp(34)))
        tCur = Ui.text(a, "0:00", 11f, Color.WHITE, true)
        ctl.addView(tCur, LinearLayout.LayoutParams(-2, -2).also { it.leftMargin = dp(2) })
        seek = SeekLine(a)
        seek.onScrub = { f, fin -> onScrub(f, fin) }
        ctl.addView(seek, LinearLayout.LayoutParams(0, dp(34), 1f))
        tTot = Ui.text(a, "-:--", 11f, Ui.SUB, true)
        ctl.addView(tTot)
        right.addView(ctl, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(4) })
        status = Ui.text(a, "", 11f, Ui.SUB)
        status.gravity = Gravity.CENTER
        right.addView(status, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(2) })
        body.addView(right, LinearLayout.LayoutParams(0, -1, 0.53f).also { it.leftMargin = dp(16) })

        buildInfo()
        buildRows()
        d.setContentView(root)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.BLACK))
            w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        }
        d.setOnDismissListener {
            closed = true
            ui.removeCallbacksAndMessages(null)
            releaseAudio()
            MenuMusic.hold = false
            MenuMusic.autoStart(a)
        }
        d.showImmersive(a)
        startSnippet(0)
        loadFullAudio()
        loadDetail()
        if (diffs.isNotEmpty()) select(diffs.size / 2)
        ui.post(ticker)
    }

    private fun heartTint(): Int = if (Accounts.isFav(r.id)) Ui.ACCENT else 0xFFDDDDEE.toInt()

    private fun refreshHeart() {
        heart.kind = if (Accounts.isFav(r.id)) IconView.HEART_FILLED else IconView.HEART
        heart.tint = heartTint()
        heart.invalidate()
    }

    private fun close() {
        try {
            dlg.dismiss()
        } catch (e: Exception) {
        }
    }

    private fun buildInfo() {
        val d = detail
        val src = d?.remote ?: r
        val stat = StringBuilder()
        if (src.status.isNotEmpty()) stat.append(src.status.uppercase()).append("   ")
        if (src.plays > 0) stat.append(L.t("${src.plays} dimainkan", "${src.plays} plays")).append("   ")
        if (src.favs > 0) stat.append(L.t("${src.favs} suka", "${src.favs} favourites"))
        statLine.text = stat.toString().trim()
        statLine.visibility = if (stat.isBlank()) View.GONE else View.VISIBLE
        val ex = d?.extra
        val parts = ArrayList<String>()
        if (ex != null) {
            val gl = listOf(ex.genre, ex.language).filter { it.isNotBlank() && it.lowercase() != "unspecified" && it.lowercase() != "any" }
            if (gl.isNotEmpty()) parts.add(gl.joinToString(" · "))
            val df = java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM)
            if (ex.submitted > 0) parts.add(L.t("Dikirim ", "Submitted ") + df.format(java.util.Date(ex.submitted)))
            if (ex.ranked > 0) parts.add(L.t("Ranked/Loved ", "Ranked/Loved ") + df.format(java.util.Date(ex.ranked)))
            val extras = ArrayList<String>()
            if (ex.video) extras.add(L.t("ada video", "has video"))
            if (ex.storyboard) extras.add("storyboard")
            if (extras.isNotEmpty()) parts.add(extras.joinToString(", "))
            if (ex.source.isNotBlank()) parts.add(L.t("Sumber: ", "Source: ") + ex.source)
            if (ex.tags.isNotBlank()) parts.add("Tag: " + ex.tags.trim())
        }
        infoLine.text = parts.joinToString("\n")
        infoLine.maxLines = 6
        infoLine.ellipsize = android.text.TextUtils.TruncateAt.END
        infoLine.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun buildRows() {
        rows.removeAllViews()
        if (diffs.isEmpty()) {
            rows.addView(
                Ui.text(a, "Detail diff belum tersedia (memuat…). Cuplikan lagu tetap diputar.", 12f, Ui.SUB),
                LinearLayout.LayoutParams(-1, -2)
            )
            return
        }
        val ex = detail?.extra
        for ((i, df) in diffs.withIndex()) {
            val row = LinearLayout(a)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(10), dp(6), dp(10), dp(6))
            row.background = Ui.ripple(Ui.rounded(if (i == sel) 0x40FFFFFF else 0x20FFFFFF, dp(12).toFloat()))
            val chip = Ui.text(a, String.format(java.util.Locale.US, "%.1f", df.stars), 12f, Color.WHITE, true)
            chip.gravity = Gravity.CENTER
            chip.background = Ui.rounded(starColor(df.stars), dp(9).toFloat())
            row.addView(chip, LinearLayout.LayoutParams(dp(40), dp(24)))
            val col = LinearLayout(a)
            col.orientation = LinearLayout.VERTICAL
            val name = Ui.text(a, "${df.keys}K  ${df.version}", 13.5f, Color.WHITE, i == sel)
            name.maxLines = 1
            name.ellipsize = android.text.TextUtils.TruncateAt.END
            col.addView(name)
            val len = String.format(java.util.Locale.US, "%d:%02d", df.length / 60, df.length % 60)
            val nps = if (df.length > 0) df.notes.toFloat() / df.length else 0f
            val taps = ex?.taps?.get(df.id)
            val holds = ex?.holds?.get(df.id)
            val l1 = if (taps != null && holds != null)
                String.format(java.util.Locale.US, "%d note (%d tap · %d hold) · %.1f nps", df.notes, taps, holds, nps)
            else String.format(java.util.Locale.US, "%d note · %.1f nps", df.notes, nps)
            val l2 = String.format(java.util.Locale.US, "%.0f BPM · %s · OD %.1f · HP %.1f", df.bpm, len, df.od, df.hp)
            for (t in listOf(l1, l2)) {
                val m = Ui.text(a, t, 10.5f, Ui.SUB)
                m.maxLines = 1
                m.ellipsize = android.text.TextUtils.TruncateAt.END
                col.addView(m)
            }
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = dp(10) })
            row.setOnClickListener { select(i) }
            rows.addView(row, LinearLayout.LayoutParams(-1, -2).also { it.bottomMargin = dp(5) })
        }
    }

    /** Data lengkap (tag, genre, tap/hold per diff…) dari API; bila gagal tampilan tetap memakai data pencarian. */
    private fun loadDetail() {
        Thread {
            val dt = Downloader.fetchDetail(r.id)
            a.runOnUiThread {
                if (closed || dt == null) return@runOnUiThread
                detail = dt
                if (diffs.isEmpty() || dt.remote.diffs.size >= diffs.size) {
                    val sorted = dt.remote.diffs.sortedWith(compareBy({ it.keys }, { it.stars }))
                    if (sorted.isNotEmpty()) diffs = sorted
                }
                buildInfo()
                buildRows()
                if (sel < 0 && diffs.isNotEmpty()) select(diffs.size / 2)
            }
        }.start()
    }

    // ---------- pilih diff + muat note ----------
    private fun select(i: Int) {
        if (i !in diffs.indices) return
        sel = i
        buildRows()
        val df = diffs[i]
        val token = ++loadToken
        curBm = null
        view.setChart(null, 0.0) { 0.0 }
        view.message = L.t("Memuat note…", "Loading notes…")
        if (df.id <= 0) {
            view.message = L.t("Note tidak tersedia untuk diff ini", "Notes unavailable for this difficulty")
            return
        }
        Thread {
            val f = Downloader.fetchOsu(df.id, a.cacheDir)
            val b = if (f != null) try {
                Beatmap.parse(f, true)
            } catch (e: Throwable) {
                null
            } else null
            var start = 0.0
            if (b != null && f != null) {
                val m = Regex("PreviewTime\\s*:\\s*(-?\\d+)").find(try { f.readText() } catch (e: Exception) { "" })
                val pt = m?.groupValues?.get(1)?.toIntOrNull() ?: -1
                start = if (pt > 0) pt.toDouble() else b.notes.getOrNull((b.notes.size * 0.4).toInt())?.time?.toDouble() ?: 0.0
            }
            a.runOnUiThread {
                if (closed || token != loadToken) return@runOnUiThread
                if (b == null || b.notes.isEmpty()) {
                    view.message = L.t("Note tidak bisa dimuat (server tidak menjawab)", "Could not load notes (server did not answer)")
                } else {
                    curBm = b
                    chartLenMs = b.notes.maxOf { it.endTime }.toDouble() + 2500.0
                    val firstChart = snippetStart == 0.0
                    snippetStart = start
                    timerStart = SystemClock.uptimeMillis()
                    // mode cuplikan: lagu dimulai dari PreviewTime chart, jadi posisi chart = PreviewTime + posisi cuplikan
                    if (mode == 0 && firstChart) seekSnippetToStart()
                    view.setChart(b, 0.0) { posMs() }
                    if (fullFailed) enterSilent()
                }
            }
        }.start()
    }

    // ---------- jam preview ----------
    /** Posisi (ms) di dalam chart saat ini, tergantung mode. */
    private fun posMs(): Double {
        when (mode) {
            1 -> {
                val m = mp
                if (m != null && mpReady) return try { m.currentPosition.toDouble() } catch (e: Exception) { 0.0 }
                return 0.0
            }
            2 -> {
                val p = if (playing) silentPos + (SystemClock.uptimeMillis() - silentT0) else silentPos
                return if (chartLenMs > 0) p.coerceIn(0.0, chartLenMs) else p
            }
            else -> {
                val m = mp
                val inSnip = if (m != null && mpReady && !audioFailed) {
                    try { m.currentPosition.toDouble() } catch (e: Exception) { (SystemClock.uptimeMillis() - timerStart).toDouble() }
                } else ((SystemClock.uptimeMillis() - timerStart) % 12000L).toDouble()
                return snippetStart + inSnip
            }
        }
    }

    private fun durMs(): Double = when (mode) {
        1 -> fullDurMs.toDouble()
        2 -> chartLenMs
        else -> 0.0
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (closed) return
            val dur = durMs()
            if (mode == 2 && playing && dur > 0 && posMs() >= dur - 1) { // akhir chart: ulang dari awal
                silentPos = 0.0
                silentT0 = SystemClock.uptimeMillis()
            }
            if (!seek.scrubbing) {
                seek.frac = if (dur > 0) (posMs() / dur).toFloat() else 0f
                tCur.text = mmss(posMs())
            }
            tTot.text = if (dur > 0) mmss(dur) else "-:--"
            val k = if (playing) IconView.PAUSE else IconView.PLAY
            if (playBtn.kind != k) {
                playBtn.kind = k
                playBtn.invalidate()
            }
            ui.postDelayed(this, 100)
        }
    }

    private fun onScrub(f: Float, fin: Boolean) {
        val dur = durMs()
        if (dur <= 0) return
        val ms = f * dur
        tCur.text = mmss(ms)
        if (!fin) return
        when (mode) {
            1 -> try { mp?.seekTo(ms.toInt()) } catch (e: Exception) { }
            2 -> {
                silentPos = ms
                silentT0 = SystemClock.uptimeMillis()
            }
        }
        view.setChart(curBm, 0.0) { posMs() } // reset penunjuk note supaya lompatan maju / mundur langsung tergambar
    }

    private fun togglePlay() {
        when (mode) {
            1 -> {
                val m = mp ?: return
                try {
                    if (m.isPlaying) {
                        m.pause()
                        playing = false
                    } else {
                        m.start()
                        playing = true
                    }
                } catch (e: Exception) {
                }
            }
            2 -> {
                if (playing) silentPos = posMs() else silentT0 = SystemClock.uptimeMillis()
                playing = !playing
            }
            else -> {
                val m = mp ?: return
                try {
                    if (m.isPlaying) {
                        m.pause()
                        playing = false
                    } else {
                        m.start()
                        playing = true
                    }
                } catch (e: Exception) {
                }
            }
        }
    }

    // ---------- audio: cuplikan dulu (langsung terdengar), lalu lagu penuh bila berhasil diambil ----------
    private fun seekSnippetToStart() {
        // cuplikan dari server selalu mulai di PreviewTime: tidak perlu seek; hanya selaraskan timer cadangan
        timerStart = SystemClock.uptimeMillis()
    }

    private fun startSnippet(i: Int) {
        if (closed) return
        val urls = Downloader.previewAudioUrls(r.id)
        if (i >= urls.size) {
            audioFailed = true
            status.text = L.t("Cuplikan lagu tidak tersedia", "Song preview unavailable")
            return
        }
        status.text = L.t("Memuat cuplikan lagu…", "Loading song preview…")
        releaseAudio()
        val m = MediaPlayer()
        mp = m
        mpReady = false
        try {
            m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            val v = Settings.musicGain
            m.setVolume(v, v)
            m.setDataSource(urls[i])
            m.isLooping = true
            m.setOnPreparedListener {
                if (mp === it && mode == 0) {
                    mpReady = true
                    try {
                        it.start()
                    } catch (e: Exception) {
                    }
                    playing = true
                    status.text = L.t("Cuplikan diputar — memuat lagu penuh…", "Playing preview — loading full song…")
                }
            }
            m.setOnErrorListener { _, _, _ ->
                if (mp === m && mode == 0) startSnippet(i + 1)
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            startSnippet(i + 1)
        }
    }

    private fun purgeOldAudio() {
        try {
            val fs = a.cacheDir.listFiles { f -> f.name.startsWith("pva_") }?.sortedByDescending { it.lastModified() } ?: return
            for (f in fs.drop(5)) f.delete()
        } catch (e: Exception) {
        }
    }

    /** Ambil HANYA file lagu dari .osz di server (HTTP Range), mirror satu per satu. */
    private fun loadFullAudio() {
        if (fullTried) return
        fullTried = true
        Thread {
            var ok: File? = null
            for (url in Downloader.downloadUrls(r.id)) {
                if (closed) return@Thread
                try {
                    val src = RemoteZip.probe(url)
                    val list = RemoteZip.entries(src)
                    val e = RemoteZip.pickAudio(list, null) ?: continue
                    val ext = e.name.substringAfterLast('.', "mp3").lowercase()
                    val f = File(a.cacheDir, "pva_${r.id}.$ext")
                    if (!(f.isFile && f.length() == e.usize)) {
                        RemoteZip.extract(src, e, f) { p ->
                            a.runOnUiThread {
                                if (!closed && mode == 0) {
                                    seek.buffered = p
                                    status.text = L.t("Cuplikan diputar — memuat lagu penuh ${(p * 100).toInt()}%", "Playing preview — loading full song ${(p * 100).toInt()}%")
                                }
                            }
                        }
                    } else f.setLastModified(System.currentTimeMillis())
                    ok = f
                    break
                } catch (e: Exception) {
                    continue
                }
            }
            a.runOnUiThread {
                if (closed) return@runOnUiThread
                if (ok != null) startFull(ok!!) else {
                    fullFailed = true
                    if (curBm != null) enterSilent()
                    else status.text = L.t("Lagu penuh tidak bisa diambil", "Full song could not be fetched")
                }
            }
        }.start()
    }

    private fun startFull(f: File) {
        val resumeAt = posMs()
        val m = MediaPlayer()
        try {
            m.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            val v = Settings.musicGain
            m.setVolume(v, v)
            m.setDataSource(f.path)
            m.setOnPreparedListener { pm ->
                if (closed) {
                    try { pm.release() } catch (e: Exception) { }
                    return@setOnPreparedListener
                }
                val old = mp
                mp = pm
                mpReady = true
                try { old?.release() } catch (e: Exception) { }
                mode = 1
                fullDurMs = try { pm.duration } catch (e: Exception) { 0 }
                try {
                    pm.seekTo(resumeAt.toInt().coerceIn(0, maxOf(0, fullDurMs - 500)))
                    pm.start()
                } catch (e: Exception) {
                }
                playing = true
                pm.setOnCompletionListener { c2 ->
                    try {
                        c2.seekTo(0)
                        c2.start()
                    } catch (e: Exception) {
                    }
                }
                seek.isEnabled = true
                seek.buffered = 1f
                status.text = L.t("Lagu penuh — geser bar merah untuk loncat", "Full song — drag the red bar to jump")
                view.setChart(curBm, 0.0) { posMs() }
            }
            m.setOnErrorListener { _, _, _ ->
                if (!closed && mode != 1) {
                    fullFailed = true
                    if (curBm != null) enterSilent()
                }
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            fullFailed = true
            if (curBm != null) enterSilent()
        }
    }

    /** Lagu penuh tidak ada: hentikan cuplikan, tampilkan seluruh chart tanpa suara dengan bar yang tetap bisa digeser. */
    private fun enterSilent() {
        if (closed || mode != 0) return
        val startAt = posMs()
        releaseAudio()
        mode = 2
        silentPos = startAt.coerceIn(0.0, maxOf(0.0, chartLenMs))
        silentT0 = SystemClock.uptimeMillis()
        playing = true
        seek.isEnabled = true
        seek.buffered = 0f
        status.text = L.t(
            "Lagu penuh tidak bisa diambil — tampil tanpa suara. Geser bar merah untuk melihat seluruh chart.",
            "Full song unavailable — showing the chart without sound. Drag the red bar to scrub the whole chart."
        )
        view.setChart(curBm, 0.0) { posMs() }
    }

    private fun releaseAudio() {
        val m = mp ?: return
        mp = null
        mpReady = false
        try {
            m.release()
        } catch (e: Exception) {
        }
    }
}
