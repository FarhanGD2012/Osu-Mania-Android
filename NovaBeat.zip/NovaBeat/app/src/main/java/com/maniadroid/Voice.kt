package com.maniadroid

import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.SocketAddress
import java.util.Arrays
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.LockSupport
import kotlin.math.sqrt

/**
 * Codec suara IMA-ADPCM 4-bit (16 kHz mono = 64 kbps, SNR ~30 dB). Tiap frame membawa status dekoder (prediktor + indeks)
 * di headernya, jadi frame yang hilang TIDAK merusak frame sesudahnya.
 */
object Adpcm {
    private val STEP = intArrayOf(
        7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 130,
        143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408, 449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282,
        1411, 1552, 1707, 1878, 2066, 2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630,
        9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767
    )
    private val IDX = intArrayOf(-1, -1, -1, -1, 2, 4, 6, 8)

    class Enc {
        var pred = 0
        var index = 0
    }

    /** Menyandikan [n] sampel (genap) ke n/2 byte di [out] mulai [off]. */
    fun encode(pcm: ShortArray, n: Int, st: Enc, out: ByteArray, off: Int) {
        var o = off
        var low = 0
        var haveLow = false
        for (k in 0 until n) {
            val s = pcm[k].toInt()
            var diff = s - st.pred
            var sign = 0
            if (diff < 0) {
                sign = 8
                diff = -diff
            }
            var step = STEP[st.index]
            var code = 0
            var vp = step shr 3
            if (diff >= step) {
                code = 4
                diff -= step
                vp += step
            }
            step = step shr 1
            if (diff >= step) {
                code = code or 2
                diff -= step
                vp += step
            }
            step = step shr 1
            if (diff >= step) {
                code = code or 1
                vp += step
            }
            var p = if (sign != 0) st.pred - vp else st.pred + vp
            if (p > 32767) p = 32767 else if (p < -32768) p = -32768
            st.pred = p
            code = code or sign
            var ix = st.index + IDX[code and 7]
            if (ix < 0) ix = 0 else if (ix > 88) ix = 88
            st.index = ix
            if (!haveLow) {
                low = code
                haveLow = true
            } else {
                out[o++] = (low or (code shl 4)).toByte()
                haveLow = false
            }
        }
    }

    /** Mendekode [n] sampel dari [inp] mulai [off] dengan status awal ([pred0], [idx0]). */
    fun decode(inp: ByteArray, off: Int, n: Int, pred0: Int, idx0: Int, out: ShortArray) {
        var pred = pred0
        var index = idx0
        for (k in 0 until n) {
            val b = inp[off + (k shr 1)].toInt()
            val code = if (k and 1 == 0) b and 15 else (b shr 4) and 15
            val step = STEP[index]
            var vp = step shr 3
            if (code and 4 != 0) vp += step
            if (code and 2 != 0) vp += step shr 1
            if (code and 1 != 0) vp += step shr 2
            var p = if (code and 8 != 0) pred - vp else pred + vp
            if (p > 32767) p = 32767 else if (p < -32768) p = -32768
            pred = p
            var ix = index + IDX[code and 7]
            if (ix < 0) ix = 0 else if (ix > 88) ix = 88
            index = ix
            out[k] = pred.toShort()
        }
    }
}

/**
 * Voice chat room multiplayer.
 *
 * Jalur kirim: LAN = UDP ke HP host (host meneruskan ke pemain lain), internet = topik MQTT `.../voice` (host menjembatani
 * pemain LAN <-> pemain internet). Tangkap: AudioRecord VOICE_COMMUNICATION (+ AEC / noise suppressor / AGC bawaan HP bila ada),
 * filter high-pass, deteksi suara adaptif (hanya mengirim saat bicara, dengan pre-roll supaya awal kata tidak terpotong).
 * Terima: jitter buffer adaptif per pembicara (kedalaman 60-160 ms), penyembunyian paket hilang (PLC), kejar-latensi, lalu
 * dicampur dan diputar lewat AudioTrack. Mikrofon BARU menyala bila pemain menekan tombolnya (bawaan mati).
 */
object Voice {
    const val SR = 16000
    const val FRAME = 320 // 20 ms
    private const val HDR = 5 // seq(2) + pred(2) + index(1)
    private const val ADPCM_BYTES = FRAME / 2
    private const val T_FRAME = 1
    private const val T_HELLO = 2
    private const val T_EOS = 3
    private const val FRAME_NS = 20_000_000L

    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null

    // ---- status yang dibaca UI ----
    @Volatile var micOn = false
        private set
    @Volatile var deafened = false
    @Volatile var volume = 1.0f
    @Volatile var micError = ""
        private set
    @Volatile private var roomVoice = true
    @Volatile private var hostMuted: Set<String> = emptySet()
    private val localMuted: MutableSet<String> = ConcurrentHashMap.newKeySet()
    @Volatile private var myId = ""
    @Volatile private var running = false
    @Volatile private var generation = 0
    var onActivity: (() -> Unit)? = null

    private val speakingAt = ConcurrentHashMap<String, Long>()
    private val speakers = ConcurrentHashMap<String, Speaker>()

    // ---- transport ----
    @Volatile private var role = 0 // 0 tidak ada, 1 host, 2 klien LAN, 3 klien internet
    @Volatile private var sock: DatagramSocket? = null
    @Volatile private var hub: MpHub? = null
    @Volatile private var mqtt: MqttLite? = null
    private var topic = ""
    private var hostAddr: InetSocketAddress? = null
    private val lanAddrs = ConcurrentHashMap<String, SocketAddress>()
    private val mqSendQ = LinkedBlockingQueue<ByteArray>(60)
    private var cap: Capture? = null

    // ============================================================ API untuk Versus / UI
    fun isLocallyMuted(id: String) = localMuted.contains(id)

    fun setLocalMute(id: String, mute: Boolean) {
        if (mute) {
            localMuted.add(id)
            speakers.remove(id)
        } else localMuted.remove(id)
        notifyUi()
    }

    fun isSpeaking(id: String): Boolean {
        val t = speakingAt[id] ?: return false
        return SystemClock.elapsedRealtime() - t < 450
    }

    fun hasMicPermission(): Boolean {
        val c = app ?: return false
        return c.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }

    /** Pemain menyalakan / mematikan mikrofonnya. Mikrofon fisik dilepas saat mati (indikator mikrofon HP ikut padam). */
    fun setMic(on: Boolean) {
        micOn = on
        micError = ""
        updateCapture()
        notifyUi()
    }

    fun setDeafen(on: Boolean) {
        deafened = on
        if (on) speakers.clear()
        notifyUi()
    }

    /** Dipanggil Versus tiap status room berubah. */
    fun onRoom(enabled: Boolean, muted: Set<String>) {
        roomVoice = enabled
        hostMuted = muted
        if (!enabled) {
            micOn = false
            speakers.clear()
        }
        updateCapture()
        notifyUi()
    }

    val iAmMuted: Boolean get() = hostMuted.contains(myId)

    // ============================================================ memulai / menghentikan
    /** Host: buka soket UDP SEBELUM hub dibuat (port-nya dikabarkan ke pemain lewat pesan welcome). */
    @Synchronized
    fun openHostSocket(c: Context): Int {
        app = c.applicationContext
        try {
            sock?.close()
        } catch (e: Exception) {
        }
        val s = try {
            DatagramSocket(null).also {
                it.reuseAddress = true
                it.bind(InetSocketAddress(MpConst.VOICE_PORT))
            }
        } catch (e: Exception) {
            try {
                DatagramSocket(0)
            } catch (e2: Exception) {
                null
            }
        }
        sock = s
        return s?.localPort ?: 0
    }

    @Synchronized
    fun startHost(c: Context, h: MpHub, mq: MqttLite?, code: String) {
        app = c.applicationContext
        val keep = sock
        sock = null // supaya resetState() tidak menutup soket yang baru dibuka openHostSocket()
        resetState()
        sock = keep
        role = 1
        hub = h
        mqtt = mq
        topic = MpConst.voiceTopic(code)
        myId = MpHub.LOCAL_ID
        running = true
        val gen = ++generation
        startPlayer(gen)
        if (mq != null) startMqttSender(gen)
        val s = sock
        if (s != null) {
            Thread {
                val buf = ByteArray(1500)
                val pk = DatagramPacket(buf, buf.size)
                while (running && gen == generation) {
                    try {
                        pk.length = buf.size
                        s.receive(pk)
                    } catch (e: Exception) {
                        break
                    }
                    try {
                        hostOnUdp(buf, pk.length, pk.socketAddress)
                    } catch (e: Exception) {
                    }
                }
            }.also { it.isDaemon = true; it.name = "voice-host-rx" }.start()
        }
        updateCapture()
    }

    @Synchronized
    fun startLan(c: Context, ip: String, port: Int, id: String) {
        app = c.applicationContext
        resetState()
        role = 2
        myId = id
        running = true
        val gen = ++generation
        startPlayer(gen)
        Thread {
            try {
                val s = DatagramSocket()
                val addr = InetSocketAddress(ip, port)
                synchronized(this) {
                    if (gen != generation) {
                        s.close()
                        return@Thread
                    }
                    sock = s
                    hostAddr = addr
                }
                // terima
                Thread {
                    val buf = ByteArray(1500)
                    val pk = DatagramPacket(buf, buf.size)
                    while (running && gen == generation) {
                        try {
                            pk.length = buf.size
                            s.receive(pk)
                        } catch (e: Exception) {
                            break
                        }
                        deliver(buf, pk.length)
                    }
                }.also { it.isDaemon = true; it.name = "voice-lan-rx" }.start()
                // hello berkala: memberi tahu host alamat UDP kita (sekaligus menjaga jalur tetap hidup)
                val hello = helloPacket(id)
                while (running && gen == generation) {
                    try {
                        s.send(DatagramPacket(hello, hello.size, addr))
                    } catch (e: Exception) {
                    }
                    try {
                        Thread.sleep(1000)
                    } catch (e: InterruptedException) {
                        break
                    }
                }
            } catch (e: Exception) {
                micError = "Voice chat LAN tidak bisa dibuka"
            }
        }.also { it.isDaemon = true; it.name = "voice-lan" }.start()
        updateCapture()
    }

    @Synchronized
    fun startNet(c: Context, mq: MqttLite, code: String, id: String) {
        app = c.applicationContext
        resetState()
        role = 3
        myId = id
        mqtt = mq
        topic = MpConst.voiceTopic(code)
        running = true
        val gen = ++generation
        startPlayer(gen)
        startMqttSender(gen)
        updateCapture()
    }

    @Synchronized
    fun stop() {
        resetState()
        micOn = false
        micError = ""
        roomVoice = true
        hostMuted = emptySet()
        notifyUi()
    }

    private fun resetState() {
        running = false
        generation++
        cap?.stopNow()
        cap = null
        try {
            sock?.close()
        } catch (e: Exception) {
        }
        sock = null
        hub = null
        mqtt = null
        hostAddr = null
        role = 0
        speakers.clear()
        speakingAt.clear()
        lanAddrs.clear()
        mqSendQ.clear()
    }

    // ============================================================ kirim
    private fun helloPacket(id: String): ByteArray {
        val idb = id.toByteArray(Charsets.UTF_8)
        val b = ByteArray(2 + idb.size)
        b[0] = T_HELLO.toByte()
        b[1] = idb.size.toByte()
        System.arraycopy(idb, 0, b, 2, idb.size)
        return b
    }

    private fun framePacket(id: String, seq: Int, pred: Int, idx: Int, adpcm: ByteArray): ByteArray {
        val idb = id.toByteArray(Charsets.UTF_8)
        val b = ByteArray(2 + idb.size + HDR + ADPCM_BYTES)
        b[0] = T_FRAME.toByte()
        b[1] = idb.size.toByte()
        System.arraycopy(idb, 0, b, 2, idb.size)
        var p = 2 + idb.size
        b[p++] = (seq shr 8).toByte()
        b[p++] = seq.toByte()
        b[p++] = (pred shr 8).toByte()
        b[p++] = pred.toByte()
        b[p++] = idx.toByte()
        System.arraycopy(adpcm, 0, b, p, ADPCM_BYTES)
        return b
    }

    private fun eosPacket(id: String, seq: Int): ByteArray {
        val idb = id.toByteArray(Charsets.UTF_8)
        val b = ByteArray(2 + idb.size + 2)
        b[0] = T_EOS.toByte()
        b[1] = idb.size.toByte()
        System.arraycopy(idb, 0, b, 2, idb.size)
        b[2 + idb.size] = (seq shr 8).toByte()
        b[3 + idb.size] = seq.toByte()
        return b
    }

    /** Dipakai thread tangkap: kirim satu paket sesuai peran. */
    private fun sendOut(pkt: ByteArray) {
        when (role) {
            1 -> {
                relayLan(pkt, "")
                queueMqtt(pkt)
            }
            2 -> {
                val s = sock
                val a = hostAddr
                if (s != null && a != null) try {
                    s.send(DatagramPacket(pkt, pkt.size, a))
                } catch (e: Exception) {
                }
            }
            3 -> queueMqtt(pkt)
        }
    }

    private fun queueMqtt(pkt: ByteArray) {
        if (mqtt != null) mqSendQ.offer(pkt) // penuh = buang (lebih baik hilang daripada tertunda)
    }

    /** Publikasi MQTT lewat thread sendiri supaya tulis soket yang lambat tidak mengganggu pembacaan mikrofon. */
    private fun startMqttSender(gen: Int) {
        val mq = mqtt ?: return
        val tp = topic
        Thread {
            while (running && gen == generation) {
                val p = try {
                    mqSendQ.poll(500, TimeUnit.MILLISECONDS)
                } catch (e: InterruptedException) {
                    break
                } ?: continue
                try {
                    mq.publish(tp, p)
                } catch (e: Exception) {
                }
            }
        }.also { it.isDaemon = true; it.name = "voice-mqtt-tx" }.start()
    }

    private fun relayLan(pkt: ByteArray, exceptId: String) {
        val s = sock ?: return
        val h = hub ?: return
        for ((id, a) in lanAddrs) {
            if (id == exceptId) continue
            if (!h.voiceMember(id)) {
                lanAddrs.remove(id)
                continue
            }
            try {
                s.send(DatagramPacket(pkt, pkt.size, a))
            } catch (e: Exception) {
            }
        }
    }

    // ============================================================ terima
    private class Pkt(val type: Int, val id: String, val seq: Int, val pred: Int, val idx: Int, val dataOff: Int)

    private fun parse(b: ByteArray, len: Int): Pkt? {
        if (len < 3) return null
        val type = b[0].toInt() and 0xFF
        val il = b[1].toInt() and 0xFF
        if (il == 0 || len < 2 + il) return null
        val id = String(b, 2, il, Charsets.UTF_8)
        val p = 2 + il
        if (type == T_HELLO) return Pkt(type, id, 0, 0, 0, p)
        if (type == T_EOS) {
            if (len < p + 2) return null
            return Pkt(type, id, ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF), 0, 0, p + 2)
        }
        if (type == T_FRAME) {
            if (len != p + HDR + ADPCM_BYTES) return null
            val seq = ((b[p].toInt() and 0xFF) shl 8) or (b[p + 1].toInt() and 0xFF)
            val pred = ((b[p + 2].toInt() shl 8) or (b[p + 3].toInt() and 0xFF)).toShort().toInt()
            val idx = (b[p + 4].toInt() and 0xFF).coerceIn(0, 88)
            return Pkt(type, id, seq, pred, idx, p + HDR)
        }
        return null
    }

    private fun hostOnUdp(buf: ByteArray, len: Int, addr: SocketAddress) {
        val p = parse(buf, len) ?: return
        val h = hub ?: return
        if (p.id == MpHub.LOCAL_ID || !h.voiceMember(p.id)) return
        lanAddrs[p.id] = addr
        if (p.type == T_HELLO) return
        if (!h.voiceAllowed(p.id)) return
        val pkt = buf.copyOf(len)
        relayLan(pkt, p.id)
        queueMqtt(pkt)
        deliver(pkt, len)
    }

    /** Dari broker MQTT (thread MQTT). Host menjembatani ke pemain LAN; klien internet langsung memutar. */
    fun onMqttFrame(payload: ByteArray) {
        when (role) {
            1 -> {
                val p = parse(payload, payload.size) ?: return
                val h = hub ?: return
                // abaikan gema paket kita sendiri (host & pemain LAN yang sudah kita publikasikan)
                if (p.id == MpHub.LOCAL_ID || lanAddrs.containsKey(p.id) || !h.voiceMember(p.id)) return
                if (p.type == T_HELLO || !h.voiceAllowed(p.id)) return
                relayLan(payload, p.id)
                deliver(payload, payload.size)
            }
            3 -> deliver(payload, payload.size)
        }
    }

    private fun deliver(b: ByteArray, len: Int) {
        val p = parse(b, len) ?: return
        if (p.type == T_HELLO || p.id == myId) return
        if (!roomVoice || deafened || hostMuted.contains(p.id) || localMuted.contains(p.id)) return
        val sp = speakers.getOrPut(p.id) { Speaker() }
        if (p.type == T_EOS) {
            sp.end()
            return
        }
        sp.push(p.seq, p.pred, p.idx, b, p.dataOff)
        markSpeaking(p.id)
    }

    // ============================================================ indikator "sedang bicara"
    private var notifyPending = false

    private fun markSpeaking(id: String) {
        speakingAt[id] = SystemClock.elapsedRealtime()
        notifyUi()
    }

    private fun notifyUi() {
        synchronized(this) {
            if (notifyPending) return
            notifyPending = true
        }
        main.postDelayed({
            synchronized(this) { notifyPending = false }
            onActivity?.invoke()
            // selama masih ada yang bicara, segarkan lagi supaya indikator padam tepat waktu
            val now = SystemClock.elapsedRealtime()
            if (speakingAt.values.any { now - it < 600 }) notifyUi()
        }, 220)
    }

    // ============================================================ jitter buffer per pembicara
    private class Speaker {
        private val buf = TreeMap<Int, ShortArray>()
        private var lastU = 0
        private var init = false
        private var playing = false
        private var nextSeq = 0
        private var target = 3 // frame (x20 ms)
        private var lastFrame = ShortArray(FRAME)
        private var concealed = 0
        private var stable = 0
        private var waitSince = 0L
        private var eos = false
        private var fadeIn = false
        @Volatile var lastRx = 0L

        @Synchronized
        fun push(seq: Int, pred: Int, idx: Int, d: ByteArray, off: Int) {
            val now = SystemClock.elapsedRealtime()
            val su: Int
            if (!init) {
                init = true
                su = seq
                lastU = su
            } else {
                val diff = (seq - (lastU and 0xFFFF)) and 0xFFFF
                su = if (diff < 0x8000) lastU + diff else lastU - (0x10000 - diff)
                if (su > lastU) lastU = su
            }
            lastRx = now
            eos = false
            if (playing && su < nextSeq) return // terlambat: sudah dilewati
            if (buf.containsKey(su)) return
            val pcm = ShortArray(FRAME)
            Adpcm.decode(d, off, FRAME, pred, idx, pcm)
            buf[su] = pcm
            while (buf.size > 30) buf.pollFirstEntry()
            if (!playing && buf.size == 1) waitSince = now
        }

        @Synchronized
        fun end() {
            eos = true
        }

        /** Isi [out] dengan 20 ms audio. true = ada suara. */
        @Synchronized
        fun pull(out: ShortArray): Boolean {
            val now = SystemClock.elapsedRealtime()
            if (!playing) {
                if (buf.isEmpty()) return false
                if (buf.size < target && now - waitSince < 100) return false
                playing = true
                nextSeq = buf.firstKey()
                concealed = 0
                fadeIn = true
            }
            // kejar latensi bila antrean menumpuk
            while (buf.size > target + 3) {
                buf.pollFirstEntry()
                if (buf.isNotEmpty()) nextSeq = buf.firstKey()
            }
            val f = buf.remove(nextSeq)
            if (f != null) {
                System.arraycopy(f, 0, out, 0, FRAME)
                System.arraycopy(f, 0, lastFrame, 0, FRAME)
                concealed = 0
                nextSeq++
                if (++stable > 400 && target > 3) {
                    target--
                    stable = 0
                }
                if (fadeIn) {
                    for (i in 0 until 64) out[i] = (out[i] * (i / 64f)).toInt().toShort()
                    fadeIn = false
                }
                if (eos && buf.isEmpty()) { // akhir ucapan: redam ujung frame, lalu berhenti
                    for (i in FRAME - 64 until FRAME) out[i] = (out[i] * ((FRAME - 1 - i) / 64f)).toInt().toShort()
                    playing = false
                    eos = false
                }
                return true
            }
            if (buf.isNotEmpty() && buf.firstKey() > nextSeq) { // paket hilang di tengah ucapan
                conceal(out)
                nextSeq++
                return true
            }
            // buffer kosong
            if (eos) {
                playing = false
                eos = false
                return false
            }
            if (concealed < 3) {
                if (concealed == 0 && target < 8) {
                    target++ // underrun sungguhan: perdalam buffer
                    stable = 0
                }
                conceal(out)
                nextSeq++
                return true
            }
            playing = false
            return false
        }

        private fun conceal(out: ShortArray) {
            for (i in 0 until FRAME) out[i] = (lastFrame[i] * 0.6f).toInt().toShort()
            System.arraycopy(out, 0, lastFrame, 0, FRAME)
            concealed++
        }
    }

    // ============================================================ pemutar (campur semua pembicara)
    private fun startPlayer(gen: Int) {
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            var track: AudioTrack? = null
            var started = false
            var idle = 0
            var sweep = 0
            val mix = IntArray(FRAME)
            val tmp = ShortArray(FRAME)
            val outB = ShortArray(FRAME)
            val silence = ShortArray(FRAME)
            var due = System.nanoTime()
            try {
                while (running && gen == generation) {
                    val now = System.nanoTime()
                    if (now < due) {
                        LockSupport.parkNanos(due - now)
                        continue
                    }
                    due += FRAME_NS
                    if (now - due > 200_000_000L) due = now + FRAME_NS // tertinggal jauh: sinkron ulang
                    Arrays.fill(mix, 0)
                    var n = 0
                    for (sp in speakers.values) {
                        if (sp.pull(tmp)) {
                            n++
                            for (i in 0 until FRAME) mix[i] += tmp[i].toInt()
                        }
                    }
                    if (n > 0) {
                        if (track == null) track = createTrack()
                        val t = track
                        if (t == null) {
                            micError = "Speaker voice chat tidak bisa dibuka"
                            continue
                        }
                        if (!started) {
                            t.play()
                            started = true
                            t.write(silence, 0, FRAME) // ruang aman 40 ms supaya tidak tersendat saat jitter kecil
                            t.write(silence, 0, FRAME)
                        }
                        idle = 0
                        val g = volume * (if (n > 1) 0.8f else 1f)
                        for (i in 0 until FRAME) {
                            var v = (mix[i] * g).toInt()
                            if (v > 32767) v = 32767 else if (v < -32768) v = -32768
                            outB[i] = v.toShort()
                        }
                        t.write(outB, 0, FRAME)
                    } else if (started) {
                        val t = track
                        if (t != null) {
                            idle++
                            if (idle > 25) {
                                t.pause()
                                t.flush()
                                started = false
                            } else t.write(silence, 0, FRAME)
                        }
                    }
                    if (++sweep >= 500) { // buang pembicara yang sudah lama diam
                        sweep = 0
                        val nowMs = SystemClock.elapsedRealtime()
                        val it = speakers.entries.iterator()
                        while (it.hasNext()) if (nowMs - it.next().value.lastRx > 30000) it.remove()
                    }
                }
            } catch (e: Exception) {
            } finally {
                try {
                    track?.stop()
                } catch (e: Exception) {
                }
                try {
                    track?.release()
                } catch (e: Exception) {
                }
            }
        }.also { it.isDaemon = true; it.name = "voice-play" }.start()
    }

    private fun createTrack(): AudioTrack? = try {
        val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val size = maxOf(minBuf, FRAME * 2 * 3)
        val b = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(size)
            .setTransferMode(AudioTrack.MODE_STREAM)
        if (Build.VERSION.SDK_INT >= 26) b.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
        b.build()
    } catch (e: Exception) {
        null
    }

    // ============================================================ mikrofon
    @Synchronized
    private fun updateCapture() {
        val want = running && micOn && roomVoice && !hostMuted.contains(myId) && hasMicPermission()
        if (want && cap == null) {
            cap = Capture(generation).also { it.start() }
        } else if (!want && cap != null) {
            cap?.stopNow()
            cap = null
        }
    }

    private class Capture(val gen: Int) : Thread("voice-cap") {
        @Volatile private var go = true

        fun stopNow() {
            go = false
        }

        init {
            isDaemon = true
        }

        override fun run() {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            var rec: AudioRecord? = null
            val fx = ArrayList<android.media.audiofx.AudioEffect>()
            try {
                val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                rec = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION, SR, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, FRAME * 2 * 6)
                )
                if (rec.state != AudioRecord.STATE_INITIALIZED) {
                    fail("Mikrofon tidak bisa dibuka")
                    return
                }
                val sid = rec.audioSessionId
                try {
                    if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(sid)?.let { it.enabled = true; fx.add(it) }
                    if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(sid)?.let { it.enabled = true; fx.add(it) }
                    if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(sid)?.let { it.enabled = true; fx.add(it) }
                } catch (e: Exception) {
                }
                rec.startRecording()

                val pcm = ShortArray(FRAME)
                val enc = Adpcm.Enc()
                val adpcm = ByteArray(ADPCM_BYTES)
                val pre = ArrayList<Pair<Int, ShortArray>>() // pre-roll: 2 frame terakhir sebelum bicara
                var seq = 0
                var floor = 200f
                var hang = 0
                var sending = false
                var agc = 1.0f
                var hpX = 0f
                var hpY = 0f
                var lastSeqSent = 0
                while (go && running && gen == generation) {
                    var got = 0
                    while (got < FRAME && go) {
                        val r = rec.read(pcm, got, FRAME - got)
                        if (r <= 0) {
                            fail("Mikrofon berhenti")
                            return
                        }
                        got += r
                    }
                    if (!go) break
                    // high-pass (buang DC & gemuruh)
                    var sum = 0.0
                    for (i in 0 until FRAME) {
                        val x = pcm[i].toFloat()
                        val y = x - hpX + 0.995f * hpY
                        hpX = x
                        hpY = y
                        val c = y.coerceIn(-32768f, 32767f)
                        pcm[i] = c.toInt().toShort()
                        sum += (c * c).toDouble()
                    }
                    val rms = sqrt(sum / FRAME).toFloat()
                    // lantai derau adaptif + deteksi suara
                    floor = if (rms < floor) floor * 0.5f + rms * 0.5f else floor + (rms - floor) * 0.003f
                    floor = floor.coerceIn(30f, 1500f)
                    val voiced = rms > maxOf(floor * 2.8f, 260f)
                    if (voiced) hang = 12 else if (hang > 0) hang--
                    // AGC ringan agar suara kecil tetap terdengar (maks. 4x), pelan supaya tidak "memompa"
                    if (voiced) {
                        val want = (3000f / maxOf(rms, 1f)).coerceIn(1f, 4f)
                        agc += (want - agc) * 0.05f
                    }
                    if (agc != 1.0f) {
                        for (i in 0 until FRAME) {
                            val v = pcm[i] * agc
                            pcm[i] = (if (v > 32767f) 32767f else if (v < -32768f) -32768f else v).toInt().toShort()
                        }
                    }
                    setLevel(rms)
                    val cur = seq
                    seq = (seq + 1) and 0xFFFF
                    if (voiced || hang > 0) {
                        if (!sending) {
                            sending = true
                            enc.pred = if (pre.isNotEmpty()) pre[0].second[0].toInt() else pcm[0].toInt()
                            enc.index = 0
                            for (pf in pre) sendFrame(pf.first, pf.second, enc, adpcm)
                            pre.clear()
                        }
                        sendFrame(cur, pcm, enc, adpcm)
                        lastSeqSent = cur
                        markSpeaking(myId)
                    } else {
                        if (sending) {
                            sending = false
                            sendOut(eosPacket(myId, (lastSeqSent + 1) and 0xFFFF))
                        }
                        pre.add(Pair(cur, pcm.copyOf()))
                        if (pre.size > 2) pre.removeAt(0)
                    }
                }
            } catch (e: Exception) {
                fail("Mikrofon galat: ${e.message ?: "?"}")
            } finally {
                for (e in fx) try {
                    e.release()
                } catch (x: Exception) {
                }
                try {
                    rec?.stop()
                } catch (e: Exception) {
                }
                try {
                    rec?.release()
                } catch (e: Exception) {
                }
            }
        }

        private fun sendFrame(seq: Int, pcm: ShortArray, enc: Adpcm.Enc, adpcm: ByteArray) {
            val pred = enc.pred
            val idx = enc.index
            Adpcm.encode(pcm, FRAME, enc, adpcm, 0)
            sendOut(framePacket(myId, seq, pred, idx, adpcm))
        }

        private fun fail(msg: String) {
            micOn = false
            micError = msg
            main.post {
                synchronized(Voice) { if (cap === this) cap = null }
                onActivity?.invoke()
            }
        }
    }

    @Volatile var micLevel = 0f
        private set

    private fun setLevel(rms: Float) {
        micLevel = (rms / 6000f).coerceIn(0f, 1f)
    }
}
