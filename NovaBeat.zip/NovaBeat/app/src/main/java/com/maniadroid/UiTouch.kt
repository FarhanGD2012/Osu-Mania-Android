package com.maniadroid

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Context
import android.graphics.Matrix
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max

/**
 * Efek untuk SEMUA tombol dalam satu tempat (dipanggil dari BaseActivity dan dialog bergaya lazer):
 *  - suara saat tombol diketuk (bukan saat menggulir / menahan lama),
 *  - tombol sedikit mengecil saat ditekan lalu memantul kembali.
 * Mencari tombol yang tersentuh sendiri lewat pengujian sentuhan pada pohon view, jadi tidak perlu
 * mengubah tiap tombol satu per satu.
 */
class UiTouchTracker(ctx: Context) {
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val d = ctx.resources.displayMetrics.density
    private var target: View? = null
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var scaledView: View? = null
    private var scaleAnim: ObjectAnimator? = null
    private val tmp = FloatArray(2)
    private val inv = Matrix()

    fun onTouch(root: View, ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                end(false)
                val t = find(root, ev.x, ev.y, root.width, root.height)
                target = t
                downX = ev.x
                downY = ev.y
                moved = false
                if (t != null) pressIn(t, root)
            }
            MotionEvent.ACTION_MOVE -> {
                if (target != null && !moved && (abs(ev.x - downX) > slop * 1.5f || abs(ev.y - downY) > slop * 1.5f)) {
                    moved = true
                    pressOut()
                }
            }
            MotionEvent.ACTION_UP -> {
                val quick = ev.eventTime - ev.downTime < ViewConfiguration.getLongPressTimeout()
                end(!moved && quick)
            }
            MotionEvent.ACTION_CANCEL -> end(false)
        }
    }

    private fun end(play: Boolean) {
        val t = target ?: return
        target = null
        pressOut()
        if (play && t.isAttachedToWindow && t.isEnabled) UiSound.play(kindFor(t))
    }

    private fun kindFor(v: View): Int {
        if (v is LogoView) return UiSound.CONFIRM
        if (v is LazerBack) return UiSound.BACK
        if (v is TextView) {
            val s = v.text?.toString()?.trim().orEmpty()
            if (s in BACK_WORDS) return UiSound.BACK
        }
        return UiSound.CLICK
    }

    private fun pressIn(t: View, root: View) {
        if (t is LogoView) return // logo punya animasi tekan sendiri
        if (t.scaleX != 1f || t.scaleY != 1f) return
        val w = t.width
        val h = t.height
        if (w <= 0 || h <= 0) return
        if (w.toLong() * h > 0.2 * root.width * root.height) return
        val s = (1f - 5f * d / max(w, h)).coerceIn(0.93f, 0.992f)
        scaleAnim?.cancel()
        val a = ObjectAnimator.ofPropertyValuesHolder(
            t, PropertyValuesHolder.ofFloat(View.SCALE_X, s), PropertyValuesHolder.ofFloat(View.SCALE_Y, s)
        )
        a.duration = 90
        a.interpolator = DecelerateInterpolator()
        a.start()
        scaleAnim = a
        scaledView = t
    }

    private fun pressOut() {
        val v = scaledView ?: return
        scaledView = null
        scaleAnim?.cancel()
        val a = ObjectAnimator.ofPropertyValuesHolder(
            v, PropertyValuesHolder.ofFloat(View.SCALE_X, 1f), PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f)
        )
        a.duration = 240
        a.interpolator = OvershootInterpolator(2.4f)
        a.start()
        scaleAnim = a
    }

    /** Cari view paling atas yang bisa diketuk di titik (x, y) (koordinat lokal view [v]). */
    private fun find(v: View, x: Float, y: Float, rw: Int, rh: Int): View? {
        if (v.visibility != View.VISIBLE || v.alpha < 0.05f) return null
        if (x < 0f || y < 0f || x >= v.width || y >= v.height) return null
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) {
                val c = v.getChildAt(i)
                tmp[0] = x + v.scrollX - c.left
                tmp[1] = y + v.scrollY - c.top
                if (!c.matrix.isIdentity) {
                    if (!c.matrix.invert(inv)) continue
                    inv.mapPoints(tmp)
                }
                val r = find(c, tmp[0], tmp[1], rw, rh)
                if (r != null) return r
            }
        }
        return if (candidate(v, x, y, rw, rh)) v else null
    }

    private fun candidate(v: View, x: Float, y: Float, rw: Int, rh: Int): Boolean {
        if (!v.isClickable || !v.isEnabled) return false
        if (v is GameView || v is EditorView) return false
        // penutup layar penuh (overlay jeda / hasil) hanya penelan sentuhan, bukan tombol
        if (v.width > rw * 0.7f && v.height > rh * 0.7f) return false
        if (v is LogoView && !v.containsLogoPoint(x, y)) return false
        return true
    }

    companion object {
        private val BACK_WORDS = setOf("Kembali", "Back", "Tutup", "Close", "Batal", "Cancel")
    }
}
