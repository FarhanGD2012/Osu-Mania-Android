package com.maniadroid

import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import kotlin.math.max

/** Melacak tombol yang sedang ditekan dari dua sumber: KeyEvent dan sumbu analog (trigger / D-Pad hat). */
class PadState {
    private val key = HashSet<Int>()
    private val axis = HashSet<Int>()
    private fun eff(c: Int) = key.contains(c) || axis.contains(c)

    /** true jika tombol baru saja menjadi "tertekan" */
    fun keyDown(c: Int): Boolean {
        val was = eff(c)
        key.add(c)
        return !was
    }

    /** true jika tombol baru saja menjadi "terlepas" */
    fun keyUp(c: Int): Boolean {
        val was = eff(c)
        key.remove(c)
        return was && !eff(c)
    }

    /** +1 baru ditekan, -1 baru dilepas, 0 tidak berubah */
    fun axisSet(c: Int, pressed: Boolean): Int {
        val was = eff(c)
        if (pressed) axis.add(c) else axis.remove(c)
        val now = eff(c)
        return if (!was && now) 1 else if (was && !now) -1 else 0
    }

    fun clear() {
        key.clear()
        axis.clear()
    }
}

object Input {
    /** Kode tombol yang bisa datang lewat sumbu analog (urutan sama dengan axisStates). */
    val AXIS_CODES = intArrayOf(
        KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2,
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN
    )

    fun isJoystickMove(ev: MotionEvent): Boolean =
        (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
                ev.actionMasked == MotionEvent.ACTION_MOVE

    fun axisStates(ev: MotionEvent): BooleanArray {
        val lt = max(ev.getAxisValue(MotionEvent.AXIS_LTRIGGER), ev.getAxisValue(MotionEvent.AXIS_BRAKE))
        val rt = max(ev.getAxisValue(MotionEvent.AXIS_RTRIGGER), ev.getAxisValue(MotionEvent.AXIS_GAS))
        val hx = ev.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = ev.getAxisValue(MotionEvent.AXIS_HAT_Y)
        return booleanArrayOf(lt > 0.55f, rt > 0.55f, hx < -0.5f, hx > 0.5f, hy < -0.5f, hy > 0.5f)
    }

    fun isSystemKey(code: Int): Boolean =
        code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_VOLUME_UP ||
                code == KeyEvent.KEYCODE_VOLUME_DOWN || code == KeyEvent.KEYCODE_VOLUME_MUTE ||
                code == KeyEvent.KEYCODE_POWER || code == KeyEvent.KEYCODE_HOME

    fun isPauseKey(code: Int): Boolean =
        code == KeyEvent.KEYCODE_BUTTON_START || code == KeyEvent.KEYCODE_BUTTON_MODE ||
                code == KeyEvent.KEYCODE_ESCAPE

    fun name(code: Int): String = when (code) {
        0 -> L.t("(kosong)", "(empty)")
        KeyEvent.KEYCODE_BUTTON_A -> "A"
        KeyEvent.KEYCODE_BUTTON_B -> "B"
        KeyEvent.KEYCODE_BUTTON_X -> "X"
        KeyEvent.KEYCODE_BUTTON_Y -> "Y"
        KeyEvent.KEYCODE_BUTTON_C -> "C"
        KeyEvent.KEYCODE_BUTTON_Z -> "Z"
        KeyEvent.KEYCODE_BUTTON_L1 -> "L1"
        KeyEvent.KEYCODE_BUTTON_R1 -> "R1"
        KeyEvent.KEYCODE_BUTTON_L2 -> "L2"
        KeyEvent.KEYCODE_BUTTON_R2 -> "R2"
        KeyEvent.KEYCODE_BUTTON_THUMBL -> L.t("L3 (stick kiri)", "L3 (left stick)")
        KeyEvent.KEYCODE_BUTTON_THUMBR -> L.t("R3 (stick kanan)", "R3 (right stick)")
        KeyEvent.KEYCODE_BUTTON_START -> "Start"
        KeyEvent.KEYCODE_BUTTON_SELECT -> "Select"
        KeyEvent.KEYCODE_BUTTON_MODE -> "Mode"
        KeyEvent.KEYCODE_DPAD_UP -> L.t("D-Pad atas", "D-Pad up")
        KeyEvent.KEYCODE_DPAD_DOWN -> L.t("D-Pad bawah", "D-Pad down")
        KeyEvent.KEYCODE_DPAD_LEFT -> L.t("D-Pad kiri", "D-Pad left")
        KeyEvent.KEYCODE_DPAD_RIGHT -> L.t("D-Pad kanan", "D-Pad right")
        KeyEvent.KEYCODE_DPAD_CENTER -> L.t("D-Pad tengah", "D-Pad center")
        KeyEvent.KEYCODE_SPACE -> L.t("Spasi", "Space")
        KeyEvent.KEYCODE_ENTER -> "Enter"
        KeyEvent.KEYCODE_SEMICOLON -> ";"
        else -> {
            val s = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
            if (s.startsWith("BUTTON_")) L.t("Tombol ", "Button ") + s.removePrefix("BUTTON_")
            else s.replace('_', ' ')
        }
    }
}

/** Pemetaan tombol keyboard/controller -> kolom, tersimpan per jumlah key. Tiap kolom punya 2 slot. */
object Bindings {
    private fun kb(vararg c: Int) = c

    private fun keyboardDefault(keys: Int): IntArray = when (keys) {
        1 -> kb(KeyEvent.KEYCODE_SPACE)
        2 -> kb(KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_J)
        3 -> kb(KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_J)
        4 -> kb(KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K)
        5 -> kb(KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K)
        6 -> kb(KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K, KeyEvent.KEYCODE_L)
        7 -> kb(KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K, KeyEvent.KEYCODE_L)
        8 -> kb(KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K, KeyEvent.KEYCODE_L, KeyEvent.KEYCODE_SEMICOLON)
        9 -> kb(KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K, KeyEvent.KEYCODE_L, KeyEvent.KEYCODE_SEMICOLON)
        else -> kb(KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F, KeyEvent.KEYCODE_V, KeyEvent.KEYCODE_N, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K, KeyEvent.KEYCODE_L, KeyEvent.KEYCODE_SEMICOLON)
    }

    // Slot 2 (controller). 4K: paling kiri L1, kiri L2, kanan R2, paling kanan R1.
    private fun padDefault(keys: Int): IntArray = when (keys) {
        4 -> kb(KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2, KeyEvent.KEYCODE_BUTTON_R1)
        else -> IntArray(keys)
    }

    fun default(keys: Int, col: Int, slot: Int): Int {
        val arr = if (slot == 0) keyboardDefault(keys) else padDefault(keys)
        return if (col in arr.indices) arr[col] else 0
    }

    private fun key(keys: Int, col: Int, slot: Int) = "bind_${keys}_${col}_$slot"

    fun get(keys: Int, col: Int, slot: Int): Int = Settings.sp.getInt(key(keys, col, slot), default(keys, col, slot))

    fun set(keys: Int, col: Int, slot: Int, code: Int) {
        Settings.sp.edit().putInt(key(keys, col, slot), code).apply()
    }

    fun reset(keys: Int) {
        val e = Settings.sp.edit()
        for (c in 0 until 10) for (s in 0..1) e.remove(key(keys, c, s))
        e.apply()
    }

    /** kode tombol -> daftar kolom yang memakainya */
    fun map(keys: Int): HashMap<Int, ArrayList<Int>> {
        val m = HashMap<Int, ArrayList<Int>>()
        for (c in 0 until keys) for (s in 0..1) {
            val code = get(keys, c, s)
            if (code != 0) m.getOrPut(code) { ArrayList() }.add(c)
        }
        return m
    }

    fun laneLabel(keys: Int, col: Int): String = when {
        keys == 4 -> arrayOf(L.t("Paling kiri", "Leftmost"), L.t("Kiri", "Left"), L.t("Kanan", "Right"), L.t("Paling kanan", "Rightmost"))[col]
        col == 0 -> L.t("Kolom 1 (paling kiri)", "Column 1 (leftmost)")
        col == keys - 1 -> L.t("Kolom ${col + 1} (paling kanan)", "Column ${col + 1} (rightmost)")
        else -> L.t("Kolom ${col + 1}", "Column ${col + 1}")
    }
}
