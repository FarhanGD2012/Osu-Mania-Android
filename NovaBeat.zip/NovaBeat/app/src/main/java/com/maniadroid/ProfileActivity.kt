package com.maniadroid

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.DateFormat
import java.util.Date

/**
 * Profil lengkap. Akun Nova Beat disimpan di SERVER (kata sandi di-hash Argon2 di server), jadi bisa masuk dari HP mana pun
 * tanpa Google / Gmail. Belum masuk: Masuk / Buat akun. Sudah masuk: PP & peringkat, cari teman, ubah profil, keluar.
 * Akun lokal lama (tanpa server) tetap bisa dipakai lewat bagian "Akun lokal lama".
 */
class ProfileActivity : BaseActivity() {
    private lateinit var left: LinearLayout
    private lateinit var right: LinearLayout
    private val REQ_AVATAR = 31
    private val REQ_EXPORT = 32
    private val REQ_IMPORT = 33

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = FrameLayout(this)
        root.addView(MenuBackdrop(this), Ui.matchParams())
        val dim = View(this)
        dim.setBackgroundColor(0x99000000.toInt())
        root.addView(dim, Ui.matchParams())

        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        body.setPadding(dp(16), dp(LazerBack.H_DP + 12), dp(16), dp(10))
        left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.gravity = Gravity.CENTER_HORIZONTAL
        left.setPadding(dp(14), dp(14), dp(14), dp(14))
        left.background = Ui.rounded(0x66000000, dp(18).toFloat())
        body.addView(left, LinearLayout.LayoutParams(0, -1, 0.36f))
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.setPadding(dp(4), 0, dp(4), dp(20))
        sv.addView(right, FrameLayout.LayoutParams(-1, -2))
        body.addView(sv, LinearLayout.LayoutParams(0, -1, 0.64f).also { it.leftMargin = dp(14) })
        root.addView(body, Ui.matchParams())

        root.addView(
            LazerBack(this) { finish() },
            FrameLayout.LayoutParams(dp(LazerBack.W_DP), dp(LazerBack.H_DP), Gravity.TOP or Gravity.START)
        )
        // judul di sebelah tombol kembali
        val title = LazerTitle(this, L.t("Profil"), L.t("akun online", "online account"))
        root.addView(title, FrameLayout.LayoutParams(-2, dp(LazerBack.H_DP), Gravity.TOP or Gravity.START).also {
            it.leftMargin = dp(LazerBack.W_DP + 14)
        })
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    // ---------- tampilan ----------
    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(top) }

    private fun render() {
        if (!::left.isInitialized) return
        left.removeAllViews()
        right.removeAllViews()
        val acc = Accounts.current()
        val av = AvatarView(this)
        av.set(acc, Versus.displayName())
        left.addView(av, LinearLayout.LayoutParams(dp(92), dp(92)))
        if (acc != null) av.setOnClickListener { pickAvatar() }

        val name = Ui.text(this, acc?.name ?: Versus.displayName(), 20f, Color.WHITE, true)
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        name.gravity = Gravity.CENTER
        left.addView(name, lp(10))
        val sub = Ui.text(
            this,
            if (acc != null) L.t("Bergabung ", "Joined ") + DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(acc.created))
            else L.t("Tamu · belum masuk", "Guest · not signed in"),
            11.5f, Ui.ACCENT, true
        )
        sub.gravity = Gravity.CENTER
        left.addView(sub, lp(2))
        if (acc != null) {
            val bio = Ui.text(this, if (acc.bio.isEmpty()) L.t("Ketuk \"Ubah bio\" untuk menulis sesuatu.", "Tap \"Edit bio\" to write something.") else acc.bio, 12f, 0xFFD0D0E0.toInt())
            bio.gravity = Gravity.CENTER
            left.addView(bio, lp(10))
            val tip = Ui.text(this, L.t("Ketuk foto untuk mengganti", "Tap the photo to change it"), 10.5f, Ui.SUB)
            tip.gravity = Gravity.CENTER
            left.addView(tip, lp(10))
        } else {
            val tip = Ui.text(
                this,
                L.t(
                    "Akun tersimpan di server Nova Beat: masuk dari HP mana pun, ikut peringkat, dan cari teman. Tidak perlu Google / Gmail.",
                    "Your account lives on the Nova Beat server: sign in from any phone, join the leaderboards and find friends. No Google / Gmail needed."
                ),
                11f, Ui.SUB
            )
            tip.gravity = Gravity.CENTER
            left.addView(tip, lp(12))
        }
        if (acc == null) renderGuest() else renderAccount(acc)
    }

    private fun section(t: String) {
        right.addView(Ui.text(this, t, 18f, Color.WHITE, true), lp(14))
        val bar = View(this)
        bar.background = Ui.rounded(Ui.ACCENT, dp(2).toFloat())
        right.addView(bar, LinearLayout.LayoutParams(dp(30), dp(3)).also { it.topMargin = dp(5) })
    }

    private fun btn(label: String, kind: Int = 0, onClick: () -> Unit) {
        val bg = when (kind) {
            1 -> Ui.ACCENT
            2 -> 0xFF4A2332.toInt()
            else -> 0xFF2B2A3A.toInt()
        }
        val b = Ui.button(this, label, false, 10) { onClick() }
        b.background = Ui.ripple(Ui.rounded(bg, dp(10).toFloat()))
        b.setTextColor(if (kind == 2) 0xFFFF9AA8.toInt() else Color.WHITE)
        b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14f)
        b.minHeight = dp(44)
        b.minimumHeight = dp(44)
        right.addView(b, lp(8))
    }

    private fun renderGuest() {
        section(L.t("Masuk atau buat akun", "Sign in or create an account"))
        btn("Masuk", 1) { loginDialog(null) }
        btn("Buat akun baru") { createDialog() }
        btn("Alamat server") { serverDialog() }
        right.addView(
            Ui.text(
                this,
                "Kata sandi tidak pernah disimpan di HP maupun dikirim sebagai teks biasa ke database: server menyimpannya sebagai hash Argon2id.",
                11.5f, Ui.SUB
            ), lp(10)
        )
        val legacy = Accounts.all().filter { it.hash.isNotEmpty() }
        section(L.t("Akun lokal lama (tanpa server)", "Old local accounts (no server)"))
        for (a in legacy) btn(a.name) { localLoginDialog(a.name) }
        btn("Impor akun lokal dari file") { pickImport() }
    }

    private fun statCard(label: String, value: String): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.background = Ui.rounded(0x66000000, dp(14).toFloat())
        c.setPadding(dp(8), dp(10), dp(8), dp(10))
        c.addView(Ui.text(this, value, 17f, Color.WHITE, true))
        c.addView(Ui.text(this, label, 10.5f, Ui.SUB))
        return c
    }

    private fun renderCloudAccount(acc: Account) {
        section(L.t("PP & peringkat", "PP & rank"))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val ppV = statCard("Total PP", String.format(java.util.Locale.US, "%,.1f", Cloud.totalPp.toDouble()))
        val rankV = statCard(L.t("Peringkat global", "Global rank"), "…")
        val mapsV = statCard(L.t("Map tamat", "Maps cleared"), "…")
        for ((i, c) in listOf(ppV, rankV, mapsV).withIndex()) row.addView(c, LinearLayout.LayoutParams(0, -2, 1f).also { if (i > 0) it.leftMargin = dp(6) })
        right.addView(row, lp(10))
        Cloud.async({
            Cloud.refreshMe()
            Cloud.user(Cloud.userId)
        }) { r ->
            if (isFinishing || !r.ok) return@async
            val u = r.json.optJSONObject("user") ?: return@async
            fun setVal(card: View, v: String) {
                ((card as LinearLayout).getChildAt(0) as TextView).text = v
            }
            setVal(ppV, String.format(java.util.Locale.US, "%,.1f", u.optDouble("total_pp")))
            val rk = u.optInt("global_rank")
            setVal(rankV, if (rk > 0) "#$rk" else "-")
            setVal(mapsV, u.optInt("maps_cleared").toString())
        }
        btn("Peringkat global", 1) { startActivity(Intent(this, LeaderboardActivity::class.java)) }
        btn("Cari pemain & teman") { startActivity(Intent(this, PlayersActivity::class.java)) }
        btn("Lihat profil publikku") { startActivity(Intent(this, PlayerProfileActivity::class.java).putExtra("user_id", Cloud.userId)) }

        section(L.t("Akun", "Account"))
        btn("Ganti foto profil") { pickAvatar() }
        if (Accounts.avatarFile(acc).isFile) btn("Hapus foto profil") {
            Accounts.removeAvatar(acc)
            Cloud.async({ Cloud.removeAvatar() }) { }
            render()
        }
        btn("Ubah bio") {
            formAsync("Ubah bio", listOf(Field("Tulis sesuatu tentang kamu", false, acc.bio)), "Simpan") { v, done ->
                Cloud.async({ Cloud.setBio(v[0]) }) { r ->
                    done(if (r.ok) null else r.message)
                    if (r.ok) render()
                }
            }
        }
        btn("Ubah kata sandi") {
            formAsync("Ubah kata sandi", listOf(Field("Kata sandi lama", true, ""), Field("Kata sandi baru (min. 6)", true, "")), "Simpan") { v, done ->
                Cloud.async({ Cloud.changePassword(v[0], v[1]) }) { r -> done(if (r.ok) null else r.message) }
            }
        }
        btn("Alamat server") { serverDialog() }
        section(L.t("Keluar", "Sign out"))
        btn("Keluar (ganti akun)") {
            Cloud.logout()
            render()
        }
        btn("Hapus akun ini", 2) {
            formAsync("Hapus akun ini?", listOf(Field("Masukkan kata sandi untuk konfirmasi", true, "")), "Hapus") { v, done ->
                Cloud.async({ Cloud.deleteAccount(v[0]) }) { r ->
                    done(if (r.ok) null else r.message)
                    if (r.ok) render()
                }
            }
        }
    }

    private fun renderAccount(acc: Account) {
        if (Accounts.isCloud) {
            renderCloudAccount(acc)
            return
        }
        val st = Accounts.stats(acc)
        section(L.t("Statistik", "Stats"))
        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        val nf = java.text.NumberFormat.getIntegerInstance()
        val cards = listOf(
            statCard(L.t("Dimainkan", "Plays"), st.plays.toString()),
            statCard(L.t("Total skor", "Total score"), nf.format(st.totalScore)),
            statCard(L.t("Skor terbaik", "Best score"), nf.format(st.bestScore)),
            statCard(L.t("Akurasi terbaik", "Best accuracy"), String.format(java.util.Locale.US, "%.2f%%", st.bestAcc)),
            statCard(L.t("Favorit", "Favourites"), Accounts.favCount().toString())
        )
        for ((i, c) in cards.withIndex()) row1.addView(c, LinearLayout.LayoutParams(0, -2, 1f).also { if (i > 0) it.leftMargin = dp(6) })
        right.addView(row1, lp(10))

        section(L.t("Akun", "Account"))
        btn("Ganti foto profil") { pickAvatar() }
        if (Accounts.avatarFile(acc).isFile) btn("Hapus foto profil") {
            Accounts.removeAvatar(acc)
            render()
        }
        btn("Ubah nama") {
            form("Ubah nama", listOf(Field("Nama baru", false, acc.name)), "Simpan") { v ->
                Accounts.rename(acc, v[0]) ?: run { render(); null }
            }
        }
        btn("Ubah bio") {
            form("Ubah bio", listOf(Field("Tulis sesuatu tentang kamu", false, acc.bio)), "Simpan") { v ->
                Accounts.setBio(acc, v[0])
                render()
                null
            }
        }
        btn("Ubah kata sandi") {
            form("Ubah kata sandi", listOf(Field("Kata sandi lama", true, ""), Field("Kata sandi baru", true, "")), "Simpan") { v ->
                Accounts.changePassword(acc, v[0], v[1])
            }
        }
        section(L.t("Pindah HP / keluar", "Move phone / sign out"))
        btn("Ekspor akun ke file") { pickExport(acc) }
        btn("Keluar (ganti akun)") {
            Accounts.logout()
            render()
        }
        btn("Hapus akun ini", 2) {
            LDialog.confirm(this, "Hapus akun?", "Profil, foto, statistik, dan favorit akun ini dihapus dari HP ini. Tidak bisa dikembalikan kecuali kamu punya file ekspor.", "Hapus") {
                Accounts.delete(acc)
                render()
            }
        }
    }

    // ---------- dialog isian ----------
    private class Field(val hint: String, val secret: Boolean, val initial: String)

    /** Dialog dengan beberapa kotak isian. [onOk] mengembalikan pesan galat (dialog tetap terbuka) atau null (selesai). */
    private fun form(title: String, fields: List<Field>, okLabel: String, onOk: (List<String>) -> String?) {
        formAsync(title, fields, okLabel) { v, done -> done(onOk(v)) }
    }

    /** Sama seperti [form], tetapi pekerjaan boleh async: panggil `done(pesanGalat)` atau `done(null)` di thread utama bila selesai. */
    private fun formAsync(title: String, fields: List<Field>, okLabel: String, onSubmit: (List<String>, (String?) -> Unit) -> Unit) {
        val (dlg, box) = LDialog.make(this, 400)
        LDialog.title(this, box, L.t(title))
        val edits = ArrayList<EditText>()
        for (f in fields) {
            val e = EditText(this)
            e.setText(f.initial)
            e.setSelection(f.initial.length)
            e.hint = L.t(f.hint)
            e.setHintTextColor(Ui.SUB)
            e.setTextColor(Ui.TEXT)
            e.textSize = 14f
            e.setSingleLine(true)
            Ui.noExtractUi(e)
            e.inputType = if (f.secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else InputType.TYPE_CLASS_TEXT
            e.background = Ui.rounded(0x33FFFFFF, dp(12).toFloat())
            e.setPadding(dp(14), dp(10), dp(14), dp(10))
            box.addView(e, lp(10))
            edits.add(e)
        }
        val err = Ui.text(this, "", 12f, 0xFFFF7A8A.toInt(), true)
        err.visibility = View.GONE
        box.addView(err, lp(8))
        var busy = false
        lateinit var okBtn: TextView
        fun submit() {
            if (busy) return
            busy = true
            okBtn.alpha = 0.5f
            err.visibility = View.GONE
            onSubmit(edits.map { it.text.toString().trim() }) { msg ->
                busy = false
                okBtn.alpha = 1f
                if (msg == null) {
                    dlg.dismiss()
                } else {
                    err.text = L.t(msg)
                    err.visibility = View.VISIBLE
                }
            }
        }
        okBtn = LDialog.textButton(this, okLabel, true) { submit() }
        LDialog.buttons(this, box, LDialog.textButton(this, "Batal", false) { dlg.dismiss() }, okBtn)
        dlg.showImmersive(this)
    }

    private fun loginDialog(prefill: String?) {
        formAsync("Masuk", listOf(Field("Nama akun", false, prefill ?: ""), Field("Kata sandi", true, "")), "Masuk") { v, done ->
            Cloud.async({ Cloud.authenticate(false, v[0], v[1]) }) { r ->
                done(if (r.ok) null else r.message)
                if (r.ok) {
                    render()
                    Cloud.async({ Cloud.flushPending() }) { }
                }
            }
        }
    }

    private fun createDialog() {
        formAsync(
            "Buat akun baru",
            listOf(Field("Nama (3–20: huruf, angka, . - _)", false, ""), Field("Kata sandi (min. 6)", true, ""), Field("Ulangi kata sandi", true, "")),
            "Buat"
        ) { v, done ->
            if (v[1] != v[2]) done("Kata sandi tidak sama")
            else Cloud.async({ Cloud.authenticate(true, v[0], v[1]) }) { r ->
                done(if (r.ok) null else r.message)
                if (r.ok) render()
            }
        }
    }

    /** Masuk ke akun lokal lama (tanpa server). */
    private fun localLoginDialog(prefill: String?) {
        form("Masuk (akun lokal lama)", listOf(Field("Nama akun", false, prefill ?: ""), Field("Kata sandi", true, "")), "Masuk") { v ->
            Accounts.login(v[0], v[1]) ?: run { render(); null }
        }
    }

    private fun serverDialog() {
        LDialog.input(this, L.t("Alamat server Nova Beat", "Nova Beat server address"), "https://contoh.fly.dev", Cloud.baseUrl) { v ->
            val u = v.trim()
            if (u.startsWith("http://") || u.startsWith("https://")) {
                Cloud.baseUrl = u
                Toast.makeText(this, "Alamat server disimpan", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this, "Alamat harus diawali http:// atau https://", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- file ----------
    @Suppress("DEPRECATION")
    private fun pickAvatar() {
        if (Accounts.current() == null) return
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        startActivityForResult(i, REQ_AVATAR)
    }

    @Suppress("DEPRECATION")
    private fun pickExport(acc: Account) {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/octet-stream"
        i.putExtra(Intent.EXTRA_TITLE, "NovaBeat_${acc.name}.odacc")
        startActivityForResult(i, REQ_EXPORT)
    }

    @Suppress("DEPRECATION")
    private fun pickImport() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        startActivityForResult(i, REQ_IMPORT)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri: Uri = data?.data ?: return
        if (res != RESULT_OK) return
        val acc = Accounts.current()
        when (req) {
            REQ_AVATAR -> {
                if (acc == null) return
                if (!Accounts.setAvatar(acc, uri)) Toast.makeText(this, "Gambar tidak bisa dibaca", Toast.LENGTH_SHORT).show()
                else if (Accounts.isCloud) {
                    val f = Accounts.avatarFile(acc)
                    Cloud.async({ Cloud.uploadAvatar(f) }) { r ->
                        if (!r.ok) Toast.makeText(this, r.message, Toast.LENGTH_LONG).show()
                    }
                }
                render()
            }
            REQ_EXPORT -> {
                if (acc == null) return
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(Accounts.exportJson(acc).toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(this, "Akun diekspor. Simpan file ini baik-baik.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Gagal menyimpan file", Toast.LENGTH_SHORT).show()
                }
            }
            REQ_IMPORT -> {
                val msg = try {
                    val txt = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                    Accounts.importJson(txt)
                } catch (e: Exception) {
                    "File tidak bisa dibaca"
                }
                if (msg != null) Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                else Toast.makeText(this, "Akun diimpor. Sekarang Masuk dengan kata sandi yang sama.", Toast.LENGTH_LONG).show()
                render()
            }
        }
    }
}
