package com.maniadroid

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import kotlin.math.min

/**
 * Menu jeda ala osu!lazer: latar gelap redup, pita lebar di tengah layar dengan judul lagu,
 * persen lagu + HP, dan empat tombol jajar genjang berwarna (Lanjut / Ulangi / Setelan / Keluar).
 * "Setelan" langsung membuka layar pengaturan lengkap (bukan panel kecil).
 */
class PauseOverlay(
    ctx: Context,
    private val title: String,
    private val sub: String,
    private val status: String,
    private val onContinue: () -> Unit,
    private val onRetry: () -> Unit,
    private val onQuit: () -> Unit,
    private val onBot: (() -> Unit)? = null,
    private val onAllSettings: () -> Unit
) : FrameLayout(ctx) {

    private val wrap = FrameLayout(ctx)
    private val band = LinearLayout(ctx)
    private val row = LinearLayout(ctx)

    private fun dp(v: Int) = Ui.dp(context, v)

    init {
        setBackgroundColor(0xCC050509.toInt())
        isClickable = true
        isFocusable = true

        // ---- pita tengah ----
        band.orientation = LinearLayout.VERTICAL
        band.gravity = Gravity.CENTER_HORIZONTAL
        band.setPadding(dp(24), dp(14), dp(24), dp(16))
        band.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xF0121120.toInt(), 0xF01C1932.toInt(), 0xF0121120.toInt())
        )
        wrap.addView(band, LayoutParams(-1, -2))
        val lineTop = View(context)
        lineTop.setBackgroundColor(0x555FAAFF)
        wrap.addView(lineTop, LayoutParams(-1, dp(2), Gravity.TOP))
        val lineBot = View(context)
        lineBot.setBackgroundColor(0x22FFFFFF)
        wrap.addView(lineBot, LayoutParams(-1, dp(1), Gravity.BOTTOM))
        addView(wrap, LayoutParams(-1, -2, Gravity.CENTER))

        // ---- judul ----
        val head = Ui.text(context, "JEDA", 11f, Ui.ACCENT, true)
        head.letterSpacing = 0.35f
        head.gravity = Gravity.CENTER
        band.addView(head, LinearLayout.LayoutParams(-2, -2))

        val t = Ui.text(context, title, 18f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        val tp = LinearLayout.LayoutParams(-1, -2)
        tp.topMargin = dp(4)
        band.addView(t, tp)

        val s = Ui.text(context, sub, 12f, Ui.SUB)
        s.gravity = Gravity.CENTER
        s.maxLines = 1
        s.ellipsize = TextUtils.TruncateAt.END
        band.addView(s, LinearLayout.LayoutParams(-1, -2))

        if (status.isNotEmpty()) {
            val st = Ui.text(context, status, 12f, 0xFFB3D6FF.toInt(), true)
            st.gravity = Gravity.CENTER
            st.setPadding(dp(14), dp(4), dp(14), dp(4))
            st.background = Ui.rounded(0x265FAAFF, dp(12).toFloat())
            val sp = LinearLayout.LayoutParams(-2, -2)
            sp.topMargin = dp(8)
            band.addView(st, sp)
        }

        // ---- tombol jajar genjang ----
        row.orientation = LinearLayout.HORIZONTAL
        fun btn(kind: Int, label: String, color: Int, click: () -> Unit) {
            row.addView(MenuButton(context, kind, label, color, click), LinearLayout.LayoutParams(0, -1, 1f))
        }
        btn(IconView.PLAY, "Lanjut", 0xFF4FBF7A.toInt()) { onContinue() }
        btn(IconView.RETRY, "Ulangi", 0xFFE9A92E.toInt()) { onRetry() }
        val bot = onBot
        if (bot != null) btn(IconView.GAMEPAD, "BOT", 0xFF765BE0.toInt()) { bot() }
        btn(IconView.SETTINGS, "Setelan", 0xFF6A72D6.toInt()) { onAllSettings() }
        btn(IconView.EXIT, "Keluar", 0xFFE0524D.toInt()) { onQuit() }
        val w = min(dp(if (onBot != null) 640 else 560), resources.displayMetrics.widthPixels - dp(40))
        val rp = LinearLayout.LayoutParams(w, dp(80))
        rp.topMargin = dp(14)
        band.addView(row, rp)

        // ---- animasi masuk: pita membuka, tombol meluncur dari sisi ----
        alpha = 0f
        wrap.scaleY = 0.35f
        animate().alpha(1f).setDuration(170).start()
        wrap.animate().scaleY(1f).setDuration(230).setInterpolator(DecelerateInterpolator()).start()
        val dist = dp(46).toFloat()
        for (i in 0 until row.childCount) {
            val c = row.getChildAt(i)
            c.alpha = 0f
            c.translationX = if (i < row.childCount / 2) -dist else dist
            c.animate().alpha(1f).translationX(0f).setStartDelay(60L + i * 40L).setDuration(260)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    /** Menu jeda tidak punya panel dalam lagi; selalu false supaya tombol Back = lanjut main. */
    fun back(): Boolean = false
}
