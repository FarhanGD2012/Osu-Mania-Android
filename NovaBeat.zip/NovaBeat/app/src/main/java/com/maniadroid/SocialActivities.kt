package com.maniadroid

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/** Dasar layar sosial: latar menu, tombol kembali, judul, dan area isi. */
abstract class SocialBase : BaseActivity() {
    protected fun dp(v: Int) = Ui.dp(this, v)
    protected lateinit var body: LinearLayout

    protected fun frame(title: String, section: String) {
        val root = FrameLayout(this)
        root.addView(MenuBackdrop(this), Ui.matchParams())
        val dim = View(this)
        dim.setBackgroundColor(0x99000000.toInt())
        root.addView(dim, Ui.matchParams())
        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(16), dp(LazerBack.H_DP + 12), dp(16), dp(10))
        root.addView(body, Ui.matchParams())
        root.addView(
            LazerBack(this) { finish() },
            FrameLayout.LayoutParams(dp(LazerBack.W_DP), dp(LazerBack.H_DP), Gravity.TOP or Gravity.START)
        )
        root.addView(LazerTitle(this, title, section), LazerTitle.params(this))
        setContentView(root)
    }

    protected fun lp(w: Int, h: Int, top: Int = 0, left: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h).also {
            it.topMargin = dp(top)
            it.leftMargin = dp(left)
        }

    /** Teks dari pengguna (nama, bio, judul map): TIDAK diterjemahkan, supaya nama seperti "Main" tidak berubah. */
    protected fun raw(s: String, sp: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = Ui.text(this, "", sp, color, bold)
        t.text = s
        return t
    }

    protected fun pill(label: String, color: Int, onClick: () -> Unit): TextView {
        val t = Ui.text(this, label, 12.5f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), dp(7), dp(14), dp(7))
        t.background = Ui.ripple(Ui.rounded(color, dp(14).toFloat()))
        t.setOnClickListener { onClick() }
        return t
    }

    protected fun info(s: String): TextView {
        val t = Ui.text(this, s, 13f, Ui.SUB)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(8), dp(24), dp(8), dp(24))
        return t
    }

    protected fun avatar(id: Long, at: Long, name: String): AvatarView {
        val av = AvatarView(this)
        av.setRemote(name, null)
        Cloud.avatar(id, at) { b -> if (!isFinishing) av.setRemote(name, b) }
        return av
    }

    protected fun fmtTime(ms: Long): String =
        if (ms <= 0L) "-" else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(ms))

    protected fun openProfile(id: Long) {
        startActivity(Intent(this, PlayerProfileActivity::class.java).putExtra("user_id", id))
    }

    protected fun goLogin() {
        startActivity(Intent(this, ProfileActivity::class.java))
    }

    protected fun fmtPp(v: Double): String = String.format(Locale.US, "%,.1f pp", v)
    protected fun fmtAcc(v: Double): String = String.format(Locale.US, "%.2f%%", v)
}

// ====================================================================== PERINGKAT

/** Peringkat global (total PP) dan peringkat per map (skor terbaik tiap pemain). Ketuk baris untuk membuka profil. */
class LeaderboardActivity : SocialBase() {
    private var mapKey = ""
    private var mapTitle = ""
    private var tab = 0 // 0 global, 1 map ini
    private lateinit var tabRow: LinearLayout
    private lateinit var headBox: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var meBox: LinearLayout
    private var gen = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        mapKey = intent.getStringExtra("map_key") ?: ""
        mapTitle = intent.getStringExtra("map_title") ?: ""
        tab = if (mapKey.isNotEmpty()) 1 else 0
        frame(L.t("Peringkat", "Leaderboard"), L.t("pemain terbaik", "top players"))
        tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        tabRow.gravity = Gravity.CENTER_VERTICAL
        body.addView(tabRow, lp(-1, -2))
        headBox = LinearLayout(this)
        headBox.orientation = LinearLayout.VERTICAL
        body.addView(headBox, lp(-1, -2, 8))
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        sv.addView(listBox, FrameLayout.LayoutParams(-1, -2))
        body.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f).also { it.topMargin = dp(4) })
        meBox = LinearLayout(this)
        meBox.orientation = LinearLayout.VERTICAL
        body.addView(meBox, lp(-1, -2, 6))
        renderTabs()
        load()
    }

    private fun renderTabs() {
        tabRow.removeAllViews()
        fun t(label: String, idx: Int) {
            val sel = tab == idx
            val p = pill(label, if (sel) Ui.ACCENT else 0xFF2B2A3A.toInt()) {
                if (tab != idx) {
                    tab = idx
                    renderTabs()
                    load()
                }
            }
            tabRow.addView(p, lp(-2, -2, 0, if (idx > 0) 8 else 0))
        }
        t(L.t("Global (total PP)", "Global (total PP)"), 0)
        if (mapKey.isNotEmpty()) t(L.t("Map ini", "This map"), 1)
        if (tab == 1 && mapTitle.isNotEmpty()) {
            val m = raw(mapTitle, 12f, Ui.SUB)
            m.maxLines = 1
            m.ellipsize = TextUtils.TruncateAt.END
            tabRow.addView(m, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = dp(12) })
        }
    }

    private val wGlobal = floatArrayOf(1.2f, 1.0f, 1.7f)
    private val wMap = floatArrayOf(1.25f, 1.0f, 1.0f, 1.7f)

    private fun headerRow(cols: List<String>, w: FloatArray): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(10), dp(2), dp(10), dp(2))
        row.addView(Ui.text(this, "#", 10.5f, Ui.SUB, true), LinearLayout.LayoutParams(0, -2, 0.55f))
        row.addView(Ui.text(this, L.t("Pemain", "Player"), 10.5f, Ui.SUB, true), LinearLayout.LayoutParams(0, -2, 2.0f).also { it.leftMargin = dp(38) })
        for ((i, c) in cols.withIndex()) {
            val t = Ui.text(this, c, 10.5f, Ui.SUB, true)
            t.gravity = Gravity.END
            row.addView(t, LinearLayout.LayoutParams(0, -2, w[i]))
        }
        return row
    }

    private fun entryRow(rank: Int, uid: Long, name: String, at: Long, cols: List<String>, w: FloatArray, mine: Boolean): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(6), dp(10), dp(6))
        row.background = Ui.ripple(Ui.rounded(if (mine) 0x405FAAFF else 0x55000000, dp(12).toFloat()))
        val rc = when (rank) {
            1 -> 0xFFFFD84D.toInt()
            2 -> 0xFFC9D1E0.toInt()
            3 -> 0xFFE0A070.toInt()
            else -> Color.WHITE
        }
        row.addView(raw("#$rank", 14f, rc, true), LinearLayout.LayoutParams(0, -2, 0.55f))
        row.addView(avatar(uid, at, name), LinearLayout.LayoutParams(dp(30), dp(30)))
        val n = raw(name, 14f, Color.WHITE, true)
        n.maxLines = 1
        n.ellipsize = TextUtils.TruncateAt.END
        row.addView(n, LinearLayout.LayoutParams(0, -2, 2.0f).also { it.leftMargin = dp(8) })
        for ((i, c) in cols.withIndex()) {
            val t = raw(c, if (i == 0) 13.5f else 12f, if (i == 0) Color.WHITE else 0xFFD0D0E0.toInt(), i == 0)
            t.gravity = Gravity.END
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            row.addView(t, LinearLayout.LayoutParams(0, -2, w[i]))
        }
        row.setOnClickListener { openProfile(uid) }
        return row
    }

    private fun load() {
        val g = ++gen
        headBox.removeAllViews()
        listBox.removeAllViews()
        meBox.removeAllViews()
        listBox.addView(info(L.t("Memuat…", "Loading…")))
        val isMap = tab == 1
        val key = mapKey
        Cloud.async({ if (isMap) Cloud.mapBoard(key, "score") else Cloud.globalBoard() }) { r ->
            if (g != gen || isFinishing) return@async
            listBox.removeAllViews()
            if (!r.ok) {
                listBox.addView(info(L.t(r.message)))
                return@async
            }
            val arr = r.json.optJSONArray("entries") ?: JSONArray()
            if (arr.length() == 0) {
                listBox.addView(info(if (isMap) L.t("Belum ada yang menamatkan map ini. Jadilah yang pertama!", "Nobody has cleared this map yet. Be the first!") else L.t("Belum ada pemain di peringkat.", "No players on the leaderboard yet.")))
                return@async
            }
            val w = if (isMap) wMap else wGlobal
            val cols = if (isMap) listOf(L.t("Skor", "Score"), "PP", L.t("Akurasi", "Accuracy"), L.t("Waktu", "Time"))
            else listOf("PP", L.t("Akurasi", "Accuracy"), L.t("Skor terakhir", "Last score"))
            headBox.addView(headerRow(cols, w))
            val meId = Cloud.userId
            fun cells(o: JSONObject): List<String> = if (isMap)
                listOf(String.format(Locale.US, "%,d", o.optInt("score")), String.format(Locale.US, "%.1f", o.optDouble("pp")), fmtAcc(o.optDouble("accuracy")), fmtTime(o.optLong("achieved_at")))
            else
                listOf(fmtPp(o.optDouble("pp")), fmtAcc(o.optDouble("accuracy")), fmtTime(o.optLong("achieved_at")))
            var meShown = false
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val uid = o.optLong("user_id")
                if (uid == meId) meShown = true
                listBox.addView(
                    entryRow(o.optInt("rank"), uid, o.optString("username"), o.optLong("avatar_at"), cells(o), w, uid == meId),
                    lp(-1, -2, 4)
                )
            }
            val me = r.json.optJSONObject("me")
            if (me != null && !meShown) {
                meBox.addView(raw(L.t("Peringkatmu", "Your rank"), 10.5f, Ui.ACCENT, true))
                meBox.addView(entryRow(me.optInt("rank"), me.optLong("user_id"), me.optString("username"), 0L, cells(me), w, true), lp(-1, -2, 4))
            } else if (!Cloud.loggedIn) {
                meBox.addView(raw(L.t("Masuk ke akun untuk ikut peringkat.", "Sign in to join the leaderboard."), 11.5f, Ui.SUB))
            }
        }
    }
}

// ====================================================================== CARI PEMAIN & TEMAN

/** Cari pemain lain, kirim / terima permintaan pertemanan, dan lihat daftar teman. */
class PlayersActivity : SocialBase() {
    private var tab = 0 // 0 cari, 1 teman, 2 permintaan
    private lateinit var tabRow: LinearLayout
    private lateinit var content: LinearLayout
    private var friends = JSONObject()
    private var gen = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        frame(L.t("Teman", "Friends"), L.t("cari pemain", "find players"))
        tabRow = LinearLayout(this)
        tabRow.orientation = LinearLayout.HORIZONTAL
        body.addView(tabRow, lp(-1, -2))
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        sv.addView(content, FrameLayout.LayoutParams(-1, -2))
        body.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f).also { it.topMargin = dp(8) })
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        renderTabs()
        renderContent()
        if (Cloud.loggedIn && friends.length() == 0) loadFriends()
    }

    private fun renderTabs() {
        tabRow.removeAllViews()
        if (!Cloud.loggedIn) return
        val inc = friends.optJSONArray("incoming")?.length() ?: 0
        val fr = friends.optJSONArray("friends")?.length() ?: 0
        fun t(label: String, idx: Int) {
            val p = pill(label, if (tab == idx) Ui.ACCENT else 0xFF2B2A3A.toInt()) {
                tab = idx
                render()
            }
            tabRow.addView(p, lp(-2, -2, 0, if (idx > 0) 8 else 0))
        }
        t(L.t("Cari", "Search"), 0)
        t(L.t("Teman ($fr)", "Friends ($fr)"), 1)
        t(if (inc > 0) L.t("Permintaan ($inc)", "Requests ($inc)") else L.t("Permintaan", "Requests"), 2)
    }

    private fun renderContent() {
        content.removeAllViews()
        if (!Cloud.loggedIn) {
            content.addView(info(L.t("Masuk ke akun Nova Beat dulu untuk mencari pemain dan berteman.", "Sign in to your Nova Beat account to find players and make friends.")))
            content.addView(Ui.button(this, "Masuk / buat akun", true, 14) { goLogin() }, lp(-1, dp(46), 4))
            return
        }
        when (tab) {
            0 -> renderSearch()
            1 -> renderFriends()
            else -> renderRequests()
        }
    }

    private fun loadFriends() {
        val g = ++gen
        Cloud.async({ Cloud.friends() }) { r ->
            if (g != gen || isFinishing || !r.ok) return@async
            friends = r.json
            renderTabs()
            if (tab != 0) renderContent() // di tab Cari, hasil pencarian tidak dihapus
        }
    }

    private fun userRow(o: JSONObject, trailing: View?): View {
        val id = o.optLong("id")
        val name = o.optString("username")
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(10), dp(8), dp(10), dp(8))
        row.background = Ui.ripple(Ui.rounded(0x55000000, dp(14).toFloat()))
        row.addView(avatar(id, o.optLong("avatar_at"), name), LinearLayout.LayoutParams(dp(36), dp(36)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val n = raw(name, 14.5f, Color.WHITE, true)
        n.maxLines = 1
        n.ellipsize = TextUtils.TruncateAt.END
        col.addView(n)
        if (o.has("total_pp")) col.addView(raw(fmtPp(o.optDouble("total_pp")), 11f, Ui.ACCENT, true))
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).also { it.leftMargin = dp(10) })
        if (trailing != null) row.addView(trailing, lp(-2, -2, 0, 8))
        row.setOnClickListener { openProfile(id) }
        return row
    }

    // ---- cari ----
    private fun renderSearch() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        val e = EditText(this)
        e.hint = L.t("Cari nama pemain…", "Search player name…")
        e.setHintTextColor(Ui.SUB)
        e.setTextColor(Ui.TEXT)
        e.textSize = 14f
        e.background = Ui.rounded(0x33FFFFFF, dp(12).toFloat())
        e.setPadding(dp(14), dp(9), dp(14), dp(9))
        val results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        fun search() {
            val q = e.text.toString().trim()
            if (q.isEmpty()) return
            results.removeAllViews()
            results.addView(info(L.t("Mencari…", "Searching…")))
            Cloud.async({ Cloud.search(q) }) { r ->
                if (isFinishing) return@async
                results.removeAllViews()
                if (!r.ok) {
                    results.addView(info(L.t(r.message)))
                    return@async
                }
                val arr = r.json.optJSONArray("users") ?: JSONArray()
                if (arr.length() == 0) results.addView(info(L.t("Tidak ada pemain dengan nama itu.", "No players with that name.")))
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    results.addView(userRow(o, relationPill(o.optLong("id"), o.optString("relation")) { search() }), lp(-1, -2, 6))
                }
            }
        }
        Ui.searchField(e) { search() }
        box.addView(e, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(pill(L.t("Cari", "Search"), Ui.ACCENT) { search() }, lp(-2, -2, 0, 8))
        content.addView(box, lp(-1, -2))
        content.addView(results, lp(-1, -2, 4))
    }

    /** Tombol aksi pertemanan sesuai hubungan. [after] dipanggil setelah aksi berhasil. */
    private fun relationPill(id: Long, relation: String, after: () -> Unit): View? = when (relation) {
        "none" -> pill(L.t("Tambah", "Add"), Ui.ACCENT) {
            Cloud.async({ Cloud.friendRequest(id) }) { r ->
                Toast.makeText(this, if (r.ok) L.t("Permintaan pertemanan terkirim", "Friend request sent") else r.message, Toast.LENGTH_SHORT).show()
                loadFriends()
                after()
            }
        }
        "outgoing" -> pill(L.t("Terkirim", "Sent"), 0xFF4A4962.toInt()) {
            Cloud.async({ Cloud.friendRemove(id) }) { r ->
                Toast.makeText(this, if (r.ok) L.t("Permintaan dibatalkan", "Request cancelled") else r.message, Toast.LENGTH_SHORT).show()
                loadFriends()
                after()
            }
        }
        "incoming" -> pill(L.t("Terima", "Accept"), 0xFF3FA66A.toInt()) {
            Cloud.async({ Cloud.friendAccept(id) }) { r ->
                Toast.makeText(this, if (r.ok) L.t("Sekarang kalian berteman", "You are now friends") else r.message, Toast.LENGTH_SHORT).show()
                loadFriends()
                after()
            }
        }
        "friend" -> pill(L.t("Teman ✓", "Friend ✓"), 0xFF2E7D55.toInt()) { openProfile(id) }
        else -> null
    }

    // ---- teman ----
    private fun renderFriends() {
        val arr = friends.optJSONArray("friends") ?: JSONArray()
        if (arr.length() == 0) {
            content.addView(info(L.t("Belum ada teman. Cari pemain di tab Cari lalu ketuk Tambah.", "No friends yet. Find players in the Search tab and tap Add.")))
            return
        }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            content.addView(userRow(o, null), lp(-1, -2, if (i == 0) 0 else 6))
        }
    }

    // ---- permintaan ----
    private fun renderRequests() {
        val inc = friends.optJSONArray("incoming") ?: JSONArray()
        val out = friends.optJSONArray("outgoing") ?: JSONArray()
        if (inc.length() == 0 && out.length() == 0) {
            content.addView(info(L.t("Tidak ada permintaan pertemanan.", "No friend requests.")))
            return
        }
        if (inc.length() > 0) content.addView(raw(L.t("Masuk", "Incoming"), 11f, Ui.ACCENT, true))
        for (i in 0 until inc.length()) {
            val o = inc.optJSONObject(i) ?: continue
            val id = o.optLong("id")
            val btns = LinearLayout(this)
            btns.orientation = LinearLayout.HORIZONTAL
            btns.addView(pill(L.t("Terima", "Accept"), 0xFF3FA66A.toInt()) {
                Cloud.async({ Cloud.friendAccept(id) }) { loadFriends() }
            })
            btns.addView(pill(L.t("Tolak", "Decline"), 0xFF4A2332.toInt()) {
                Cloud.async({ Cloud.friendRemove(id) }) { loadFriends() }
            }, lp(-2, -2, 0, 8))
            content.addView(userRow(o, btns), lp(-1, -2, 6))
        }
        if (out.length() > 0) content.addView(raw(L.t("Terkirim", "Sent"), 11f, Ui.ACCENT, true), lp(-2, -2, 14))
        for (i in 0 until out.length()) {
            val o = out.optJSONObject(i) ?: continue
            val id = o.optLong("id")
            content.addView(
                userRow(o, pill(L.t("Batalkan", "Cancel"), 0xFF4A4962.toInt()) { Cloud.async({ Cloud.friendRemove(id) }) { loadFriends() } }),
                lp(-1, -2, 6)
            )
        }
    }
}

// ====================================================================== PROFIL PEMAIN

/** Profil pemain lain (atau diri sendiri): foto, bio, peringkat, total PP, statistik, skor terbaru, dan tombol pertemanan. */
class PlayerProfileActivity : SocialBase() {
    private lateinit var left: LinearLayout
    private lateinit var right: LinearLayout
    private var uid = 0L

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        uid = intent.getLongExtra("user_id", 0L)
        frame(L.t("Profil pemain", "Player profile"), L.t("statistik", "stats"))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.gravity = Gravity.CENTER_HORIZONTAL
        left.setPadding(dp(14), dp(14), dp(14), dp(14))
        left.background = Ui.rounded(0x66000000, dp(18).toFloat())
        row.addView(left, LinearLayout.LayoutParams(0, -1, 0.36f))
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.setPadding(dp(4), 0, dp(4), dp(20))
        sv.addView(right, FrameLayout.LayoutParams(-1, -2))
        row.addView(sv, LinearLayout.LayoutParams(0, -1, 0.64f).also { it.leftMargin = dp(14) })
        body.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
        load()
    }

    private fun load() {
        left.removeAllViews()
        right.removeAllViews()
        right.addView(info(L.t("Memuat…", "Loading…")))
        Cloud.async({ Cloud.user(uid) }) { r ->
            if (isFinishing) return@async
            right.removeAllViews()
            val u = r.json.optJSONObject("user")
            if (!r.ok || u == null) {
                right.addView(info(L.t(r.message)))
                return@async
            }
            show(u)
        }
    }

    private fun statCard(label: String, value: String): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.background = Ui.rounded(0x66000000, dp(14).toFloat())
        c.setPadding(dp(8), dp(10), dp(8), dp(10))
        c.addView(raw(value, 16f, Color.WHITE, true).also { it.maxLines = 1; it.gravity = Gravity.CENTER })
        c.addView(Ui.text(this, label, 10.5f, Ui.SUB).also { it.gravity = Gravity.CENTER })
        return c
    }

    private fun show(u: JSONObject) {
        val name = u.optString("username")
        val relation = u.optString("relation")
        left.addView(avatar(u.optLong("id"), u.optLong("avatar_at"), name), LinearLayout.LayoutParams(dp(92), dp(92)))
        left.addView(raw(name, 20f, Color.WHITE, true).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END; it.gravity = Gravity.CENTER }, lp(-1, -2, 10))
        left.addView(
            raw(L.t("Bergabung ", "Joined ") + DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(u.optLong("created_at"))), 11.5f, Ui.ACCENT, true).also { it.gravity = Gravity.CENTER },
            lp(-1, -2, 2)
        )
        val bio = u.optString("bio")
        left.addView(
            raw(if (bio.isEmpty()) L.t("Belum menulis bio.", "No bio yet.") else bio, 12f, 0xFFD0D0E0.toInt()).also { it.gravity = Gravity.CENTER },
            lp(-1, -2, 10)
        )
        // tombol pertemanan
        val id = u.optLong("id")
        fun act(work: () -> CloudRes, okMsg: String) {
            Cloud.async(work) { r ->
                Toast.makeText(this, if (r.ok) okMsg else r.message, Toast.LENGTH_SHORT).show()
                load()
            }
        }
        when (relation) {
            "none" -> left.addView(Ui.button(this, "Tambah teman", true, 12) { act({ Cloud.friendRequest(id) }, L.t("Permintaan pertemanan terkirim", "Friend request sent")) }, lp(-1, dp(44), 14))
            "outgoing" -> left.addView(Ui.button(this, "Permintaan terkirim · batalkan", false, 12) { act({ Cloud.friendRemove(id) }, L.t("Permintaan dibatalkan", "Request cancelled")) }, lp(-1, dp(44), 14))
            "incoming" -> {
                left.addView(Ui.button(this, "Terima permintaan", true, 12) { act({ Cloud.friendAccept(id) }, L.t("Sekarang kalian berteman", "You are now friends")) }, lp(-1, dp(44), 14))
                left.addView(Ui.button(this, "Tolak", false, 12) { act({ Cloud.friendRemove(id) }, L.t("Permintaan ditolak", "Request declined")) }, lp(-1, dp(44), 6))
            }
            "friend" -> left.addView(Ui.button(this, "Teman ✓ · hapus", false, 12) {
                LDialog.confirm(this, L.t("Hapus teman?", "Remove friend?"), name, L.t("Hapus", "Remove")) {
                    act({ Cloud.friendRemove(id) }, L.t("Teman dihapus", "Friend removed"))
                }
            }, lp(-1, dp(44), 14))
        }

        // statistik
        val rank = u.optInt("global_rank")
        val cards1 = listOf(
            statCard("Total PP", String.format(Locale.US, "%,.1f", u.optDouble("total_pp"))),
            statCard(L.t("Peringkat global", "Global rank"), if (rank > 0) "#$rank" else "-"),
            statCard(L.t("Map tamat", "Maps cleared"), u.optInt("maps_cleared").toString()),
            statCard(L.t("Dimainkan", "Plays"), u.optInt("plays").toString())
        )
        val cards2 = listOf(
            statCard(L.t("Akurasi rata-rata", "Avg accuracy"), fmtAcc(u.optDouble("avg_accuracy"))),
            statCard(L.t("Skor terbaik", "Best score"), String.format(Locale.US, "%,d", u.optInt("best_score"))),
            statCard(L.t("Teman", "Friends"), u.optInt("friends").toString())
        )
        for ((ri, cards) in listOf(cards1, cards2).withIndex()) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            for ((i, c) in cards.withIndex()) r.addView(c, LinearLayout.LayoutParams(0, -2, 1f).also { if (i > 0) it.leftMargin = dp(6) })
            right.addView(r, lp(-1, -2, if (ri == 0) 4 else 6))
        }
        val recent = u.optJSONArray("recent") ?: JSONArray()
        right.addView(Ui.text(this, L.t("Skor terbaru", "Recent scores"), 17f, Color.WHITE, true), lp(-2, -2, 18))
        if (recent.length() == 0) right.addView(info(L.t("Belum ada skor.", "No scores yet.")))
        for (i in 0 until recent.length()) {
            val o = recent.optJSONObject(i) ?: continue
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(8), dp(12), dp(8))
            row.background = Ui.rounded(0x55000000, dp(12).toFloat())
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(raw(o.optString("map_title").ifEmpty { "-" }, 13.5f, Color.WHITE, true).also { it.maxLines = 1; it.ellipsize = TextUtils.TruncateAt.END })
            col.addView(raw(fmtTime(o.optLong("achieved_at")), 10.5f, Ui.SUB))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            val right2 = LinearLayout(this)
            right2.orientation = LinearLayout.VERTICAL
            right2.gravity = Gravity.END
            right2.addView(raw(String.format(Locale.US, "%,d", o.optInt("score")), 14f, Color.WHITE, true))
            right2.addView(raw(fmtAcc(o.optDouble("accuracy")) + "  ·  " + String.format(Locale.US, "%.1f pp", o.optDouble("pp")), 10.5f, Ui.ACCENT, true))
            row.addView(right2)
            right.addView(row, lp(-1, -2, 6))
        }
    }
}
