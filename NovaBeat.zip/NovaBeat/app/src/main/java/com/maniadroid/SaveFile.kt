package com.maniadroid

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * File save untuk akun LOKAL (tanpa server), seperti save di Geometry Dash:
 *  - Pemain memilih lokasi file SEKALI (Android menyimpan izin aksesnya).
 *  - Setelah itu file DITIMPA otomatis setiap kali data akun berubah (selesai main, favorit, bio, foto, kata sandi, ...).
 *  - Pindah HP: kirim file itu, lalu "Muat akun dari file save" di HP baru dan masuk dengan nama + kata sandi yang sama.
 * Isi file = hasil [Accounts.exportJson] (JSON; berisi hash kata sandi, BUKAN kata sandi). Jangan kirim ke sembarang orang.
 */
object SaveFile {
    private lateinit var app: Context
    private lateinit var sp: SharedPreferences
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "savefile").also { it.isDaemon = true } }
    private val pending = AtomicBoolean(false)

    fun init(ctx: Context, prefs: SharedPreferences) {
        if (!::app.isInitialized) {
            app = ctx.applicationContext
            sp = prefs
        }
    }

    private fun key(id: String, k: String) = "sf_${id}_$k"

    fun uriOf(a: Account): Uri? = sp.getString(key(a.id, "uri"), null)?.let { Uri.parse(it) }
    fun lastSaved(a: Account): Long = sp.getLong(key(a.id, "time"), 0L)
    fun hasError(a: Account): Boolean = sp.getBoolean(key(a.id, "err"), false)

    private fun fail(a: Account, msg: String): String {
        sp.edit().putBoolean(key(a.id, "err"), true).apply()
        return msg
    }

    /** Hubungkan [a] ke file [uri] (hasil ACTION_CREATE_DOCUMENT) lalu tulis sekarang. Return pesan galat atau null. */
    fun bind(a: Account, uri: Uri, grantFlags: Int): String? {
        if (a.id.startsWith("cloud_")) return "Akun server tersimpan di server, tidak memakai file save."
        val rw = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try {
            app.contentResolver.takePersistableUriPermission(uri, grantFlags and rw)
        } catch (e: Exception) {
            return "Lokasi ini tidak mengizinkan penyimpanan otomatis. Pilih file di penyimpanan HP (bukan aplikasi cloud)."
        }
        val old = uriOf(a)
        if (old != null && old != uri) {
            try {
                app.contentResolver.releasePersistableUriPermission(old, rw)
            } catch (e: Exception) {
            }
        }
        sp.edit().putString(key(a.id, "uri"), uri.toString()).putBoolean(key(a.id, "err"), false).apply()
        return writeNow(a)
    }

    fun unbind(a: Account) {
        val old = uriOf(a)
        if (old != null) {
            try {
                app.contentResolver.releasePersistableUriPermission(old, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (e: Exception) {
            }
        }
        val e = sp.edit()
        for (k in sp.all.keys) if (k.startsWith("sf_${a.id}_")) e.remove(k)
        e.apply()
    }

    /**
     * Tulis file save sekarang (memblokir: panggil dari thread latar). Isi disiapkan penuh di memori lalu ditulis sekali dengan mode
     * "wt" (potong dulu) supaya sisa isi lama tidak tertinggal. Return pesan galat (Indonesia) atau null bila berhasil.
     */
    fun writeNow(a: Account): String? {
        val uri = uriOf(a) ?: return "Belum ada file save. Pilih lokasi file dulu."
        return try {
            val bytes = Accounts.exportJson(a).toByteArray(Charsets.UTF_8)
            val os = app.contentResolver.openOutputStream(uri, "wt")
                ?: return fail(a, "File save tidak bisa dibuka. Pilih lokasi file save lagi.")
            os.use {
                it.write(bytes)
                it.flush()
            }
            sp.edit().putLong(key(a.id, "time"), System.currentTimeMillis()).putBoolean(key(a.id, "err"), false).apply()
            null
        } catch (e: Exception) {
            fail(a, "Gagal menulis file save (file dihapus/dipindah?). Pilih lokasi file save lagi.")
        }
    }

    /** Dipanggil setiap data akun berubah. Bergabung: banyak perubahan beruntun hanya memicu satu penulisan. */
    fun autoSave(a: Account) {
        if (!::sp.isInitialized || a.id.startsWith("cloud_") || uriOf(a) == null) return
        if (!pending.compareAndSet(false, true)) return
        val id = a.id
        io.execute {
            pending.set(false)
            Accounts.all().firstOrNull { it.id == id }?.let { writeNow(it) }
        }
    }
}
