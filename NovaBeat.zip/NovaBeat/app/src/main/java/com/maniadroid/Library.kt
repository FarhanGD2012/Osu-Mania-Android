package com.maniadroid

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

class SongSet(val dir: File, val maps: List<Beatmap>) {
    val title: String get() = maps.first().title
    val artist: String get() = maps.first().artist
    val creator: String get() = maps.first().creator
}

object Library {
    fun songsDir(c: Context): File {
        val d = File(c.filesDir, "songs")
        d.mkdirs()
        return d
    }

    fun customBg(c: Context): File? {
        val f = File(c.filesDir, "custom_bg")
        return if (f.isFile && f.length() > 0) f else null
    }

    fun menuMusicDir(c: Context): File {
        val d = File(c.filesDir, "menumusic")
        d.mkdirs()
        return d
    }

    fun displayName(c: Context, u: Uri): String? {
        return try {
            c.contentResolver.query(u, null, null, null, null)?.use { cur ->
                val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && cur.moveToFirst()) cur.getString(i) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun copyUri(c: Context, uri: Uri, dest: File): Boolean {
        return try {
            val ins = c.contentResolver.openInputStream(uri) ?: return false
            ins.use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Cari file secara case-insensitive (Android case-sensitive, chart dari Windows tidak). */
    fun findFile(dir: File, rel: String): File? {
        val clean = rel.replace('\\', '/')
        val direct = File(dir, clean)
        if (direct.isFile) return direct
        return dir.walkTopDown().firstOrNull {
            it.isFile && it.relativeTo(dir).path.replace('\\', '/').equals(clean, ignoreCase = true)
        }
    }

    fun scanDir(d: File): List<Beatmap> {
        val maps = ArrayList<Beatmap>()
        for (f in d.walkTopDown().maxDepth(2)) {
            if (f.isFile && f.extension.equals("osu", ignoreCase = true)) {
                val b = Beatmap.parse(f, false)
                if (b != null) maps.add(b)
            }
        }
        maps.sortWith(compareBy({ it.keys }, { it.noteCount }))
        return maps
    }

    fun scanSets(c: Context): List<SongSet> {
        val out = ArrayList<SongSet>()
        for (d in songsDir(c).listFiles().orEmpty()) {
            if (!d.isDirectory) continue
            val maps = scanDir(d)
            if (maps.isNotEmpty()) out.add(SongSet(d, maps))
        }
        out.sortBy { it.title.lowercase() }
        return out
    }

    /** Impor .osz. Return jumlah chart mania yang valid, atau -1 jika gagal. */
    fun importOsz(c: Context, name: String, open: () -> InputStream?): Int {
        val base = name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N}._ -]"), "_")
            .trim().take(80).ifEmpty { "chart" }
        val dir = File(songsDir(c), base)
        if (dir.exists()) dir.deleteRecursively()
        dir.mkdirs()
        var ok = false
        for (cs in listOf(Charsets.UTF_8, Charsets.ISO_8859_1)) {
            try {
                val ins = open()
                if (ins == null) {
                    dir.deleteRecursively()
                    return -1
                }
                ZipInputStream(BufferedInputStream(ins), cs).use { z -> unzip(z, dir) }
                ok = true
                break
            } catch (e: IllegalArgumentException) {
                dir.deleteRecursively()
                dir.mkdirs()
            } catch (e: Exception) {
                dir.deleteRecursively()
                return -1
            }
        }
        if (!ok) {
            dir.deleteRecursively()
            return -1
        }
        val n = scanDir(dir).size
        if (n == 0) dir.deleteRecursively()
        return n
    }

    /** Buat set baru dari file audio (untuk Editor). Return file .osu yang dibuat, atau null jika gagal. */
    fun createSet(
        c: Context, audioName: String, open: () -> InputStream?,
        title: String, artist: String, mapper: String, bpm: Double, offset: Int, keys: Int
    ): File? {
        val dir = File(songsDir(c), "new_" + System.currentTimeMillis())
        dir.mkdirs()
        try {
            val ext = audioName.substringAfterLast('.', "mp3").lowercase().ifEmpty { "mp3" }
            val audio = File(dir, "audio.$ext")
            val ins = open()
            if (ins == null) {
                dir.deleteRecursively()
                return null
            }
            ins.use { i -> FileOutputStream(audio).use { o -> i.copyTo(o) } }
            val beat = 60000.0 / bpm
            val t = if (title.isBlank()) "Tanpa judul" else title.trim()
            val a = if (artist.isBlank()) "Unknown" else artist.trim()
            val m = if (mapper.isBlank()) "Saya" else mapper.trim()
            val text = buildString {
                append("osu file format v14\n\n[General]\nAudioFilename: ${audio.name}\nAudioLeadIn: 0\nPreviewTime: -1\n")
                append("Countdown: 0\nSampleSet: Soft\nStackLeniency: 0.7\nMode: 3\nLetterboxInBreaks: 0\nSpecialStyle: 0\nWidescreenStoryboard: 0\n\n")
                append("[Editor]\nDistanceSpacing: 1\nBeatDivisor: 4\nGridSize: 4\nTimelineZoom: 1\n\n")
                append("[Metadata]\nTitle:$t\nTitleUnicode:$t\nArtist:$a\nArtistUnicode:$a\nCreator:$m\nVersion:Normal\nSource:\nTags:\nBeatmapID:0\nBeatmapSetID:-1\n\n")
                append("[Difficulty]\nHPDrainRate:5\nCircleSize:$keys\nOverallDifficulty:7\nApproachRate:5\nSliderMultiplier:1.4\nSliderTickRate:1\n\n")
                append("[Events]\n//Background and Video events\n\n")
                append("[TimingPoints]\n$offset,${String.format(java.util.Locale.US, "%.10f", beat)},4,2,0,100,1,0\n\n")
                append("[HitObjects]\n")
            }
            val f = File(dir, safeName("$a - $t ($m) [Normal]") + ".osu")
            f.writeText(text, Charsets.UTF_8)
            return f
        } catch (e: Exception) {
            dir.deleteRecursively()
            return null
        }
    }

    fun safeName(s: String): String = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(100)

    private fun unzip(z: ZipInputStream, dir: File) {
        val root = dir.canonicalPath + File.separator
        var e = z.nextEntry
        while (e != null) {
            if (!e.isDirectory) {
                val out = File(dir, e.name.replace('\\', '/'))
                if (out.canonicalPath.startsWith(root)) { // anti zip-slip
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { z.copyTo(it) }
                }
            }
            z.closeEntry()
            e = z.nextEntry
        }
    }
}
