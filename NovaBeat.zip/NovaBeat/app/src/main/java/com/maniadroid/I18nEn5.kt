package com.maniadroid

/**
 * Terjemahan tambahan (v2.2): sisa teks Indonesia (profil, akun, pesan galat, dll.).
 * Dipakai L.t() setelah EN_MAP4. Teks berisi angka / nama ditangani [EN_TEMPLATES] (pola) dan
 * [EN_PHRASES] (potongan kalimat, untuk pesan galat dari jaringan / unduhan).
 */
val EN_MAP5: Map<String, String> = mapOf(
    "Nama minimal 3 huruf" to "Name must be at least 3 letters",
    "Nama maksimal 24 huruf" to "Name can be at most 24 letters",
    "Kata sandi minimal 4 karakter" to "Password must be at least 4 characters",
    "Nama itu sudah dipakai di HP ini" to "That name is already used on this phone",
    "Nama itu sudah dipakai" to "That name is already taken",
    "Akun tidak ditemukan di HP ini" to "Account not found on this phone",
    "Kata sandi salah" to "Wrong password",
    "Kata sandi lama salah" to "Old password is wrong",
    "Kata sandi baru minimal 4 karakter" to "New password must be at least 4 characters",
    "File bukan akun Nova Beat" to "This file is not a Nova Beat account",
    "File akun rusak" to "The account file is corrupted",
    "Set ini tidak berisi chart mania" to "This set contains no mania charts",
    "Pilih jumlah key, lalu ketuk sebuah tombol di bawah dan tekan tombol di controller/keyboard. Tiap kolom punya 2 tombol (Tombol 1 & 2). Semua tombol bisa dipakai, termasuk L1, L2, R1, R2." to
        "Choose the key count, then tap a button below and press a button on your controller/keyboard. Every column has 2 keys (Key 1 & 2). Any button works, including L1, L2, R1, R2.",
    "Detail diff belum tersedia (memuat…). Cuplikan lagu tetap diputar." to "Difficulty details are not available yet (loading…). The song preview keeps playing.",
    "Lagu penuh tidak bisa diambil — tampil tanpa suara. Geser bar merah untuk melihat seluruh chart." to "Full song unavailable — showing the chart without sound. Drag the red bar to scrub the whole chart.",
    "Room penuh" to "Room is full",
    "Password room salah" to "Wrong room password",
    "Hanya host yang boleh memilih chart" to "Only the host can pick the chart",
    "Pemain" to "Players",
    "Ketuk \"Ubah bio\" untuk menulis sesuatu." to "Tap \"Edit bio\" to write something.",
    "Akun hanya tersimpan di HP ini. Tidak perlu akun Google / Gmail." to "Accounts are stored on this phone only. No Google / Gmail account needed.",
    "Masuk" to "Sign in",
    "Buat akun baru" to "Create new account",
    "Mau memakai akun yang sama di HP lain? Di HP lama: Profil > Ekspor akun. Di HP baru: Impor akun dari file, lalu Masuk dengan nama dan kata sandi yang sama." to
        "Want to use the same account on another phone? On the old phone: Profile > Export account. On the new phone: import the account from the file, then sign in with the same name and password.",
    "Hapus foto profil" to "Remove profile photo",
    "Nama baru" to "New name",
    "Ubah bio" to "Edit bio",
    "Tulis sesuatu tentang kamu" to "Write something about yourself",
    "Ubah kata sandi" to "Change password",
    "Kata sandi lama" to "Old password",
    "Kata sandi baru" to "New password",
    "Keluar (ganti akun)" to "Sign out (switch account)",
    "Hapus akun?" to "Delete account?",
    "Hapus akun ini" to "Delete this account",
    "Profil, foto, statistik, dan favorit akun ini dihapus dari HP ini. Tidak bisa dikembalikan kecuali kamu punya file ekspor." to
        "This account's profile, photo, stats and favorites will be removed from this phone. It can't be restored unless you have an export file.",
    "Nama akun" to "Account name",
    "Kata sandi" to "Password",
    "Nama (3–24 huruf)" to "Name (3–24 letters)",
    "Kata sandi (min. 4)" to "Password (min. 4)",
    "Ulangi kata sandi" to "Repeat password",
    "Kata sandi tidak sama" to "Passwords don't match",
    "Gambar tidak bisa dibaca" to "Can't read the image",
    "Akun diekspor. Simpan file ini baik-baik." to "Account exported. Keep this file safe.",
    "Gagal menyimpan file" to "Failed to save the file",
    "File tidak bisa dibaca" to "Can't read the file",
    "Akun diimpor. Sekarang Masuk dengan kata sandi yang sama." to "Account imported. Now sign in with the same password.",
    "Musik menu terus berjalan di semua layar menu (kecuali Sinkron)" to "Menu music keeps playing on every menu screen (except Sync)",
    "Akun lokal (nama, kata sandi, foto profil) tanpa Google. Nama akun dipakai di lobi dan papan skor Multiplayer." to
        "Local account (name, password, profile photo) without Google. Your account name is used in the Multiplayer lobby and scoreboard.",
    "Sudah diterapkan otomatis. Nilai bisa diubah manual di Pengaturan." to "Applied automatically. You can change the value manually in Settings.",
    "Belum ada room di jaringan ini. Pastikan HP-mu satu Wi-Fi / hotspot dengan host, atau tekan Cari di internet." to
        "No rooms on this network yet. Make sure your phone is on the same Wi-Fi / hotspot as the host, or tap Search online.",
    // ---- teks baru v2.2 ----
    "Pilih bahasa" to "Choose language",
    "Pilih bahasa yang ingin kamu pakai. Bisa diganti kapan saja di Pengaturan." to "Pick the language you want to use. You can change it any time in Settings.",
    "Warna glow" to "Glow color",
    "Warna glow kolom saat ditekan. Bawaan: ikut warna note." to "Column glow color when pressed. Default: follows the note color.",
    "Glow putih untuk semua kolom" to "White glow for all columns",
    "Glow ikut warna note" to "Glow follows note color",
    "Warna bawaan" to "Default color",
    "Tampilkan FPS" to "Show FPS",
    "Angka FPS di pojok kanan atas saat main (merah = lag)" to "FPS counter in the top-right corner while playing (red = lagging)"
)

/** Pola teks dinamis: regex Indonesia -> English (pakai $1, $2 untuk bagian yang ditangkap). */
val EN_TEMPLATES: List<Pair<Regex, String>> = listOf(
    Regex("^Profil & akun: (.*)$", RegexOption.DOT_MATCHES_ALL) to "Profile & account: $1",
    Regex("^Impor selesai: (\\d+) berhasil, (\\d+) gagal \\(bukan \\.osz mania / rusak\\)$") to "Import done: $1 succeeded, $2 failed (not a mania .osz / corrupted)",
    Regex("^Impor selesai: (\\d+) berhasil$") to "Import done: $1 succeeded",
    Regex("^Sudah ada akun lain bernama \"(.*)\" di HP ini$") to "Another account named \"$1\" already exists on this phone",
    Regex("^Keluarkan (.*)\\?$") to "Kick $1?",
    Regex("^Mulai otomatis dalam (\\d+) detik$") to "Starting automatically in $1 s",
    Regex("^Terpasang: (\\d+) chart mania$") to "Installed: $1 mania charts",
    Regex("^Gagal unduh: (.*)$", RegexOption.DOT_MATCHES_ALL) to "Download failed: $1",
    Regex("^Kolom (\\d+)$") to "Column $1",
    Regex("^metode kompresi (\\d+) tidak didukung$") to "compression method $1 not supported",
    Regex("^(\\d+) lagu ditambahkan ke musik menu$") to "$1 songs added to menu music",
    Regex("^Reset tombol \\((\\d+)K\\) ke default$") to "Reset keys ($1K) to default"
)

/** Potongan kalimat untuk pesan galat yang disusun dari bagian-bagian (jaringan, unduhan, zip). Urutan: yang terpanjang dulu. */
val EN_PHRASES: List<Pair<String, String>> = listOf(
    "Tidak bisa terhubung ke internet" to "Can't connect to the internet",
    "Tidak ada koneksi internet" to "No internet connection",
    "server tidak mendukung Range" to "server does not support Range",
    "direktori zip tidak ditemukan" to "zip directory not found",
    "metode kompresi" to "compression method",
    "zip64 tidak didukung" to "zip64 not supported",
    "ukuran tidak diketahui" to "unknown size",
    "ukuran lagu tidak cocok" to "song size mismatch",
    "gagal menyimpan lagu" to "failed to save the song",
    "file terlalu kecil" to "file too small",
    "zip kosong" to "empty zip",
    "unduhan tidak lengkap" to "incomplete download",
    "balasan kosong" to "empty reply",
    "hasil kosong" to "empty result",
    "Semua mirror gagal" to "All mirrors failed",
    "koneksi terputus" to "connection lost",
    "unduhan terputus" to "download interrupted",
    "Broker menutup koneksi" to "Broker closed the connection"
)
