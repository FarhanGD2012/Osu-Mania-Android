package com.maniadroid

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

/** Cuplikan lagu saat memilih chart (seperti layar pilih lagu osu!lazer): diputar dari titik PreviewTime chart. */
object SelectPreview {
    private var mp: MediaPlayer? = null
    private var key = ""
    private var token = 0

    /** true selama ada cuplikan yang sedang disiapkan / diputar (musik menu tidak boleh menyala bersamaan). */
    val active: Boolean get() = mp != null

    fun play(c: Context, bm: Beatmap) {
        if (!Settings.selectPreview) return
        val f = Library.findFile(bm.dir, bm.audio) ?: return
        if (f.path == key && mp != null) return // lagu yang sama: biarkan terus berjalan
        stop()
        key = f.path
        val my = ++token
        MenuMusic.pause() // musik menu berhenti selama cuplikan diputar
        val p = MediaPlayer()
        mp = p
        try {
            p.setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            p.setDataSource(f.path)
            p.setOnPreparedListener { m ->
                if (my != token || mp !== m) return@setOnPreparedListener
                try {
                    val dur = m.duration
                    val at = if (bm.previewTime > 0 && bm.previewTime < dur - 3000) bm.previewTime else (dur * 0.4f).toInt()
                    val v = Settings.musicGain
                    m.setVolume(v, v)
                    m.seekTo(at)
                    m.isLooping = true
                    m.start()
                } catch (e: Exception) {
                }
            }
            p.setOnErrorListener { _, _, _ ->
                if (mp === p) stop()
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            stop()
        }
    }

    fun stop() {
        token++
        key = ""
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
    }
}
