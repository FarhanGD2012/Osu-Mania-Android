package com.maniadroid

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

private class BarView(ctx: Context) : View(ctx) {
    var frac = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        val r = h / 2f
        p.color = 0x30FFFFFF
        c.drawRoundRect(0f, 0f, width.toFloat(), h, r, r, p)
        p.color = Ui.ACCENT
        c.drawRoundRect(0f, 0f, width * frac.coerceIn(0f, 1f), h, r, r, p)
    }
}

/** Pilih lagu ala osu!lazer: info chart di kiri, daftar kartu di kanan. */
class SongSelectActivity : BaseActivity() {
    private var all: List<SongSet> = emptyList()
    private var sets: List<SongSet> = emptyList()
    private var selDir = ""
    private var selSet = -1
    private var selDiff = 0
    private var editMode = false
    private var pickMode = false
    private var query = ""
    private var sortIdx = 0
    private var keyIdx = 0
    private lateinit var bgImg: ImageView
    private val sortNames = listOf("Judul (A-Z)", "Artis", "Mapper", "Terbaru ditambahkan", "Paling banyak note")
    private val keyNames = listOf("Semua key", "4K", "5K", "6K", "7K", "8K+")
    private val keyVals = intArrayOf(0, 4, 5, 6, 7, 8)
    private lateinit var infoBox: LinearLayout
    private lateinit var empty: View

    private fun dp(v: Int) = Ui.dp(this, v)

    private class Card(val root: FrameLayout, val img: ImageView, val title: TextView, val sub: TextView, val chips: TextView)

    private fun ring(): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(Color.TRANSPARENT)
        d.setStroke(dp(2), Ui.ACCENT)
        d.cornerRadius = dp(18).toFloat()
        return d
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = sets.size
        override fun getItem(position: Int): Any = sets[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val cd = (convertView?.tag as? Card) ?: newCard()
            val s = sets[position]
            cd.title.text = s.title
            cd.sub.text = "${s.artist}  ·  mapper ${s.creator}"
            val keys = s.maps.map { it.keys }.distinct().joinToString(", ") { "${it}K" }
            cd.chips.text = "$keys   ·   ${s.maps.size} diff"
            val hue = (abs(s.title.hashCode()) % 360).toFloat()
            cd.img.setBackgroundColor(Color.HSVToColor(floatArrayOf(hue, 0.45f, 0.32f)))
            Img.loadCover(s, cd.img)
            val sel = position == selSet
            cd.root.foreground = if (sel) ring() else null
            cd.root.translationX = if (sel) -dp(14).toFloat() else 0f
            return cd.root
        }
    }

    private fun newCard(): Card {
        val root = FrameLayout(this)
        root.background = Ui.rounded(Ui.CARD, dp(18).toFloat())
        root.clipToOutline = true
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(img, FrameLayout.LayoutParams(-1, -1))
        val shade = View(this)
        shade.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xF2101018.toInt(), 0xB3101018.toInt(), 0x40101018.toInt())
        )
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_VERTICAL
        col.setPadding(dp(18), dp(6), dp(18), dp(6))
        val title = Ui.text(this, "", 17f, Ui.TEXT, true)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        val sub = Ui.text(this, "", 12f, 0xFFC9C9DA.toInt())
        sub.maxLines = 1
        sub.ellipsize = TextUtils.TruncateAt.END
        val chips = Ui.text(this, "", 11f, Ui.ACCENT, true)
        col.addView(title)
        col.addView(sub)
        col.addView(chips)
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        root.layoutParams = AbsListView.LayoutParams(-1, dp(86))
        val cd = Card(root, img, title, sub, chips)
        root.tag = cd
        return cd
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        editMode = intent.getBooleanExtra("edit", false)
        pickMode = intent.getBooleanExtra("pick", false)

        sortIdx = Settings.sp.getInt("ssSort", 0).coerceIn(0, sortNames.size - 1)
        keyIdx = Settings.sp.getInt("ssKey", 0).coerceIn(0, keyNames.size - 1)
        val frame0 = FrameLayout(this)
        frame0.background = Ui.bgGradient()
        bgImg = ImageView(this)
        bgImg.scaleType = ImageView.ScaleType.CENTER_CROP
        bgImg.alpha = 0.55f
        frame0.addView(bgImg, FrameLayout.LayoutParams(-1, -1))
        val bgShade = View(this)
        bgShade.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xE60B0A12.toInt(), 0xAA0B0A12.toInt(), 0xCC0B0A12.toInt())
        )
        frame0.addView(bgShade, FrameLayout.LayoutParams(-1, -1))
        // isi layar: info chart di kiri, daftar kartu di kanan; baris atas (kembali + cari) menumpang di atasnya
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.setPadding(dp(16), dp(LazerBack.H_DP + 10), dp(16), dp(10))

        // kiri: info
        infoBox = LinearLayout(this)
        infoBox.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(infoBox)
        root.addView(sv, LinearLayout.LayoutParams(0, -1, 0.40f))

        // kanan: cari + daftar
        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        val search = EditText(this)
        search.hint = L.t(if (editMode) "Pilih chart untuk diedit — cari…" else "Cari judul / artis / mapper…")
        search.setHintTextColor(Ui.SUB)
        search.setTextColor(Ui.TEXT)
        search.textSize = 14f
        search.setSingleLine(true)
        search.inputType = InputType.TYPE_CLASS_TEXT
        Ui.searchField(search) { } // daftar sudah memfilter saat mengetik; Enter menutup keyboard dan menampilkan hasil
        search.background = Ui.rounded(0x33FFFFFF, dp(22).toFloat())
        search.setPadding(dp(16), 0, dp(16), 0)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim()?.lowercase() ?: ""
                applyFilter()
            }

            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        val frame = FrameLayout(this)
        // tampilan kosong ala osu!lazer: pesan + tombol pintas ke Unduh chart
        val emptyBox = LinearLayout(this)
        emptyBox.orientation = LinearLayout.VERTICAL
        emptyBox.gravity = Gravity.CENTER
        val et = Ui.text(this, "Belum ada chart", 18f, Ui.TEXT, true)
        et.gravity = Gravity.CENTER
        emptyBox.addView(et)
        val es = Ui.text(this, "Impor file .osz dari menu utama, atau unduh chart langsung dari sini.", 12.5f, Ui.SUB)
        es.gravity = Gravity.CENTER
        val esp = LinearLayout.LayoutParams(-2, -2)
        esp.topMargin = dp(6)
        esp.bottomMargin = dp(14)
        emptyBox.addView(es, esp)
        emptyBox.addView(Ui.button(this, "Unduh chart", true) {
            startActivity(Intent(this, DownloadActivity::class.java))
        }, LinearLayout.LayoutParams(-2, -2))
        empty = emptyBox
        frame.addView(emptyBox, FrameLayout.LayoutParams(-1, -1))
        val list = ListView(this)
        list.divider = ColorDrawable(Color.TRANSPARENT)
        list.dividerHeight = dp(8)
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.clipToPadding = false
        list.setPadding(dp(14), dp(8), 0, dp(8))
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            if (pos == selSet) act() else select(pos)
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            confirmDelete(sets[pos])
            true
        }
        frame.addView(list, FrameLayout.LayoutParams(-1, -1))
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.gravity = Gravity.CENTER_VERTICAL
        val sortDd = LazerDropdown(this, L.t("Urutkan") + ": " + L.t(sortNames[sortIdx]))
        sortDd.setOnClickListener {
            LDialog.pick(this, L.t("Urutkan"), sortNames.map { L.t(it) }, sortIdx) { i ->
                sortIdx = i
                Settings.sp.edit().putInt("ssSort", i).apply()
                sortDd.text = L.t("Urutkan") + ": " + L.t(sortNames[i])
                applyFilter()
            }
        }
        val keyDd = LazerDropdown(this, L.t(keyNames[keyIdx]))
        keyDd.setOnClickListener {
            LDialog.pick(this, "Key", keyNames.map { L.t(it) }, keyIdx) { i ->
                keyIdx = i
                Settings.sp.edit().putInt("ssKey", i).apply()
                keyDd.text = L.t(keyNames[i])
                applyFilter()
            }
        }
        chips.addView(sortDd, LinearLayout.LayoutParams(0, dp(36), 1.5f))
        chips.addView(keyDd, LinearLayout.LayoutParams(0, dp(36), 1f).also { it.leftMargin = dp(8) })
        right.addView(chips, LinearLayout.LayoutParams(-1, -2).also { it.topMargin = dp(2); it.leftMargin = dp(14) })
        right.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        val rp = LinearLayout.LayoutParams(0, -1, 0.60f)
        rp.leftMargin = dp(14)
        root.addView(right, rp)
        frame0.addView(root, FrameLayout.LayoutParams(-1, -1))

        // pojok kiri atas: tombol kembali ala osu!lazer, di sebelahnya kotak pencarian
        val sp = FrameLayout.LayoutParams(-1, dp(LazerBack.H_DP - 2), Gravity.TOP or Gravity.START)
        sp.leftMargin = dp(LazerBack.W_DP + 12)
        sp.rightMargin = dp(16) + (if (Settings.menuMusic) dp(MusicBar.W_DP + 6) else 0) // sisakan ruang untuk mini-player musik
        sp.topMargin = dp(1)
        frame0.addView(search, sp)
        frame0.addView(
            LazerBack(this) { finish() },
            FrameLayout.LayoutParams(dp(LazerBack.W_DP), dp(LazerBack.H_DP), Gravity.TOP or Gravity.START)
        )
        setContentView(frame0)
        showInfo()
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    override fun onPause() {
        super.onPause()
        SelectPreview.stop()
    }

    private fun reload() {
        Thread {
            val s = Library.scanSets(this)
            runOnUiThread {
                all = s
                applyFilter()
            }
        }.start()
    }

    private fun applyFilter() {
        var l: List<SongSet> = if (query.isEmpty()) all else all.filter {
            it.title.lowercase().contains(query) || it.artist.lowercase().contains(query) ||
                    it.creator.lowercase().contains(query)
        }
        val kv = keyVals[keyIdx]
        if (kv > 0) l = l.filter { s -> s.maps.any { if (kv >= 8) it.keys >= 8 else it.keys == kv } }
        l = when (sortIdx) {
            1 -> l.sortedBy { it.artist.lowercase() }
            2 -> l.sortedBy { it.creator.lowercase() }
            3 -> l.sortedByDescending { it.dir.lastModified() }
            4 -> l.sortedByDescending { s -> s.maps.maxOf { it.noteCount } }
            else -> l.sortedBy { it.title.lowercase() }
        }
        sets = l
        selSet = sets.indexOfFirst { it.dir.path == selDir }
        if (selSet < 0 && selDir.isEmpty() && sets.isNotEmpty()) {
            selSet = 0
            selDir = sets[0].dir.path
            selDiff = 0
        }
        if (selSet < 0) selDiff = 0
        adapter.notifyDataSetChanged()
        empty.visibility = if (sets.isEmpty()) View.VISIBLE else View.GONE
        showInfo()
    }

    private fun select(pos: Int) {
        selSet = pos
        selDir = sets[pos].dir.path
        selDiff = 0
        adapter.notifyDataSetChanged()
        showInfo()
    }

    private fun current(): Beatmap? {
        val s = sets.getOrNull(selSet) ?: return null
        return s.maps.getOrNull(selDiff.coerceIn(0, s.maps.size - 1))
    }

    private fun act() {
        val m = current() ?: return
        if (pickMode) {
            setResult(RESULT_OK, Intent().putExtra("osu", m.file.path))
            finish()
            return
        }
        SelectPreview.stop()
        val cls = if (editMode) EditorActivity::class.java else GameActivity::class.java
        startActivity(Intent(this, cls).putExtra("osu", m.file.path).putExtra("bot", !editMode && Mods.auto))
    }

    private fun diffColor(nps: Float): Int = when {
        nps < 3f -> 0xFF4CD08A.toInt()
        nps < 5f -> 0xFF4DA3FF.toInt()
        nps < 7f -> 0xFFFFC94D.toInt()
        nps < 9f -> 0xFFFF8A4D.toInt()
        else -> 0xFFFF4D6A.toInt()
    }

    private fun statRow(label: String, value: String, frac: Float): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(Ui.text(this, label, 11f, Ui.SUB), LinearLayout.LayoutParams(dp(66), -2))
        val bar = BarView(this)
        bar.frac = frac
        val bp = LinearLayout.LayoutParams(0, dp(5), 1f)
        bp.leftMargin = dp(4)
        bp.rightMargin = dp(8)
        r.addView(bar, bp)
        val v = Ui.text(this, value, 11f, Ui.TEXT, true)
        v.gravity = Gravity.END
        r.addView(v, LinearLayout.LayoutParams(dp(50), -2))
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(5)
        r.layoutParams = lp
        return r
    }

    private fun showInfo() {
        infoBox.removeAllViews()
        val s = sets.getOrNull(selSet)
        val m = current()
        if (m != null) SelectPreview.play(this, m) else SelectPreview.stop()
        if (s != null) Img.loadCover(s, bgImg) else bgImg.setImageDrawable(null)
        if (s == null || m == null) {
            infoBox.addView(Ui.text(this, if (editMode) "Pilih chart di kanan untuk diedit,\natau buat chart baru dari file audio." else "Pilih lagu di sebelah kanan.", 13f, Ui.SUB))
            if (editMode) addButtons(null)
            return
        }

        // kepala: sampul + judul (kecil dan rapi)
        val banner = FrameLayout(this)
        banner.background = Ui.rounded(Ui.CARD, dp(16).toFloat())
        banner.clipToOutline = true
        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        val hue = (abs(s.title.hashCode()) % 360).toFloat()
        img.setBackgroundColor(Color.HSVToColor(floatArrayOf(hue, 0.45f, 0.32f)))
        Img.loadCover(s, img)
        banner.addView(img, FrameLayout.LayoutParams(-1, -1))
        val shade = View(this)
        shade.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xF2101018.toInt(), 0xB8101018.toInt(), 0x50101018.toInt())
        )
        banner.addView(shade, FrameLayout.LayoutParams(-1, -1))
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.gravity = Gravity.CENTER_VERTICAL
        tcol.setPadding(dp(14), dp(6), dp(14), dp(6))
        val title = Ui.text(this, s.title, 16f, Ui.TEXT, true)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        tcol.addView(title)
        val artist = Ui.text(this, s.artist, 12f, 0xFFE0E0EE.toInt())
        artist.maxLines = 1
        artist.ellipsize = TextUtils.TruncateAt.END
        tcol.addView(artist)
        val mapper = Ui.text(this, "mapper ${s.creator}", 10.5f, Ui.SUB)
        mapper.maxLines = 1
        mapper.ellipsize = TextUtils.TruncateAt.END
        tcol.addView(mapper)
        banner.addView(tcol, FrameLayout.LayoutParams(-1, -1))
        infoBox.addView(banner, LinearLayout.LayoutParams(-1, dp(76)))

        // pilihan tingkat kesulitan (kotak warna kecil)
        val spread = LinearLayout(this)
        spread.orientation = LinearLayout.HORIZONTAL
        spread.gravity = Gravity.CENTER_VERTICAL
        for ((i, d) in s.maps.withIndex()) {
            val c = Ui.text(this, "${d.keys}K", 12f, Color.WHITE, true)
            c.gravity = Gravity.CENTER
            c.background = Ui.rounded(diffColor(d.nps), dp(9).toFloat())
            c.alpha = if (i == selDiff) 1f else 0.45f
            if (i == selDiff) c.foreground = GradientDrawable().also {
                it.setColor(Color.TRANSPARENT)
                it.setStroke(dp(2), Color.WHITE)
                it.cornerRadius = dp(9).toFloat()
            }
            c.setOnClickListener {
                selDiff = i
                showInfo()
            }
            val lp = LinearLayout.LayoutParams(dp(42), dp(28))
            lp.rightMargin = dp(5)
            spread.addView(c, lp)
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(spread)
        val hp = LinearLayout.LayoutParams(-1, -2)
        hp.topMargin = dp(8)
        infoBox.addView(hs, hp)

        val vn = Ui.text(this, m.version, 14f, Ui.TEXT, true)
        vn.maxLines = 1
        vn.ellipsize = TextUtils.TruncateAt.END
        val vp = LinearLayout.LayoutParams(-1, -2)
        vp.topMargin = dp(6)
        infoBox.addView(vn, vp)

        // ringkasan satu baris: durasi, BPM, jumlah note
        val meta = Ui.text(this, "${m.lengthText}   \u00B7   ${m.bpmText}   \u00B7   ${m.noteCount} ${L.t("note", "notes")}", 11.5f, 0xFFB4B4C8.toInt())
        meta.maxLines = 1
        meta.ellipsize = TextUtils.TruncateAt.END
        infoBox.addView(meta, LinearLayout.LayoutParams(-1, -2))

        // statistik tipis
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(10), dp(2), dp(10), dp(7))
        box.background = Ui.rounded(0x55181826, dp(12).toFloat())
        box.addView(statRow("Kepadatan", String.format("%.1f nps", m.nps), m.nps / 14f))
        box.addView(statRow("OD", String.format("%.1f", m.od), m.od / 10f))
        box.addView(statRow("HP", String.format("%.1f", m.hp), m.hp / 10f))
        val bxp = LinearLayout.LayoutParams(-1, -2)
        bxp.topMargin = dp(8)
        infoBox.addView(box, bxp)

        addButtons(m)
    }

    private fun addButtons(m: Beatmap?) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        if (m != null) {
            val play = Ui.button(this, if (editMode) "Edit" else if (pickMode) "Pilih" else "Main", true, 12) { act() }
            play.minHeight = dp(40)
            play.minimumHeight = dp(40)
            row.addView(play, LinearLayout.LayoutParams(0, -2, 1.7f))
            if (!editMode && !pickMode) {
                // mod BOT (ala Autoplay osu!lazer): map jalan sendiri
                // tulisan tetap "BOT" (tidak memenuhi kotak); hijau = nyala, merah = mati
                val bot = Ui.button(this, "BOT", Mods.auto, 12) { }
                bot.background = Ui.ripple(Ui.lazerFill(if (Mods.auto) 0xFF2FB872.toInt() else 0xFFD9435A.toInt(), dp(12).toFloat(), false, this))
                bot.minHeight = dp(40)
                bot.minimumHeight = dp(40)
                bot.setPadding(dp(4), 0, dp(4), 0)
                bot.setOnClickListener {
                    Mods.auto = !Mods.auto
                    showInfo()
                }
                val bp = LinearLayout.LayoutParams(0, -2, 1f)
                bp.leftMargin = dp(8)
                row.addView(bot, bp)
            }
            if (!editMode && !pickMode) {
                val board = Ui.button(this, "Peringkat", false, 12) {
                    startActivity(
                        Intent(this, LeaderboardActivity::class.java).putExtra("map_key", Pp.mapKey(m))
                            .putExtra("map_title", "${m.artist} - ${m.title} [${m.version}]")
                    )
                }
                board.minHeight = dp(40)
                board.minimumHeight = dp(40)
                board.setPadding(dp(4), 0, dp(4), 0)
                board.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12.5f)
                board.maxLines = 1
                val bdp = LinearLayout.LayoutParams(0, -2, 1.3f)
                bdp.leftMargin = dp(8)
                row.addView(board, bdp)
            }
            val del = Ui.button(this, "Hapus", false, 12) { sets.getOrNull(selSet)?.let { confirmDelete(it) } }
            del.minHeight = dp(40)
            del.minimumHeight = dp(40)
            val dp1 = LinearLayout.LayoutParams(0, -2, 1f)
            dp1.leftMargin = dp(8)
            row.addView(del, dp1)
        }
        val rp = LinearLayout.LayoutParams(-1, -2)
        rp.topMargin = dp(10)
        infoBox.addView(row, rp)
        if (editMode) {
            val nb = Ui.button(this, "Chart baru dari file audio", false, 12) { pickAudio() }
            nb.minHeight = dp(40)
            nb.minimumHeight = dp(40)
            val np = LinearLayout.LayoutParams(-1, -2)
            np.topMargin = dp(8)
            infoBox.addView(nb, np)
        }
    }

    private fun confirmDelete(s: SongSet) {
        LDialog.confirm(this, "Hapus chart?", "${s.artist} - ${s.title}", "Hapus") {
            s.dir.deleteRecursively()
            selDir = ""
            reload()
        }
    }

    // ---- chart baru dari audio (mode editor) ----
    private fun pickAudio() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "audio/*"
        @Suppress("DEPRECATION")
        startActivityForResult(i, 2)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 2 || res != RESULT_OK) return
        val uri = data?.data ?: return
        val name = try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) c.getString(i) else null
            }
        } catch (e: Exception) {
            null
        } ?: "audio.mp3"
        newChartForm(name, uri)
    }

    private fun newChartForm(audioName: String, uri: Uri) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18), dp(14), dp(18), dp(6))
        fun field(label: String, def: String, type: Int): EditText {
            box.addView(Ui.text(this, label, 12f, Ui.SUB))
            val e = EditText(this)
            Ui.noExtractUi(e)
            e.setText(def)
            e.setTextColor(Ui.TEXT)
            e.inputType = type
            e.setSingleLine(true)
            box.addView(e)
            return e
        }
        val title = field("Judul lagu", audioName.substringBeforeLast('.'), InputType.TYPE_CLASS_TEXT)
        val artist = field("Artis", "", InputType.TYPE_CLASS_TEXT)
        val mapper = field("Nama pembuat chart", "", InputType.TYPE_CLASS_TEXT)
        val bpm = field("BPM", "120", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        val off = field("Offset beat pertama (ms)", "0", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED)
        var keys = 4
        val kb: Button = Ui.button(this, L.t("Jumlah key: 4K", "Key count: 4K"), false) {}
        kb.setOnClickListener {
            keys = if (keys >= 10) 1 else keys + 1
            kb.text = L.t("Jumlah key: ${keys}K", "Key count: ${keys}K")
        }
        val kp = LinearLayout.LayoutParams(-1, -2)
        kp.topMargin = dp(10)
        box.addView(kb, kp)
        val sv = ScrollView(this)
        sv.addView(box)
        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
            .setTitle(L.t("Chart baru"))
            .setView(sv)
            .setNegativeButton(L.t("Batal"), null)
            .setPositiveButton(L.t("Buat")) { _, _ ->
                val bpmV = bpm.text.toString().toDoubleOrNull()?.takeIf { it in 20.0..999.0 } ?: 120.0
                val offV = off.text.toString().toIntOrNull() ?: 0
                val t = title.text.toString()
                val a = artist.text.toString()
                val m = mapper.text.toString()
                Toast.makeText(this, "Membuat chart…", Toast.LENGTH_SHORT).show()
                Thread {
                    val f = Library.createSet(this, audioName, { contentResolver.openInputStream(uri) }, t, a, m, bpmV, offV, keys)
                    runOnUiThread {
                        if (f == null) {
                            Toast.makeText(this, "Gagal membuat chart", Toast.LENGTH_LONG).show()
                        } else {
                            startActivity(Intent(this, EditorActivity::class.java).putExtra("osu", f.path))
                        }
                    }
                }.start()
            }
            .create().also { it.showImmersive(this) }
    }
}
