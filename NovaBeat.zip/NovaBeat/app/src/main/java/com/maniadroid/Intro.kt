package com.maniadroid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Intro saat game dibuka, terinspirasi osu!lazer: layar hitam, segitiga melayang pelan, cincin menyempit ke
 * tengah (mengumpulkan energi), lalu HENTAKAN: kilat putih, gelombang kejut, dan logo "meletup" muncul.
 * Musik menu mulai tepat di momen hentakan. Ketuk layar untuk MEMPERCEPAT intro (tiap ketukan makin cepat);
 * tombol Kembali baru benar-benar melewatinya.
 */
class IntroView(
    ctx: Context,
    private val onImpact: () -> Unit,
    private val onDone: () -> Unit,
    private val onSpeed: (Float) -> Unit = {}
) : View(ctx), Choreographer.FrameCallback {

    companion object {
        const val IMPACT_MS = 1700f
        const val END_MS = 3100f
    }

    init {
        LogoView.loadArt(ctx)
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val dens = resources.displayMetrics.density
    private var startNano = 0L
    private var lastNano = 0L
    private var simT = 0f      // waktu intro (ms) yang sudah "dimainkan"; maju lebih cepat saat dipercepat
    private var speed = 1f
    private var started = false
    private var impacted = false
    private var finished = false

    // segitiga latar (posisi & kecepatan acak tetap)
    private val n = 30
    private val rnd = java.util.Random(7)
    private val tx = FloatArray(n) { rnd.nextFloat() }
    private val ty = FloatArray(n) { rnd.nextFloat() }
    private val ts = FloatArray(n) { 0.04f + rnd.nextFloat() * 0.09f }
    private val tv = FloatArray(n) { 0.015f + rnd.nextFloat() * 0.045f }
    private val ta = FloatArray(n) { 0.05f + rnd.nextFloat() * 0.11f }

    init {
        isClickable = true
    }

    fun begin() {
        if (started || finished) return
        started = true
        startNano = System.nanoTime()
        lastNano = startNano
        simT = 0f
        Choreographer.getInstance().postFrameCallback(this)
    }

    /** Lewati intro: langsung ke menu (dipakai tombol Kembali). */
    fun skip() {
        finish()
    }

    /** Ketukan layar: intro dipercepat (x3, lalu makin cepat tiap ketukan, maksimal x10). */
    private fun speedUp() {
        if (finished || !started) return
        speed = if (speed <= 1f) 3f else min(speed * 1.6f, 10f)
        onSpeed(speed)
        invalidate()
    }

    private fun fireImpact() {
        if (impacted) return
        impacted = true
        onImpact()
    }

    private fun finish() {
        if (finished) return
        finished = true
        Choreographer.getInstance().removeFrameCallback(this)
        fireImpact()
        onDone()
    }

    override fun onDetachedFromWindow() {
        Choreographer.getInstance().removeFrameCallback(this)
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) speedUp()
        return true
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (finished) return
        val nowN = System.nanoTime()
        simT += (nowN - lastNano) / 1e6f * speed
        lastNano = nowN
        val t = simT
        if (t >= IMPACT_MS) fireImpact()
        if (t >= END_MS) {
            finish()
            return
        }
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun easeOutCubic(x: Float): Float {
        val u = 1f - x.coerceIn(0f, 1f)
        return 1f - u * u * u
    }

    private fun easeOutBack(x: Float): Float {
        val u = x.coerceIn(0f, 1f)
        val c1 = 1.70158f
        val c3 = c1 + 1f
        return 1f + c3 * (u - 1f).pow(3) + c1 * (u - 1f).pow(2)
    }

    override fun onDraw(cv: Canvas) {
        if (!started) {
            cv.drawColor(Color.BLACK)
            return
        }
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val t = simT.coerceAtLeast(0f)
        val sinceHit = t - IMPACT_MS
        val maxDim = max(w, h)

        // getaran kecil sesaat setelah hentakan
        var sx = 0f
        var sy = 0f
        if (sinceHit in 0f..320f) {
            val k = 1f - sinceHit / 320f
            sx = sin(sinceHit * 0.11f) * 5f * dens * k
            sy = sin(sinceHit * 0.13f + 1f) * 5f * dens * k
        }
        cv.save()
        cv.translate(sx, sy)

        // latar hitam yang memudar jadi transparan setelah hentakan (menampakkan menu di belakangnya)
        val bgA = if (sinceHit < 0f) 1f else 1f - easeOutCubic(sinceHit / 900f)
        cv.drawColor(Color.argb((bgA * 255).toInt().coerceIn(0, 255), 0, 0, 0))

        // segitiga melayang
        val triFade = when {
            t < 300f -> 0f
            t < 1100f -> (t - 300f) / 800f
            sinceHit < 0f -> 1f
            else -> 1f - (sinceHit / 1300f).coerceIn(0f, 1f)
        }
        if (triFade > 0f) {
            p.style = Paint.Style.FILL
            for (i in 0 until n) {
                val yy = ((ty[i] - tv[i] * t / 1000f) % 1f + 1f) % 1f
                val size = ts[i] * h
                val x = tx[i] * w
                val y = yy * (h + size * 2f) - size
                path.reset()
                path.moveTo(x, y - size * 0.6f)
                path.lineTo(x - size * 0.52f, y + size * 0.3f)
                path.lineTo(x + size * 0.52f, y + size * 0.3f)
                path.close()
                p.color = Color.argb((ta[i] * triFade * 255).toInt().coerceIn(0, 255), 110, 0xAF, 255)
                cv.drawPath(path, p)
            }
        }

        // fase "mengumpulkan energi": inti menyala + cincin menyempit
        if (sinceHit < 0f && t > 450f) {
            val prog = ((t - 450f) / (IMPACT_MS - 450f)).coerceIn(0f, 1f)
            p.style = Paint.Style.FILL
            p.color = Color.argb((60 + 195 * prog).toInt().coerceIn(0, 255), 255, 255, 255)
            cv.drawCircle(cx, cy, (3f + 20f * prog * prog) * dens, p)
            p.style = Paint.Style.STROKE
            for (j in 0 until 3) {
                val ph = (((t - 450f) / 750f) + j / 3f) % 1f
                val rr = maxDim * 0.55f * (1f - ph) + 10f * dens
                p.strokeWidth = (1.5f + 2f * prog) * dens
                p.color = Color.argb((ph * (80 + 110 * prog)).toInt().coerceIn(0, 255), 100, 0xA5, 255)
                cv.drawCircle(cx, cy, rr, p)
            }
        }

        // setelah hentakan: gelombang kejut + logo meletup
        if (sinceHit >= 0f) {
            p.style = Paint.Style.STROKE
            for (j in 0 until 2) {
                val u = ((sinceHit - j * 140f) / 1100f)
                if (u <= 0f || u >= 1f) continue
                val rr = easeOutCubic(u) * maxDim * 0.8f
                p.strokeWidth = (10f - 7f * u) * dens
                p.color = Color.argb(((1f - u) * 200).toInt().coerceIn(0, 255), 255, 255, 255)
                cv.drawCircle(cx, cy, rr, p)
            }

            val s = easeOutBack(sinceHit / 750f)
            val glow = (1f - sinceHit / 700f).coerceIn(0f, 1f)
            val base = min(w, h) * LogoView.BASE
            LogoView.paintLogo(cv, p, cx, cy, base * max(s, 0.001f), glow)
        }
        cv.restore()

        // kilat putih
        if (sinceHit in 0f..520f) {
            val a = (1f - sinceHit / 520f)
            cv.drawColor(Color.argb((a * a * 235).toInt().coerceIn(0, 255), 255, 255, 255))
        }

        // penanda kecepatan saat dipercepat
        if (speed > 1f) {
            p.style = Paint.Style.FILL
            p.textAlign = Paint.Align.RIGHT
            p.textSize = 13f * dens
            p.typeface = android.graphics.Typeface.DEFAULT_BOLD
            p.color = Color.argb(200, 255, 255, 255)
            cv.drawText(">>  x${speed.toInt()}", w - 16f * dens, h - 14f * dens, p)
            p.textAlign = Paint.Align.LEFT
        }
    }
}

/** Suara intro buatan sendiri (disintesis, bukan rekaman): sapuan naik lalu hentakan + akor. */
object IntroSound {
    private const val SR = 44100
    private const val VER = "v1"
    private const val IMPACT_SEC = 1.7
    private const val TOTAL_SEC = 3.4

    /** Siapkan pemutar (panggil di thread latar). Mengembalikan null jika gagal; intro tetap jalan tanpa suara. */
    fun prepare(c: Context): MediaPlayer? {
        return try {
            val f = File(c.cacheDir, "intro_$VER.wav")
            if (!f.isFile || f.length() < 1000) write(f)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            mp.setDataSource(f.path)
            mp.prepare()
            val v = Settings.musicGain
            mp.setVolume(v, v)
            mp
        } catch (e: Exception) {
            null
        }
    }

    private fun write(f: File) {
        val n = (SR * TOTAL_SEC).toInt()
        val buf = DoubleArray(n)
        val rnd = java.util.Random(5)
        var noise = 0.0
        var ph1 = 0.0
        var ph2 = 0.0
        val chord = doubleArrayOf(523.25, 659.25, 783.99, 1046.5)
        for (i in 0 until n) {
            val t = i.toDouble() / SR
            noise = noise * 0.6 + (rnd.nextDouble() * 2.0 - 1.0) * 0.4
            var x = 0.0
            if (t < IMPACT_SEC) {
                val u = t / IMPACT_SEC
                val fr = 140.0 * 10.0.pow(u) // 140 Hz -> 1400 Hz
                ph1 += 2.0 * PI * fr / SR
                ph2 += 2.0 * PI * fr * 1.006 / SR
                x += (sin(ph1) + sin(ph2)) * 0.5 * 0.30 * u * u
                x += noise * 0.12 * u * u * u
            } else {
                val a = t - IMPACT_SEC
                val atk = 1.0 - exp(-a / 0.004)
                x += sin(2.0 * PI * 55.0 * a) * 0.85 * exp(-a / 0.30) * atk
                x += sin(2.0 * PI * 110.0 * a) * 0.35 * exp(-a / 0.20) * atk
                x += noise * 0.45 * exp(-a / 0.05)
                for (fq in chord) x += sin(2.0 * PI * fq * a) * 0.16 * exp(-a / 0.9) * atk
                x += sin(2.0 * PI * 2093.0 * a) * 0.05 * exp(-a / 0.5) * atk
            }
            val tail = TOTAL_SEC - t
            if (tail < 0.15) x *= tail / 0.15
            buf[i] = x
        }
        var peak = 0.0
        for (v in buf) peak = max(peak, abs(v))
        val g = if (peak > 0.0) 0.9 / peak else 1.0
        val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + n * 2); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16)
        bb.putShort(1); bb.putShort(1); bb.putInt(SR); bb.putInt(SR * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(n * 2)
        for (v in buf) bb.putShort((v * g * 32767.0).toInt().coerceIn(-32768, 32767).toShort())
        f.writeBytes(bb.array())
    }
}
