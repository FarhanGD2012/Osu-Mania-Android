package com.maniadroid

/** Rekaman sentuhan satu permainan: waktu lagu (ms), kolom, dan tekan/lepas. Diputar ulang lewat mesin penilaian yang sama. */
class ReplayData(val t: DoubleArray, val c: IntArray, val d: BooleanArray, val n: Int)

/** Menyimpan replay permainan terakhir (di memori). Hanya permainan tanpa jeda yang bisa diputar ulang persis. */
object Replays {
    private var path = ""
    private var data: ReplayData? = null

    fun put(p: String, d: ReplayData) {
        path = p
        data = d
    }

    fun get(p: String): ReplayData? = if (p == path) data else null
}

/** Mod sesi (tidak disimpan): BOT = map dimainkan otomatis dan skornya tidak dicatat. */
object Mods {
    var auto = false
}
