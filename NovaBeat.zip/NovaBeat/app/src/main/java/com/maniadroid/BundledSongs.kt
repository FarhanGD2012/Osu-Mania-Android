package com.maniadroid

import android.content.Context
import java.io.File

/**
 * Lagu bawaan (Neon Circles, Pink Horizon, Soft Landing) sudah DIHAPUS dari aplikasi.
 * Objek ini hanya membersihkan salinan yang dulu terpasang otomatis di HP (sekali saja saat pertama dibuka
 * setelah pembaruan), supaya ketiga level itu benar-benar hilang dari daftar lagu dan musik menu.
 * Hanya folder dengan nama lagu bawaan DAN pembuat "ManiaDroid" yang dihapus; chart buatan / unduhan kamu aman.
 */
object BundledSongs {
    private const val KEY = "bundledPurged"
    private val NAMES = listOf("Neon Circles", "Pink Horizon", "Soft Landing")

    @Synchronized
    fun purge(c: Context) {
        if (!Settings.ready) Settings.init(c)
        if (Settings.sp.getInt(KEY, 0) >= 1) return
        try {
            for (n in NAMES) {
                val d = File(Library.songsDir(c.applicationContext), n)
                if (!d.isDirectory) continue
                val ours = d.listFiles().orEmpty().any { f ->
                    f.isFile && f.extension.equals("osu", ignoreCase = true) &&
                            f.readLines().any { it.trim().equals("Creator:ManiaDroid", ignoreCase = true) }
                }
                if (ours) d.deleteRecursively()
            }
        } catch (e: Exception) {
        }
        Settings.sp.edit().putInt(KEY, 1).apply()
    }
}
