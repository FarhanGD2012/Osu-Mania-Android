package com.maniadroid

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Satu akun lokal. Kata sandi tidak disimpan, hanya hash PBKDF2 + salt. */
class Account(
    val id: String,
    var name: String,
    var bio: String,
    val created: Long,
    var salt: String,
    var hash: String
)

/**
 * Akun LOKAL (tanpa server, tanpa Google / Gmail): nama, kata sandi, foto profil, bio, statistik main dan daftar favorit.
 * Semuanya tersimpan di HP ini. Untuk memakai akun yang sama di HP lain: Ekspor akun (file) lalu Impor di HP itu,
 * kemudian masuk dengan nama + kata sandi yang sama.
 */
object Accounts {
    private lateinit var sp: SharedPreferences
    private lateinit var app: Context

    fun init(c: Context) {
        if (!::sp.isInitialized) {
            app = c.applicationContext
            sp = app.getSharedPreferences("maniadroid_accounts", Context.MODE_PRIVATE)
        }
    }

    // ---------- baca ----------
    private fun parse(js: String): Account? = try {
        val o = JSONObject(js)
        Account(
            o.getString("id"), o.getString("name"), o.optString("bio"), o.optLong("created"),
            o.optString("salt"), o.optString("hash")
        )
    } catch (e: Exception) {
        null
    }

    private fun toJson(a: Account): String = JSONObject()
        .put("id", a.id).put("name", a.name).put("bio", a.bio).put("created", a.created)
        .put("salt", a.salt).put("hash", a.hash).toString()

    private fun ids(): List<String> = (sp.getString("ids", "") ?: "").split(",").filter { it.isNotEmpty() }

    fun all(): List<Account> = ids().mapNotNull { id -> sp.getString("acc_$id", null)?.let { parse(it) } }

    fun current(): Account? {
        val id = sp.getString("current", "") ?: ""
        if (id.isEmpty()) return null
        return sp.getString("acc_$id", null)?.let { parse(it) }
    }

    private fun save(a: Account) {
        val list = ids().toMutableList()
        if (!list.contains(a.id)) list.add(a.id)
        sp.edit().putString("acc_${a.id}", toJson(a)).putString("ids", list.joinToString(",")).apply()
    }

    fun nameTaken(name: String, exceptId: String = ""): Boolean =
        all().any { it.id != exceptId && it.name.equals(name, ignoreCase = true) }

    // ---------- kata sandi ----------
    private fun hashPw(pw: String, salt: String): String {
        val spec = PBEKeySpec(pw.toCharArray(), Base64.decode(salt, Base64.NO_WRAP), 20000, 256)
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        return Base64.encodeToString(f.generateSecret(spec).encoded, Base64.NO_WRAP)
    }

    private fun newSalt(): String {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, Base64.NO_WRAP)
    }

    fun verify(a: Account, pw: String): Boolean = try {
        MessageDigest.isEqual(hashPw(pw, a.salt).toByteArray(), a.hash.toByteArray())
    } catch (e: Exception) {
        false
    }

    // ---------- aksi ----------
    /** Buat akun baru lalu langsung masuk. Return pesan galat (Indonesia) atau null bila berhasil. */
    fun create(name: String, pw: String): String? {
        val n = name.trim()
        if (n.length < 3) return "Nama minimal 3 huruf"
        if (n.length > 24) return "Nama maksimal 24 huruf"
        if (pw.length < 4) return "Kata sandi minimal 4 karakter"
        if (nameTaken(n)) return "Nama itu sudah dipakai di HP ini"
        val salt = newSalt()
        val id = java.lang.Long.toHexString(System.currentTimeMillis()) + java.lang.Integer.toHexString(SecureRandom().nextInt(0xFFFF))
        val a = Account(id, n, "", System.currentTimeMillis(), salt, hashPw(pw, salt))
        save(a)
        sp.edit().putString("current", id).apply()
        return null
    }

    fun login(name: String, pw: String): String? {
        val a = all().firstOrNull { it.name.equals(name.trim(), ignoreCase = true) } ?: return "Akun tidak ditemukan di HP ini"
        if (!verify(a, pw)) return "Kata sandi salah"
        sp.edit().putString("current", a.id).apply()
        return null
    }

    fun logout() {
        sp.edit().putString("current", "").apply()
    }

    fun rename(a: Account, name: String): String? {
        val n = name.trim()
        if (n.length < 3) return "Nama minimal 3 huruf"
        if (n.length > 24) return "Nama maksimal 24 huruf"
        if (nameTaken(n, a.id)) return "Nama itu sudah dipakai"
        a.name = n
        save(a)
        return null
    }

    fun setBio(a: Account, bio: String) {
        a.bio = bio.trim().take(120)
        save(a)
    }

    fun changePassword(a: Account, old: String, new: String): String? {
        if (!verify(a, old)) return "Kata sandi lama salah"
        if (new.length < 4) return "Kata sandi baru minimal 4 karakter"
        a.salt = newSalt()
        a.hash = hashPw(new, a.salt)
        save(a)
        return null
    }

    fun delete(a: Account) {
        val list = ids().toMutableList()
        list.remove(a.id)
        val e = sp.edit().remove("acc_${a.id}").putString("ids", list.joinToString(","))
        for (k in sp.all.keys) if (k.startsWith("st_${a.id}_") || k == "fav_${a.id}") e.remove(k)
        if (sp.getString("current", "") == a.id) e.putString("current", "")
        e.apply()
        avatarFile(a).delete()
    }

    // ---------- foto profil ----------
    fun avatarFile(a: Account): File = File(app.filesDir, "avatar_${a.id}.jpg")

    /** Ambil gambar dari [uri], potong persegi di tengah, kecilkan 256 px, simpan. */
    fun setAvatar(a: Account, uri: Uri): Boolean = try {
        val bounds = BitmapFactory.Options().also { it.inJustDecodeBounds = true }
        app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 512 && bounds.outHeight / (sample * 2) >= 512) sample *= 2
        val o = BitmapFactory.Options().also { it.inSampleSize = sample }
        val src = app.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        if (src == null) false else {
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
            avatarFile(a).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            AvatarView.invalidateCache()
            true
        }
    } catch (e: Throwable) {
        false
    }

    fun removeAvatar(a: Account) {
        avatarFile(a).delete()
        AvatarView.invalidateCache()
    }

    // ---------- statistik ----------
    class Stats(val plays: Int, val totalScore: Long, val bestScore: Int, val bestAcc: Float)

    fun stats(a: Account): Stats = Stats(
        sp.getInt("st_${a.id}_plays", 0),
        sp.getLong("st_${a.id}_score", 0L),
        sp.getInt("st_${a.id}_best", 0),
        sp.getFloat("st_${a.id}_acc", 0f)
    )

    /** Dipanggil saat sebuah permainan selesai (bukan gagal, bukan BOT / replay). Tidak berbuat apa-apa jika belum masuk. */
    fun recordPlay(score: Int, acc: Float) {
        val a = current() ?: return
        val st = stats(a)
        sp.edit()
            .putInt("st_${a.id}_plays", st.plays + 1)
            .putLong("st_${a.id}_score", st.totalScore + score)
            .putInt("st_${a.id}_best", maxOf(st.bestScore, score))
            .putFloat("st_${a.id}_acc", maxOf(st.bestAcc, acc))
            .apply()
    }

    // ---------- favorit chart (per akun; tanpa akun = daftar tamu) ----------
    private fun favKey(): String = "fav_" + (current()?.id ?: "guest")

    private fun favArray(): JSONArray = try {
        JSONArray(sp.getString(favKey(), "[]") ?: "[]")
    } catch (e: Exception) {
        JSONArray()
    }

    fun isFav(id: Int): Boolean {
        val a = favArray()
        for (i in 0 until a.length()) if (a.optJSONObject(i)?.optInt("id") == id) return true
        return false
    }

    fun favCount(): Int = favArray().length()

    /** Tambah / hapus favorit. Return true bila sekarang jadi favorit. */
    fun toggleFav(r: Downloader.Remote): Boolean {
        val a = favArray()
        val out = JSONArray()
        var had = false
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (o.optInt("id") == r.id) had = true else out.put(o)
        }
        if (!had) {
            val o = JSONObject().put("id", r.id).put("title", r.title).put("artist", r.artist).put("creator", r.creator)
                .put("status", r.status).put("plays", r.plays).put("favs", r.favs).put("rankedAt", r.rankedAt)
            val ks = JSONArray()
            for (k in r.keyCounts) ks.put(k)
            val ss = JSONArray()
            for (s in r.stars) ss.put(s.toDouble())
            o.put("keys", ks).put("stars", ss)
            out.put(o)
        }
        sp.edit().putString(favKey(), out.toString()).apply()
        return !had
    }

    /** Daftar favorit (terbaru di atas) sebagai kartu unduhan; diff detail diambil ulang saat kartu dibuka. */
    fun favorites(): List<Downloader.Remote> {
        val a = favArray()
        val out = ArrayList<Downloader.Remote>()
        for (i in a.length() - 1 downTo 0) {
            val o = a.optJSONObject(i) ?: continue
            val ks = o.optJSONArray("keys") ?: JSONArray()
            val ss = o.optJSONArray("stars") ?: JSONArray()
            out.add(
                Downloader.Remote(
                    o.optInt("id"), o.optString("title"), o.optString("artist"), o.optString("creator"), o.optString("status"),
                    "oleh " + o.optString("creator"),
                    List(ss.length()) { ss.optDouble(it).toFloat() },
                    List(ks.length()) { ks.optInt(it) },
                    o.optInt("plays"), o.optInt("favs"), o.optLong("rankedAt")
                )
            )
        }
        return out
    }

    // ---------- ekspor / impor (pindah ke HP lain) ----------
    fun exportJson(a: Account): String {
        val o = JSONObject(toJson(a))
        o.put("format", "novabeat-account-1")
        val st = stats(a)
        o.put("plays", st.plays).put("score", st.totalScore).put("best", st.bestScore).put("acc", st.bestAcc.toDouble())
        o.put("favs", JSONArray(sp.getString("fav_${a.id}", "[]") ?: "[]"))
        val f = avatarFile(a)
        if (f.isFile) {
            val bo = ByteArrayOutputStream()
            f.inputStream().use { it.copyTo(bo) }
            o.put("avatar", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP))
        }
        return o.toString()
    }

    /** Impor akun dari isi file ekspor. Return pesan galat atau null bila berhasil (akun belum otomatis masuk). */
    fun importJson(js: String): String? {
        val o = try {
            JSONObject(js)
        } catch (e: Exception) {
            return "File bukan akun Nova Beat"
        }
        if (o.optString("format") != "novabeat-account-1" && o.optString("format") != "novalane-account-1") return "File bukan akun Nova Beat"
        val a = parse(o.toString()) ?: return "File akun rusak"
        if (a.salt.isEmpty() || a.hash.isEmpty()) return "File akun rusak"
        val clash = all().firstOrNull { it.name.equals(a.name, ignoreCase = true) && it.id != a.id }
        if (clash != null) return "Sudah ada akun lain bernama \"${a.name}\" di HP ini"
        save(a)
        val e = sp.edit()
            .putInt("st_${a.id}_plays", o.optInt("plays"))
            .putLong("st_${a.id}_score", o.optLong("score"))
            .putInt("st_${a.id}_best", o.optInt("best"))
            .putFloat("st_${a.id}_acc", o.optDouble("acc", 0.0).toFloat())
        o.optJSONArray("favs")?.let { e.putString("fav_${a.id}", it.toString()) }
        e.apply()
        val av = o.optString("avatar")
        if (av.isNotEmpty()) try {
            avatarFile(a).writeBytes(Base64.decode(av, Base64.NO_WRAP))
            AvatarView.invalidateCache()
        } catch (e2: Exception) {
        }
        return null
    }
}
