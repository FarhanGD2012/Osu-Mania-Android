plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

base {
    archivesName.set("NovaBeat")
}

// Alamat server bawaan: -Pnovabeat.serverUrl=https://... (atau variabel repo GitHub NOVABEAT_SERVER_URL). Bisa diganti pemain di Profil.
val serverUrl: String = ((project.findProperty("novabeat.serverUrl") as String?) ?: "")
    .trim().trimEnd('/').ifEmpty { "https://novabeat-server.onrender.com" }
require(Regex("^https?://[A-Za-z0-9._:-]+$").matches(serverUrl)) { "novabeat.serverUrl tidak valid: $serverUrl" }

android {
    namespace = "com.maniadroid"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.novalane.game"
        minSdk = 24
        targetSdk = 34
        versionCode = 16
        versionName = "1.0"
        buildConfigField("String", "SERVER_URL", "\"$serverUrl\"")
    }

    buildFeatures {
        buildConfig = true
    }

    // Keystore tetap: build di GitHub (runner selalu baru) tetap bertanda tangan sama,
    // jadi APK baru bisa menimpa APK lama tanpa uninstall.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    // Keystore RILIS (produksi): dibaca dari variabel lingkungan / gradle.properties, TIDAK pernah dimasukkan ke repo.
    // Bila belum diatur, build release tetap bisa jalan (ditandatangani debug) supaya CI tidak gagal.
    val relFile = System.getenv("NOVABEAT_KEYSTORE_FILE") ?: (project.findProperty("novabeat.keystoreFile") as String?)
    if (!relFile.isNullOrEmpty()) {
        signingConfigs {
            create("release") {
                storeFile = file(relFile)
                storePassword = System.getenv("NOVABEAT_KEYSTORE_PASSWORD") ?: (project.findProperty("novabeat.keystorePassword") as String?)
                keyAlias = System.getenv("NOVABEAT_KEY_ALIAS") ?: (project.findProperty("novabeat.keyAlias") as String?)
                keyPassword = System.getenv("NOVABEAT_KEY_PASSWORD") ?: (project.findProperty("novabeat.keyPassword") as String?)
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (!relFile.isNullOrEmpty()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // WebSocket untuk room multiplayer lewat server (TLS, ping, dan pembingkaian ditangani library ini). Gratis, sumber terbuka.
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
