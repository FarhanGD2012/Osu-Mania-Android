package com.maniadroid

import android.app.Activity
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import java.io.File

class GameActivity : BaseActivity(), GameView.Callback {
    // layar ini memutar audio sendiri: musik menu dijeda dan mini-player disembunyikan
    override fun wantsMenuMusic(): Boolean = false
    override val showMusicBar: Boolean = false

    private var mp: MediaPlayer? = null
    private var game: GameView? = null
    private var backdrop: Backdrop? = null
    private var resultUi: ResultOverlay? = null
    private var rootView: FrameLayout? = null
    private var pauseUi: PauseOverlay? = null
    private var songTitle = ""
    private var songSub = ""
    private var finished = false
    private var bestKey = ""
    private var bestPath = ""
    private val pad = PadState()
    private var laneMap = HashMap<Int, ArrayList<Int>>()

    override val recreateOnLanguageChange: Boolean = false

    // ---- Versus ----
    private var vsMode = false
    private var vsOverlay: VersusResultOverlay? = null
    private var vsLastResult: Result? = null
    private val vsListener = object : Versus.Listener {
        override fun onResults() {
            showVsResults()
        }

        override fun onClosed(reason: String) {
            Toast.makeText(this@GameActivity, reason, Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun showVsResults() {
        val ui = vsOverlay ?: return
        val r = Versus.results ?: return
        ui.show(r, Versus.myId)
    }

    private fun confirmQuitVs() {
        if (finished) {
            finish()
            return
        }
        LDialog.confirm(this, "Keluar dari pertandingan?", "Skormu dihitung gagal dan lawan lanjut bermain.", "Keluar") {
            val g = game
            if (g != null && !finished) {
                finished = true
                Versus.sendFinish(g.currentResult(true))
            }
            finish()
        }
    }

    /** Saat bermain, efek tombol menu dimatikan supaya sentuhan di kolom tidak diproses dua kali (mengurangi lag). */
    override fun wantsUiFeedback(): Boolean = pauseUi != null || resultUi != null || vsOverlay != null

    /** Minta layar memakai refresh rate tertinggi (mis. 90 / 120 Hz) pada resolusi yang sama: scroll note lebih halus. */
    @Suppress("DEPRECATION")
    private fun requestHighRefresh() {
        if (!Settings.highRefresh || Build.VERSION.SDK_INT < 23) return
        try {
            val d = if (Build.VERSION.SDK_INT >= 30) display else windowManager.defaultDisplay
            if (d == null) return
            val cur = d.mode
            var best = cur
            for (m in d.supportedModes) {
                if (m.physicalWidth == cur.physicalWidth && m.physicalHeight == cur.physicalHeight && m.refreshRate > best.refreshRate) best = m
            }
            if (best.modeId != cur.modeId) {
                val lp = window.attributes
                lp.preferredDisplayModeId = best.modeId
                window.attributes = lp
            }
        } catch (e: Throwable) {
        }
    }

    /**
     * Anti-lag saat menekan banyak tombol: thread utama (tempat sentuhan diproses dan layar digambar) dinaikkan
     * prioritasnya, dan "sustained performance" dinyalakan bila perangkat mendukung supaya HP tidak menurunkan
     * kecepatan CPU di tengah lagu panjang.
     */
    private fun boostPerformance() {
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY)
        } catch (e: Throwable) {
        }
        try {
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            if (Build.VERSION.SDK_INT >= 24 && pm.isSustainedPerformanceModeSupported) window.setSustainedPerformanceMode(true)
        } catch (e: Throwable) {
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        vsMode = intent.getBooleanExtra("vs", false)
        Sfx.init(this)
        Ui.applyOrientation(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestHighRefresh()
        boostPerformance()
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        val path = intent.getStringExtra("osu")
        if (path == null) {
            finish()
            return
        }
        val file = File(path)
        val bm = Beatmap.parse(file, true)
        if (bm == null || bm.notes.isEmpty()) {
            Toast.makeText(this, "Chart tidak valid / bukan mode mania", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        laneMap = Bindings.map(bm.keys)
        val audio = Library.findFile(bm.dir, bm.audio)
        if (audio == null) {
            Toast.makeText(this, L.t("File audio tidak ditemukan: ${bm.audio}", "Audio file not found: ${bm.audio}"), Toast.LENGTH_LONG).show()
            finish()
            return
        }
        val player = MediaPlayer()
        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            player.setDataSource(audio.path)
            player.prepare()
            val v = Settings.musicGain
            player.setVolume(v, v)
        } catch (e: Exception) {
            Toast.makeText(this, L.t("Audio gagal dibuka: ${e.message}", "Failed to open audio: ${e.message}"), Toast.LENGTH_LONG).show()
            player.release()
            finish()
            return
        }
        mp = player
        bestKey = file.parentFile!!.name + "/" + file.name
        bestPath = file.path

        songTitle = "${bm.artist} - ${bm.title}"
        songSub = "[${bm.version}]  ·  mapper ${bm.creator}"
        val root = FrameLayout(this)
        rootView = root
        val bd = Backdrop(this, bm)
        backdrop = bd
        bd.onNote = { msg -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        bd.initialNote?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        root.addView(bd, Ui.matchParams())
        val gv = GameView(this, bm, bd, player, this)
        game = gv
        root.addView(gv, Ui.matchParams())
        setContentView(root)
        if (!vsMode) {
            if (intent.getBooleanExtra("bot", false)) gv.startBot()
            else if (intent.getBooleanExtra("replay", false)) {
                val rd = Replays.get(bm.file.path)
                if (rd != null) gv.startReplay(rd) else Toast.makeText(this, "Belum ada replay untuk chart ini", Toast.LENGTH_SHORT).show()
            }
        }
        if (vsMode) {
            gv.onSnapshot = { s, a, c, h, p -> Versus.sendScore(s, a, c, h, p) }
            gv.overlayDraw = { cv, w, h, d -> Versus.drawBoard(cv, w, h, d) }
            Versus.listener = vsListener
            gv.beginAt(Versus.startNano)
        } else {
            gv.begin()
        }
    }

    // ---- controller & keyboard ----
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val g = game ?: return super.dispatchKeyEvent(e)
        val code = e.keyCode
        if (Input.isSystemKey(code)) return super.dispatchKeyEvent(e)
        val lanes = laneMap[code]
        val pauseKey = lanes == null && Input.isPauseKey(code)
        if (lanes == null && !pauseKey) return super.dispatchKeyEvent(e)
        if (e.action == KeyEvent.ACTION_DOWN) {
            if (e.repeatCount > 0) return true
            if (lanes != null) {
                if (pad.keyDown(code)) for (c in lanes) g.padPress(c, e.eventTime)
            } else {
                onPausePressed()
            }
        } else if (e.action == KeyEvent.ACTION_UP && lanes != null) {
            if (pad.keyUp(code)) for (c in lanes) g.padRelease(c, e.eventTime)
        }
        return true
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val g = game
        if (g != null && Input.isJoystickMove(ev)) {
            val st = Input.axisStates(ev)
            for (i in st.indices) {
                val code = Input.AXIS_CODES[i]
                val ch = pad.axisSet(code, st[i])
                if (ch == 0) continue
                val lanes = laneMap[code]
                if (lanes != null) {
                    for (c in lanes) if (ch > 0) g.padPress(c, ev.eventTime) else g.padRelease(c, ev.eventTime)
                }
            }
            return true
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun onPause() {
        super.onPause()
        if (!finished && game != null && !vsMode && Settings.pauseOnLeave) {
            game?.pauseGame()
            showPauseMenu()
        }
    }

    override fun onResume() {
        super.onResume()
        // sehabis dari layar pengaturan lengkap: terapkan pengaturan baru
        game?.applySettings()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (vsMode) {
            confirmQuitVs()
            return
        }
        if (finished || game == null) {
            super.onBackPressed()
            return
        }
        val ui = pauseUi
        if (ui != null) {
            if (!ui.back()) doResume() // Back di menu jeda = lanjut main
            return
        }
        game?.pauseGame()
        showPauseMenu()
    }

    override fun onPausePressed() {
        if (vsMode) {
            confirmQuitVs()
            return
        }
        if (pauseUi != null) {
            doResume() // tombol Start controller: jeda <-> lanjut
            return
        }
        game?.pauseGame()
        showPauseMenu()
    }

    private fun showPauseMenu() {
        val root = rootView ?: return
        if (finished || isFinishing || pauseUi != null) return
        val ui = PauseOverlay(
            this, songTitle, songSub, game?.statusText() ?: "",
            onContinue = { doResume() },
            onRetry = { retry() },
            onQuit = { finish() },
            onBot = if (vsMode) null else { { retryBot() } },
            // "Setelan" langsung ke pengaturan lengkap (layar besar), bukan panel kecil
            onAllSettings = { startActivity(Intent(this, SettingsActivity::class.java).putExtra("fromGame", true)) }
        )
        pauseUi = ui
        root.addView(ui, Ui.matchParams())
    }

    private fun hidePauseMenu() {
        val ui = pauseUi ?: return
        pauseUi = null
        ui.animate().alpha(0f).setDuration(120).withEndAction { rootView?.removeView(ui) }.start()
    }

    private fun doResume() {
        hidePauseMenu()
        game?.applySettings()
        game?.resumeGame()
    }

    private fun retry() {
        val i = Intent(intent)
        finish()
        startActivity(i)
        overridePendingTransition(0, 0)
    }

    /** Mulai ulang chart ini dengan BOT (map jalan sendiri). */
    private fun retryBot() {
        val i = Intent(intent).putExtra("bot", true).putExtra("replay", false)
        finish()
        startActivity(i)
        overridePendingTransition(0, 0)
    }

    /** Putar ulang rekaman permainan terakhir pada chart ini. */
    private fun watchReplay() {
        val i = Intent(intent).putExtra("replay", true).putExtra("bot", false)
        finish()
        startActivity(i)
        overridePendingTransition(0, 0)
    }

    override fun onEnd(r: Result) {
        finished = true
        if (vsMode) {
            vsLastResult = r
            Versus.sendFinish(r)
            val ui = VersusResultOverlay(this) { finish() }
            vsOverlay = ui
            rootView?.addView(ui, Ui.matchParams())
            ui.waiting(r.score, r.acc)
            showVsResults()
            return
        }
        val auto = r.bot || r.replay
        val prev = Settings.best(bestKey)
        if (!r.failed && !auto) Settings.saveBest(bestKey, r.score) // BOT / replay tidak memecahkan rekor
        if (!r.failed && !auto) Accounts.recordPlay(r.score, r.acc) // statistik profil
        val best = Settings.best(bestKey)
        val newBest = !r.failed && !auto && r.score > prev
        pauseUi?.let {
            pauseUi = null
            rootView?.removeView(it)
        }
        resultUi?.let { rootView?.removeView(it) }
        val ui = ResultOverlay(
            this, songTitle + if (r.bot) "  ·  BOT" else if (r.replay) "  ·  REPLAY" else "", songSub, r, best, newBest,
            onRetry = { retry() },
            onBack = { finish() },
            onReplay = if (Replays.get(bestPath) != null) { { watchReplay() } } else null
        )
        resultUi = ui
        rootView?.addView(ui, Ui.matchParams())
    }

    override fun onDestroy() {
        super.onDestroy()
        if (vsMode && Versus.listener === vsListener) Versus.listener = null
        game?.destroy()
        backdrop?.release()
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
    }
}
