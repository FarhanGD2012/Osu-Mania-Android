package com.maniadroid

import android.content.Context

/**
 * Bahasa antarmuka (Pengaturan > Bahasa). Teks sumber di kode berbahasa Indonesia;
 * saat bahasa = English, [t] mencari terjemahannya di [EN_MAP] (jika tidak ada, tampil apa adanya).
 * Ui.text / Ui.button / Toast sudah otomatis memanggil [t].
 */
object L {
    const val ID = 0
    const val EN = 1

    val en: Boolean get() = Settings.ready && Settings.language == EN

    /** Teks statis: Indonesia (sumber) -> English bila perlu. */
    fun t(s: String): String = if (en) (EN_MAP[s] ?: EN_MAP2[s] ?: EN_MAP3[s] ?: EN_MAP4[s] ?: s) else s

    /** Teks dinamis (berisi angka / nama): tulis dua versinya langsung. */
    fun t(id: String, en: String): String = if (this.en) en else id
}

/**
 * Pengganti android.widget.Toast di paket ini: sama persis, hanya teksnya diterjemahkan lebih dulu.
 * (Semua file memakai `Toast.makeText(...)` tanpa import, sehingga otomatis memakai yang ini.)
 */
object Toast {
    const val LENGTH_SHORT = android.widget.Toast.LENGTH_SHORT
    const val LENGTH_LONG = android.widget.Toast.LENGTH_LONG

    fun makeText(c: Context, text: CharSequence, duration: Int): android.widget.Toast =
        android.widget.Toast.makeText(c, L.t(text.toString()), duration)
}
