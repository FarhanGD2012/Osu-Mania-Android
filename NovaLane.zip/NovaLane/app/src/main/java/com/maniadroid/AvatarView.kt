package com.maniadroid

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View

/** Foto profil bulat; tanpa foto: lingkaran pink dengan huruf pertama nama. */
class AvatarView(ctx: Context) : View(ctx) {
    companion object {
        private var cacheKey = ""
        private var cacheBmp: Bitmap? = null

        fun invalidateCache() {
            cacheKey = ""
            cacheBmp = null
        }

        private fun load(a: Account?): Bitmap? {
            if (a == null) return null
            val f = Accounts.avatarFile(a)
            if (!f.isFile) return null
            val key = f.path + ":" + f.lastModified()
            if (key == cacheKey) return cacheBmp
            val b = try {
                BitmapFactory.decodeFile(f.path)
            } catch (e: Throwable) {
                null
            }
            cacheKey = key
            cacheBmp = b
            return b
        }
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var bmp: Bitmap? = null
    private var shader: BitmapShader? = null
    private var letter = "?"
    private val m = android.graphics.Matrix()

    fun set(a: Account?, fallbackName: String) {
        letter = (a?.name ?: fallbackName).trim().take(1).uppercase().ifEmpty { "?" }
        val b = load(a)
        if (b !== bmp) {
            bmp = b
            shader = if (b != null) BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) else null
        }
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val r = minOf(width, height) / 2f
        val cx = width / 2f
        val cy = height / 2f
        val sh = shader
        val b = bmp
        if (sh != null && b != null) {
            m.reset()
            val s = (r * 2f) / b.width
            m.setScale(s, s)
            m.postTranslate(cx - r, cy - r)
            sh.setLocalMatrix(m)
            p.shader = sh
            cv.drawCircle(cx, cy, r, p)
            p.shader = null
        } else {
            p.color = 0xFF66ADFF.toInt()
            cv.drawCircle(cx, cy, r, p)
            p.color = Color.WHITE
            p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = r * 1.0f
            cv.drawText(letter, cx, cy + r * 0.35f, p)
        }
    }
}
