package com.maniadroid

import android.app.Activity
import android.app.ActivityManager
import android.app.Dialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

/**
 * Dasar semua layar:
 *  - fullscreen imersif (bar status & tombol navigasi HP disembunyikan; geser dari tepi untuk memunculkan sementara),
 *  - layar dibuat ulang otomatis bila bahasa diganti di Pengaturan.
 */
open class BaseActivity : Activity() {
    companion object {
        private var taskIcon: android.graphics.Bitmap? = null

        /** Jumlah layar aplikasi yang sedang terlihat; 0 = aplikasi di latar belakang (musik menu dijeda). */
        private var started = 0
    }

    /**
     * true (bawaan) = musik menu terus berjalan di layar ini. Layar yang memutar audio sendiri
     * (main, Sinkron, Editor) menjadikannya false: musik menu dijeda selama layar itu terbuka.
     */
    protected open fun wantsMenuMusic(): Boolean = true

    /** Tampilkan mini-player musik menu di pojok kanan atas layar ini. */
    protected open val showMusicBar: Boolean = true

    /** Ditaruh di sini supaya layar tertentu bisa memindahkannya / menyisakan ruang (lihat [MusicBar.W_DP]). */
    protected var musicBar: MusicBar? = null

    private var langAtCreate = 0
    private val touchTracker by lazy { UiTouchTracker(this) }

    /** Suara tombol + efek tekan untuk semua tombol di layar ini (lihat [UiTouchTracker]). */
    protected open val uiFeedback: Boolean = true

    /** Dicek tiap sentuhan: GameActivity mematikan efek tombol saat bermain supaya tidak membebani input. */
    protected open fun wantsUiFeedback(): Boolean = true

    /** GameActivity mematikan ini supaya permainan tidak ter-restart saat bahasa diganti dari menu jeda. */
    protected open val recreateOnLanguageChange: Boolean = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Settings.init(this)
        Accounts.init(this)
        langAtCreate = Settings.language
        UiSound.init(this)
        hideBars()
        applyTaskIcon()
    }

    /** Ikon + warna kartu aplikasi di layar "terbaru / saran" (recents) disamakan dengan ikon Osu! Mania. */
    @Suppress("DEPRECATION")
    private fun applyTaskIcon() {
        try {
            if (taskIcon == null) {
                val id = resources.getIdentifier("ic_launcher", "mipmap", packageName)
                if (id != 0) taskIcon = BitmapFactory.decodeResource(resources, id)
            }
            setTaskDescription(ActivityManager.TaskDescription("NovaLane", taskIcon, 0xFF111136.toInt()))
        } catch (e: Exception) {
        }
    }

    override fun onPostCreate(b: Bundle?) {
        super.onPostCreate(b)
        // layar sudah dipasang (setContentView) oleh kelas turunan: tambahkan mini-player di atasnya
        if (showMusicBar && musicBar == null && !isFinishing) {
            try {
                val bar = MusicBar(this)
                addContentView(
                    bar,
                    android.widget.FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).also {
                        it.topMargin = Ui.dp(this, 4)
                        it.rightMargin = Ui.dp(this, 10)
                    }
                )
                musicBar = bar
            } catch (e: Exception) {
            }
        }
    }

    override fun onStart() {
        super.onStart()
        started++
    }

    override fun onStop() {
        super.onStop()
        started = (started - 1).coerceAtLeast(0)
        if (started == 0) MenuMusic.pause() // aplikasi ke latar belakang
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (uiFeedback && wantsUiFeedback()) {
            try {
                touchTracker.onTouch(window.decorView, ev)
            } catch (e: Exception) {
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    // Transisi antar layar: masuk memudar + membesar sedikit, keluar memudar (tetap landscape, tanpa gerak miring).
    @Suppress("DEPRECATION")
    override fun startActivityForResult(intent: Intent, requestCode: Int, options: Bundle?) {
        super.startActivityForResult(intent, requestCode, options)
        transition(true)
    }

    override fun finish() {
        super.finish()
        transition(false)
    }

    @Suppress("DEPRECATION")
    private fun transition(forward: Boolean) {
        try {
            val inId = resources.getIdentifier(if (forward) "ui_in" else "ui_hold", "anim", packageName)
            val outId = resources.getIdentifier(if (forward) "ui_hold" else "ui_out", "anim", packageName)
            if (inId != 0 && outId != 0) overridePendingTransition(inId, outId)
        } catch (e: Exception) {
        }
    }

    override fun onResume() {
        super.onResume()
        if (recreateOnLanguageChange && Settings.language != langAtCreate) {
            langAtCreate = Settings.language
            recreate()
        }
        if (wantsMenuMusic()) MenuMusic.ensure(this) else MenuMusic.pause()
        musicBar?.refresh()
    }

    @Suppress("DEPRECATION")
    protected fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }
}

/** Tampilkan dialog tanpa memunculkan tombol navigasi HP (tetap imersif). */
@Suppress("DEPRECATION")
fun Dialog.showImmersive(a: Activity) {
    val w = window
    if (w == null) {
        show()
        return
    }
    w.setFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
    show()
    w.decorView.systemUiVisibility = a.window.decorView.systemUiVisibility
    w.clearFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
}
